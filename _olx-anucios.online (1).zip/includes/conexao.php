<?php
error_reporting(0);
$db_host = ('localhost');
$db_user = ('u181997302_123');
$db_pass = ('171@Brabo');
$db_name = ('u181997302_123');
$conexao = mysqli_connect($db_host, $db_user, $db_pass, $db_name) or die ('banco de dados invalido, tente novamente!');

$sql = "SELECT * FROM configs";
$query = mysqli_query($conexao, $sql);
$config = mysqli_fetch_assoc($query);


?>