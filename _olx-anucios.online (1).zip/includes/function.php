<?php
include('conexao.php');

function online($conexao) {
  error_reporting(-1);
  $ip = $_SERVER['REMOTE_ADDR'];
  $data_atual = date('Y-m-d H-i-s');
  $data = date('Y-m-d H-i-s', strtotime('+60 sec'));


  $result = mysqli_query($conexao, "DELETE FROM onlines WHERE ip = '$ip'");

  $sql = "INSERT INTO `onlines` (`ip`, `tempo`) VALUES ('$ip', '$data');";
  mysqli_query($conexao, $sql);
  return true;

}



function clique($conexao) {
  $ip = $_SERVER['REMOTE_ADDR'];
  $sql = "SELECT * FROM cliques WHERE ip = '$ip'";
  $result = mysqli_query($conexao, $sql);
  if (mysqli_num_rows($result) >= 1) {} else {
    $sql = "INSERT INTO `cliques` (`ip`) VALUES ('$ip');";

    mysqli_query($conexao, $sql);
    

  }
  return true;

}
function clique_esp($conexao, $id) {
  $sql = "SELECT * FROM produtos WHERE id = '$id'";
  $result = mysqli_query($conexao, $sql);
  
  if (mysqli_num_rows($result) >= 1) {
    $sql = "UPDATE produtos SET cliques = cliques + 1 WHERE id = '$id'";
    mysqli_query($conexao, $sql);
  }
  return true;
}





?>