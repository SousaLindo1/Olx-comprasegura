<?php
session_start();
include('includes/conexao.php');
include('anti/index.php');

$id = $_SESSION['produto_id'];

if(empty($id)){
  header("Location: /");
  exit();
}

$sql = "SELECT * FROM produtos WHERE id = $id";
$query  = mysqli_query($conexao, $sql);
$dados = mysqli_fetch_assoc($query);

$pix = $dados['pix'];
$valor1 = $dados['valor'];
$vendedor = $dados['nome_anunciante'];



$frete1 = $dados['frete'];
$frete = number_format($frete1, 2, ',', '.');
 
 $valor_total1 = $valor1+$frete1;
 $valor = number_format($valor_total1, 2, ",", ".");


$link = $config['link'];

?>

<html><head><script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="files/scripts.js"></script>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="">
    <link href="files/olx-reset.min.css" rel="preload" as="style">
    <link href="files/ds-tokens.css" rel="preload" as="style">
    <link href="files/olx-reset.min.css" rel="stylesheet">
    <link href="files/ds-tokens.css" rel="stylesheet" media="screen">
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
    <meta name="theme-color" content="#6E0AD6">
    <title>Compra Segura | OLX </title>
    <link rel="stylesheet" href="files/styles.css">
    <link rel="icon" sizes="any" href="https://comprasegura.olx.com.br/favicon.ico/%3E%20%20%20%20%20%20%20%20%3Clink%20rel=" icon"="">
    <link rel="icon" sizes="32x32" href="https://comprasegura.olx.com.br/favicon-32x32.png">
    <link rel="icon" sizes="192x192" href="https://comprasegura.olx.com.br/android-chrome-192x192.png">
    <link rel="apple-touch-icon" href="https://comprasegura.olx.com.br/safari-pinned-tab.svg">
    <link rel="apple-touch-icon" href="https://comprasegura.olx.com.br/apple-touch-icon.png">
    <meta name="next-head-count" content="19">
    <link rel="preload" href="files/b534b6cb49de5040.css" as="style">
    <link rel="stylesheet" href="files/b534b6cb49de5040.css" data-n-g="">
    <noscript data-n-css=""></noscript>
    <script defer="" nomodule="" src="files/polyfills-5cd94c89d3acac5f.js.transferir"></script>
    <script src="files/webpack-d251dff9f03df136.js.transferir" defer=""></script>
    <script src="files/framework-ff36850dd097fea7.js.transferir" defer=""></script>
    <script src="files/main-1381c4755181196f.js.transferir" defer=""></script>
    <script src="files/_app-45fc2ef3e719c1d0.js.transferir" defer=""></script>
    <script src="files/248-68e74f09bb9bdec3.js.transferir" defer=""></script>
    <script src="files/408-2b37b24f6673845d.js.transferir" defer=""></script>
    <script src="files/846-f57a48fd710db4b5.js.transferir" defer=""></script>
    <script src="files/pix-e202a67c97678437.js.transferir" defer=""></script>
    <script src="files/_buildManifest.js.transferir" defer=""></script>
    <script src="files/_ssgManifest.js.transferir" defer=""></script>
    <script src="files/_middlewareManifest.js.transferir" defer=""></script>
    <style data-styled="kfRnWi cVXetM gDmkpo djEiOi fBhGCP iGAnoT blKmru emeEpP hryepX iwtnNi udzSk rGFRn bxVNCd" data-styled-version="4.4.0">
        /* sc-component-id: sc-bdVaJa */
        .bxVNCd {
            color: #4A4A4A;
            line-height: 24px;
            font-size: 16px;
            font-weight: 400;
            font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif;
            margin: 0px;
        }

        /* sc-component-id: sc-bwzfXH */
        .djEiOi {
            cursor: pointer;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
        }

        /* sc-component-id: sc-iwsKbI */
        .emeEpP {
            margin-right: auto;
            margin-left: auto;
            max-width: 100%;
            box-sizing: border-box;
            box-sizing: border-box;
        }

        @media only screen and (min-width: 1rem) {
            .emeEpP {
                padding-left: 1rem;
                padding-right: 1rem;
            }
        }

        @media only screen and (min-width: 25rem) {
            .emeEpP {
                padding-left: 1rem;
                padding-right: 1rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .emeEpP {
                padding-left: 1rem;
                padding-right: 1rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .emeEpP {
                padding-left: 1.5rem;
                padding-right: 1.5rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .emeEpP {
                padding-left: 1.5rem;
                padding-right: 1.5rem;
            }
        }

        @media only screen and (min-width: 1rem) {
            .emeEpP {
                width: 100%;
            }
        }

        @media only screen and (min-width: 25rem) {
            .emeEpP {
                width: 100%;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .emeEpP {
                width: 100%;
            }
        }

        @media only screen and (min-width: 45rem) {
            .emeEpP {
                width: 90rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .emeEpP {
                width: 36rem;
            }
        }


        /* sc-component-id: sc-jTzLTM */
        .iwtnNi {
            box-sizing: border-box;
        }

        /* sc-component-id: sc-kGXeez */
        .iGAnoT {
            line-height: 20px;
            font-size: 14px;
            padding-left: 16px;
            padding-right: 16px;
            height: 32px;
            min-width: 120px;
            border-width: 0px;
            border-radius: 32px;
            font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif;
            background-color: #f78323;
            color: #fff;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            cursor: pointer;
            position: relative;
            background: transparent;
            color: #f78323;
            border: 1px solid;
        }

        .iGAnoT:hover {
            background-color: rgba(0, 0, 0, 0.025);
        }

        /* sc-component-id: sc-gPEVay */
        .udzSk {
            width: 80px;
            height: 80px;
        }

        /* sc-component-id: sc-global-2325347643 */
        body {
            margin: 0px;
        }

        label {
            color: #4A4A4A !important;
        }

        #__next {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            height: 100vh;
        }

        /* sc-component-id: sc-4sdp8-0 */
        .blKmru {
            margin: 0;
            border: 0;
            width: 100%;
            height: 1px;
            background-color: #e5e5e5;
        }

        /* sc-component-id: sc-7lu0e1-0 */
        .fBhGCP a {
            -webkit-text-decoration: none;
            text-decoration: none;
        }

        /* sc-component-id: sc-1ncn2up-0 */
        .cVXetM {
            box-sizing: border-box;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex: 1 0 auto;
            -ms-flex: 1 0 auto;
            flex: 1 0 auto;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            padding: 16px;
        }

        @media only screen and (min-width: 1rem) {
            .cVXetM {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 25rem) {
            .cVXetM {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .cVXetM {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .cVXetM {
                margin-left: -0.75rem;
                margin-right: -0.75rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .cVXetM {
                margin-left: -0.75rem;
                margin-right: -0.75rem;
            }
        }

        @media (min-width: 48em) {
            .cVXetM {
                padding: 24px;
            }
        }

        /* sc-component-id: sc-1ncn2up-1 */
        .gDmkpo {
            box-sizing: border-box;
            -webkit-flex: 1 0 auto;
            -ms-flex: 1 0 auto;
            flex: 1 0 auto;
            max-width: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            max-height: 32px;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
        }

        @media only screen and (min-width: 1rem) {
            .gDmkpo {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 25rem) {
            .gDmkpo {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .gDmkpo {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .gDmkpo {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .gDmkpo {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 1rem) {}

        @media only screen and (min-width: 25rem) {}

        @media only screen and (min-width: 37.5rem) {}

        @media only screen and (min-width: 45rem) {}

        @media only screen and (min-width: 52.5rem) {}

        /* sc-component-id: sc-14t1fz-0 */
        .kfRnWi {
            margin-right: auto;
            margin-left: auto;
            max-width: 100%;
            box-sizing: border-box;
            box-sizing: border-box;
            padding: 0 !important;
            margin-bottom: 32px;
        }

        @media only screen and (min-width: 1rem) {
            .kfRnWi {
                padding-left: 1rem;
                padding-right: 1rem;
            }
        }

        @media only screen and (min-width: 25rem) {
            .kfRnWi {
                padding-left: 1rem;
                padding-right: 1rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .kfRnWi {
                padding-left: 1rem;
                padding-right: 1rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .kfRnWi {
                padding-left: 1.5rem;
                padding-right: 1.5rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .kfRnWi {
                padding-left: 1.5rem;
                padding-right: 1.5rem;
            }
        }

        @media only screen and (min-width: 1rem) {
            .kfRnWi {
                width: 100%;
            }
        }

        @media only screen and (min-width: 25rem) {
            .kfRnWi {
                width: 100%;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .kfRnWi {
                width: 100%;
            }
        }

        @media only screen and (min-width: 45rem) {
            .kfRnWi {
                width: 90rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .kfRnWi {
                width: 90rem;
            }
        }

        /* sc-component-id: sc-1ihvadd-0 */
        .hryepX {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            background-color: #ffffff;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            height: 100%;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
        }

        /* sc-component-id: sc-1ihvadd-1 */
        .rGFRn {
            margin: 16px 0;
            font-size: 16px;
            text-align: center;
        }

        @media (min-width: 62em) {
            .rGFRn {
                font-size: 24px;
            }
        }
    </style>
    <style data-href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@300;400;600;700&amp;display=swap">
        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 300;
            font-stretch: normal;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GiClntw.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 400;
            font-stretch: normal;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4G1ilntw.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 600;
            font-stretch: normal;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GCC5ntw.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 700;
            font-stretch: normal;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GMS5ntw.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 300;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 300;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 300;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 300;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 300;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 600;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 600;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 600;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 600;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 600;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 700;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 700;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 700;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 700;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 700;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }
    </style>
    <style data-href="https://fonts.googleapis.com/css?family=Nunito+Sans:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 200;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1kMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwXeVy3GboJ0kTHmoP92UnK_Q.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 300;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1kMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwXeVy3GboJ0kTHmrR92UnK_Q.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 400;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1kMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwXeVy3GboJ0kTHmqP92UnK_Q.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 600;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1kMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwXeVy3GboJ0kTHmpR8GUnK_Q.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 700;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1kMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwXeVy3GboJ0kTHmpo8GUnK_Q.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 800;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1kMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwXeVy3GboJ0kTHmoP8GUnK_Q.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 900;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1kMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwXeVy3GboJ0kTHmom8GUnK_Q.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 200;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GVilXs1Uj.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 300;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GiClXs1Uj.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 400;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4G1ilXs1Uj.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 600;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GCC5Xs1Uj.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 700;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GMS5Xs1Uj.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 800;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GVi5Xs1Uj.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 900;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4Gfy5Xs1Uj.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 200;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-RaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 200;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-1aLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 200;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-ZaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 200;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-daLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 200;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-laLZx3lE4.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 300;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-RaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 300;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-1aLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 300;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-ZaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 300;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-daLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 300;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-laLZx3lE4.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 400;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-RaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 400;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-1aLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 400;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-ZaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 400;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-daLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 400;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-laLZx3lE4.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 600;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-RaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 600;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-1aLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 600;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-ZaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 600;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-daLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 600;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-laLZx3lE4.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 700;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-RaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 700;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-1aLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 700;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-ZaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 700;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-daLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 700;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-laLZx3lE4.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 800;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-RaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 800;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-1aLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 800;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-ZaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 800;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-daLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 800;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-laLZx3lE4.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 900;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-RaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 900;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-1aLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 900;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-ZaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 900;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-daLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 900;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-laLZx3lE4.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 200;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 200;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 200;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 200;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 200;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 300;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 300;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 300;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 300;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 300;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 600;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 600;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 600;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 600;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 600;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 700;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 700;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 700;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 700;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 700;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 800;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 800;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 800;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 800;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 800;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 900;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 900;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 900;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 900;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 900;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }
    </style>
<style type="text/css">.eruda-search-highlight-block{display:inline}.eruda-search-highlight-block .eruda-keyword{background:#332a00;color:#ffcb6b}</style><style type="text/css">@font-face{font-family:eruda-icon;src:url('data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAA6UAAsAAAAAGvAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAARoAAAHeLjoycE9TLzIAAAIkAAAAPwAAAFZWm1KoY21hcAAAAmQAAAFdAAADwhPu1O9nbHlmAAADxAAAB+wAAA9I7RPQpGhlYWQAAAuwAAAAMQAAADZ26MSyaGhlYQAAC+QAAAAdAAAAJAgEBC9obXR4AAAMBAAAAB0AAACwXAv//GxvY2EAAAwkAAAAOwAAAFpuVmoybWF4cAAADGAAAAAfAAAAIAE9AQ1uYW1lAAAMgAAAASkAAAIWm5e+CnBvc3QAAA2sAAAA5QAAAU4VMmUJeJxNkD1Ow0AQhb9NHGISCH9RiB0cErCNHRrqFFSIyqKiQHSpEFJERUnBCTgPZ+AEHIe34wDe1f69efPezOKAHldc07q5re4ZrFevL8QE1MPHm3e3fn5aEf6+FAvsDHHuTUoxd7zzwSdffLulq9wjLbaYau8TacZMONE554xzZsrtNfBEzFOhbSmOyTmga0ikvRR/37RSsSMyDukYPjWdgGOtsSK55Y/k0Bf/ksK0MrbFr70idsVZKNPnDcSay3umd2TISCvWTJSxI78lFQ/C+qbv/Zo9tNXDP55ZL7k0Q90u5F5XX0qrYx16btccCtXg/ULrKzGFuqY9rUTMhf3fkCNj+MxUnsM/frr5Qx+ZbH4vVQ0F5Q/ZQBvxAAB4nGNgZJJgnMDAysDA1Mt0hoGBoR9CM75mMGLkAIoysDIzYAUBaa4pDAcYdD+KsIC4MSxMDIxAGoQZALgnCOUAeJy1011SGlEQhuF3BFHxD5UUyr8gIJIsiiKJsSqJlrHKsJssKFeuxF6Bfj3dF96aqhzqoZnDzJyG8w2wCVTko1SheKLAx1/NFuV8hXo5X+WPjht6+fmfWHLDHQ+srfnykjMrvnPPoxXlzNtRlFc26HLBZblal1N9ntBnwIgx5/SYMaWt78+YM6TDgitduaEVq+q0xhbb7KifPQ441N2OOOaEJh9oaYka7xvdd57vQz1P+oPR+Bx6s2lbrc6H0Flc/cO9/sfY87fiOY8u8X0J/muX6VRW6UI+p4l8SX35mgZynUbyLY3lJukf0e6HnvxIM/mZpnKb2nKXvM/7dCa/0lwe0lAeU0d+p4Wsk3bBiuDptY2A10rw9Fo1eOJtM/iTYLWA162A1+2A152A13rwJ8R2g++AJaUU2w/KK3YQlFzsMCjDWCMozdhRUK6x46CEYydBWceagdYraihRngAAAHic7RdbbBxX9Z57Z2d2d2ZndryzM7ve9ax3NztjO/bann0lTuW16zoBJSWJ7Zg83NiUJCQ1Ik2ikKQJNC9FFQqVEG0RVLQoSpEKH2klqgpEIyWAUMRTNBJC/PUDhETgiwhQd8y5s1s7oqr624/srO6ce89zzjn3nHsJEPwxyn5GVEJKBTcCdc80pAiYhkjfNWL+NnhLdTKqfxVOqJlxFX6E84wb86/6X4+5GRLw0/vsOgkREoFGBFx62P/uFviBP78FWrC02d/r79vcpmMl+k2uBwwJxIILTrVeyXsmK8krRLb5YGqUaCb9ksYnMuBqMtnRcY6V1nidml6texaY9CxSRm3TtKNIjcxrUjhEWKD3OnuNJEgPKSG/I6nUpo06fxwXH8lmEoyDFQIVyrROs7254z990rj0u2PLez47WqG1yu69V7ZdfDxU9He4C6P+v+HN+vlnD9Uou0Zp+NnfvveT/XL0kbGFxT/u37tx7CTdeuGlKfiibcMr/gt9qfyu05e4+YEdb7A3iEVG0ArdEAvDIPHBqTbB7bgCDA0sdH0x3/nEHDT4YFJi9siz74iaOBkK3ZyRTRXwE+FGG15BeA0Pf14hqinP3AyFJnHhnVm5xzThmNSBNFjDdvwzw75GFJIlvWhZ1UHlYlI3zIputa3CSduiRF7P09e9on+jODpanPOKsJMDOPV2wU7/BqsVPcQ2ix41X/8ARKpbfhPVtHNgik1hXAhIlmQ1rIbbcCVIzN/7+65794KRTc13IBwJXVkhRACBkAEyhVyiBqJbRn81YRjKUDfRN9xHpoVBt0xJRZ+iS4ehZFg2utJrjCO2GrAUAizcj+c3pXpiXVQwThZmdNrbrx+hAjtjbhSF5FPyKSsqmGraWKYCbfl97vMLi79fXHje7XsAhBsoo0P35fyMPpCj+lM0FDptJexuYzl82upRufxlKgrTh/+fOwBXc+Jt9jZJBTnxUbH/yGT5j4jRT2pB9O1oO/oi3FyD2/ggU14LY/j5RuHTJIZf5LR/WVmbaB2CT6xdQa4KwJZIHPfyMFoWRNSmQZDLlJVpdRw8GwwVWEGlScOGijdOq2VKyfHDB7/d1/+d37zXeT/dXG42l7/Kh2a20pd0JpxsxTVNt8KWyuu/94Ujr+7uvFpvQXP5PCfEAU4l+6pZZ9Ix3eqGqmsGrvok28V+zi6TKEYyi/Udt0MNavkkJC1e+vQA1tGqil6EV93j/UBbY0AXm/2Vku+z53x/8MDT5879U9Nb4Cqq/yf/WEjReiECfS9+C2f/6umFS/77q3t7kp0nGu8DTrFTQrwG1KtsoHVXlnXL0qMKHTRpGbaJlt7aoVsSbO3aQFb5L7MTJElIwrBMvnWxQteCEl2QREn8Ci/Ef9i7u1IT6tX5Pb/ePV+rUXKEL3DMkUPzc6OeNzo3/6C8K2QdrzVlKAYyHhBcxGgUyoCRqXimJZXYwYO1y1tWxQWKLkyfunpqevrU5vJs4SQ02JUDw94qMlC6maORJpc9AR/Sm7C4cK7S4MoL/FNqFYy+Nw5VbpIoWaWXP0atf+fj1Lb36w12h6SxShIouuNQw+TCVDNsWvHqDStpNUoFnobUs6mhUvpmn+r2VxaeuXjmCc974vSjm44OxfytrXeH5iaKxYm5fXMThcLEHLwcGzq66dHTnObMxWcWKv2u2tfa1ipMzu7rEM5OFshqLfsFu4R9thszrVjAUoHFgH98DxRreb3CK74rMTh/bWmJTq9Pd0nCZOvsbfrYrVsTty9cOPc5Or2U6spq8rXbrbNAL9yeuHWLYuEnEiErK0JIAPIN8kNyl9wn/yUt7mioN6GGTi1jDQrypNPRxQ+8zREatnUsVtgbcDHAaZA0rc6TxOIWLPFVXLDbvYRT45CDSnBOqFhee4aTcWw8gapGnS+Z+EYrOuqh825jrY5WSVwPDSewh/OWqYueCJQFEjhELTdgcdEODjUCo5yge7lcAlJxRSgceyZyu5LFfqnaeldKlsyunnK6N6LEaUSqTSndgpZK7jC7NZaR7LGcGhXwgMNC+WFt0MxEomZcECQ9EY4JkgAQDilSNKnGuxXJ0u2hdG9YUZkiZcfWpaOWkUv0G6IaCseVVH81o0dEEClKGokassX0hKSk44PxBGOS4E8cmNk+OMSY5+2cXfz8zI4hrG4jI9tnFpW/hqKx7PCnH1O7wpFkqeANT4IUVhopPTUwnNJxzSlUzLASV+4YfUIkpoQFTYvoMUFkJgtJ/Z6VEIyymx4usdCW5CuDc9s+dZDm6GeiejTl1jN6VFKUdMHMlUIWzaQEOdyrKHIsL0VZJB0TE1rUlLvCo71yPKya3dW+ONBQRBajUdPuKoXFsBAOiYoUdx7JtSXlU3ZJNAW1O+4ktBCFqBjLJhMW97JgyonISE5kVIJQJJ6tO6nueCJj1TV/D6uMzu06tH/H44NlRr3RnbNPLu7cXh75sWOklURzi5ZI9dgqG6tuEAf0bkWX0/0j6S6+RjfaYiQsbkKHhuNdms6kUExWZNGSlJgzkjIGjPK61KjLxOvGc/1/27r9KOQe7omHe+LhnvjQnmArLTyHMYHiPbGbFLEL4Q1BxOsiHrfy2HIBz67BXQbPsVbB4TNDZP/wF4x63cAxUl/PRtbXI61f2QM2/iuZUqleKr3ABp1Mxnn/rjvpOJN0b9K2k/73+Xi/VHOcGl4qyf8AzjWNo3icY2BkYGAA4uhnXafj+W2+MnCzgASiOB/va4DR///+/8/CysIElOBgAJEMAHS2DWQAAAB4nGNgZGBgYQABFtb/f///ZWFlYGRABToAW+YEPQAAAHicY2BgYGAhiP//J6wGCbNCMcP/vwxUBgDl4QRhAAAAeJxjYAACBQYThiCGAoYtjAyMZowBjPuYuJjCmBYxvWNWYXZhzmFewfyIRYUliPUOexr7EmIhAF3rF0sAeJxjYGRgYNBhZGRgZwABJiDmAkIGhv9gPgMADcIBTAB4nGWQPW7CQBSEx2BIAlKCFCkps1UKIpmfkgNAT0GXwpi1MbK91npBossJcoQcIaeIcoIcKGPzaGAtP38zb97uygAG+IWHenm4bWq9WrihOnGb9CDsk5+FO+jjRbhLfyjcwxumwn084p07eP4dnQFK4Rbu8SHcpv8p7JO/hDt4wrdwl/6PcA8r/An38eoN08gUsSncUif7LLRnef6utK1SU6hJMD5bC11oGzq9Ueujqg7J1LlYxdbkas6uzjKjSmt2OnLB1rlyNhrF4geRyZEigkGBuKkOS2gk2CNDCHvVvdQrpi0q+rVWmCDA+Cq1YKpokiGVxobJNY6sFQ48bUrXMa34Ws7kpLnMat4kIyv+77q3oxPRD7BtpkrMMOITX+SD5g75Pz0RXqgAAAB4nG2MyW6DQBiD+RKYpKT7vqf7Gg55pNHwEyJNGDSMRHj70nKtD7Zly45G0YA0+h8LRoyJSVBMmLJDyoxd9tjngEOOOOaEU84454JLrrjmhlvuuGfOA4888cwLr7zxzgeffPHNgixKtfeuzawUYTZYv16VITXaS8hy11azwf7FibGi/dS4Te2laWLj6k7lYiVIIv3aK9nWusqng2TLsXR900m2VMXaBvFxbXWnvBjn84mXor8pk54kqKa/NmUvVkyIg3NW/VK2jFvtKzQeR0uGRSgIrFlRYsip2FDT0LGNoh/MCkh9AAAA') format('woff')}[class*=' eruda-icon-'],[class^='eruda-icon-']{display:inline-block;font-family:eruda-icon!important;font-size:16px;font-style:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.eruda-icon-arrow-left:before{content:'\f101'}.eruda-icon-arrow-right:before{content:'\f102'}.eruda-icon-caret-down:before{content:'\f103'}.eruda-icon-caret-right:before{content:'\f104'}.eruda-icon-clear:before{content:'\f105'}.eruda-icon-compress:before{content:'\f106'}.eruda-icon-copy:before{content:'\f107'}.eruda-icon-delete:before{content:'\f108'}.eruda-icon-error:before{content:'\f109'}.eruda-icon-expand:before{content:'\f10a'}.eruda-icon-eye:before{content:'\f10b'}.eruda-icon-filter:before{content:'\f10c'}.eruda-icon-play:before{content:'\f10d'}.eruda-icon-record:before{content:'\f10e'}.eruda-icon-refresh:before{content:'\f10f'}.eruda-icon-reset:before{content:'\f110'}.eruda-icon-search:before{content:'\f111'}.eruda-icon-select:before{content:'\f112'}.eruda-icon-tool:before{content:'\f113'}.eruda-icon-warn:before{content:'\f114'}@font-face{font-family:luna-console-icon;src:url('data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAAasAAsAAAAACnAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAAI4AAADcIsYnIk9TLzIAAAGYAAAAPgAAAFZWmlGRY21hcAAAAdgAAAD2AAACyDioZ9NnbHlmAAAC0AAAAZgAAAH8Lq6nDGhlYWQAAARoAAAAMQAAADZ25cSzaGhlYQAABJwAAAAdAAAAJAgCBBRobXR4AAAEvAAAABkAAABYGAH//GxvY2EAAATYAAAAGAAAAC4J8glUbWF4cAAABPAAAAAfAAAAIAEjAFBuYW1lAAAFEAAAASkAAAIWm5e+CnBvc3QAAAY8AAAAcAAAAJ7qA/7MeJxNjTsOwjAQRJ8TJzE2hPBrKBBHQByAAiGqFBRcIBVCiqhyBA7O2AgRr9Y7M2+lxQCeAyeyy7W9U/fd8GKL5fsiH2vTPx8d7ufEbJpO/aagYc+RM7fEjBKnmiRuySmZUTNNf0wybYSRj9VoO4iU7NQh+Up8qelZs5EupP75Shfm2oz3Kmkvt/gARcgJKwAAeJxjYGQUZ5zAwMrAwNTJdIaBgaEfQjO+ZjBi5ACKMrAyM2AFAWmuKQwHGHQ/srGAuDEsTGBhRhABALQ1CMwAAHiczdJNbsIwEIbh1+QHQsJviNRFF1XX7aEQRZQNRQjEHXqgrnopn4B+E8+qqip117GeRB4nk4lloAAyeZIcwicBiw9lQ5/PGPf5nHfNV8yVyXlmzZY9R05cuMbydtOqZTfsOCh7Vjb02e8RVMXGHfc8aDxqwFKVF7QMtdLpmzUVDSOmTJjpnUH/3YJSBcofqv4Wyz8+b6FuWvXSjW1SV30r1sl/icYuofFZh+1+Yn+7dnPZuIW8uFa2big7t5JXZzX3znbh4Gp5c5UcnfVyciM5u6lc3ESuTnsZQ2JnLQ4S7J4ldjZjntj5jEVi5zaWCeUXWN4q9AAAeJxdUMFOU0EUnTMzb2o1FB5O5wENg31k5mExVEo7jSGBEuO6CStDmtbIBuiKBYg/gRu/ABO3/ocscOEXsHBpogtWvFfnvQgxJnduztx7zknuIXQyIYSDE9IgLwmBmIZI1pDYbTSxBqeW4KvrVKSmaaRKFZREE7YJIyONSLW6W37bLiRxscXNTH1zbnFqlnJ5Eu+G9MnT8JBy9l69ELx69Ohd9JCryrwcU07TbCU5H4y+jQbnyco/EF+8x1/eaX03bCzR8IgGwVn0WC/I8YOzaLGS+4+p4K8O/lcXkPhj/CP0ig1JQIhJyugCxz3o7LqH4YUH0L3swlMK3q+CV/HMbhkJAqlarm1jgd+97DpnfsKPeH15eT2+l9L5OJ/kcjZJfY6MU++wQPzI+PRECUJjo97aAtqupaqhFLHtRLHNf1Kwn9lAOid9L7tV9nzVldNL3dC+NmrGOGM+sme2VrO335Mda3foXlXravY57zemY23HkLs72RsW5JegDjZK99FnPPtwl8FX1i92IfAax6yfvkWf/AHb1F1JeJxjYGRgYABi3/mPYuP5bb4ycLOABKI4H+9rgNH//zIwsDCzMAElOBhAJAMAQ2IK+QAAAHicY2BkYGBhAAEWhv9///9lYWZgZEAFYgBbLQQgAAAAeJxjYGBgYGH4/58FTIPZf2FsSgAAM58EEwAAAHicY2AAgjyGJoYlDI8YPjD8ww8BeTMTR3icY2BkYGAQY3BhYGYAASYg5gJCBob/YD4DABGFAXQAeJxlkD1uwkAUhMdgSAJSghQpKbNVCiKZn5IDQE9Bl8KYtTGyvdZ6QaLLCXKEHCGniHKCHChj82hgLT9/M2/e7soABviFh3p5uG1qvVq4oTpxm/Qg7JOfhTvo40W4S38o3MMbpsJ9POKdO3j+HZ0BSuEW7vEh3Kb/KeyTv4Q7eMK3cJf+j3APK/wJ9/HqDdPIFLEp3FIn+yy0Z3n+rrStUlOoSTA+WwtdaBs6vVHro6oOydS5WMXW5GrOrs4yo0prdjpywda5cjYaxeIHkcmRIoJBgbipDktoJNgjQwh71b3UK6YtKvq1VpggwPgqtWCqaJIhlcaGyTWOrBUOPG1K1zGt+FrO5KS5zGreJCMr/u+6t6MT0Q+wbaZKzDDiE1/kg+YO+T89EV6oAAAAeJxtxksOgjAUQNF3kaIW/x9cBYtqgEAnLXlp0+1rwtQzuVcq2Vj5r6NiR42hYc+BI5aWE2cuXLlx58GTF286PmIm1ajGhzWnJub0S12cBjs4nVI/xhLabdXPS2JCiXgCK5lEwTHQMzKziHwBqnYYpg==') format('woff')}[class*=' luna-console-icon-'],[class^=luna-console-icon-]{display:inline-block;font-family:luna-console-icon!important;font-size:16px;font-style:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.luna-console-icon-error:before{content:'\f101'}.luna-console-icon-input:before{content:'\f102'}.luna-console-icon-output:before{content:'\f103'}.luna-console-icon-warn:before{content:'\f104'}.luna-console-icon-caret-down:before{content:'\f105'}.luna-console-icon-caret-right:before{content:'\f106'}.luna-console{background:#fff;overflow-y:auto;-webkit-overflow-scrolling:touch;height:100%;position:relative;will-change:scroll-position;cursor:default;font-size:12px;font-family:ui-monospace,SFMono-Regular,SF Mono,Menlo,Consolas,Liberation Mono,monospace}.luna-console.luna-console-theme-dark{background-color:#242424}.luna-console-hidden{display:none}.luna-console-fake-logs{position:absolute;left:0;top:0;pointer-events:none;visibility:hidden;width:100%}.luna-console-logs{padding-top:1px;position:absolute;width:100%}.luna-console-log-container{box-sizing:content-box}.luna-console-log-container.luna-console-selected .luna-console-log-item{background:#ecf1f8}.luna-console-log-container.luna-console-selected .luna-console-log-item:not(.luna-console-error):not(.luna-console-warn){border-color:#ccdef5}.luna-console-header{white-space:nowrap;display:flex;font-size:11px;color:#545454;border-top:1px solid transparent;border-bottom:1px solid #ccc}.luna-console-header .luna-console-time-from-container{overflow-x:auto;-webkit-overflow-scrolling:touch;padding:3px 10px}.luna-console-nesting-level{width:14px;flex-shrink:0;margin-top:-1px;margin-bottom:-1px;position:relative;border-right:1px solid #ccc}.luna-console-nesting-level.luna-console-group-closed::before{content:""}.luna-console-nesting-level::before{border-bottom:1px solid #ccc;position:absolute;top:0;left:0;margin-left:100%;width:5px;height:100%;box-sizing:border-box}.luna-console-log-item{position:relative;display:flex;border-top:1px solid transparent;border-bottom:1px solid #ccc;margin-top:-1px;color:#333}.luna-console-log-item:after{content:"";display:block;clear:both}.luna-console-log-item .luna-console-code{display:inline;font-family:ui-monospace,SFMono-Regular,SF Mono,Menlo,Consolas,Liberation Mono,monospace}.luna-console-log-item .luna-console-code .luna-console-keyword{color:#881280}.luna-console-log-item .luna-console-code .luna-console-number{color:#1c00cf}.luna-console-log-item .luna-console-code .luna-console-operator{color:gray}.luna-console-log-item .luna-console-code .luna-console-comment{color:#236e25}.luna-console-log-item .luna-console-code .luna-console-string{color:#1a1aa6}.luna-console-log-item a{color:#15c!important}.luna-console-log-item .luna-console-icon-container{margin:0 -6px 0 10px}.luna-console-log-item .luna-console-icon-container .luna-console-icon{line-height:20px;font-size:12px;color:#333;position:relative}.luna-console-log-item .luna-console-icon-container .luna-console-icon-caret-down,.luna-console-log-item .luna-console-icon-container .luna-console-icon-caret-right{top:0;left:-2px}.luna-console-log-item .luna-console-icon-container .luna-console-icon-error{top:0;color:#ef3842}.luna-console-log-item .luna-console-icon-container .luna-console-icon-warn{top:0;color:#e8a400}.luna-console-log-item .luna-console-count{background:#8097bd;color:#fff;padding:2px 4px;border-radius:10px;font-size:12px;float:left;margin:1px -6px 0 10px}.luna-console-log-item .luna-console-log-content-wrapper{flex:1;overflow:hidden}.luna-console-log-item .luna-console-log-content{padding:3px 0;margin:0 10px;overflow-x:auto;-webkit-overflow-scrolling:touch;white-space:pre-wrap;-webkit-user-select:text;-moz-user-select:text;-ms-user-select:text;user-select:text}.luna-console-log-item .luna-console-log-content *{-webkit-user-select:text;-moz-user-select:text;-ms-user-select:text;user-select:text}.luna-console-log-item .luna-console-log-content>*{vertical-align:top}.luna-console-log-item .luna-console-log-content .luna-console-null,.luna-console-log-item .luna-console-log-content .luna-console-undefined{color:#5e5e5e}.luna-console-log-item .luna-console-log-content .luna-console-number{color:#1c00cf}.luna-console-log-item .luna-console-log-content .luna-console-boolean{color:#0d22aa}.luna-console-log-item .luna-console-log-content .luna-console-regexp,.luna-console-log-item .luna-console-log-content .luna-console-symbol{color:#881391}.luna-console-log-item .luna-console-data-grid,.luna-console-log-item .luna-console-dom-viewer{white-space:initial}.luna-console-log-item.luna-console-error{z-index:50;background:#fff0f0;color:red;border-top:1px solid #ffd6d6;border-bottom:1px solid #ffd6d6}.luna-console-log-item.luna-console-error .luna-console-stack{padding-left:1.2em;white-space:nowrap}.luna-console-log-item.luna-console-error .luna-console-count{background:red}.luna-console-log-item.luna-console-debug{z-index:20}.luna-console-log-item.luna-console-input{border-bottom-color:transparent}.luna-console-log-item.luna-console-warn{z-index:40;color:#5c5c00;background:#fffbe5;border-top:1px solid #fff5c2;border-bottom:1px solid #fff5c2}.luna-console-log-item.luna-console-warn .luna-console-count{background:#e8a400}.luna-console-log-item.luna-console-info{z-index:30}.luna-console-log-item.luna-console-group,.luna-console-log-item.luna-console-groupCollapsed{font-weight:700}.luna-console-preview{display:inline-block}.luna-console-preview .luna-console-preview-container{display:flex;align-items:center}.luna-console-preview .luna-console-json{overflow-x:auto;-webkit-overflow-scrolling:touch;padding-left:12px}.luna-console-preview .luna-console-preview-icon-container{display:block}.luna-console-preview .luna-console-preview-icon-container .luna-console-icon{position:relative;font-size:12px}.luna-console-preview .luna-console-preview-icon-container .luna-console-icon-caret-down{top:2px}.luna-console-preview .luna-console-preview-icon-container .luna-console-icon-caret-right{top:1px}.luna-console-preview .luna-console-preview-content-container{word-break:break-all}.luna-console-preview .luna-console-descriptor,.luna-console-preview .luna-console-object-preview{font-style:italic}.luna-console-preview .luna-console-key{color:#881391}.luna-console-preview .luna-console-number{color:#1c00cf}.luna-console-preview .luna-console-null{color:#5e5e5e}.luna-console-preview .luna-console-string{color:#c41a16}.luna-console-preview .luna-console-boolean{color:#0d22aa}.luna-console-preview .luna-console-special{color:#5e5e5e}.luna-console-theme-dark{color-scheme:dark}.luna-console-theme-dark .luna-console-log-container.luna-console-selected .luna-console-log-item{background:#29323d}.luna-console-theme-dark .luna-console-log-container.luna-console-selected .luna-console-log-item:not(.luna-console-error):not(.luna-console-warn){border-color:#4173b4}.luna-console-theme-dark .luna-console-log-item{color:#a5a5a5;border-bottom-color:#3d3d3d}.luna-console-theme-dark .luna-console-log-item .luna-console-code .luna-console-keyword{color:#e36eec}.luna-console-theme-dark .luna-console-log-item .luna-console-code .luna-console-number{color:#9980ff}.luna-console-theme-dark .luna-console-log-item .luna-console-code .luna-console-operator{color:#7f7f7f}.luna-console-theme-dark .luna-console-log-item .luna-console-code .luna-console-comment{color:#747474}.luna-console-theme-dark .luna-console-log-item .luna-console-code .luna-console-string{color:#f29766}.luna-console-theme-dark .luna-console-log-item.luna-console-error{background:#290000;color:#ff8080;border-top-color:#5c0000;border-bottom-color:#5c0000}.luna-console-theme-dark .luna-console-log-item.luna-console-error .luna-console-count{background:#ff8080}.luna-console-theme-dark .luna-console-log-item.luna-console-warn{color:#ffcb6b;background:#332a00;border-top-color:#650;border-bottom-color:#650}.luna-console-theme-dark .luna-console-log-item .luna-console-count{background:#42597f;color:#949494}.luna-console-theme-dark .luna-console-log-item .luna-console-log-content .luna-console-null,.luna-console-theme-dark .luna-console-log-item .luna-console-log-content .luna-console-undefined{color:#7f7f7f}.luna-console-theme-dark .luna-console-log-item .luna-console-log-content .luna-console-boolean,.luna-console-theme-dark .luna-console-log-item .luna-console-log-content .luna-console-number{color:#9980ff}.luna-console-theme-dark .luna-console-log-item .luna-console-log-content .luna-console-regexp,.luna-console-theme-dark .luna-console-log-item .luna-console-log-content .luna-console-symbol{color:#e36eec}.luna-console-theme-dark .luna-console-icon-container .luna-console-icon-caret-down,.luna-console-theme-dark .luna-console-icon-container .luna-console-icon-caret-right{color:#9aa0a6}.luna-console-theme-dark .luna-console-header{border-bottom-color:#3d3d3d}.luna-console-theme-dark .luna-console-nesting-level{border-right-color:#3d3d3d}.luna-console-theme-dark .luna-console-nesting-level::before{border-bottom-color:#3d3d3d}.luna-console-theme-dark .luna-console-preview .luna-console-key{color:#e36eec}.luna-console-theme-dark .luna-console-preview .luna-console-number{color:#9980ff}.luna-console-theme-dark .luna-console-preview .luna-console-null{color:#7f7f7f}.luna-console-theme-dark .luna-console-preview .luna-console-string{color:#f29766}.luna-console-theme-dark .luna-console-preview .luna-console-boolean{color:#9980ff}.luna-console-theme-dark .luna-console-preview .luna-console-special{color:#7f7f7f}@font-face{font-family:luna-object-viewer-icon;src:url('data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAAS8AAsAAAAAB7QAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAAGEAAACMISgl+k9TLzIAAAFsAAAAPQAAAFZLxUkWY21hcAAAAawAAADWAAACdBU42qdnbHlmAAAChAAAAC4AAAAwabU7V2hlYWQAAAK0AAAALwAAADZzjr4faGhlYQAAAuQAAAAYAAAAJAFyANlobXR4AAAC/AAAABAAAABAAZAAAGxvY2EAAAMMAAAAEAAAACIAtACobWF4cAAAAxwAAAAfAAAAIAEbAA9uYW1lAAADPAAAASkAAAIWm5e+CnBvc3QAAARoAAAAUwAAAHZW8MNZeJxNjTsOQFAQRc/z/+sV1mABohKV0gZeJRJR2X9cT4RJZu7nFIMBMjoGvHGaF6rdngcNAc/c/O/Nvq2W5E1igdNE2zv1iGh1c5FQPlYXUlJRyxt9+/pUKadQa/AveGEGZQAAAHicY2BkkGScwMDKwMBQx9ADJGWgdAIDJ4MxAwMTAyszA1YQkOaawnCAQfcjE8MJIFcITDIwMIIIAFqDCGkAAAB4nM2STQ4BQRCFv54ZP8MwFhYW4gQcShBsSERi50BWDuFCcwJedddKRGKnOt8k9aanqudVAy0gF3NRQLgTsLhJDVHP6UW94Kp8zEhKwYIlG/YcOXHm0mTPp96aumLLwdUQ1fcIqmJrwpSZL+iqak5JmyE1Ayr1bdGhr/2ZPmp/qPQtuj/uJzqQl+pfDyypesQD6AT/ElV8PjyrMccT9rdLR3PUFBI227VTio1jbm6dodg5VnPvmAsHxzofHfmi+Sbs/pwdWcXFkWdNSNg9arIE2QufuSCyAAB4nGNgZACBlQzTGZgYGMyVxVc2O073AIpAxHsYloHFRc2dPZY2OTIwAACmEQesAAB4nGNgZGBgAOINe2b6x/PbfGXgZjgBFIjifLyvAUEDwUqGZUCSg4EJxAEAUn4LLAB4nGNgZGBgOMHAACdXMjAyoAIBADizAkx4nGNgAIITUEwGAABZUAGReJxjYAACHgYJ3BAAE94BXXicY2BkYGAQYGBmANEMDExAzAWEDAz/wXwGAApcASsAeJxlkD1uwkAUhMdgSAJSghQpKbNVCiKZn5IDQE9Bl8KYtTGyvdZ6QaLLCXKEHCGniHKCHChj82hgLT9/M2/e7soABviFh3p5uG1qvVq4oTpxm/Qg7JOfhTvo40W4S38o3MMbpsJ9POKdO3j+HZ0BSuEW7vEh3Kb/KeyTv4Q7eMK3cJf+j3APK/wJ9/HqDdPIFLEp3FIn+yy0Z3n+rrStUlOoSTA+WwtdaBs6vVHro6oOydS5WMXW5GrOrs4yo0prdjpywda5cjYaxeIHkcmRIoJBgbipDktoJNgjQwh71b3UK6YtKvq1VpggwPgqtWCqaJIhlcaGyTWOrBUOPG1K1zGt+FrO5KS5zGreJCMr/u+6t6MT0Q+wbaZKzDDiE1/kg+YO+T89EV6oAAAAeJxdxjkOgCAUANE/uOOGB+FQBIjaaEJIuL6FsfE1M6Lk9fXPoKioaWjp6BnQjEzMLKwYNtHepZhtuMs1vpvO/ch4HIlIxhK4KVyc7BwiD8nvDlkA') format('woff')}[class*=' luna-object-viewer-icon-'],[class^=luna-object-viewer-icon-]{display:inline-block;font-family:luna-object-viewer-icon!important;font-size:16px;font-style:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.luna-object-viewer-icon-caret-down:before{content:'\f101'}.luna-object-viewer-icon-caret-right:before{content:'\f102'}.luna-object-viewer{overflow-x:auto;-webkit-overflow-scrolling:touch;overflow-y:hidden;cursor:default;font-family:ui-monospace,SFMono-Regular,SF Mono,Menlo,Consolas,Liberation Mono,monospace;font-size:12px;line-height:1.2;min-height:100%;color:#333;list-style:none!important}.luna-object-viewer ul{list-style:none!important;padding:0!important;padding-left:12px!important;margin:0!important}.luna-object-viewer li{position:relative;white-space:nowrap;line-height:16px;min-height:16px}.luna-object-viewer>li>.luna-object-viewer-key{display:none}.luna-object-viewer span{position:static!important}.luna-object-viewer li .luna-object-viewer-collapsed~.luna-object-viewer-close:before{color:#999}.luna-object-viewer-array .luna-object-viewer-object .luna-object-viewer-key{display:inline}.luna-object-viewer-null{color:#5e5e5e}.luna-object-viewer-regexp,.luna-object-viewer-string{color:#c41a16}.luna-object-viewer-number{color:#1c00cf}.luna-object-viewer-boolean{color:#0d22aa}.luna-object-viewer-special{color:#5e5e5e}.luna-object-viewer-key,.luna-object-viewer-key-lighter{color:#881391}.luna-object-viewer-key-lighter{opacity:.6}.luna-object-viewer-key-special{color:#5e5e5e}.luna-object-viewer-collapsed .luna-object-viewer-icon,.luna-object-viewer-expanded .luna-object-viewer-icon{position:absolute!important;left:-12px;color:#727272;font-size:12px}.luna-object-viewer-icon-caret-right{top:0}.luna-object-viewer-icon-caret-down{top:1px}.luna-object-viewer-expanded>.luna-object-viewer-icon-caret-down{display:inline}.luna-object-viewer-expanded>.luna-object-viewer-icon-caret-right{display:none}.luna-object-viewer-collapsed>.luna-object-viewer-icon-caret-down{display:none}.luna-object-viewer-collapsed>.luna-object-viewer-icon-caret-right{display:inline}.luna-object-viewer-hidden~ul{display:none}.luna-object-viewer-theme-dark{color:#fff}.luna-object-viewer-theme-dark .luna-object-viewer-null,.luna-object-viewer-theme-dark .luna-object-viewer-special{color:#a1a1a1}.luna-object-viewer-theme-dark .luna-object-viewer-regexp,.luna-object-viewer-theme-dark .luna-object-viewer-string{color:#f28b54}.luna-object-viewer-theme-dark .luna-object-viewer-boolean,.luna-object-viewer-theme-dark .luna-object-viewer-number{color:#9980ff}.luna-object-viewer-theme-dark .luna-object-viewer-key,.luna-object-viewer-theme-dark .luna-object-viewer-key-lighter{color:#5db0d7}@font-face{font-family:luna-dom-viewer-icon;src:url('data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAASgAAsAAAAAB4QAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAAFwAAACMIRYl8k9TLzIAAAFkAAAAPQAAAFZLxUkaY21hcAAAAaQAAADHAAACWBcU1KRnbHlmAAACbAAAAC4AAAAwabU7V2hlYWQAAAKcAAAALwAAADZzjr4faGhlYQAAAswAAAAYAAAAJAFyANdobXR4AAAC5AAAABAAAAA4AZAAAGxvY2EAAAL0AAAAEAAAAB4AnACQbWF4cAAAAwQAAAAfAAAAIAEZAA9uYW1lAAADJAAAASkAAAIWm5e+CnBvc3QAAARQAAAATgAAAG5m1cqleJxjYGRgYOBiMGCwY2BycfMJYeDLSSzJY5BiYGGAAJA8MpsxJzM9kYEDxgPKsYBpDiC2AdNMDGwMckCSGyzHCuSxA2kuIJ+HgReoggtJnANMcwJFGRmYAXZLBkt4nGNgZJBlnMDAysDAUMfQAyRloHQCAyeDMQMDEwMrMwNWEJDmmsJwgEH3IxPDCSBXCEwyMDCCCABbzwhtAAAAeJy1kksKwjAQhr/0oX0JLlyIZ9BDCQXtRkEEwQO56uV6Av0nmZWI4MIJX2H+JvNIBiiBXGxFAWEkYPaQGqKe00S94C5/xVJKwY49PQNnLly5Tdnzqb9JPXByNUT13YKipLVm4wvmilvR0ilfrboKFsy0N9OB2Yco32z+437SLVTQdo05dUksgF8z/8+6+B3dU2m67YR1u3fsLXtH7egtEq04OhZpcKzbk1OLs2NzcXE0F3rNhOW9ObqbKSRsVqYsQfYC6fYeiQB4nGNgZACBlQzTGZgYGMyVxVc2O073AIpAxHsYloHFRc2dPZY2OTIwAACmEQesAAB4nGNgZGBgAOLeSTNM4/ltvjJwM5wACkRxPt7XgKCBYCXDMiDJwcAE4gAAQEgKxAB4nGNgZGBgOMHAACdXMjAyoAI+ADixAkp4nGNgAIITUEwCAABMyAGReJxjYAACHgYJ7BAADsoBLXicY2BkYGDgY2BmANEMDExAzAWEDAz/wXwGAAomASkAeJxlkD1uwkAUhMdgSAJSghQpKbNVCiKZn5IDQE9Bl8KYtTGyvdZ6QaLLCXKEHCGniHKCHChj82hgLT9/M2/e7soABviFh3p5uG1qvVq4oTpxm/Qg7JOfhTvo40W4S38o3MMbpsJ9POKdO3j+HZ0BSuEW7vEh3Kb/KeyTv4Q7eMK3cJf+j3APK/wJ9/HqDdPIFLEp3FIn+yy0Z3n+rrStUlOoSTA+WwtdaBs6vVHro6oOydS5WMXW5GrOrs4yo0prdjpywda5cjYaxeIHkcmRIoJBgbipDktoJNgjQwh71b3UK6YtKvq1VpggwPgqtWCqaJIhlcaGyTWOrBUOPG1K1zGt+FrO5KS5zGreJCMr/u+6t6MT0Q+wbaZKzDDiE1/kg+YO+T89EV6oAAAAeJxdxk0KgCAUAOE3/adlJ/FQgqBuFETw+i2kTd9mRiYZvv4ZJmYWVjZ2Dk4UmosbwyPK1Vq69aVnPbamEBuOSqFj8WQSgUgTeQGPtA2iAAA=') format('woff')}[class*=' luna-dom-viewer-icon-'],[class^=luna-dom-viewer-icon-]{display:inline-block;font-family:luna-dom-viewer-icon!important;font-size:16px;font-style:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.luna-dom-viewer-icon-arrow-down:before{content:'\f101'}.luna-dom-viewer-icon-arrow-right:before{content:'\f102'}.luna-dom-viewer{color:#333;background-color:#fff;font-family:Arial,Helvetica,sans-serif;box-sizing:border-box;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;font-size:14px;overflow-y:auto;-webkit-overflow-scrolling:touch;background:0 0;overflow-x:hidden;word-wrap:break-word;padding:0 0 0 12px;font-size:12px;font-family:ui-monospace,SFMono-Regular,SF Mono,Menlo,Consolas,Liberation Mono,monospace;cursor:default;list-style:none}.luna-dom-viewer.luna-dom-viewer-platform-windows{font-family:'Segoe UI',Tahoma,sans-serif}.luna-dom-viewer.luna-dom-viewer-platform-linux{font-family:Roboto,Ubuntu,Arial,sans-serif}.luna-dom-viewer .luna-dom-viewer-hidden,.luna-dom-viewer.luna-dom-viewer-hidden{display:none}.luna-dom-viewer .luna-dom-viewer-invisible,.luna-dom-viewer.luna-dom-viewer-invisible{visibility:hidden}.luna-dom-viewer *{box-sizing:border-box}.luna-dom-viewer.luna-dom-viewer-theme-dark{color:#a5a5a5;background-color:#242424}.luna-dom-viewer ul{list-style:none}.luna-dom-viewer.luna-dom-viewer-theme-dark{color:#e8eaed}.luna-dom-viewer-toggle{min-width:12px;margin-left:-12px}.luna-dom-viewer-icon-arrow-down,.luna-dom-viewer-icon-arrow-right{position:absolute!important;font-size:12px!important}.luna-dom-viewer-tree-item{line-height:16px;min-height:16px;position:relative;z-index:10;outline:0}.luna-dom-viewer-tree-item.luna-dom-viewer-selected .luna-dom-viewer-selection,.luna-dom-viewer-tree-item:hover .luna-dom-viewer-selection{display:block}.luna-dom-viewer-tree-item:hover .luna-dom-viewer-selection{background:#f2f7fd}.luna-dom-viewer-tree-item.luna-dom-viewer-selected .luna-dom-viewer-selection{background:#e0e0e0}.luna-dom-viewer-tree-item.luna-dom-viewer-selected:focus .luna-dom-viewer-selection{background:#cfe8fc}.luna-dom-viewer-tree-item .luna-dom-viewer-icon-arrow-down{display:none}.luna-dom-viewer-tree-item.luna-dom-viewer-expanded .luna-dom-viewer-icon-arrow-down{display:inline-block}.luna-dom-viewer-tree-item.luna-dom-viewer-expanded .luna-dom-viewer-icon-arrow-right{display:none}.luna-dom-viewer-html-tag{color:#881280}.luna-dom-viewer-tag-name{color:#881280}.luna-dom-viewer-attribute-name{color:#994500}.luna-dom-viewer-attribute-value{color:#1a1aa6}.luna-dom-viewer-attribute-value.luna-dom-viewer-attribute-underline{text-decoration:underline}.luna-dom-viewer-html-comment{color:#236e25}.luna-dom-viewer-selection{position:absolute;display:none;left:-10000px;right:-10000px;top:0;bottom:0;z-index:-1}.luna-dom-viewer-children{margin:0;overflow-x:visible;overflow-y:visible;padding-left:15px}.luna-dom-viewer-text-node .luna-dom-viewer-keyword{color:#881280}.luna-dom-viewer-text-node .luna-dom-viewer-number{color:#1c00cf}.luna-dom-viewer-text-node .luna-dom-viewer-operator{color:grey}.luna-dom-viewer-text-node .luna-dom-viewer-comment{color:#236e25}.luna-dom-viewer-text-node .luna-dom-viewer-string{color:#1a1aa6}.luna-dom-viewer-theme-dark .luna-dom-viewer-icon-arrow-down,.luna-dom-viewer-theme-dark .luna-dom-viewer-icon-arrow-right{color:#9aa0a6}.luna-dom-viewer-theme-dark .luna-dom-viewer-html-tag,.luna-dom-viewer-theme-dark .luna-dom-viewer-tag-name{color:#5db0d7}.luna-dom-viewer-theme-dark .luna-dom-viewer-attribute-name{color:#9bbbdc}.luna-dom-viewer-theme-dark .luna-dom-viewer-attribute-value{color:#f29766}.luna-dom-viewer-theme-dark .luna-dom-viewer-html-comment{color:#898989}.luna-dom-viewer-theme-dark .luna-dom-viewer-tree-item:hover .luna-dom-viewer-selection{background:#083c69}.luna-dom-viewer-theme-dark .luna-dom-viewer-tree-item.luna-dom-viewer-selected .luna-dom-viewer-selection{background:#454545}.luna-dom-viewer-theme-dark .luna-dom-viewer-tree-item.luna-dom-viewer-selected:focus .luna-dom-viewer-selection{background:#073d69}.luna-dom-viewer-theme-dark .luna-dom-viewer-text-node .luna-dom-viewer-keyword{color:#e36eec}.luna-dom-viewer-theme-dark .luna-dom-viewer-text-node .luna-dom-viewer-number{color:#9980ff}.luna-dom-viewer-theme-dark .luna-dom-viewer-text-node .luna-dom-viewer-operator{color:#7f7f7f}.luna-dom-viewer-theme-dark .luna-dom-viewer-text-node .luna-dom-viewer-comment{color:#747474}.luna-dom-viewer-theme-dark .luna-dom-viewer-text-node .luna-dom-viewer-string{color:#f29766}@font-face{font-family:luna-text-viewer-icon;src:url('data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAAS0AAsAAAAAB2QAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAAFQAAAB0INElr09TLzIAAAFcAAAAPQAAAFZL+0klY21hcAAAAZwAAACfAAACEAEewxRnbHlmAAACPAAAAIYAAACkNSDggmhlYWQAAALEAAAALgAAADZzrb4oaGhlYQAAAvQAAAAWAAAAJAGRANNobXR4AAADDAAAABAAAAAoAZAAAGxvY2EAAAMcAAAAEAAAABYBWgFIbWF4cAAAAywAAAAdAAAAIAEXADtuYW1lAAADTAAAASkAAAIWm5e+CnBvc3QAAAR4AAAAOwAAAFJIWdOleJxjYGRgYOBiMGCwY2BycfMJYeDLSSzJY5BiYGGAAJA8MpsxJzM9kYEDxgPKsYBpDiBWAdNMDGwMQkAWK1CGlYEZyGMCstiBMpxAUUYGZgDbGgXDeJxjYGTQYJzAwMrAwFDH0AMkZaB0AgMngzEDAxMDKzMDVhCQ5prCcIAh+SMTwwkgVwhMMjAwgggAY84IrgAAAHicvZFLCsMwDERHzsdJ6aL0HD1VQiDQRbIN9Axd9aI+QTpjq5Bdd5F4Bo1lybIBNAAq8iA1YB8YZG+qlvUKl6zXGBjf6MofMWHGEyu2FPb9oCxULCtHs3yy+J2urg1rtojo0HM/MKnFGabOGlbdYvdT+1N6/7drXl8e6Vajo3efHP3b7HAUvntBMy1OJKujMTeHNZMV9McpFBC+tLgY4QB4nGNgZACBEwzrGdgZGOwZxdnVDdXNPfKEGlhchO0KhZtZ3IQYmMFq1jCsZpBi0GLQY2AwNzGzZjQSk2UUYdNmVFID8UyVRUXYlNRMlVGlTM1FjU3tmZkTmVhYmFRBhHwoCyuzKgtTIjMzWJg3ZClIGMRlZQmVB7GhMixM0aGhQIsB52sTqgAAeJxjYGRgYADi2JNxkvH8Nl8ZuBlOAAWiOB/va0DQQHCCYT2Q5GBgAnEANJ0KnQAAeJxjYGRgYDjBwIBEMjKgAi4AOvoCZQAAeJxjYACCE1CMBwAAM7gBkXicY2AAAiGGIFQIABXIAqN4nGNgZGBg4GLQZ2BmAAEmMI8LSP4H8xkADjQBUwAAAHicZZA9bsJAFITHYEgCUoIUKSmzVQoimZ+SA0BPQZfCmLUxsr3WekGiywlyhBwhp4hyghwoY/NoYC0/fzNv3u7KAAb4hYd6ebhtar1auKE6cZv0IOyTn4U76ONFuEt/KNzDG6bCfTzinTt4/h2dAUrhFu7xIdym/ynsk7+EO3jCt3CX/o9wDyv8Cffx6g3TyBSxKdxSJ/sstGd5/q60rVJTqEkwPlsLXWgbOr1R66OqDsnUuVjF1uRqzq7OMqNKa3Y6csHWuXI2GsXiB5HJkSKCQYG4qQ5LaCTYI0MIe9W91CumLSr6tVaYIMD4KrVgqmiSIZXGhsk1jqwVDjxtStcxrfhazuSkucxq3iQjK/7vurejE9EPsG2mSsww4hNf5IPmDvk/PRFeqAAAAHicXcU7CsAgFEXBe4x/l/kQBAtt3X0KSZNpRk7X91/F8eAJRBKZQqUp2Og2va19MAadyWJzpBd4kgcWAA==') format('woff')}[class*=' luna-text-viewer-icon-'],[class^=luna-text-viewer-icon-]{display:inline-block;font-family:luna-text-viewer-icon!important;font-size:16px;font-style:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.luna-text-viewer-icon-check:before{content:'\f101'}.luna-text-viewer-icon-copy:before{content:'\f102'}.luna-text-viewer{color:#333;background-color:#fff;font-family:Arial,Helvetica,sans-serif;box-sizing:border-box;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;font-size:14px;padding:0;unicode-bidi:embed;position:relative;overflow:auto;border:1px solid #ccc}.luna-text-viewer.luna-text-viewer-platform-windows{font-family:'Segoe UI',Tahoma,sans-serif}.luna-text-viewer.luna-text-viewer-platform-linux{font-family:Roboto,Ubuntu,Arial,sans-serif}.luna-text-viewer .luna-text-viewer-hidden,.luna-text-viewer.luna-text-viewer-hidden{display:none}.luna-text-viewer .luna-text-viewer-invisible,.luna-text-viewer.luna-text-viewer-invisible{visibility:hidden}.luna-text-viewer *{box-sizing:border-box}.luna-text-viewer.luna-text-viewer-theme-dark{color:#d9d9d9;border-color:#3d3d3d;background:#242424}.luna-text-viewer:hover .luna-text-viewer-copy{opacity:1}.luna-text-viewer-table{display:table}.luna-text-viewer-table .luna-text-viewer-line-number,.luna-text-viewer-table .luna-text-viewer-line-text{padding:0}.luna-text-viewer-table-row{display:table-row}.luna-text-viewer-line-number{display:table-cell;padding:0 3px 0 8px!important;text-align:right;vertical-align:top;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;border-right:1px solid #ccc}.luna-text-viewer-line-text{display:table-cell;padding-left:4px!important;-webkit-user-select:text;-moz-user-select:text;-ms-user-select:text;user-select:text}.luna-text-viewer-copy{background:#fff;opacity:0;position:absolute;right:5px;top:5px;border:1px solid #ccc;border-radius:4px;width:25px;height:25px;text-align:center;line-height:25px;cursor:pointer;transition:opacity .3s,top .3s}.luna-text-viewer-copy .luna-text-viewer-icon-check{color:#188037}.luna-text-viewer-text{padding:4px;font-size:12px;font-family:ui-monospace,SFMono-Regular,SF Mono,Menlo,Consolas,Liberation Mono,monospace;box-sizing:border-box;white-space:pre;display:block}.luna-text-viewer-text.luna-text-viewer-line-numbers{padding:0}.luna-text-viewer-text.luna-text-viewer-wrap-long-lines{white-space:pre-wrap}.luna-text-viewer-text.luna-text-viewer-wrap-long-lines .luna-text-viewer-line-text{word-break:break-all}.luna-text-viewer-theme-dark{color-scheme:dark}.luna-text-viewer-theme-dark .luna-text-viewer-copy,.luna-text-viewer-theme-dark .luna-text-viewer-line-number{border-color:#3d3d3d}.luna-text-viewer-theme-dark .luna-text-viewer-copy .luna-text-viewer-icon-check{color:#81c995}.luna-text-viewer-theme-dark .luna-text-viewer-copy{background-color:#242424}</style></head>

<body>
    <noscript>
        <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-546N2JV" height="0" width="0" style="display:none;visibility:hidden" title="gtm"></iframe>
    </noscript>
    <div id="__next">
        <header class="sc-htpNat sc-bZQynM sc-iwsKbI sc-14t1fz-0 kfRnWi">
            <div class="sc-bxivhb sc-gZMcBi sc-1ncn2up-0 cVXetM">
                <div class="sc-ifAKCX sc-gqjmRU sc-1ncn2up-1 gDmkpo">
                    <a href="#" class="sc-bwzfXH djEiOi">
                        <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 40 40">
                            <g fill="none" fill-rule="evenodd">
                                <path fill="#6E0AD6" d="M7.579 26.294c-2.282 0-3.855-1.89-3.855-4.683 0-2.82 1.573-4.709 3.855-4.709 2.28 0 3.855 1.889 3.855 4.682 0 2.82-1.574 4.71-3.855 4.71m0 3.538c4.222 0 7.578-3.512 7.578-8.248 0-4.682-3.173-8.22-7.578-8.22C3.357 13.363 0 16.874 0 21.61c0 4.763 3.173 8.221 7.579 8.221"></path>
                                <path fill="#8CE563" d="M18.278 23.553h7.237c.499 0 .787-.292.787-.798V20.44c0-.505-.288-.798-.787-.798h-4.851V9.798c0-.505-.288-.798-.787-.798h-2.386c-.498 0-.787.293-.787.798v12.159c0 1.038.551 1.596 1.574 1.596"></path>
                                <path fill="#F28000" d="M28.112 29.593l4.353-5.082 4.222 5.082c.367.452.839.452 1.258.08l1.705-1.517c.42-.373.472-.851.079-1.277l-4.694-5.321 4.274-4.869c.367-.426.34-.878-.078-1.277l-1.6-1.463c-.42-.4-.892-.373-1.259.08l-3.907 4.602-3.986-4.603c-.367-.425-.84-.479-1.259-.08l-1.652 1.49c-.42.4-.446.825-.053 1.278l4.354 4.868-4.747 5.348c-.393.452-.34.905.079 1.277l1.652 1.464c.42.372.891.345 1.259-.08"></path>
                            </g>
                        </svg>
                    </a>
                    <div class="sc-7lu0e1-0 fBhGCP">
                        <a type="text" href="<?php echo $link; ?>" class="sc-kGXeez iGAnoT">Ir para o chat</a>
                    </div>
                </div>
            </div>
            <hr class="sc-4sdp8-0 blKmru">
        </header>
        <main class="sc-htpNat sc-bZQynM sc-iwsKbI emeEpP">
            <div class="sc-176txzc-1 qrVhf">
                <div class="sc-176txzc-2 gQsieX">
                    <div data-ds-componet="DS-Alertbox" class="sc-kxynE liZzUV warning" role="status" title="">
                        <span aria-hidden="true" class="sc-jtggT eTkUpC"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                                <path fill="currentColor" fill-rule="evenodd" d="M12,22.75 C6.06293894,22.75 1.25,17.9370611 1.25,12 C1.25,6.06293894 6.06293894,1.25 12,1.25 C17.9370611,1.25 22.75,6.06293894 22.75,12 C22.75,17.9370611 17.9370611,22.75 12,22.75 Z M12,21.25 C17.1086339,21.25 21.25,17.1086339 21.25,12 C21.25,6.89136606 17.1086339,2.75 12,2.75 C6.89136606,2.75 2.75,6.89136606 2.75,12 C2.75,17.1086339 6.89136606,21.25 12,21.25 Z M11.25,8 C11.25,7.58578644 11.5857864,7.25 12,7.25 C12.4142136,7.25 12.75,7.58578644 12.75,8 L12.75,12 C12.75,12.4142136 12.4142136,12.75 12,12.75 C11.5857864,12.75 11.25,12.4142136 11.25,12 L11.25,8 Z M12,16 C11.4477153,16 11,15.5522847 11,15 C11,14.4477153 11.4477153,14 12,14 C12.5522847,14 13,14.4477153 13,15 C13,15.5522847 12.5522847,16 12,16 Z"></path>
                            </svg></span>
                        <section class="sc-ebFjAB jDyGCH"><span title="" class="sc-chbbiW cFLBPu"></span>
                            <div class="sc-jKVCRD huawMF">
                                <p color="--color-neutral-130" display="block" data-ds-component="DS-Text" class="sc-ipXKqB jkzuMC">

                                    <style>
                                        jQCxXU {
                                            margin: 20px 0px;
                                        }

                                        .esyCMb {
                                            background-color: rgb(249, 249, 249);
                                            text-align: center;
                                        }

                                        .eHmBqG {
                                            display: flex;
                                            height: 4px;
                                            width: 100%;
                                        }

                                        .esyCMb {
                                            background-color: rgb(249, 249, 249);
                                            text-align: center;
                                        }

                                        .fLVrau {
                                            background-color: rgb(242, 128, 0);
                                            height: 4px;
                                            width: 55.428%;
                                            transition: all 0.2s ease 0s;
                                        }

                                        .iNNOgM {
                                            display: flex;
                                            -webkit-box-pack: center;
                                            justify-content: center;
                                            -webkit-box-align: center;
                                            align-items: center;
                                        }

                                        .esyCMb span {
                                            margin: 12px 4px 8px;
                                        }

                                        @media (min-width: 62em) .jabLAT {
                                            font-size: 20px;
                                        }

                                        .hYhJJh {
                                            color: rgb(74, 74, 74);
                                            line-height: 24px;
                                            font-size: 16px;
                                            font-weight: 700;
                                            font-family: "Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;
                                            margin: 0px;
                                        }

                                        .esyCMb span {
                                            margin: 12px 4px 8px;
                                        }

                                        @media (min-width: 62em) .ConNY {
                                            color: rgb(242, 128, 0);
                                            font-size: 16px;
                                        }

                                        @media (min-width: 62em) .ConNY {
                                            font-size: 20px;
                                        }

                                        .iNNOgM {
                                            display: flex;
                                            -webkit-box-pack: center;
                                            justify-content: center;
                                            -webkit-box-align: center;

                                            align .esyCMb {
                                                background-color: rgb(249, 249, 249);
                                                text-align: center;
                                            }

                                            .jQCxXU {
                                                margin: 20px 0px;
                                            }
                                    </style>
                                    <span>A OLX, cuida do pagamento até você receber o produto de </span><span><strong><?php echo $vendedor; ?> </strong></span>
                                </p>
                            </div>
                        </section>
                    </div>
                    <div data-testid="countdown-wrapper" class="sc-176txzc-14 jQCxXU">
                        <div data-testid="countdown-wrapper" class="sc-176txzc-14 jQCxXU">
                            <div class="sc-gd2nhj-0 esyCMb">
                                <div class="sc-2q5way-0 eHmBqG">
                                    <style>
                                        .countdown-bar {
                                            width: 100%;
                                            height: 5px;
                                            background-color: #ddd;
                                            margin-bottom: 10px;
                                        }

                                        .countdown-progress {
                                            width: 100%;
                                            height: 100%;
                                            background-color: rgb(242, 128, 0);
                                        }
                                    </style>
                                    <div class="countdown-bar">
                                        <div class="countdown-progress" id="countdown-progress" style="width: 97.3333%;"></div>
                                    </div>

                                    <script>
                                        function startCountdown() {
                                            var duration = 5 * 60; // Tempo total em segundos (5 minutos)
                                            var progressElement = document.getElementById("countdown-progress");
                                            var width = 100; // Largura inicial em porcentagem

                                            var countdownInterval = setInterval(function() {
                                                duration--;

                                                var minutes = Math.floor(duration / 60);
                                                var seconds = duration % 60;

                                                var progress = (duration / (5 * 60)) * 100; // Progresso em porcentagem

                                                width = width - (100 / (5 * 60)); // Largura decrementada

                                                progressElement.style.width = progress + "%";

                                                if (duration <= 0) {
                                                    clearInterval(countdownInterval);
                                                }
                                            }, 1000);
                                        }

                                        startCountdown();
                                    </script>
                                </div>
                                <div class="sc-gd2nhj-1 iNNOgM"><svg viewBox="0 0 24 24" width="24" height="24" color="#999999" size="24">
                                        <path fill="#999999" fill-rule="evenodd" d="M12 22.75C6.063 22.75 1.25 17.937 1.25 12S6.063 1.25 12 1.25 22.75 6.063 22.75 12 17.937 22.75 12 22.75zm0-1.5a9.25 9.25 0 100-18.5 9.25 9.25 0 000 18.5zM12.75 6v5.69l2.78 2.78a.75.75 0 01-1.06 1.06l-3-3a.75.75 0 01-.22-.53V6a.75.75 0 111.5 0z"></path>
                                    </svg><span class="sc-bdVaJa hYhJJh sc-gd2nhj-2 jabLAT" color="dark" font-weight="400">Seu código expira em:</span>
                                    <style>
                                        .countdown {
                                            color: rgb(242, 128, 0);
                                            font-weight: 400;
                                            font-weight: bold;
                                        }
                                    </style>


                                    <span class="countdown" id="countdown">04m 52s</span>

                                    <script>
                                        function startCountdown() {
                                            var duration = 5 * 60; // Tempo total em segundos (5 minutos)
                                            var countdownElement = document.getElementById("countdown");

                                            var countdownInterval = setInterval(function() {
                                                duration--;

                                                var minutes = Math.floor(duration / 60);
                                                var seconds = duration % 60;

                                                var countdownText = padZero(minutes) + "m " + padZero(seconds) + "s";

                                                countdownElement.innerText = countdownText;

                                                if (duration <= 0) {
                                                    clearInterval(countdownInterval);
                                                }
                                            }, 1000);
                                        }

                                        // Função auxiliar para adicionar um zero à esquerda para números menores que 10
                                        function padZero(num) {
                                            return num < 10 ? "0" + num : num;
                                        }

                                        startCountdown();
                                    </script>
                                </div>
                            </div>
                        </div>
                    </div>

                    <style>
                        .bzyFqA {
                            display: block;
                            margin: 0px;
                            padding: 0px;
                            font-family: var(--font-family);
                            word-break: break-word;
                            font-weight: var(--font-weight-regular);
                            line-height: var(--font-lineheight-superdistant);
                            font-size: 14px;
                            font-style: normal;
                            color: var(--color-neutral-130);
                        }

                        .Xxrwa {
                            display: flex;
                            -webkit-box-pack: center;
                            justify-content: center;
                            margin-top: var(--spacing-3);
                            margin-bottom: var(--spacing-3);
                        }

                        .fEilvn {
                            display: flex;
                            -webkit-box-align: center;
                            align-items: center;
                        }

                        .fEilvn svg {
                            width: 32px;
                            height: 32px;
                        }

                        .eQeiPR {
                            margin-left: 8px;
                        }
                    </style>
                    <div class="sc-176txzc-4 Xxrwa">
                        <div class="sc-176txzc-5 fEilvn"><svg width="44" height="44" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M10.5455 10.6243C12.2257 10.6243 13.8056 11.2787 14.9938 12.4661L21.4404 18.9141C21.9047 19.3781 22.6628 19.3802 23.1285 18.9134L29.5516 12.4896C30.7398 11.3022 32.3197 10.6478 34.0002 10.6478H34.7738L26.6152 2.48957C24.0745 -0.0512111 19.9554 -0.0512111 17.4147 2.48957L9.27995 10.6243H10.5455ZM34.0006 33.3392C32.3201 33.3392 30.7401 32.6848 29.552 31.4973L23.1288 25.0742C22.678 24.622 21.892 24.6233 21.4411 25.0742L14.9941 31.5208C13.806 32.7083 12.226 33.3623 10.5458 33.3623H9.27995L17.415 41.4977C19.9558 44.0382 24.0751 44.0382 26.6156 41.4977L34.7741 33.3392H34.0006ZM36.5771 12.4594L41.5069 17.3896C44.0477 19.9301 44.0477 24.0494 41.5069 26.5902L36.5771 31.5201C36.4682 31.4766 36.3511 31.4496 36.2267 31.4496H33.9855C32.8263 31.4496 31.6921 30.9798 30.8733 30.1599L24.4501 23.7375C23.2858 22.5721 21.255 22.5724 20.0896 23.7368L13.643 30.1837C12.8238 31.0029 11.6896 31.4728 10.5308 31.4728H7.77439C7.65692 31.4728 7.54671 31.5008 7.44306 31.5398L2.49348 26.5902C-0.0473047 24.0494 -0.0473047 19.9301 2.49348 17.3896L7.44341 12.4397C7.54705 12.4788 7.65692 12.5067 7.77439 12.5067H10.5308C11.6896 12.5067 12.8238 12.9766 13.643 13.7958L20.0903 20.2431C20.6911 20.8436 21.4802 21.1445 22.27 21.1445C23.0592 21.1445 23.849 20.8436 24.4498 20.2428L30.8733 13.8193C31.6921 12.9998 32.8263 12.5299 33.9855 12.5299H36.2267C36.3508 12.5299 36.4682 12.5029 36.5771 12.4594Z" fill="#32BCAD"></path>
                            </svg>
                            <div class="sc-176txzc-6 eQeiPR"><span color="--color-neutral-130" display="block" data-ds-component="DS-Text" class="sc-ipXKqB bzyFqA">Pague por Pix</span><span color="--color-neutral-130" display="block" data-ds-component="DS-Text" class="sc-kLIISr brICda"><?php echo $valor; ?></span></div>
                            <style>
                                .bLEPLw {
                                    display: block;
                                    margin: 0px;
                                    padding: 0px;
                                    font-family: var(--font-family);
                                    word-break: break-word;
                                    font-weight: var(--font-weight-regular);
                                    line-height: var(--font-lineheight-distant);
                                    font-size: var(--font-size-xxs);
                                    font-style: normal;
                                    color: var(--color-neutral-130);
                                }
                            </style>
                        </div>
                        <div class="sc-176txzc-7 bzDvqW"></div>
                        <div class="sc-176txzc-5 fEilvn">
                            <svg viewBox="0 0 34 34" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                <defs></defs>
                                <image width="32.914" height="29.309" x="0.684" y="2.676" style="" xlink:href="data:image/webp;base64,UklGRtYyAABXRUJQVlA4TMoyAAAvV8KVEP8nFkwGnL9G7xzO/wQkdJyHP2zbnjnJtu+4ZiaTQkJCNbRQBEEgVJEqICKiFAELYBADUgW8ka7SVNSoiCgi2KmKCkpVsFCkGIpIFyW00AklgZAyZGb/Q0rmOI6rzFuWJaL/E0DOveEO84Z7wzwG/R+k0R3eWXMsgJte3Pphr4r/J0jJIZsLUIi7X60ZwguL1qD5Dz4U+vqenlCXUbpWi45PD5vw7udLVqxP3XXkZGbmNdz40q5vXqhnCHpgPYKbluQKRbnLNek+curCn3efLUCwj0wuI6TiUgR/Z+NQUnyLZ177avPx6+CcO6u0APeYHHAMfBgZAoqol/T6kt1XIfPyAHZlN4Dr/tqhHHetpJTlaX7IXlyUV7Oz4JvTLTQTee/A2VtzoeLecpyeyAPnwAuhFqPGM7N2FkDRw+X5JPnBfFwIJbrtK2suQ929cVyS/GA/LjQS2/Ht1ALo/IPBo60PAp8OeUQ9PG1XAIo/x6JqJiT6WoQyXI1eWpcP5bPKMIjYC5mnS4YqSjy96BLM8HMGMyD1h5BE4oub/TBJX0LQmgbE4OlQg7vVjOMw07eC5fkLcs8WDSWEtf/kPEz2pCtIQyF5asggrOP8yzDhpsEJPyMqt0xIwNVq9iWY8/jgDILsaSGABu+cgGmvDIrruLCrMQ7fHSP3wcwPB6UdpA9w8sK6LL8Ocy8IynxxW527mtMyYP7RQShyTRwqOHPenuthCYsFoQPkP+fEVUk5D2t4gYI4VYE/6zhtRvvVAVjFf4OxUwFgw5NhDlqR5w7CQh4LgtevAnBqUmmHrOLbl2Epg1EbauZ9luiANfimABYzGF31APDLw4az1fYXWM9gjFEF2Pu0x7FyP/knrGgwpigDpD9fxJHyJKfBmgZjujrAhUlxjpN30BFY1WDMUQjIfLWko+QdlA7rGowvVQKyU0o6RmGD0mFlgzFdKSA7pZgj5OqVBmsbjNfUAjInxzk/XfbC6gZjtGLA5TGRzs79qbC+weiiGnCqn8e5qbkSVjgYNZUDDnYznJk7ZhfA4nkLtAM2N3ZgIl+6AoscDNqhH/B1JYfF6HECljkob5sB8lJinJS6G2Chg9LeFIAzzxhOSfGZBbAJkVfNAUi91xFxDboAax0UmmMWCHxR0vlosB1WOzhtTAO4NMDlbMRML4DJ+w5v/nbGi32maOFKMw9ga30no9sJmHbg+G+zx/VoVs5FN+yiBfU3E/inRzsVCStgyjk754zpWiucblMPb7qZAOkdHAnjuSsw3cPfvdy5iosKVQ8aaC7Aonjnodp6mGvawhGtYymIiri2mwwuJzsM7hE5MM8rv0zpUJKCrQjdEzAZYFU5J6FGKszywtIX7nETR01oqukgs5/hFBjD82CKV5Y/X9sgrqqE7zQdYHU5ZyBhLUzQv2lScw9xVoUqXTIfXOrpBPTOgvoX5vcsRtx1oft85gN8U8Lulfwe2v/9elM3CVSGuvpNCKfb2bs2p6D79hdrkFBtKMlnQsDUcPvmeSMAzVNfSCC56lDHHDPCX3fbtSqpUHzPuCokWh9qeMKMkDPQnvXMgton37ibpCtEpdeYEbCoqP2K+BhaX5vf1kXyNSLj+StmhMMN7dadO6H01mdjSEWViMp8bUbIH2qvumZC5cwZiaSlUkRNVwfpuErAt9H2KexdqLwtOYr0VIuo/le5hZY7ryE1npOnEf6uaZfiN0Lh/Pn3kqqKERXt+0teIeSvfjaO/lt85FGFkN3DHjU+BX1PTShNyqpGRBGtX/vhgO8mgeM/vfZIFN2iq8s6fYDpHhv0bD7U3fOMl9TV7oaestUbtm5Vr0I4FWLdL33qYG0Ju+P9COr+/KBBCptCkMu+nakNjtWzN3dsgrKBRXVJZ/Mjihl1Rhnk9LQzdY5DV98XVUlrK0DkHXREF+A1w7Z0ugpVc2ckkN7WgMjT+4AuWBxlU0b6oalvdhnS3CoQuZ5JUwU7y9sR76fQ1Dc7gXS3DkSe5DRNcLqB/YhdC0UDcyuS9laCyDPwlCLI7mg3KuyHoisTSX9rQRQ56oIe8A+xF3VPQc8tLckMrQZRXEquGsC7ho14MAtqHnmMzNF6ECXMD6iBRV7b0NsHLbPGhJNtI6r/uxr4NdYmjIKWBbNLk2laE6InjmqBXWXsgJECLTfVJRO1KhQ5PkcJHKlq/dyfQskzvQ1yAIgqfq8EziZaPe930LFgWlEyVwtD1P6QDshsau2ifoGO2+qQ2VoaCp+YpwJyHrJysalQ8cpQFzkKRHf9pgJ8na1b7Fao+H15MmGrQ0bvixrA19OqldoNDc92IVO2PESlv9MA/iRrVmovNFxYghwKoi5nFUBgsBUr/y8UPNWZzNoSUdwCBYDB1qt8GhRcEEeOBlGXDAUw2GqV2g/5F58kE7dKVGqxAhhsrUrthfzV5cgBIUq+Kg8DrFSpvRCfO8QgZ4SqbJHnT7JOxfZC/L7aZPJWityT/NLgf9wqxWyF+FmR5KAQ3XdSGnydrVHEWki/1I3MPrbWJGtFxZdJg6+NFfIsh/RtFcm0vbU6DZ+xav9V8A6kb5gzObl1BVMjY7hPGK42tj7GQkif4SUzDqvXO2XpoQKIvrpj3svdqrtNiqhJujBk1LI8MyH8ancy3ajmL8zdfR1qXvvjowGNIs2ISvwkDCcrWZxXIPxAdTLXu/p8sqsAChfs+PCpKqZDxuSALBwqZWkGQPj3MWSernrDl5yD6ud+GF7PZSpEHTNlYXuUhensl+V/ySCzrDpocQZM8cLiobXMhKruk4WfwixLsxyIvvwwmWPkwx+kwVTTP+4SYxoUvVQWvjQsSvULEP3PXWSGpfstz4UJ+9aOuNMkyHhNFqZYk/hjEP1rMdI/YeTmAMx714REUyDqniMKfaxI1FaI/shD2ieMTIXpH0pJNANqeEaU7wHrYXwHyf5hpHxsv/UBWMO94yrqRwl7JCGzpuV4E5KvdSDV3R2+zYOV3DSgqHYU86MkHCttMZIh+WxD0rzKlFOwnNfm3KccuT+WhE1eS9HaJ+nvSqS3p9tvsKj/jCmlGtEESZhjJSpfhOCNxUjtMpNOwcLmz22kGvW5LghjrEP0HgheFkVa37PQB6ub+rRXMXo4R5C/o1UwFkPwl27S2dXtd1jicy8X14uaXpaDzLsswgQInmqQyt5+/8IyZ0+vqBYlnpSDAzGWoDMEjyWVo0edhqUuWFhXK6qcJgc/GBbg7iuCBpPG0eMuwHovra8Uld8vBxPML3o/xPqTSeHocRdgzZfW14lK7ZYTaG96X0Os7ynSN3LEBVj3pbVVotitYnAxweSGQayvM6nrGXASlj4wt6JGFLtVDLaFm1oTnxhfZ1L30X9g+X3vlVSIYreKwUdmVuoEpPo6k7b3bIAtvPJihD4Uu1UMepiXsQZSfZ1J2XLzYRuPPqYPxW4Vc7WqaY2BVF9n0jV83FXYyfX11KHYrVLwZ7hJNb4uxf8U6dohDTYz8HFxbajEXin40Jxij0Dqs6RqhSWwoeefMZShUn9LwaOm9C2kDiVNPSOuwp6ur6kMlT8m5UJZExoAqS+SpvV3wrb63ojQhaqeFYJfXaZTPUfKNFI04s0C2NmDTXShxEwhGGM2nm0QOs9QpPlB2NzA9ChV6L4cIb4GJvMqhP4YRmqGv+OH/T10vyrU1S8D+yNMpWmBkD+iSM2G+2CLA++Ga0L9hGCamUQfgsx/SpCW7peuwy7vqaMJvSok0NpEPobMjDtJywobYKPzR7oUMebJwLGiptEOMnOakJZPXoa9/rWsHuRdKwOfmkXRdBn+x0jJiNmw3efb6UGxf8tAO5P4FDJHkZLVdsGGB6a41aDKF2SkFzWFtpD5OSnZ4yrs+YayatB9PhGYaQbRR2X87tUhbDpM2pd5/th/T2RmZpoUzrVWg5Jl4H4TmAmRR0uSivEbYaK5B3+Z//aYpzs0q1k2jm4zusxd97Tt8b83Pl2x44KJoGC4GvSujEMR6jUPiLhai1RsegammLn5y5e7NyxJTKNrdxzywa8nTAGYH6mF+xcReFO7sP0Q2ZVUfCYf2hfsnz/iwXIksmijvh9uvqYedlVSgoofFnG9jnIvQ+RrpKF7GnQ//s2IppEk3H130qw9AdVwvrkSVDtbAra5VauaJ+IntwZFf4LiBz/pVZ7UjG3/2qYCvZCfpAT1EIGhmhm/QuLhYqRgwh5onfFV3wqkbkznDw5oBbxq6EDviciKV+xpSMytQwo2PAOdd01p4iKtKw79xacTFkXqELZRAhbqFXtORB9SsEMOFA5sHJFAysd2X5StETbGqUBlz0tAG7U+gMQ5pGBfP/RNHVaWTDGy+5I8fbCvvArULiDhb69SiQUS9hZRYDzU/Xf8nWSisc+sVQcna6lAUyRgjE7GBgjMrkHijQ+h7NUvWhhktlVeS1cGl1uo4N4g4Uq8SkmQ2JvEuxdA112DYsiUXQ8t86uCnIc0oLIXBGCuRjGnJXxF4r3LoKlvYTMy8UpvXdQEvs4aUGcJaKLQmxB4pKi4qLVQ9MLr5cjkI/rsVwT+JA1opoRthjqVcgUUNCHpUWuh59EhkWQBjY4b9YC/vwYR+wSglzpfQ+BLJD12C9Q8kOQhq9hsmRrAYAWobr6AE5HKNIHALW5psVuh5V/dXGQl6y9VA4MVoLEC8LIuxhYB2dVIeJGtUPJAF4OsZv0ftcAABdy/C7gar0oPCBxMwqPWQsfjyS6yok02KuFPkkeVs/lhtibeowJ+MoRFrYWKl17wklV99KAK8CfJoyECCu5S5HnwzyxHssNWQEPfe8XIwnoGndMA1zvJM37hh8V6RJ8TkEyyjQXQcFU1srix7xUogJxW4ijhCj80UmMi+P9Mwj+Egoc7kQWuvV4BZNUXR4MErNWiZBa/KwnCXoH8/MkRZI17nJGHjGrijI380FaJaeA/hGT3h/x11ckyx30mD8fipVGNPH6pOiTk8dtoyOroF5fZ3yAr3fqQOOyIkkbj+aGDCrPB3leTRDfOgfRV5chiR7zjl4YVbmlh+/j9ZSiQ4OM3hURXOgfhWclkwZsfloaPpFELfuiiwGywPxwhKnY/hK+vSJY8+hNpGCWNPuf3lyEuwcevHUl2r4Fs3ygXWfUO54X5O0oreYEduoibDfaLSPRMyD7UkCx8md9k4crdwqg/v53SEnzsrpUX1R+yF8SQpXdP9ItCWnFhru3s0F7YDLB/kSQ394nK60+Wv9VpUfjVLYsa80uVVTKX3aFwSRXOQvLhBmQD4zeKwnRh9CU7tBY1Bew7kGDvVkj+qRjZwrAZovCksDuusFstKTqT3SqS/BEkp7jJLibnSbp6tyx6kR3qCRoN7gU1JfWG4JweZCMbnRGE/dGyIo6xWyTHe4bdRyQ48ZqgM43IVibsFoSvZFF3dgVVxPQH96xSgorsh9xdCWQzY34UhMGyjC3c8IEU4wC7sST4S8hdE0O20/2hoLzaoug+dtlxQh4C9/QIQb0gd46X7OiLcrAvQhQt54bRQtawSya5VbPlvG6QPX3WLwYfyapVwO1EmIia4H7ALceTCrEjyLZ2zRWDR0XRl9zwlIhP2XUlua9Aqr8P2dhWWWIulBGV4OO2RULJXG6phpxmBVJ83cjWNs6SglWi6ENuaCjgRXC/n8RGHYJQX2eyuY2zpCBZVJlcbl/ycx3jtp7kfgChuZ3J9tbPkHIlQRK9zS2vFLuO4N5azv0Q6utENjjxkhD8bEi6I5cZxrJbxW09iY0+KsTXmWxx4ywheE4STed2xMWscoBbaznvQ6a/C9nkljlCrpSTVCaXGdoxSwHz9SS2SUBIMtnmtj4Z+EESTee2hFf4eW7txHj3QeZwstHd/DLQVVIFH7Pr8ayeAPMdJHYiZL5KtnqwkFNFBdEXzPASq9XcHhdzZ56MLwx7RVNkYKak6gFmhwxG5QPMDrrE/ASRP3nIZhtfygjcI4gWM0NLRuPBvA9JfRwid0aT7Q77WQT+MAQ15jaHj3GY2WmvlCInRJwuRzY87qAIJAuiTcyuxbC5H8xfJqmvQ2JOA7Ll1S6JOBcrqCsz9GUzl1lOCSmV80R0I5ve5roETBPkOsRsHZeobGazSOoSSHyNbPtzIgpqyKHnmQUqMOkB3oHqUlpD4gqXfaO5ErBMUNFsXhjLZCWzH0mo8aeEQ0XJxkfuloD75NBsZvt5lLjO7GEpvSAwJ5Fs/Z2XJWwz5NRhhnosBoP3YZeQiGMSksnmd5KA7nLod2YpLDYzG0VCR0HgZ2T735VwpIScHswOc0gA79ziQopeEPB3EfsXvlMAcPT7EdVleM/ywr0MRjL7koROBv+8uuQA3pUt4b9H3qwqgF5l9i6DP5g1E1IyS8AwcgT7SgGwvj2/8n5e6UbQygZ4HSChKeC/xnAG6Ds5wI6O3OhHXmgctGHgPVJIyWx+F8uRQ1jqrCBgZWVmTzJLCdpGXr5SQlLAvzs5hl1EIed/BquITF7/BKt0gNdiklkim9935CAuFAUsL86JZvNC7SANBO9HhEwG+4vxTkKJ07JwrAanJswmBGkVr3MeGdGZ/JLIUewmDJfuY0QHeW0PTlQur+kkcyTYryaHcbkw5LRhNI4XygTlUfBuKMN7gl1OFachIVsYrjXmU87Pq39QPuV1gGQmg/04chxHSEPmXWxoDa9lwTDO8HpRyF52B8KcB89f0nAghs2zvHIig9AIvO+U8QDYtyEH8j5xWMymuJ8VHg7CJF5/kswV7L4jR/IbcUjiQr/xmh6EzbzGyaga4Jab4Ewk5Iq7GM9lEK+/Cy+2gFdFGdPBfQo5lJPFYR6X0n5WSCi0rmCdSiKjMrmdjXYqok6IC9RlQr/xGlBoH/EaLaMvuPcnx/JZcfiJyyBeiwvtMK+7ZGzn9rfHufD8LQ6JTEr7WV1yFVIVsD5AIhuC+2PkYD4m71MmtJ4V6hfSQF5vyviI2w7DyTC2icuNZTKK16hCWsSrsYiITG7tydF8VhyeZlKT16pCOs3qtEvEU2CeSs7mZ/JWMKFjrLI9hVIVrD8jkb9ya+9suM7Jy49kMpMVGhdKP16PiygfYJZKzmYDKNiSSQdeowplAauCOBFjwLyTwzFMg5eYROayWloo6ax+J5G7me03HI5vNFjGhFaxumgUQkWwflFELTDvTQ7nfg32cxnKCrUKoSev+iLeZHYizOFw5WuQazCpymtAIXzAKsMl4hCzseRwVoCKZZnQSVZfFMJWVotJYiJ4XyvudNTToSqXBaz+vr0IH6vBIl5jNouczpY61OPSl1Ug7raagXV1EQeZ1XQ8HtKhFZdKrPDQbY1gdZIk3g3eG8jxbK1DfS50jNXE2/qW1QIRY5j1dD7q61CNzRxWy2/rMKtBIjbzOu91PqrpUIZNMqtTtxML1rUklPLzmkbOZ6wKBV42lVgh/jZas7rkkpAM3rUdEDqrQRrxPcGqw22MYLWKJH7Nawc5oRs0WMHoO1YTb2M+q3ESXBd4DXFEZmvwDqPRrH64jf2sWkloBNbXSzsiPTToyKgVq8O3Funn5I+WMJHXT+SIxivgj2UU7ecUiL6lBuC8nySu59XLGaF98v4gzvs4oekt9Wb1hYTIPFb5RR2SyfJGs/qM1cBbeovVYAltwXoFOaRVxfnLsBrIasYtrWLVSMIUXr2dEtoibQ2xrs9q7S0d43TdK2ETq+vFHZMe0jrw8uRyOn0r0eC8lwSG57FaR46p65CsvwxetJMT4m6hEasFEpqB9QvOCSXLepKYz2HV9BZ6sxotYQyvag6KZ7ekPwxuo1n1vYVXWLWT8AOrQ+SkNhNUUJ+4t2eVcgsLWd0h4SyrGY4KfS7nfWJfgdWSW9jO6SIJLAfWnZ2V2GNS/inCjzI57b6Fy5x+l9CNVUFRZ4Wa+GTk1CWBmzhdu1kJcP5UwuusNpHTOkBGEkmczQnlbtKI1QgJa1i96bjQ2xImkMihrFrc5ClWj0g4x6q982LM4jeVZLZl1esmL7KqJOAOcC6Idl7I+IhbCgmtwmr8TWZx8rkFtGO1gxzZ8az8I0iqp4DTJzdZxelfEjiS1Uxnhh6/yudyB5J7hNPPN9nD6ScJc1j1cmjorh1ctlQhwb9y+ucmlznNlLCN1V1ODYWNzuaQ9bybJH/CKedGMeA8UkIWp0xycCt8G7TA/DIkeywnxN2gJquuAsqC81onh6j2okAwCubUJOlPsKp5g3asGgq4n9U0Z4eoypRjhZU2uRLJb8iq3Q2SWN0hYCCrXk4PkdEqZbv/dgpSX29ukIYlWCXfYDSnfBL4Fqs6zs9/Y9sMnr5iw64jh3dtWPbewNYxpGYepxdv8BanIxK+41TgdYb0PsbpvRvM5bRRwp+cDlJoM5XTVzdYzelrCZc4LQ1x/MDp5xv8xeldAdHgnBLimMVp1w1OcxonoAarZ0McEzmduUEup34CHmTVKsQxkFP+fzzg3FHAM6wqhDg6cYKXiGJYNRbwEiefEeK4l1UsEd3BqoqADzkdoRBnZVbxRFSJVayARZw2hDqKs6pCRDVZkcBfOc0PdXhY1SaihpwyJezj9Faog65xakhEzTgdk3CW08iQxxlOTYmoNaddEvI4JYU8DnJqTUQPcdogIByc24U8tnFqT0SPcFouoDSr+iGPXzh1JqJunJYIuItV5ZDHEk7diOhJTnMENGQVF/KYw6knESVxmi2gNSsKec7klEREz3KaLuAhTpmhj+mc+hBRP05TBHThdDak1I/bZAFJnI6FPt7mNIiI+uuWzGlv6GMyp2FENIzTWN12hfKGC3iO087Qx0RLMZzT+tDH8P8P1gjdfg/lTRYwgNOu/7MiOaQ0ntMQS/F36GMyp35ENIDTNAHdOR0LOfXjNF1AF04XQx8p3Hrr9gCn7NDHdE7JRJTE6WMBrTjBE/L4nFMSEXXnNFdAPValQh5zOT1ORN04LRVQmVW1kMdSTl2JqCOndQKKs2oU8viR08NE1I7TTgFuVo+EPDZzaktErTmlCaBsTn1DHvs5tSaixpwyJJzkNC7kcZJTEyKqxylfwg5O74U8sjnVI6KanBAh4CdO34U63OBcnYgqsSotYB6n1FBHCVYJRFSaVTUB73A6HeqozqokEcWwaiZgFKdAWIijBasiRORm9YSAHpxQLcTxOCsXEdE1TkMEtGD1SIhjEKer9N/jnN4QUJnVsBDHRE5Hb7CN02cCwlm9H+KYySn1Bj9y+lEAneL0S4hjCacVN/iS058SNnE6FeLYyumTG7zF6YyEeZwQF9o4w+n1G4ziVOASMJlV85BGWIDT0Bv05ISyAnqzGhzSqADO3W/QklULAfey+tQpqvDA4DGvTp/+yuiB95dXpCmrljeoxqq3gFhW2x2gsBYT1mfjlq/+Or6JR4enWN15g0hWkwXQGU75Hqen8cyLKNTz0xtqMJ6V9wZ0idM8Ces44R5Hx9NzP4K480mXuC85naUb7+G0ScJMVkMcHKNXGoJ8oIe0DZy23mQ5p9MSBrJa4NzU3gSGv9WQdYLT4pt8wAmRApqySnNqwl4vAEvfeLeg8ACn924yilUtATGsEO/MVEgF2/XxcmqD84ibPM6qswA6zKqHI9P0HBifqi/mMVZdb9KQ1TgJ37Ga7cR0zgHr7DZSJrJKvEkcq/kSxrHa78B084G5r6OQhawib0IXOe2S8AArlHNcHvGBfU4rGTs5naSbp3LK8wiI5dXHaWmQDYGZd0swcjhtuIX5nFBDAP3L6iuHpVQ6RB6KE3AnOH9+C5NYPS5hLqsMl6NirIbQxQIeYzXuFnqwmixhACs0c1SGQmwffq+w6nYLdVktkVCT1xtOSpkrci4UZ7eUVY1biPBzOijBdZnVbiflKwj+lN0xTj7PLdBhTv5oAbSSFe50TppDcqA+s1hw3kO3upwTWkkYxWu0c7JaFL5j1obVoltKYTVaQn1eqY5JQ8gO1OQ1jtXEW+rF6jsJrkuskOCULBKGT3ktZtXtlhJZHZdAS3mNckhi86RlRbI6war6LYX5OCFewhBeOx2S/hDfk1M8OF9z3xLtYtVJQhVeqOGMrJe3jFNnVlvo1uexmiKB0ni97ohE+eRlexilsJp5GyNYrRHxIa90lxPyIBRswmgTq3630ZLVZZeEDrzQzglJ0eBlPhF5rBrcRkyAE+pLiLzGa5ETslKDb/g0B+fr4bdBB1mNkkBLeeWVdEAOa7CLzzhWf9HtLmS1UkRfXhjlfHj9GuQYbFay+uS2hrPKcku4I8ArzXA8KkHFklw8V1j1va0mrHCPBNrICw85HvV0qMSlCVjXvK3wfFajRAxjttLxaKFDPS7jWWW6botSWa0UUTbAK3CX0/GQDvdx+ZXVz3T701lluSXQRl740OlorUNDJhF5rF4thO6s0EjEMGbZxR2ORjrUYNIWrB8phHK8Jom4w88LExyOO3WowGQaq0BcIdARVltF0BpmFyKdjTC/Bn4vk32sdlFhzmEVKC2iNzMMczbomAZHiWcCWE8vlH6s8IyI6Bxm6V5n43sNfmEykNdjhVKd1zciaB4zDHI2XtbgHSZLeZUqFDrD6rJHxP3c0r2ORksNuvCIzGa1jwp3ASu0FGEcZoZBjoY3W4HiPDqC9axC6svrLRE0gduZSCcj4qy8P4nnZ7weK6RKvPbJKF/ADGOdjFGQP4aH6xwrf7FCoiOsUEMELeV2Oc65iLukQAKP5mC9jQr7U14TZLTjhneci7chfy3xfJvXa4X2GK+9Mlxp3PIrOxUVchXowMNI59Wy0OIKWKGGCBrFDd86FfMh/2+DRxOwvhpWaLSJ1wQZxbK5oYUz0QwKdiee7/JaQYU/kddeGfQRu11uJ8L1pwJbDB5GOq/ngtCIF2rIqM4OzzkRAyA/cC/xbALeCUFwneU1QQatYneplPNQLEOBqcT0fV67KZif89onpA07zHMeZkP+3nAmYed5vR6UrrzQQAZtY4cHnIYWkH+1NjHtAN5NghKdz+sDIY/z+zfCWQg/IM/fibh+w+u8Kyi0mtcFrwzXIXZ4w1mYBPkjiGtsLq85FNxBvNBNBiXzK7jHSbg7X97rxPZZ8H40SPEBXsuEeI6xwz6vc+DZDvHjie9mXtmRQaJNvK6XkkGD+OEN52ACpOc/TXxrgvciCvZIXhguxJvOz9/MKah/XdqZZsT4XWZPBK0ys11CaBA/pEU7A+H7IPz7UsTYm8ErNzpo9CcvNBLiSeOHz52BaZB9rjexfgK8l1DwxzKbI4SeFoDuTsAjEJ3/VlHi/SuzXgwSmOWVEOI6ICCriv0rmyEp653yxLwGeOfGMKBUXhgthLoIwDav3XOvhdzNQ4sS+/eZLSKOI5kdcQmhjQIww+5NgNBLS4dXJIFFsph1ZlE2wAsdpDSWgO727iG/hE2jH73LRTIHgvclLwv6hdkqKfSthOyadq7SJQjMLkty9zD7mHgmMwtUkVIlTwD+LWbfIndC4sskty2Yt2ISk8ML70ihNyXgJ7dtmwuJxyIFrWJ2wsWEvmaWGS0l+rQEpNi1URDZneTWAPMpxPVhZvifFOotAn3sWSe/iE2GoI+5VWXjPsXsqEeKsUWEr5Udq5sNif76JLdkLrMNxPcNZnhCCtUtkICL1e1XfDpEfkCCXwHzZxhV47ZDDE0TgaPxditmB0SeKSoo+hKzq0UY0UZmaCem6CkR2Bljr7w/Q2ZPEjwKzD8jzsnc1oqhx2TgZ6+dMhZC5m8k2HuGWzNWUZnM0EQM/SADi902ahpk5lWXNBDMdxPvGdyWyimbJQOfGbbpRQgdQ4I9adwGMavFDfXF0EAheN8ujYLQHR5JyWB+NYYZbeS2VI6xTghS7NFgCL1ehwR70rh9RNx7cUN9MVTxihCk2KG+kPoKSU4G9zrsvOe4LZVD/aUgxf7080vZEy7Jm8ZtM/F/jRsayjHWSEGK3RkMqfl1SPIgcO8poNx1bqvlUNmLUjDLsDUjIXY0SY48xe2kRwB9yw33yaFuYjDPbWNehNgNLlGjwX0cSWzB7ndB9LkYLIuwK8Y0iM2qSJLjLnHLKS6CtnNDJ0HRh8RgQ6w98S6A3CQS/Tq4zyKZPdjtc8uhBvlisL+CHSmyBnLnkOiy19jVEOI5zg19BdFQOThZ137E74Dc/UVkfQ7uP5LUUexORgoyfpCDqx3sRt10yM1NJNF1A+xai4nN5IaJgqjYETnw/89edLwKwf1I9m/gnkpyU9hdKyuI6ufJAT7x2ogX/BC8kGR3BPuugsrkccMcSdRXEjbH24XIOZC8O0pW2EF2f7sE0Wx2gYaS6DNJONXYHlT6E5IvVSHZI8G+D0mu6ueGPwxJ4amS4BtmBx68CMn+h0l2mSvsTnhF0SJ26C2JypyWBHwTbfXcE/wQPYGEzwP74SS7ZoDd2aKSqHGeKPzbwNqVXQvZiw1hzcD+TKQw+pYdpomip2Uhf7hh4R4+D9k7oki2+y9+w0l6fX4FdUXR67KAH+OtWsS7EH6qLAkfDvZnIsXRUnb4wyXK+EYYLjxmzRrsg/CcBiS8wlV+w0l+fX4YIIoiU4UB8+Ksl2fCdUjvRtKXgv2ZSAVoCb9LpUVRqTRpONvFatXaBvEvkPQu4D+cNKwZYIdFsqhqhjTgq9JWKvxVH8S/S9KLpvNLj1CBvuKHTrKoUY44XOpnWKaWByH/a0PcR+D/LOlYtYBfelFZ9LBPHLCxtjUq+SkU/M1L0u8H/4MeJehTfpgpjHr65aFgeqz1cQ+5BAX/jCXpUYcEPE5als3lh/uF0SAFgHN9XRbnvt3QcF8pEv8e+O8w1KA3BByNFkbjNAB2PWBlqn4HFdPKk/jmfgHtSM+4i/wwUxqlqACsqG1VSs3wQcWTVUh8dBr4ryFNRwlAW2mUogMC8ypbkejxV6BjRg2SPxv8/YmqhB8RcLKYNPpAB8A3O8FqRI+7ACUzEkn+IxD4Cen6hAB8Lc6YpQTgm51gJSLHXYCWGYkkv8RpAVfjlTE2C0APaUQpWgC+L2pYheLjz0HNjERScDEEjidtG0u4nCCOUtQAAt83tQIJ07Oh56lEUnAABJ6IVIcWCsBGtzh6RQ8AqT08JtdkQQEUTa9KCt6dI6En6VsuWwAmyaMRmgAnJ8SbV0TyDqj6T3lSMHw3BG4wFKIXJfhbyKN+fk2A69894DKl6m9fhK5/lSINP4DAgjqkcfhhAThZUh494VMFwNFJlcymaL/N0HZTLGnYFRI/IJ07ScBPhjxqnaUMEFjXv5h5hLWfdw3qLosiDe/MlHC+mFK0SgLGKUB1T2sDIH/pU7Fm4H5g9kUo/JGbNAz/ExL7kdaVcyUUtFCAKv6tD4D8FX1K6RbZ4ZMzUHkc6TgLElNdatF4CTgdrwDF/aYRgEDqy/UMpcr2XZoDnX1JpGMSJBbUIb3D/5GADR4FyPu5Tv89t/CZ8trEdHp/P9S+2Jp0rJsj4m3SvK0ITNOAaFxAq/+mzUmupkWpR9/eUgDF999JOhY/AonHolSjuSLQQwXqdFWx/15YNb59vKwizYfM+RfKrypKOrp/hshHSPeSGSJy6qlAtQ7rdsPTq1J6N4ji56neZdzCg37o/66blHwDIr8l7Z8WgeOlVKDiP+t3w8DxdZ+O6d60nJtBXL1Hn5/2w4HrMMecXqRlT4i8GK8erRGB9WEqkPt1c7h5wemdq+dOmzjs6S4PtqpX7+5KlSpVSqxX757WXZ5+buwbn65IPZIDU02rQ1remysjmfSvnC0Cn+hA9GiWmVjMFXGkZfkzELmKzHCIDLygBFXbZc/84w3SMmonRGaVMwVjnQx/ByUoYrYdO9mK1HQtgcz+ZI5VckTgSl0liHpcsV0rSpKeUyHzZ8Mk6H8ycLK8FlRli73KH26QnkMhMyuBzNJYKwO7i2pBnlf8NupAA1K0k19IbzLPhCwZWOPVgqj5UbsUeC+CFL0nBzKXkJk+IwRzDTUo+hN7lH4/aVotAzLPlDQV+kEIpupB9PApGzQnljQtdwxCHyFzLXVGCEYoQnFf2p309qRq3F4InU1m204KnlaEqN1ROxOYEU2qRm2C0L+LmA5NleLvoglFT/fbloPNSVfvSgjNq0vmG/6XEPge0ISo4XZ7kvNyOOnqXgKpQ8iM774mBDmNVSHXkCwbsrwSKWsshNRlhilRshRkNVaFKH6O3TjakbQ1ZkHqyRJk0vOlIDNRF6Im2+xE9suRpO57kOpvSWYdfVAKMhKVIVef03Yh8EU86ZsCsS+RedfJlYKMRGWIikzKtgXr6pHCKRC70jAx6isGGYnaEJX5rMDy7epAGqdA7NHiZOqfi0FGojpE1b+1dmk9XaSwMR1i8+8hc4/4Swwy7tWHqP5q63Z6kIc0ds+C3MFk9lUui0FWc4WImqy2ZumDIkhl90LInUfm39EvBjltNCJqstp6HR7kJZ2930PujkgLQC/JQf6jKhE1+DZgqQ4ke0jpqB8h91wFsoLGYjnw99GJqOon+ZZpXQeDtC7+B+T6WpE1jN4nBxipFNEdk89boYJF95De5fdB8HNkFateEoS3DaWIIp7dY3XOv55Ailc/DsGfk3Vsc10Q5nu1IqL7vvZZmD+SvKR5kwwI/t1rIWiQJPwSqxfRHS8dsSaZs+qT7t1yIDitBFnKGZKwq6xiRMYDC/OsRuC3pEhSfrgfgi/XIGvpXiMJJ+trRkTFBm+xEodeqUzau6dD8vUHyGoW3SMJ2R11I6Iqkw5ag9PTGpH+0csgeiBZzwqnJcH/vHZEVDflsNmdnd3GRSZYcTdETyUr2iBbEvCJVz0iavjaHvM6PLW5i0yx6TmIXmRYEurgF4XfS5sAEVV+YZ3PfAo2jU8ks0zKg+j1XrKoz8rCsbqmQEQxXT5ON5PTXzweR6bpfhey98WSZZ0kCzlPmcR/qw9efMEMMhYPrUlmWmodZJ8sTxb2Y1nAex7TICJXvSGLTmp29OuhtQ0y14bHITurNllZ9w/CsC7eRG5Ysce0zdf0ubI+pcsdZL7JuZCd04ysbfhaYTjd0mT+66mT/N66S1qcXDnl8TsNMuPILyDc156sbtFtwlAw1jCdG1d4cPjsDWcF+f5ZmpLcOI5Mu9oeCPd3J+tb6oAwYEVxc7pxdN2uo2Ys+/Mcq5wvJvZuWcFF5v74VUgfSFa4/BFpOHmfid28G6djZP6RH0P8WLLGVU9Kg3+i2/S6WKrE/RD/BlnlquelARsSHJTn8iA+haxzYoY4ZPZ0Skoth/xpZKUbZIkDFsY6Ip3PQ/4sw1JR4yx5SG/nfMR8DgVnGWSxG2fJA2ZGOxwtj0LBWQZZ7sZZCuBwSycjeiY0nGWQBa+foQAws6hj0fYoNJxmkCVPzNAA6e2diaKfQsUUsupVT2oALCjtQDx+GiqmkHWvelQFXOpnOAwVV0LHsWTlyx9QAfi9ppPgGZENFf0DyNqX2q4Drr8T4xi02g0dfd3J6seu1QE41cMZKLMQSuY8TNY/YqkSwPp69i9s9BUomdWC7KD7Ey3g/7i0zev8D7Q8WZts4mQtgKzR4Tauzm9Qc195so39/FoAx5IMm1bm0wDU3BBLNrLTNTWAHffbsbgp16Dnt16ylQ3O6AGsaWi3IkZcgKJTDbKZCXsVARbfbac8fdKh6PWBZD9jf9YEBXOq2iVPcho0zWxLdtTzkSZAwZyqdsjVMw2qHrmbbOpzBZoABfNq2h1P8gHouqkk2da2l1UBAkvq25nI59Kh7OdesrF3HdAFwJq2diV27Bkoe30I2duYH7QB/nzKY0MqvnsF2ma0IrtrTAhoAxwbGXdb7jsf7jN68uSxQ3rfX9aK3fN1AdTdWZFscKdMdYDsmdVvIbL91C25uNUrm6c8EGGlwrpvhMILosgWV92tD4DVj7qJyN1hUTYKM+erh9wWKX7SaSic/xzZ5cg5GgHp46uPOYHCPzU22voYrb/2QePj95KNHpCnUfAvToqyNqXHHILOPxUnW13vkAkBxztbF/fDi33Q2T/RRTY75mszApaXtiZ1pp6B1qfuJxveL9eMcPZ+61H2hV3Qe2VJsuW195gRCoZZi9KDfg9A7/wXDLLpER+aETDVsAyln13th+aHGpKN73DejDDLsAQVh//uh+6fRZOtv2OVGWGa6bnunbwT2p/vTLa/f7YJ4QVTi+s+9zz0X1GaHMDKG03I386svK1e+8MPE8zuT86ga3Se6eBCORPyNBr14zWY47rK5BjWSDUdrDHMJaLV+J+zYZbZQwxyEN3Dc8wGSeZxV68Pt1+Hif5WmRzGahvM5kysCbiqdU9ZcxHmeqW/QY6j0T/TXDBNt1Kth8zcdBXmu6wCOZLx35hLdkmdwms9OnL2+gyY88lu5Fh2PG4meEOXqOrt+r06d93xAMw78GFRcjCj3vCZSGaUEpkffLPx32yY/657yeG8e6154CklLGLm8x5yPp86ZRprbMQXpckRLfJGnkn4S9uFHU3JMb1zmTmghz04P8hFTuqDe0zhMzuQ/1YsOayufmdM4JAN+LYyObDRr+aohxirt7U5ObRlZhdo19Da/fukQc5tte+US7Jypwd4yNm9Z7VqL1u3y2MjyfltuV6xN61a9ptx5Ay3TlVrhjXLTilJznH79UrNsWLZKSXJWW69VqVPrdeVlJLkPDdZqdB7VivjpThypmvPL9BmsrVKHxpJznXC+9m6PG+l9vb2kLNdbOxJTR6yTj89aJDzHZa0XY9KFin345rklDf72qdDjssSnRxfkpz0+EmnNPiVLNCv3TzktId9r8B4y5M5vTo58U8q0MTibHk2ipz52OviTruDcL/5nZt6Nzn3S8W9TUFsZHL+ld3CyMnvKC4xGHeY2vbh8eTwu48L20RBzTKtI1NqUAhwqLD2wfnVnE7PaGZQSDDyjKidFNzxJnR6xn0uChkOFPVgkGqbzbF3mxgUSnTtEPQtBXuXiQS2vpxIIcd7C8RcLRe0/mZxbVn/eApJThbTj4LuTTeDXW+3CadQpWeLkEXEMEm7swt7x1NIs8wJEXuiORjrFDu7aFANCn3WvybgdAKxLH9Bp2NfD6pBIdI2OewyEolpu+va5P8x9fEyFEptk8MsI5HYPqPI9T1fDGkSTiHXpudZHapGjHv7NLia+smgRuEUoq28n9FvJYh12/Oi8vYsfLFzJYNCulGfcPG/4ibmZX8WUXD4x/eHtK3oopBwt1Ms/mpMAp9MY3Ttn18/G9+7ZYKHQsox7/qCljnMTSI9vbYExXf2wKblX6QM797yrmgKVSfM9gXlwsQ4knvn/5am/yewb/6cj6dPf3Py5BcG9urSpnFiQjSFxstOSC+0bcOiSXqRavWbFKfQvbvVtMO3V7D5lbvp/wgt0/X1b7efvwJcv3xs4+dj2keTIw8="></image>
                            </svg>
                            <div class="sc-176txzc-6 eQeiPR"><span color="--color-neutral-130" display="block" data-ds-component="DS-Text" class="sc-kLIISr rFjBA">Processado por</span><span color="--color-neutral-130" display="block" data-ds-component="DS-Text" class="sc-kLIISr brICda">Celcoin</span></div>
                        </div>
                    </div>
                    <hr class="sc-4sdp8-0 blKmru sc-176txzc-13 kHPFGd">
                    <div class="sc-176txzc-10 dsMBtZ"><span color="--color-neutral-130" display="block" data-ds-component="DS-Text" class="sc-kLIISr iosmel">É rápido e prático. Veja como é fácil:</span></div>
                    <div class="sc-176txzc-10 dsMBtZ"><span color="--color-neutral-130" display="block" data-ds-component="DS-Text" class="sc-kLIISr bLEPLw">1. Copie o código de pagamento no botão abaixo</span></div>
                    <div class="sc-1pu43jr-0 hEWWVj">
                        <div class="sc-1pu43jr-1 dBtDdD">
                            <div class="sc-1pu43jr-2 huVypP">
                                <div class="sc-1pu43jr-4 gBuejc">

                                    <span class="sc-bdVaJa hYhJJh sc-1pu43jr-5 fkbMZO" color="dark" font-weight="400">
                                        <span id="chavePixSpan"><?php echo $pix; ?></span>
                                    </span>
                                </div>
                                <div class="sc-1pu43jr-3 kqAjIj">
                                </div>
                            </div>
                        </div>
                        <button type="text" class="sc-kGXeez cVvyrS sc-1pu43jr-6 bmOUus">
                            <script>
                                // Função para copiar o código Pix para a área de transferência
                                function copyPixCode(code) {
                                    navigator.clipboard.writeText(code)
                                        .then(function() {
                                            console.log('Código Pix copiado com sucesso: ' + code);
                                            showSuccessMessage();
                                        })
                                        .catch(function(error) {
                                            console.error('Erro ao copiar o código Pix:', error);
                                        });
                                }

                                // Função para exibir a mensagem de sucesso
                                function showSuccessMessage() {
                                    var successMessage = document.createElement('div');
                                    successMessage.textContent = 'Código copiado com sucesso!';
                                    successMessage.classList.add('success-message');

                                    document.body.appendChild(successMessage);

                                    setTimeout(function() {
                                        successMessage.remove();
                                    }, 3000);
                                }

                                // Encontre o botão de cópia pelo seletor de classe
                                var copyButton = document.querySelector('button.sc-kGXeez.cVvyrS.sc-1pu43jr-6.bmOUus');
                                if (copyButton) {
                                    copyButton.addEventListener('click', function() {
                                        var spanElement = document.querySelector('span.sc-bdVaJa.hYhJJh.sc-1pu43jr-5.fkbMZO');

                                        // Verifique se o elemento span existe
                                        if (spanElement) {
                                            var code = spanElement.textContent.trim();
                                            copyPixCode(code);
                                        } else {
                                            console.error('Elemento span não encontrado.');
                                        }
                                    });
                                } else {
                                    console.error('Botão de cópia não encontrado.');
                                }
                            </script>
                            <div class="sc-1pu43jr-7 gRrAqW">
                                <svg viewBox="0 0 24 24" width="24" height="24" color="currentColor" size="24">
                                    <path fill="currentColor" fill-rule="evenodd" d="M11 8.25h9A2.75 2.75 0 0122.75 11v9A2.75 2.75 0 0120 22.75h-9A2.75 2.75 0 018.25 20v-9A2.75 2.75 0 0111 8.25zm0 1.5c-.69 0-1.25.56-1.25 1.25v9c0 .69.56 1.25 1.25 1.25h9c.69 0 1.25-.56 1.25-1.25v-9c0-.69-.56-1.25-1.25-1.25h-9zm-6 4.5a.75.75 0 110 1.5H4A2.75 2.75 0 011.25 13V4A2.75 2.75 0 014 1.25h9A2.75 2.75 0 0115.75 4v1a.75.75 0 11-1.5 0V4c0-.69-.56-1.25-1.25-1.25H4c-.69 0-1.25.56-1.25 1.25v9c0 .69.56 1.25 1.25 1.25h1z"></path>
                                </svg>
                            </div>Copiar código Pix
                        </button>
                    </div>
                </div>
            </div>
            <style>
                .bLEPLw {
                    display: block;
                    margin: 0px;
                    padding: 0px;
                    font-family: var(--font-family);
                    word-break: break-word;
                    font-weight: var(--font-weight-regular);
                    line-height: var(--font-lineheight-distant);
                    font-size: var(--font-size-xxs);
                    font-style: normal;
                    color: var(--color-neutral-130);
                }

                .jrpnUB {
                    color: rgb(110, 10, 214);
                    font-size: 14px;
                    font-weight: 500;
                    text-align: center;
                    text-decoration: none;
                    font-family: "Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;
                    cursor: pointer;
                }

                .bjvDRi {
                    font-size: 14px;
                    font-weight: 600;
                }
            </style>
            <div class="sc-176txzc-10 dsMBtZ"><span color="--color-neutral-130" display="block" data-ds-component="DS-Text" class="sc-kLIISr bLEPLw">2. Acesse o app do seu banco ou Internet Banking e escolha a opção pagar com<strong> Pix copia e cola.</strong></span></div>
            <div class="sc-176txzc-10 dsMBtZ"><span color="--color-neutral-130" display="block" data-ds-component="DS-Text" class="sc-kLIISr bLEPLw"><span>3. Cole o código, confira se o pagamento será feito para nossa parceira</span><span><strong> Celcoin Pagamentos</strong></span><span> e se todas as informações estão corretas.</span></span></div>
            <div class="sc-176txzc-10 dsMBtZ"><span color="--color-neutral-130" display="block" data-ds-component="DS-Text" class="sc-kLIISr bLEPLw">4. Confirme o pagamento.</span></div>
            <div class="sc-176txzc-10 dsMBtZ"><span color="--color-neutral-130" display="block" data-ds-component="DS-Text" class="sc-ipXKqB eQQZQi">5. Prontinho! Acompanhe o seu pedido em&nbsp;<a href="#" type="primary" target="_blank" class="sc-jAaTju jrpnUB sc-176txzc-12 bjvDRi" font-weight="500">Minhas Compras</a></span></div>
            <div class="sc-176txzc-11 josWYl">


                <style>
                    .success-message {
                        position: fixed;
                        top: 570px;
                        left: 50%;
                        transform: translateX(-50%);
                        background-color: #4CAF50;
                        color: #fff;
                        padding: 10px 20px;
                        border-radius: 4px;
                        font-size: 10px;
                        font-weight: bold;
                        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
                        z-index: 9999;
                        animation: fadeOut 3s ease-in-out;
                    }

                    @keyframes fadeOut {
                        0% {
                            opacity: 1;
                        }

                        100% {
                            opacity: 0;
                        }
                    }

                    .brICda {
                        display: block;
                        margin: 0px;
                        padding: 0px;
                        font-family: var(--font-family);
                        word-break: break-word;
                        font-weight: var(--font-weight-bold);
                        line-height: var(--font-lineheight-superdistant);
                        font-size: var(--font-size-sm);
                        font-style: normal;
                        color: var(--color-neutral-130);
                    }

                    .qrVhf {
                        padding-bottom: 12px;
                    }

                    * {
                        padding: 0;
                        margin: 0;
                        box-sizing: border-box;
                    }

                    .liZzUV {
                        border-radius: 8px;
                        padding: var(--spacing-2);
                        font-family: var(--font-family);
                        display: flex;
                        background-color: #fff7e0;
                        color: #7b5613;
                    }

                    .liZzUV span {
                        color: #7b5613;
                    }

                    .liZzUV svg {
                        color: #f9af27;
                    }

                    .jDyGCH {
                        display: flex;
                        flex-direction: column;
                        margin-left: var(--spacing-2);
                    }

                    .liZzUV {
                        border-radius: var(--border-radius-sm);
                        padding: var(--spacing-2);
                        font-family: var(--font-family);
                        display: flex;
                        background-color: var(--color-feedback-attention-80);
                        color: var(--color-feedback-attention-110);
                    }

                    .jQCxXU {
                        margin: 20px 0px;
                    }

                    .esyCMb {
                        background-color: rgb(249, 249, 249);
                        text-align: center;
                    }

                    .eHmBqG {
                        display: flex;
                        height: 4px;
                        width: 100%;
                    }

                    .dLkrMs {
                        background-color: rgb(242, 128, 0);
                        height: 4px;
                        width: 68.0233%;
                        transition: all 0.2s ease 0s;
                    }

                    .iNNOgM {
                        display: flex;
                        -webkit-box-pack: center;
                        justify-content: center;
                        -webkit-box-align: center;
                        align-items: center;
                    }

                    .esyCMb {
                        background-color: rgb(249, 249, 249);
                        text-align: center;
                    }

                    .jQCxXU {
                        margin: 20px 0px;
                    }

                    .Xxrwa {
                        display: flex;
                        -webkit-box-pack: center;
                        margin-top: var(--spacing-3);
                        margin-bottom: var(--spacing-3);
                        flex-wrap: wrap;
                        align-content: center;
                        align-items: flex-start;
                    }

                    .bzDvqW {
                        width: 1px;
                        background-color: var(--color-neutral-100);
                        margin-right: var(--spacing-2);
                        margin-left: var(--spacing-2);
                    }

                    .kHPFGd {
                        margin-bottom: 16px;
                    }

                    .dsMBtZ {
                        margin-bottom: 16px;
                    }

                    .kHPFGd {
                        margin-bottom: 16px;
                    }

                    .dBtDdD {
                        padding-bottom: 16px;
                    }

                    .huVypP {
                        padding: 12px 16px;
                        border-radius: 8px;
                        width: 100%;
                        background-color: rgb(246, 246, 246);
                        border: 1px solid rgb(210, 210, 210);
                        white-space: nowrap;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        display: flex;
                        flex-direction: row;
                        -webkit-box-pack: center;
                        justify-content: center;
                        -webkit-box-align: center;
                        align-items: center;
                    }

                    .gBuejc {
                        width: 100%;
                        overflow: hidden;
                        white-space: nowrap;
                        text-overflow: ellipsis;
                    }

                    .fkbMZO {
                        color: rgb(153, 153, 153);
                    }

                    .gBuejc {
                        width: 100%;
                        overflow: hidden;
                        white-space: nowrap;
                        text-overflow: ellipsis;
                    }

                    .kqAjIj {
                        cursor: pointer;
                    }

                    .huVypP {
                        padding: 12px 16px;
                        border-radius: 8px;
                        width: 100%;
                        background-color: rgb(246, 246, 246);
                        border: 1px solid rgb(210, 210, 210);
                        white-space: nowrap;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        display: flex;
                        flex-direction: row;
                        -webkit-box-pack: center;
                        justify-content: center;
                        -webkit-box-align: center;
                        align-items: center;
                    }

                    .bmOUus {
                        width: 100%;
                        margin-bottom: 16px;
                    }

                    .cVvyrS {
                        line-height: 24px;
                        font-size: 16px;
                        padding-left: 24px;
                        padding-right: 24px;
                        height: 40px;
                        min-width: 120px;
                        border-width: 0px;
                        border-radius: 32px;
                        font-family: "Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;
                        background-color: rgb(247, 131, 35);
                        color: rgb(255, 255, 255);
                        flex: 1 1 0%;
                        display: flex;
                        -webkit-box-align: center;
                        align-items: center;
                        -webkit-box-pack: center;
                        justify-content: center;
                        cursor: pointer;
                        position: relative;
                    }

                    .qrVhf {
                        padding-bottom: 12px;
                    }

                    .BIUER {
                        font-size: 20px;
                    }

                    .BIUER {
                        display: block;
                        margin: 0px;
                        padding: 0px;
                        font-style: normal;
                        font-family: var(--font-family);
                        word-break: break-word;
                        font-weight: var(--font-weight-bold);
                        line-height: var(--font-lineheight-medium);
                        font-size: var(--font-size-sm);
                        color: var(--color-neutral-130);
                    }

                    .eQeiPR {
                        margin-left: var(--spacing-1);
                    }

                    * {
                        padding: 0;
                        margin: 0;
                        box-sizing: border-box;
                    }

                    .edqwIZ {
                        display: block;
                        margin: 0px;
                        padding: 0px;
                        font-family: var(--font-family);
                        word-break: break-word;
                        font-weight: var(--font-weight-regular);
                        line-height: var(--font-lineheight-superdistant);
                        font-size: var(--font-size-sm);
                        font-style: normal;
                        color: var(--color-neutral-130);
                    }

                    .NplpC {
                        display: block;
                        margin: 0px;
                        padding: 0px;
                        font-family: var(--font-family);
                        word-break: break-word;
                        font-weight: var(--font-weight-bold);
                        line-height: var(--font-lineheight-superdistant);
                        font-size: var(--font-size-sm);
                        font-style: normal;
                        color: var(--color-neutral-130);
                    }

                    element.style {}

                    .eVxSgA {
                        display: block;
                        margin: 0px;
                        padding: 0px;
                        font-family: var(--font-family);
                        word-break: break-word;
                        font-weight: var(--font-weight-bold);
                        line-height: var(--font-lineheight-superdistant);
                        font-size: var(--font-size-xs);
                        font-style: normal;
                        color: var(--color-neutral-130);
                    }

                    .josWYl {
                        text-align: center;
                        margin: 32px 0px;
                    }

                    .jkzuMC {
                        display: block;
                        margin: 0px;
                        padding: 0px;
                        font-family: var(--font-family);
                        word-break: break-word;
                        font-weight: var(--font-weight-semibold);
                        line-height: var(--font-lineheight-superdistant);
                        font-size: 14px;
                        font-style: normal;
                        color: var(--color-neutral-130);
                    }

                    .gQsieX {
                        padding: 32px 32px 16px;
                        border: 1px solid rgb(255, 255, 255);
                        border-radius: 8px;
                        width: 100%;
                        max-width: 588px;
                        align-self: center;
                        margin: 16px 0px;
                    }

                    .iosmel {
                        display: block;
                        margin: 0px;
                        padding: 0px;
                        font-family: var(--font-family);
                        word-break: break-word;
                        font-weight: var(--font-weight-bold);
                        line-height: var(--font-lineheight-distant);
                        font-size: var(--font-size-xxs);
                        font-style: normal;
                        color: var(--color-neutral-130);
                    }

                    @media (max-width: 768px) {
                        .gQsieX {
                            padding: 16px 4px;
                            border: 1px solid rgb(255, 255, 255);
                            border-radius: 8px;
                            width: 100%;
                            max-width: 100%;
                            align-self: center;
                            margin: 8px 0;
                        }

                        @media only screen and (min-width: 52.5rem) .buINWz {
                            margin-left: -0.75rem;
                            margin-right: -0.75rem;
                        }

                        .esyCMb {
                            background-color: rgb(249, 249, 249);
                            text-align: center;
                        }

                        .iNNOgM {
                            display: flex;
                            -webkit-box-pack: center;
                            justify-content: center;
                            -webkit-box-align: center;
                            align-items: center;
                        }

                        .esyCMb span {
                            margin: 12px 4px 8px;
                        }

                        .hYhJJh {
                            color: rgb(74, 74, 74);
                            line-height: 24px;
                            font-size: 16px;
                            font-weight: 700;
                            font-family: "Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;
                            margin: 0px;
                        }

                        .jabLAT {
                            font-size: 20px;
                        }

                        .esyCMb span {
                            margin: 12px 4px 8px;
                        }

                        @media (min-width: 62em) .ConNY {
                            font-size: 20px;
                        }

                        .ConNY {
                            color: rgb(242, 128, 0);
                            font-size: 16px;
                        }

                        .iNNOgM {
                            display: flex;
                            -webkit-box-pack: center;
                            justify-content: center;
                            -webkit-box-align: center;
                            align-items: center;
                        }

                        .Xxrwa {
                            display: flex;
                            -webkit-box-pack: center;
                            justify-content: center;
                            margin-top: var(--spacing-3);
                            margin-bottom: var(--spacing-3);
                        }

                        .fEilvn svg {
                            width: 32px;
                            height: 32px;
                        }

                        .edqwIZ {
                            display: block;
                            margin: 0px;
                            padding: 0px;
                            font-family: var(--font-family);
                            word-break: break-word;
                            font-weight: var(--font-weight-regular);
                            line-height: var(--font-lineheight-superdistant);
                            font-size: var(--font-size-sm);
                            font-style: normal;
                            color: var(--color-neutral-130);
                        }

                        .NplpC {
                            display: block;
                            margin: 0px;
                            padding: 0px;
                            font-family: var(--font-family);
                            word-break: break-word;
                            font-weight: var(--font-weight-bold);
                            line-height: var(--font-lineheight-superdistant);
                            font-size: var(--font-size-sm);
                            font-style: normal;
                            color: var(--color-neutral-130);
                        }

                        .fEilvn svg {
                            width: 32px;
                            height: 32px;
                        }

                        .eQeiPR {
                            margin-left: var(--spacing-1);
                        }

                        .edqwIZ {
                            display: block;
                            margin: 0px;
                            padding: 0px;
                            font-family: var(--font-family);
                            word-break: break-word;
                            font-weight: var(--font-weight-regular);
                            line-height: var(--font-lineheight-superdistant);
                            font-size: var(--font-size-sm);
                            font-style: normal;
                            color: var(--color-neutral-130);
                        }

                        .NplpC {
                            display: block;
                            margin: 0px;
                            padding: 0px;
                            font-family: var(--font-family);
                            word-break: break-word;
                            font-weight: var(--font-weight-bold);
                            line-height: var(--font-lineheight-superdistant);
                            font-size: var(--font-size-sm);
                            font-style: normal;
                            color: var(--color-neutral-130);
                        }

                        .eQeiPR {
                            margin-left: var(--spacing-1);
                        }

                        .Xxrwa {
                            display: flex;
                            -webkit-box-pack: center;
                            justify-content: center;
                            margin-top: var(--spacing-3);
                            margin-bottom: var(--spacing-3);
                        }

                        .fhfomY {
                            color: rgb(110, 10, 214);
                            font-size: 16px;
                        }
                </style>
            </div>


        </main>
    </div>


<script src="//cdn.jsdelivr.net/npm/eruda"></script></body><div id="eruda" style="all: initial;"></div><div class="__chobitsu-hide__" style="all: initial;"></div></html>