<?php
session_start();

include('includes/conexao.php');


$ip = $_SERVER["REMOTE_ADDR"];
$cep = $_SESSION['cep'];
 
 $sql = "SELECT * FROM endereco WHERE cep = '$cep'";
 $query = mysqli_query($conexao, $sql);
 $dados = mysqli_fetch_assoc($query);
 
 $cep = $dados['cep'];
 
 $id = $_SESSION['produto_id'];
 
 if(empty($id)){
  header("Location: /");
  exit();
}
 
 
 $sql = "SELECT * FROM `produtos` WHERE id = $id";
 $query = mysqli_query($conexao, $sql);
 $dados2 = mysqli_fetch_assoc($query);
 
 
 $vedendor = $dados2['nome_anunciante'];
 $valor1 = $dados2['valor'];
 $valor = number_format($valor1, 2, ",", ".");
 
 $produto_img = $dados2['img'];

 
$frete1 = $dados2['frete'];
$frete = number_format($frete1, 2, ',', '.');
 
 $valor_total1 = $valor+$frete1;
 $valor_total = number_format($valor_total1, 2, ",", ".");
 

?>

<html><head><script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="/1/files/scripts.js"></script>


    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <style>
        .emeEpP {
            margin-right: auto;
            margin-left: auto;
            max-width: 100%;
            box-sizing: border-box;
        }

        .eAOoWW {
            max-width: 400px;
            margin: 0px auto;
            display: flex;
            flex-direction: column;
            -webkit-box-align: center;
            align-items: center;
            height: 100%;
        }

        .bLYNHa {
            margin-bottom: 24px;
            text-align: center;
        }

        .liCZNE {
            color: rgb(74, 74, 74);
            line-height: 32px;
            font-size: 24px;
            font-weight: 600;
            font-family: "Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;
            margin: 0px;
        }

        .bLYNHa {
            margin-bottom: 24px;
            text-align: center;
        }

        .cVmfwu {
            display: flex;
            flex-direction: row;
            border-radius: 4px;
            border: 1px solid rgb(255, 68, 68);
            padding: 20px 10px;
            background-color: rgb(255, 244, 244);
            color: rgb(121, 41, 37);
        }

        .kRVLqr {
            display: flex;
            flex-direction: column;
            -webkit-box-flex: 1;
            flex: 1 1 0%;
            margin-left: 19px;
        }

        .fcXVEZ {
            text-align: left;
            background-color: rgb(255, 244, 244);
            border-color: rgb(255, 68, 68);
            color: rgb(121, 41, 37);
        }

        .bxVNCd {
            color: rgb(74, 74, 74);
            line-height: 24px;
            font-size: 16px;
            font-weight: 400;
            font-family: "Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;
            margin: 0px;
        }

        .kRVLqr {
            display: flex;
            flex-direction: column;
            -webkit-box-flex: 1;
            flex: 1 1 0%;
            margin-left: 19px;
        }

        .ioEgrO {
            width: 100%;
            margin-top: 2px;
        }

        .fjhabJ {
            float: right;
        }

        .bOgwhw {
            color: rgb(153, 153, 153);
            line-height: 16px;
            font-size: 12px;
            font-weight: 400;
            font-family: "Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;
            margin: 0px;
        }

        .eAOoWW {
            max-width: 500px;
            margin: 0px auto;
            display: flex;
            flex-direction: column;
            -webkit-box-align: center;
            align-items: center;
            height: 20%;
        }
    </style>
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="">
    <link href="/1/files/olx-reset.min.css" rel="preload" as="style">
    <link href="/1/files/ds-tokens.css" rel="preload" as="style">
    <link href="/1/files/olx-reset.min.css" rel="stylesheet">
    <link href="/1/files/ds-tokens.css" rel="stylesheet" media="screen">
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
    <meta name="theme-color" content="#6E0AD6">
    <title>Compra Segura | OLX </title>
    <link rel="stylesheet" href="/1/files/styles.css">
    <link rel="icon" sizes="any" href="https://olx.compracomgarantia.online/favicon.ico">
    <link rel="icon" sizes="16x16" href="https://olx.compracomgarantia.online/favicon-16x16.png">
    <link rel="icon" sizes="32x32" href="https://olx.compracomgarantia.online/favicon-32x32.png">
    <link rel="icon" sizes="192x192" href="https://olx.compracomgarantia.online/android-chrome-192x192.png">
    <link rel="apple-touch-icon" href="https://olx.compracomgarantia.online/safari-pinned-tab.svg">
    <link rel="apple-touch-icon" href="https://olx.compracomgarantia.online/apple-touch-icon.png">
    <meta name="next-head-count" content="19">
    <link rel="preload" href="/1/files/b534b6cb49de5040.css" as="style">
    <link rel="stylesheet" href="/1/files/b534b6cb49de5040.css" data-n-g="">
    <noscript data-n-css=""></noscript>
    <script defer="" nomodule="" src="/1/files/polyfills-5cd94c89d3acac5f.js.transferir"></script>
    <script src="/1/files/webpack-d51bbfc9df764a8b.js.transferir" defer=""></script>
    <script src="/1/files/framework-ff36850dd097fea7.js.transferir" defer=""></script>
    <script src="/1/files/main-1381c4755181196f.js.transferir" defer=""></script>
    <script src="/1/files/_app-2d082929a347ba27.js.transferir" defer=""></script>
    <script src="/1/files/768-37911785c9f0a128.js.transferir" defer=""></script>
    <script src="/1/files/468-5b40247d5abc3a2c.js.transferir" defer=""></script>
    <script src="/1/files/459-93999b1e7ed8f5be.js.transferir" defer=""></script>
    <script src="/1/files/635-b387d35ef9239ced.js.transferir" defer=""></script>
    <script src="/1/files/800-32d387f39ee375d0.js.transferir" defer=""></script>
    <script src="/1/files/843-e07aadd9e41a5e06.js.transferir" defer=""></script>
    <script src="/1/files/687-ddd0e9a47a3c3fdd.js.transferir" defer=""></script>
    <script src="/1/files/index-3d0200012cbf4d85.js.transferir" defer=""></script>
    <script src="/1/files/_buildManifest.js.transferir" defer=""></script>
    <script src="/1/files/_ssgManifest.js.transferir" defer=""></script>
    <script src="/1/files/_middlewareManifest.js.transferir" defer=""></script>
    <style data-styled="kfRnWi cVXetM gDmkpo djEiOi fBhGCP iGAnoT kgGtxX ffJKBj blKmru emeEpP dnZsLI dqMSxz fkYpZa figEnY eENEBw bWyalL kiVISL kCULum gUozyr bRiBSP eSTbyw jVaBui iwtnNi cTigPH ldvuOj iokktF kRNWZr jXEgxZ bxVNCd klUYzE guwgRM bOgwhw fZnuCY cODJZD hYhJJh bVlgaj hoUCtC ePesmX hMlhZX iSGoFB bxYEql fCKyIN dXoPXd dXizbI ejknRT gQrazx dWUUBD cUucKA jzYJyP jrpnUB cVRqsD zdbPf kyIheh jBYyuL eDKhUO efVXAN kYbilJ dDCqeZ bVOcEU eoJfgb eIvsDr cvcIiC icbVOC eHwOXM Nemkk iepBmY eAwAIo bJAnnq jFgyMi knHTHK bfPuRn kkCvLf gpLrRz eRxJnk bmOdoE iNFJgy ftUfVK cgIWws xYBjs gmuskf bZjTWX cVjrLR jkMXpA keMAvC kfJxjd enVmOE dcuCfx guSngK gfOHNk fZMtdU UZVzF glUbjz eNuYmx POIpF bUwevg fGGaOW gwCLbA eiNXFk HzdZd dRWrJN hnqXgg peLBX frngKk fiOUrb hMUisr bxzIcb cjlDNK kTYQXr cdLYjS kXJqFl gFkqiA eCrNOA iXpPko dnjkl emuiHX bEADzi jpvVtk cNiJzf fJGvmw kCqCXh dYXLGk kswows fjFMmj kUyxLh kDddGi dTLtRu" data-styled-version="4.4.0">
        /* sc-component-id: sc-bdVaJa */
        .bxVNCd {
            color: #4A4A4A;
            line-height: 24px;
            font-size: 16px;
            font-weight: 400;
            font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif;
            margin: 0px;
        }

        .klUYzE {
            color: #999999;
            line-height: 24px;
            font-size: 16px;
            font-weight: 400;
            font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif;
            margin: 0px;
        }

        .guwgRM {
            color: #4A4A4A;
            line-height: 20px;
            font-size: 14px;
            font-weight: 600;
            font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif;
            margin: 0px;
        }

        .bOgwhw {
            color: #999999;
            line-height: 16px;
            font-size: 12px;
            font-weight: 400;
            font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif;
            margin: 0px;
        }

        .fZnuCY {
            color: #4A4A4A;
            line-height: 20px;
            font-size: 14px;
            font-weight: 700;
            font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif;
            margin: 0px;
        }

        .cODJZD {
            color: #999999;
            line-height: 16px;
            font-size: 12px;
            font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif;
            margin: 0px;
        }

        .hYhJJh {
            color: #4A4A4A;
            line-height: 24px;
            font-size: 16px;
            font-weight: 700;
            font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif;
            margin: 0px;
        }

        .bVlgaj {
            color: #999999;
            line-height: 16px;
            font-size: 12px;
            font-weight: 600;
            font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif;
            margin: 0px;
        }

        .hoUCtC {
            color: #999999;
            line-height: 24px;
            font-size: 16px;
            font-weight: 600;
            font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif;
            margin: 0px;
        }

        .ePesmX {
            color: #4A4A4A;
            line-height: 28px;
            font-size: 20px;
            font-weight: 700;
            font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif;
            margin: 0px;
        }

        /* sc-component-id: sc-bwzfXH */
        .djEiOi {
            cursor: pointer;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
        }

        /* sc-component-id: sc-iwsKbI */
        .emeEpP {
            margin-right: auto;
            margin-left: auto;
            max-width: 100%;
            box-sizing: border-box;
            box-sizing: border-box;
        }

        @media only screen and (min-width: 1rem) {
            .emeEpP {
                padding-left: 1rem;
                padding-right: 1rem;
            }
        }

        @media only screen and (min-width: 25rem) {
            .emeEpP {
                padding-left: 1rem;
                padding-right: 1rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .emeEpP {
                padding-left: 1rem;
                padding-right: 1rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .emeEpP {
                padding-left: 1.5rem;
                padding-right: 1.5rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .emeEpP {
                padding-left: 1.5rem;
                padding-right: 1.5rem;
            }
        }

        @media only screen and (min-width: 1rem) {
            .emeEpP {
                width: 100%;
            }
        }

        @media only screen and (min-width: 25rem) {
            .emeEpP {
                width: 100%;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .emeEpP {
                width: 100%;
            }
        }

        @media only screen and (min-width: 45rem) {
            .emeEpP {
                width: 90rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .emeEpP {
                width: 90rem;
            }
        }

        /* sc-component-id: sc-gZMcBi */
        .fkYpZa {
            box-sizing: border-box;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex: 1 0 auto;
            -ms-flex: 1 0 auto;
            flex: 1 0 auto;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
        }

        @media only screen and (min-width: 1rem) {
            .fkYpZa {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 25rem) {
            .fkYpZa {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .fkYpZa {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .fkYpZa {
                margin-left: -0.75rem;
                margin-right: -0.75rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .fkYpZa {
                margin-left: -0.75rem;
                margin-right: -0.75rem;
            }
        }

        /* sc-component-id: sc-gqjmRU */
        .kiVISL {
            box-sizing: border-box;
            -webkit-flex: 1 0 auto;
            -ms-flex: 1 0 auto;
            flex: 1 0 auto;
            max-width: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
        }

        @media only screen and (min-width: 1rem) {
            .kiVISL {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 25rem) {
            .kiVISL {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .kiVISL {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .kiVISL {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .kiVISL {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 1rem) {}

        @media only screen and (min-width: 25rem) {}

        @media only screen and (min-width: 37.5rem) {}

        @media only screen and (min-width: 45rem) {}

        @media only screen and (min-width: 52.5rem) {}

        /* sc-component-id: sc-jTzLTM */
        .iwtnNi {
            box-sizing: border-box;
        }

        /* sc-component-id: sc-kGXeez */
        .iGAnoT {
            line-height: 20px;
            font-size: 14px;
            padding-left: 16px;
            padding-right: 16px;
            height: 32px;
            min-width: 120px;
            border-width: 0px;
            border-radius: 32px;
            font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif;
            background-color: #f78323;
            color: #fff;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            cursor: pointer;
            position: relative;
            background: transparent;
            color: #f78323;
            border: 1px solid;
        }

        .iGAnoT:hover {
            background-color: rgba(0, 0, 0, 0.025);
        }

        .kgGtxX {
            line-height: 24px;
            font-size: 16px;
            padding-left: 24px;
            padding-right: 24px;
            height: 48px;
            min-width: 120px;
            border-width: 0px;
            border-radius: 32px;
            font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif;
            background-color: #f78323;
            color: #fff;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            cursor: pointer;
            position: relative;
            width: 100%;
            padding: 0 8px;
        }

        .kgGtxX:hover {
            background-color: #f99d53;
        }

        .ffJKBj:hover {
            background-color: rgba(0, 0, 0, 0.025);
        }

        /* sc-component-id: sc-jWBwVP */
        .dRWrJN {
            border-color: #D2D2D2;
        }

        /* sc-component-id: sc-brqgnP */
        .HzdZd>input {
            padding-left: 18px;
        }

        /* sc-component-id: sc-cMljjf */
        .eiNXFk {
            border-style: solid;
            border-width: 1px;
            border-radius: 8px;
            color: #4a4a4a;
            box-sizing: border-box;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            min-heigh: 48px;
            font-size: 16px;
            outline: none;
            width: 100%;
            padding-top: 11px;
            padding-bottom: 12px;
        }

        .eiNXFk::-webkit-input-placeholder {
            color: #d2d2d2;
        }

        .eiNXFk::-webkit-input-placeholder {
            color: #d2d2d2;
        }

        .eiNXFk::-moz-placeholder {
            color: #d2d2d2;
        }

        .eiNXFk:-ms-input-placeholder {
            color: #d2d2d2;
        }

        .eiNXFk::placeholder {
            color: #d2d2d2;
        }

        /* sc-component-id: sc-jAaTju */
        .jrpnUB {
            color: #6E0AD6;
            font-size: 14px;
            font-weight: 500;
            text-align: center;
            -webkit-text-decoration: none;
            text-decoration: none;
            font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif;
            cursor: pointer;
            margin-right: 20px;
        }
        }

        /* sc-component-id: sc-cHGsZl */
        .jVaBui {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
        }

        /* sc-component-id: sc-TOsTZ */
        .jXEgxZ {
            margin-left: 16px;
            font-size: 16px;
            font-weight: 500;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            cursor: pointer;
            color: inherit;
        }

        /* sc-component-id: sc-kgAjT */
        .ldvuOj {
            position: absolute;
            opacity: 0;
            cursor: pointer;
            height: 0px;
            width: 0px;
        }

        /* sc-component-id: sc-cJSrbW */
        .cTigPH {
            position: relative;
            cursor: pointer;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            width: 20px;
            height: 20px;
        }

        /* sc-component-id: sc-ksYbfQ */
        .iokktF {
            position: absolute;
            top: 0px;
            left: 0px;
            height: 16px;
            width: 16px;
            box-sizing: content-box;
            border-radius: 50%;
            border-color: #6E0AD6;
            border-width: 2px;
            border-style: solid;
            opacity: 1;
            background-color: #ffffff;
        }

        .iokktF:after {
            position: absolute;
            top: 3px;
            left: 3px;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: #6E0AD6;
            content: "";
            display: block;
        }

        .kRNWZr {
            position: absolute;
            top: 0px;
            left: 0px;
            height: 16px;
            width: 16px;
            box-sizing: content-box;
            border-radius: 50%;
            border-color: #999999;
            border-width: 2px;
            border-style: solid;
            opacity: 1;
            background-color: #ffffff;
        }

        .kRNWZr:after {
            position: absolute;
            top: 3px;
            left: 3px;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: #6E0AD6;
            content: "";
            display: none;
        }

        /* sc-component-id: sc-uJMKN */
        .gwCLbA {
            height: 8px;
        }

        /* sc-component-id: sc-bbmXgH */
        .POIpF {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            margin-bottom: 8px;
            width: 100%;
        }

        /* sc-component-id: sc-gGBfsJ */
        .hnqXgg {
            margin-top: 4px;
            height: 20px;
        }

        /* sc-component-id: sc-fYxtnH */
        .bUwevg {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
        }

        /* sc-component-id: sc-tilXH */
        .fGGaOW {
            margin-left: 6px;
        }

        /* sc-component-id: sc-global-2325347643 */
        body {
            margin: 0px;
        }

        label {
            color: #4A4A4A !important;
        }

        #__next {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            height: 100vh;
        }

        /* sc-component-id: sc-zyj8xt-0 */
        .kUyxLh {
            box-sizing: border-box;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex: 1 0 auto;
            -ms-flex: 1 0 auto;
            flex: 1 0 auto;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            padding-top: 1rem;
            padding-bottom: 2rem;
        }

        @media only screen and (min-width: 1rem) {
            .kUyxLh {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 25rem) {
            .kUyxLh {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .kUyxLh {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .kUyxLh {
                margin-left: -0.75rem;
                margin-right: -0.75rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .kUyxLh {
                margin-left: -0.75rem;
                margin-right: -0.75rem;
            }
        }

        /* sc-component-id: sc-zyj8xt-1 */
        .kDddGi {
            box-sizing: border-box;
            -webkit-flex: 1 0 auto;
            -ms-flex: 1 0 auto;
            flex: 1 0 auto;
            max-width: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            margin-top: 1rem;
            text-align: center;
        }

        @media only screen and (min-width: 1rem) {
            .kDddGi {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 25rem) {
            .kDddGi {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .kDddGi {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .kDddGi {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .kDddGi {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 1rem) {}

        @media only screen and (min-width: 25rem) {}

        @media only screen and (min-width: 37.5rem) {}

        @media only screen and (min-width: 45rem) {}

        @media only screen and (min-width: 52.5rem) {}

        /* sc-component-id: sc-zyj8xt-2 */
        .dTLtRu {
            font-size: 0.75rem;
        }

        /* sc-component-id: sc-1kvtbc7-0 */
        .gUozyr {
            margin-top: 0;
            margin-bottom: 8px;
            font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif;
            color: #4a4a4a;
            font-size: 1rem;
            font-weight: 700;
        }

        @media (min-width: 48em) {
            .gUozyr {
                font-size: 1.25rem;
                font-weight: 600;
            }
        }

        /* sc-component-id: sc-cBdUnI */
        .fjFMmj {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            visibility: visible;
        }

        /* sc-component-id: sc-exkUMo */
        .kswows {
            position: relative;
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            min-width: 72px;
            width: -webkit-fit-content;
            width: -moz-fit-content;
            width: fit-content;
            border-style: solid;
            border-width: var(--border-width-hairline);
            outline: none;
            -webkit-text-decoration: initial;
            text-decoration: initial;
            height: 48px;
            padding: var(--spacing-2) var(--spacing-3);
            font-size: var(--font-size-xs);
            line-height: var(--font-lineheight-supertight);
            background-color: var(--button-primary-background-color-base);
            border-color: var(--button-primary-border-color-base);
            color: var(--button-primary-color-font-base);
            border-radius: var(--border-radius-pill);
            font-family: var(--font-family);
            font-weight: var(--font-weight-semibold);
            cursor: pointer;
            -webkit-tap-highlight-color: transparent;
        }

        .kswows:hover {
            background-color: var(--button-primary-background-color-hover);
            border-color: var(--button-primary-border-color-hover);
        }

        .kswows:focus {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            outline: var(--color-neutral-130) solid var(--border-width-thin);
            outline-offset: var(--border-width-thin);
        }

        .kswows:focus:not(:focus-visible) {
            outline: none;
            outline-offset: 0;
        }

        .kswows:active {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            border-color: transparent;
        }

        .kswows.disabled {
            background-color: var(--button-primary-background-color-disabled);
            border-color: var(--button-primary-border-color-disabled);
            color: var(--button-primary-color-font-disabled);
        }

        .kswows:active {
            -webkit-transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            -webkit-transform: scale(0.96);
            -ms-transform: scale(0.96);
            transform: scale(0.96);
        }

        .kswows:not(:active) {
            -webkit-transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .kswows:hover {
            -webkit-transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .kswows:not(:hover) {
            -webkit-transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .kswows.disabled {
            cursor: not-allowed;
        }

        /* sc-component-id: sc-1deapui-0 */
        .bRiBSP {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            margin-bottom: 1rem;
            margin-top: 0rem;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
        }

        .eSTbyw {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            margin-bottom: 0rem;
            margin-top: 0rem;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
        }

        /* sc-component-id: sc-1deapui-2 */
        .kCULum {
            margin-bottom: 8px;
        }

        /* sc-component-id: sc-1i9pfcf-0 */
        .hMlhZX {
            margin-left: 0.5rem;
        }

        /* sc-component-id: sc-4sdp8-0 */
        .blKmru {
            margin: 0.5rem 0px 1rem;
            border: 0;
            width: 100%;
            height: 1px;
            background-color: #e5e5e5;
        }

        /* sc-component-id: sc-10njgmh-0 */
        .figEnY {
            margin: 0;
            padding-bottom: 8px;
            font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif;
            font-weight: 700;
            color: #4a4a4a;
            font-size: 1.25rem;
        }

        @media (min-width: 48em) {
            .figEnY {
                font-size: 1.5rem;
            }
        }

        @media (min-width: 62em) {
            .figEnY {
                font-size: 2.25rem;
            }
        }

        /* sc-component-id: sc-10njgmh-1 */
        .eENEBw {
            display: none;
        }

        @media (min-width: 48em) {
            .eENEBw {
                display: block;
                margin-top: 1rem;
                margin-bottom: 1.5rem;
            }
        }

        /* sc-component-id: sc-1139h5m-0 */
        .dWUUBD {
            width: 32px;
            height: 32px;
            background-color: #F7F1FD;
            border-radius: 9999px;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
        }

        /* sc-component-id: sc-1rhud07-0 */
        .ejknRT {
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
        }

        /* sc-component-id: sc-1rhud07-1 */
        .cUucKA {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
        }

        .cUucKA span:nth-child(1) {
            margin-bottom: 4px;
        }

        /* sc-component-id: sc-1rhud07-2 */
        .gQrazx {
            margin-right: 16px;
        }

        /* sc-component-id: sc-udrrgq-0 */
        .guSngK {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            background-color: #ffffff;
            padding-left: 16px;
            padding-right: 16px;
            padding-top: 16px;
            padding-bottom: 16px;
            border-radius: 8px;
            background-color: white;
            border-width: 1px;
            border-style: solid;
            border-color: #E5E5E5;
            overflow: hidden;
        }

        .guSngK:hover {
            background-color: #F9F9F9;
            cursor: pointer;
        }

        /* sc-component-id: sc-udrrgq-1 */
        .gfOHNk {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            width: 100%;
            background-color: #ffffff;
            background-color: transparent;
        }

        .fZMtdU {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            background-color: #ffffff;
            background-color: transparent;
        }

        /* sc-component-id: sc-udrrgq-2 */
        .UZVzF {
            margin-left: 16px;
        }

        /* sc-component-id: sc-udrrgq-3 */
        .eNuYmx {
            width: 100%;
            max-width: 250px;
        }

        /* sc-component-id: sc-udrrgq-4 */
        .peLBX {
            position: relative;
            height: 0;
            -webkit-transform: translateY(-103px);
            -ms-transform: translateY(-103px);
            transform: translateY(-103px);
            z-index: -1;
        }

        /* sc-component-id: sc-kj4xrf-0 */
        .dcuCfx {
            margin-bottom: 8px;
        }

        /* sc-component-id: sc-kj4xrf-3 */
        .glUbjz {
            box-sizing: border-box;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex: 1 0 auto;
            -ms-flex: 1 0 auto;
            flex: 1 0 auto;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            margin-top: 16px;
        }

        @media only screen and (min-width: 1rem) {
            .glUbjz {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 25rem) {
            .glUbjz {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .glUbjz {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .glUbjz {
                margin-left: -0.75rem;
                margin-right: -0.75rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .glUbjz {
                margin-left: -0.75rem;
                margin-right: -0.75rem;
            }
        }

        /* sc-component-id: sc-kj4xrf-4 */
        .frngKk {
            max-width: 130px;
            margin-left: 20px;
        }

        /* sc-component-id: sc-yl6wtf-0 */
        .jkMXpA {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            background-color: #ffffff;
            padding-left: 16px;
            padding-right: 16px;
            padding-top: 16px;
            padding-bottom: 16px;
            border-radius: 8px;
            background-color: white;
            border-width: 1px;
            border-style: solid;
            border-color: #E5E5E5;
            overflow: hidden;
        }

        .jkMXpA:hover {
            background-color: #F9F9F9;
            cursor: pointer;
        }

        /* sc-component-id: sc-yl6wtf-1 */
        .keMAvC {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            width: 100%;
            background-color: #ffffff;
            background-color: transparent;
        }

        .kfJxjd {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-align-items: flex-end;
            -webkit-box-align: flex-end;
            -ms-flex-align: flex-end;
            align-items: flex-end;
            background-color: #ffffff;
            background-color: transparent;
        }

        /* sc-component-id: sc-19xmqww-0 */
        .bEADzi {
            box-sizing: border-box;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex: 1 0 auto;
            -ms-flex: 1 0 auto;
            flex: 1 0 auto;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
        }

        @media only screen and (min-width: 1rem) {
            .bEADzi {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 25rem) {
            .bEADzi {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .bEADzi {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .bEADzi {
                margin-left: -0.75rem;
                margin-right: -0.75rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .bEADzi {
                margin-left: -0.75rem;
                margin-right: -0.75rem;
            }
        }

        /* sc-component-id: sc-19xmqww-1 */
        .jpvVtk {
            box-sizing: border-box;
            -webkit-flex: 1 0 auto;
            -ms-flex: 1 0 auto;
            flex: 1 0 auto;
            max-width: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-flex-flow: row wrap;
            -ms-flex-flow: row wrap;
            flex-flow: row wrap;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            margin-bottom: 0.5rem;
        }

        @media only screen and (min-width: 1rem) {
            .jpvVtk {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 25rem) {
            .jpvVtk {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .jpvVtk {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .jpvVtk {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .jpvVtk {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 1rem) {}

        @media only screen and (min-width: 25rem) {}

        @media only screen and (min-width: 37.5rem) {}

        @media only screen and (min-width: 45rem) {}

        @media only screen and (min-width: 52.5rem) {}

        /* sc-component-id: sc-19xmqww-3 */
        .cNiJzf {
            box-sizing: border-box;
            -webkit-flex: 1 0 auto;
            -ms-flex: 1 0 auto;
            flex: 1 0 auto;
            max-width: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-flex-flow: row wrap;
            -ms-flex-flow: row wrap;
            flex-flow: row wrap;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            margin-bottom: 0.5rem;
        }

        @media only screen and (min-width: 1rem) {
            .cNiJzf {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 25rem) {
            .cNiJzf {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .cNiJzf {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .cNiJzf {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .cNiJzf {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 1rem) {}

        @media only screen and (min-width: 25rem) {}

        @media only screen and (min-width: 37.5rem) {}

        @media only screen and (min-width: 45rem) {}

        @media only screen and (min-width: 52.5rem) {}

        /* sc-component-id: sc-19xmqww-7 */
        .fJGvmw {
            box-sizing: border-box;
            -webkit-flex: 1 0 auto;
            -ms-flex: 1 0 auto;
            flex: 1 0 auto;
            max-width: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-flex-flow: row wrap;
            -ms-flex-flow: row wrap;
            flex-flow: row wrap;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            margin-bottom: 0.5rem;
        }

        @media only screen and (min-width: 1rem) {
            .fJGvmw {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 25rem) {
            .fJGvmw {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .fJGvmw {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .fJGvmw {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .fJGvmw {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 1rem) {}

        @media only screen and (min-width: 25rem) {}

        @media only screen and (min-width: 37.5rem) {}

        @media only screen and (min-width: 45rem) {}

        @media only screen and (min-width: 52.5rem) {}

        /* sc-component-id: sc-19xmqww-8 */
        .kCqCXh {
            margin: 0.5rem 0 1rem 0;
        }

        /* sc-component-id: sc-lvlx2m-0 */
        .eCrNOA {
            max-width: 100%;
            height: auto;
            box-sizing: border-box;
        }

        /* sc-component-id: sc-1qfz6i4-0 */
        .gFkqiA {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            width: 95px;
            min-width: 95px;
            height: 71px;
            border-radius: 8px;
            box-sizing: border-box;
            background-color: #E5E5E5;
        }

        /* sc-component-id: sc-17yhrpg-0 */
        .cdLYjS {
            box-sizing: border-box;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex: 1 0 auto;
            -ms-flex: 1 0 auto;
            flex: 1 0 auto;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            padding-bottom: 0.625rem;
        }

        @media only screen and (min-width: 1rem) {
            .cdLYjS {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 25rem) {
            .cdLYjS {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .cdLYjS {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .cdLYjS {
                margin-left: -0.75rem;
                margin-right: -0.75rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .cdLYjS {
                margin-left: -0.75rem;
                margin-right: -0.75rem;
            }
        }

        @media (min-width: 62em) {
            .cdLYjS {
                padding-bottom: 1rem;
            }
        }

        /* sc-component-id: sc-17yhrpg-1 */
        .kXJqFl {
            box-sizing: border-box;
            -webkit-flex: 1 0 auto;
            -ms-flex: 1 0 auto;
            flex: 1 0 auto;
            max-width: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
        }

        @media only screen and (min-width: 1rem) {
            .kXJqFl {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 25rem) {
            .kXJqFl {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .kXJqFl {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .kXJqFl {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .kXJqFl {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 1rem) {}

        @media only screen and (min-width: 25rem) {}

        @media only screen and (min-width: 37.5rem) {}

        @media only screen and (min-width: 45rem) {}

        @media only screen and (min-width: 52.5rem) {}

        /* sc-component-id: sc-17yhrpg-2 */
        .iXpPko {
            margin-left: 1rem;
            font-weight: 400;
        }

        @media (min-width: 48em) {
            .iXpPko {
                font-weight: 600;
            }
        }

        /* sc-component-id: sc-17yhrpg-3 */
        .dnjkl {
            box-sizing: border-box;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex: 1 0 auto;
            -ms-flex: 1 0 auto;
            flex: 1 0 auto;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            padding-bottom: 0;
        }

        @media only screen and (min-width: 1rem) {
            .dnjkl {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 25rem) {
            .dnjkl {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .dnjkl {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .dnjkl {
                margin-left: -0.75rem;
                margin-right: -0.75rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .dnjkl {
                margin-left: -0.75rem;
                margin-right: -0.75rem;
            }
        }

        @media (min-width: 62em) {
            .dnjkl {
                padding-bottom: 0.25rem;
            }
        }

        /* sc-component-id: sc-16dgyc9-0 */
        .bxzIcb {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            margin-right: 0 !important;
            margin-left: 0 !important;
            padding-top: 1.5rem;
            border: 0 solid #E5E5E5;
        }

        @media (min-width: 62em) {
            .bxzIcb {
                border-width: 1px;
                border-radius: 8px;
                padding-bottom: 1.5rem;
            }
        }

        /* sc-component-id: sc-16dgyc9-1 */
        .cjlDNK {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            padding: 0 !important;
        }

        @media (min-width: 62em) {
            .cjlDNK {
                padding: 0 1.5rem !important;
            }
        }

        /* sc-component-id: sc-16dgyc9-2 */
        .kTYQXr {
            margin: 0;
        }

        @media (min-width: 62em) {
            .kTYQXr {
                margin: 0 0.5rem;
            }
        }

        /* sc-component-id: sc-16dgyc9-3 */
        .emuiHX {
            margin: 1rem 0;
        }

        /* sc-component-id: sc-16dgyc9-4 */
        .dYXLGk {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            padding-top: 1rem;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            gap: var(--spacing-1);
            --button-secondary-background-color-base: var(--color-neutral-70);
        }

        .dYXLGk button {
            width: 100%;
        }

        @media (min-width: 62em) {
            .dYXLGk {
                padding-top: 0.5rem;
            }
        }

        /* sc-component-id: sc-dPNhBE */
        .bmOdoE {
            color: #6e0ad6;
            font-size: 14px !important;
            font-weight: 600;
            text-align: center !important;
            -webkit-text-decoration: none !important;
            text-decoration: none !important;
            font-family: "Nunito Sans", sans-serif !important;
            cursor: pointer;
        }

        /* sc-component-id: sc-cgzHhG */
        .eoJfgb {
            width: 100%;
            position: relative;
            border-style: solid;
            border-width: 0px;
            border-top-width: 1px;
            border-color: #f2f2f2;
        }

        /* sc-component-id: sc-dlyikq */
        .eHwOXM {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-flex: 1;
            -webkit-flex-grow: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
        }

        .Nemkk {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            width: 100%;
        }

        .iepBmY {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            width: 30%;
        }

        .eAwAIo {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            width: 64%;
        }

        /* sc-component-id: sc-gQNndl */
        .cgIWws {
            position: relative !important;
            border-style: solid !important;
            border-color: #d2d2d2 !important;
            border-width: 1px !important;
            border-radius: 4px !important;
            width: 100% !important;
            min-height: 48px !important;
            padding-top: 11px !important;
            padding-bottom: 12px !important;
            padding-left: 16px !important;
            color: #4a4a4a !important;
            font-size: 16px !important;
            box-sizing: border-box !important;
            font-family: 'Nunito Sans' !important;
            outline: none;
        }

        .cgIWws::-webkit-input-placeholder {
            color: #d2d2d2 !important;
        }

        .cgIWws::-webkit-input-placeholder {
            color: #d2d2d2 !important;
        }

        .cgIWws::-moz-placeholder {
            color: #d2d2d2 !important;
        }

        .cgIWws:-ms-input-placeholder {
            color: #d2d2d2 !important;
        }

        .cgIWws::placeholder {
            color: #d2d2d2 !important;
        }

        .cgIWws:focus {
            border-color: #999 !important;
        }

        /* sc-component-id: sc-dNoQZL */
        .gpLrRz {
            font-size: 16px;
            font-weight: bold;
            color: #4a4a4a;
        }

        /* sc-component-id: sc-ckYZGd */
        .eRxJnk {
            font-size: 12px;
            font-weight: 400;
            color: #999999;
        }

        /* sc-component-id: sc-eweMDZ */
        .knHTHK {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
        }

        .bfPuRn {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
        }

        /* sc-component-id: sc-cnTzU */
        .xYBjs {
            margin-left: 6px;
        }

        /* sc-component-id: sc-eQGPmX */
        .jFgyMi {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            margin-bottom: 8px;
        }

        /* sc-component-id: sc-dAOnuy */
        .iNFJgy {
            padding-top: 8px;
        }

        /* sc-component-id: sc-dBfaGr */
        .efVXAN {
            padding: 0px;
            cursor: unset;
            width: 24px;
            height: 24px;
        }

        /* sc-component-id: sc-giOsra */
        .ftUfVK {
            position: relative;
            -webkit-flex: 1 0;
            -ms-flex: 1 0;
            flex: 1 0;
        }

        /* sc-component-id: sc-fATqzn */
        .cVRqsD {
            position: fixed;
            top: 0px;
            bottom: 0px;
            left: 0px;
            right: 0px;
            background-color: rgba(0, 0, 0, 0.55);
            z-index: 9999;
            display: none;
        }

        .cVRqsD.fade-enter {
            opacity: 0;
        }

        .cVRqsD.fade-enter-active {
            opacity: 1;
            -webkit-transition: opacity 300ms;
            transition: opacity 300ms;
        }

        .cVRqsD.fade-exit {
            opacity: 1;
        }

        .cVRqsD.fade-exit-active {
            opacity: 0;
            -webkit-transition: opacity 500ms;
            transition: opacity 500ms;
        }

        /* sc-component-id: sc-jbWsrJ */
        .zdbPf {
            background-color: #fff;
            padding: 32px 24px;
            position: absolute;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            top: 50%;
            -webkit-transform: translate(-50%, -50%);
            -ms-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%);
            left: 50%;
            border-radius: 10px;
            width: 400px;
        }

        @media (max-width: 440px) {
            .zdbPf {
                width: 90%;
            }
        }

        /* sc-component-id: sc-hqGPoI */
        .kyIheh {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            -webkit-align-items: flex-start;
            -webkit-box-align: flex-start;
            -ms-flex-align: flex-start;
            align-items: flex-start;
            height: 32px;
        }

        /* sc-component-id: sc-iWadT */
        .jBYyuL {
            margin-left: auto;
        }

        /* sc-component-id: sc-kDgGX */
        .eIvsDr {
            width: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
        }

        /* sc-component-id: sc-cLxPOX */
        .cvcIiC {
            width: 100%;
            margin-top: 24px;
        }

        /* sc-component-id: sc-ekHBYt */
        .bJAnnq {
            margin-bottom: 0px;
        }

        /* sc-component-id: sc-eTyWNx */
        .icbVOC {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            margin-bottom: 16px;
        }

        /* sc-component-id: sc-exdmVY */
        .gmuskf {
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            margin-top: 32px;
        }

        /* sc-component-id: sc-hDgvsY */
        .dDCqeZ {
            color: #4a4a4a;
            font-size: 20px;
            text-align: center;
            font-weight: 600;
            margin-bottom: 0.78em;
            margin-top: 0.78em;
            font-size: 20px;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
        }

        /* sc-component-id: sc-gtXRHa */
        .bVOcEU {
            margin-bottom: 16px;
        }

        /* sc-component-id: sc-bWjmDF */
        .kYbilJ {
            margin-bottom: 94px;
        }

        /* sc-component-id: sc-ccvjgv */
        .bxYEql {
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
        }

        /* sc-component-id: sc-10yflc7-0 */
        .dXoPXd {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            background-color: #ffffff;
            padding-left: 16px;
            padding-right: 16px;
            padding-top: 16px;
            padding-bottom: 16px;
            border-radius: 8px;
            background-color: white;
            border-width: 1px;
            border-style: solid;
            border-color: #E5E5E5;
            overflow: hidden;
        }

        .dXoPXd:hover {
            background-color: #F9F9F9;
            cursor: pointer;
        }

        /* sc-component-id: sc-10yflc7-1 */
        .dXizbI {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            width: 100%;
            background-color: #ffffff;
            background-color: transparent;
        }

        /* sc-component-id: sc-10yflc7-2 */
        .fCKyIN {
            box-sizing: border-box;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex: 1 0 auto;
            -ms-flex: 1 0 auto;
            flex: 1 0 auto;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            margin-top: 34px;
            padding-right: 0.5em;
            padding-left: 0.5em;
        }

        @media only screen and (min-width: 1rem) {
            .fCKyIN {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 25rem) {
            .fCKyIN {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .fCKyIN {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .fCKyIN {
                margin-left: -0.75rem;
                margin-right: -0.75rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .fCKyIN {
                margin-left: -0.75rem;
                margin-right: -0.75rem;
            }
        }

        @media (min-width: 62em) {
            .fCKyIN {
                padding-right: 0.75em;
                padding-left: 0.75em;
            }
        }

        /* sc-component-id: sc-10yflc7-3 */
        .jzYJyP {
            margin-left: 5px;
        }

        /* sc-component-id: sc-7lu0e1-0 */
        .fBhGCP a {
            -webkit-text-decoration: none;
            text-decoration: none;
        }

        /* sc-component-id: sc-1ncn2up-0 */
        .cVXetM {
            box-sizing: border-box;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex: 1 0 auto;
            -ms-flex: 1 0 auto;
            flex: 1 0 auto;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            padding: 16px;
        }

        @media only screen and (min-width: 1rem) {
            .cVXetM {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 25rem) {
            .cVXetM {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .cVXetM {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .cVXetM {
                margin-left: -0.75rem;
                margin-right: -0.75rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .cVXetM {
                margin-left: -0.75rem;
                margin-right: -0.75rem;
            }
        }

        @media (min-width: 48em) {
            .cVXetM {
                padding: 24px;
            }
        }

        /* sc-component-id: sc-1ncn2up-1 */
        .gDmkpo {
            box-sizing: border-box;
            -webkit-flex: 1 0 auto;
            -ms-flex: 1 0 auto;
            flex: 1 0 auto;
            max-width: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            max-height: 32px;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
        }

        @media only screen and (min-width: 1rem) {
            .gDmkpo {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 25rem) {
            .gDmkpo {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .gDmkpo {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .gDmkpo {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .gDmkpo {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 1rem) {}

        @media only screen and (min-width: 25rem) {}

        @media only screen and (min-width: 37.5rem) {}

        @media only screen and (min-width: 45rem) {}

        @media only screen and (min-width: 52.5rem) {}

        /* sc-component-id: sc-14t1fz-0 */
        .kfRnWi {
            margin-right: auto;
            margin-left: auto;
            max-width: 100%;
            box-sizing: border-box;
            box-sizing: border-box;
            padding: 0 !important;
            margin-bottom: 32px;
        }

        @media only screen and (min-width: 1rem) {
            .kfRnWi {
                padding-left: 1rem;
                padding-right: 1rem;
            }
        }

        @media only screen and (min-width: 25rem) {
            .kfRnWi {
                padding-left: 1rem;
                padding-right: 1rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .kfRnWi {
                padding-left: 1rem;
                padding-right: 1rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .kfRnWi {
                padding-left: 1.5rem;
                padding-right: 1.5rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .kfRnWi {
                padding-left: 1.5rem;
                padding-right: 1.5rem;
            }
        }

        @media only screen and (min-width: 1rem) {
            .kfRnWi {
                width: 95%;
            }
        }

        @media only screen and (min-width: 25rem) {
            .kfRnWi {
                width: 100%;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .kfRnWi {
                width: 100%;
            }
        }

        @media only screen and (min-width: 45rem) {
            .kfRnWi {
                width: 90rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .kfRnWi {
                width: 90rem;
            }
        }

        /* sc-component-id: sc-1j45kmn-0 */
        .fiOUrb {
            display: block;
            margin-top: 1rem;
        }

        @media (min-width: 62em) {
            .fiOUrb {
                display: none;
                margin-top: 0;
            }
        }

        /* sc-component-id: sc-vjr81a-0 */
        .dnZsLI {
            box-sizing: border-box;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex: 1 0 auto;
            -ms-flex: 1 0 auto;
            flex: 1 0 auto;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            -webkit-align-items: flex-start;
            -webkit-box-align: flex-start;
            -ms-flex-align: flex-start;
            align-items: flex-start;
        }

        @media only screen and (min-width: 1rem) {
            .dnZsLI {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 25rem) {
            .dnZsLI {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .dnZsLI {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .dnZsLI {
                margin-left: -0.75rem;
                margin-right: -0.75rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .dnZsLI {
                margin-left: -0.75rem;
                margin-right: -0.75rem;
            }
        }

        @media (min-width: 62em) {
            .dnZsLI {
                margin-right: 2.25rem;
                margin-left: 2.25rem;
                padding-bottom: 2rem;
            }
        }

        /* sc-component-id: sc-vjr81a-1 */
        .dqMSxz {
            box-sizing: border-box;
            -webkit-flex: 1 0 auto;
            -ms-flex: 1 0 auto;
            flex: 1 0 auto;
            max-width: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
        }

        @media only screen and (min-width: 1rem) {
            .dqMSxz {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 25rem) {
            .dqMSxz {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .dqMSxz {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .dqMSxz {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .dqMSxz {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 1rem) {}

        @media only screen and (min-width: 25rem) {}

        @media only screen and (min-width: 37.5rem) {}

        @media only screen and (min-width: 45rem) {}

        @media only screen and (min-width: 52.5rem) {}

        @media (min-width: 62em) {
            .dqMSxz {
                -webkit-flex: 1 1 52%;
                -ms-flex: 1 1 52%;
                flex: 1 1 52%;
                max-width: 52%;
            }
        }

        /* sc-component-id: sc-vjr81a-2 */
        .bWyalL {
            padding-top: 1.5rem;
        }

        /* sc-component-id: sc-vjr81a-3 */
        .iSGoFB {
            padding-top: 1rem;
        }

        @media (min-width: 62em) {
            .iSGoFB {
                padding-top: 2rem;
            }
        }

        /* sc-component-id: sc-vjr81a-4 */
        .bZjTWX {
            padding-top: 1rem;
        }

        @media (min-width: 62em) {
            .bZjTWX {
                padding-top: 2rem;
            }
        }

        /* sc-component-id: sc-vjr81a-5 */
        .cVjrLR {
            padding-top: 1.5rem;
        }

        @media (min-width: 62em) {
            .cVjrLR {
                padding-top: 1rem;
            }
        }

        /* sc-component-id: sc-vjr81a-6 */
        .enVmOE {
            padding-top: 1rem;
        }

        @media (min-width: 62em) {
            .enVmOE {
                padding-top: 2rem;
            }
        }

        /* sc-component-id: sc-vjr81a-7 */
        .hMUisr {
            box-sizing: border-box;
            -webkit-flex: 1 0 auto;
            -ms-flex: 1 0 auto;
            flex: 1 0 auto;
            max-width: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
        }

        @media only screen and (min-width: 1rem) {
            .hMUisr {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 25rem) {
            .hMUisr {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .hMUisr {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .hMUisr {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .hMUisr {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 1rem) {}

        @media only screen and (min-width: 25rem) {}

        @media only screen and (min-width: 37.5rem) {}

        @media only screen and (min-width: 45rem) {}

        @media only screen and (min-width: 52.5rem) {}

        @media (min-width: 62em) {
            .hMUisr {
                -webkit-flex: 1 1 36%;
                -ms-flex: 1 1 36%;
                flex: 1 1 36%;
                max-width: 36%;
            }
        }

        @media (min-width: 75em) {
            .hMUisr {
                -webkit-flex: 1 1 32%;
                -ms-flex: 1 1 32%;
                flex: 1 1 32%;
                max-width: 32%;
            }
        }
    </style>
    <style data-href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@300;400;600;700&amp;display=swap">
        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 300;
            font-stretch: normal;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GiClntw.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 400;
            font-stretch: normal;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4G1ilntw.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 600;
            font-stretch: normal;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GCC5ntw.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 700;
            font-stretch: normal;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GMS5ntw.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 300;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 300;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 300;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 300;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 300;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 600;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 600;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 600;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 600;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 600;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 700;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 700;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 700;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 700;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 700;
            font-stretch: 100%;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }
    </style>
    <style data-href="https://fonts.googleapis.com/css?family=Nunito+Sans:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 200;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1kMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwXeVy3GboJ0kTHmoP92UnK_Q.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 300;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1kMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwXeVy3GboJ0kTHmrR92UnK_Q.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 400;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1kMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwXeVy3GboJ0kTHmqP92UnK_Q.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 600;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1kMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwXeVy3GboJ0kTHmpR8GUnK_Q.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 700;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1kMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwXeVy3GboJ0kTHmpo8GUnK_Q.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 800;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1kMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwXeVy3GboJ0kTHmoP8GUnK_Q.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 900;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1kMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwXeVy3GboJ0kTHmom8GUnK_Q.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 200;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GVilXs1Uj.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 300;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GiClXs1Uj.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 400;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4G1ilXs1Uj.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 600;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GCC5Xs1Uj.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 700;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GMS5Xs1Uj.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 800;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GVi5Xs1Uj.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 900;
            font-stretch: normal;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4Gfy5Xs1Uj.woff) format('woff')
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 200;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-RaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 200;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-1aLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 200;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-ZaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 200;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-daLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 200;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-laLZx3lE4.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 300;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-RaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 300;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-1aLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 300;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-ZaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 300;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-daLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 300;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-laLZx3lE4.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 400;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-RaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 400;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-1aLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 400;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-ZaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 400;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-daLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 400;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-laLZx3lE4.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 600;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-RaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 600;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-1aLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 600;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-ZaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 600;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-daLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 600;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-laLZx3lE4.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 700;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-RaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 700;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-1aLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 700;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-ZaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 700;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-daLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 700;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-laLZx3lE4.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 800;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-RaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 800;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-1aLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 800;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-ZaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 800;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-daLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 800;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-laLZx3lE4.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 900;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-RaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 900;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-1aLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 900;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-ZaLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 900;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-daLZx3lE4-Hw.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: italic;
            font-weight: 900;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0RMImSLYBIv1o4X1M8cce4OdVisMz5nZRqy6cmmmU3t2FQWEAEOvV9wNvrwlNstMKW3Y6K5WMwd-laLZx3lE4.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 200;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 200;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 200;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 200;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 200;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 300;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 300;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 300;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 300;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 300;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 600;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 600;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 600;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 600;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 600;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 700;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 700;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 700;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 700;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 700;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 800;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 800;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 800;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 800;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 800;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 900;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 900;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 900;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 900;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF
        }

        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 900;
            font-stretch: 100%;
            src: url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
        }
    </style>
<style type="text/css">.eruda-search-highlight-block{display:inline}.eruda-search-highlight-block .eruda-keyword{background:#332a00;color:#ffcb6b}</style><style type="text/css">@font-face{font-family:eruda-icon;src:url('data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAA6UAAsAAAAAGvAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAARoAAAHeLjoycE9TLzIAAAIkAAAAPwAAAFZWm1KoY21hcAAAAmQAAAFdAAADwhPu1O9nbHlmAAADxAAAB+wAAA9I7RPQpGhlYWQAAAuwAAAAMQAAADZ26MSyaGhlYQAAC+QAAAAdAAAAJAgEBC9obXR4AAAMBAAAAB0AAACwXAv//GxvY2EAAAwkAAAAOwAAAFpuVmoybWF4cAAADGAAAAAfAAAAIAE9AQ1uYW1lAAAMgAAAASkAAAIWm5e+CnBvc3QAAA2sAAAA5QAAAU4VMmUJeJxNkD1Ow0AQhb9NHGISCH9RiB0cErCNHRrqFFSIyqKiQHSpEFJERUnBCTgPZ+AEHIe34wDe1f69efPezOKAHldc07q5re4ZrFevL8QE1MPHm3e3fn5aEf6+FAvsDHHuTUoxd7zzwSdffLulq9wjLbaYau8TacZMONE554xzZsrtNfBEzFOhbSmOyTmga0ikvRR/37RSsSMyDukYPjWdgGOtsSK55Y/k0Bf/ksK0MrbFr70idsVZKNPnDcSay3umd2TISCvWTJSxI78lFQ/C+qbv/Zo9tNXDP55ZL7k0Q90u5F5XX0qrYx16btccCtXg/ULrKzGFuqY9rUTMhf3fkCNj+MxUnsM/frr5Qx+ZbH4vVQ0F5Q/ZQBvxAAB4nGNgZJJgnMDAysDA1Mt0hoGBoR9CM75mMGLkAIoysDIzYAUBaa4pDAcYdD+KsIC4MSxMDIxAGoQZALgnCOUAeJy1011SGlEQhuF3BFHxD5UUyr8gIJIsiiKJsSqJlrHKsJssKFeuxF6Bfj3dF96aqhzqoZnDzJyG8w2wCVTko1SheKLAx1/NFuV8hXo5X+WPjht6+fmfWHLDHQ+srfnykjMrvnPPoxXlzNtRlFc26HLBZblal1N9ntBnwIgx5/SYMaWt78+YM6TDgitduaEVq+q0xhbb7KifPQ441N2OOOaEJh9oaYka7xvdd57vQz1P+oPR+Bx6s2lbrc6H0Flc/cO9/sfY87fiOY8u8X0J/muX6VRW6UI+p4l8SX35mgZynUbyLY3lJukf0e6HnvxIM/mZpnKb2nKXvM/7dCa/0lwe0lAeU0d+p4Wsk3bBiuDptY2A10rw9Fo1eOJtM/iTYLWA162A1+2A152A13rwJ8R2g++AJaUU2w/KK3YQlFzsMCjDWCMozdhRUK6x46CEYydBWceagdYraihRngAAAHic7RdbbBxX9Z57Z2d2d2ZndryzM7ve9ax3NztjO/bann0lTuW16zoBJSWJ7Zg83NiUJCQ1Ik2ikKQJNC9FFQqVEG0RVLQoSpEKH2klqgpEIyWAUMRTNBJC/PUDhETgiwhQd8y5s1s7oqr624/srO6ce89zzjn3nHsJEPwxyn5GVEJKBTcCdc80pAiYhkjfNWL+NnhLdTKqfxVOqJlxFX6E84wb86/6X4+5GRLw0/vsOgkREoFGBFx62P/uFviBP78FWrC02d/r79vcpmMl+k2uBwwJxIILTrVeyXsmK8krRLb5YGqUaCb9ksYnMuBqMtnRcY6V1nidml6texaY9CxSRm3TtKNIjcxrUjhEWKD3OnuNJEgPKSG/I6nUpo06fxwXH8lmEoyDFQIVyrROs7254z990rj0u2PLez47WqG1yu69V7ZdfDxU9He4C6P+v+HN+vlnD9Uou0Zp+NnfvveT/XL0kbGFxT/u37tx7CTdeuGlKfiibcMr/gt9qfyu05e4+YEdb7A3iEVG0ArdEAvDIPHBqTbB7bgCDA0sdH0x3/nEHDT4YFJi9siz74iaOBkK3ZyRTRXwE+FGG15BeA0Pf14hqinP3AyFJnHhnVm5xzThmNSBNFjDdvwzw75GFJIlvWhZ1UHlYlI3zIputa3CSduiRF7P09e9on+jODpanPOKsJMDOPV2wU7/BqsVPcQ2ix41X/8ARKpbfhPVtHNgik1hXAhIlmQ1rIbbcCVIzN/7+65794KRTc13IBwJXVkhRACBkAEyhVyiBqJbRn81YRjKUDfRN9xHpoVBt0xJRZ+iS4ehZFg2utJrjCO2GrAUAizcj+c3pXpiXVQwThZmdNrbrx+hAjtjbhSF5FPyKSsqmGraWKYCbfl97vMLi79fXHje7XsAhBsoo0P35fyMPpCj+lM0FDptJexuYzl82upRufxlKgrTh/+fOwBXc+Jt9jZJBTnxUbH/yGT5j4jRT2pB9O1oO/oi3FyD2/ggU14LY/j5RuHTJIZf5LR/WVmbaB2CT6xdQa4KwJZIHPfyMFoWRNSmQZDLlJVpdRw8GwwVWEGlScOGijdOq2VKyfHDB7/d1/+d37zXeT/dXG42l7/Kh2a20pd0JpxsxTVNt8KWyuu/94Ujr+7uvFpvQXP5PCfEAU4l+6pZZ9Ix3eqGqmsGrvok28V+zi6TKEYyi/Udt0MNavkkJC1e+vQA1tGqil6EV93j/UBbY0AXm/2Vku+z53x/8MDT5879U9Nb4Cqq/yf/WEjReiECfS9+C2f/6umFS/77q3t7kp0nGu8DTrFTQrwG1KtsoHVXlnXL0qMKHTRpGbaJlt7aoVsSbO3aQFb5L7MTJElIwrBMvnWxQteCEl2QREn8Ci/Ef9i7u1IT6tX5Pb/ePV+rUXKEL3DMkUPzc6OeNzo3/6C8K2QdrzVlKAYyHhBcxGgUyoCRqXimJZXYwYO1y1tWxQWKLkyfunpqevrU5vJs4SQ02JUDw94qMlC6maORJpc9AR/Sm7C4cK7S4MoL/FNqFYy+Nw5VbpIoWaWXP0atf+fj1Lb36w12h6SxShIouuNQw+TCVDNsWvHqDStpNUoFnobUs6mhUvpmn+r2VxaeuXjmCc974vSjm44OxfytrXeH5iaKxYm5fXMThcLEHLwcGzq66dHTnObMxWcWKv2u2tfa1ipMzu7rEM5OFshqLfsFu4R9thszrVjAUoHFgH98DxRreb3CK74rMTh/bWmJTq9Pd0nCZOvsbfrYrVsTty9cOPc5Or2U6spq8rXbrbNAL9yeuHWLYuEnEiErK0JIAPIN8kNyl9wn/yUt7mioN6GGTi1jDQrypNPRxQ+8zREatnUsVtgbcDHAaZA0rc6TxOIWLPFVXLDbvYRT45CDSnBOqFhee4aTcWw8gapGnS+Z+EYrOuqh825jrY5WSVwPDSewh/OWqYueCJQFEjhELTdgcdEODjUCo5yge7lcAlJxRSgceyZyu5LFfqnaeldKlsyunnK6N6LEaUSqTSndgpZK7jC7NZaR7LGcGhXwgMNC+WFt0MxEomZcECQ9EY4JkgAQDilSNKnGuxXJ0u2hdG9YUZkiZcfWpaOWkUv0G6IaCseVVH81o0dEEClKGokassX0hKSk44PxBGOS4E8cmNk+OMSY5+2cXfz8zI4hrG4jI9tnFpW/hqKx7PCnH1O7wpFkqeANT4IUVhopPTUwnNJxzSlUzLASV+4YfUIkpoQFTYvoMUFkJgtJ/Z6VEIyymx4usdCW5CuDc9s+dZDm6GeiejTl1jN6VFKUdMHMlUIWzaQEOdyrKHIsL0VZJB0TE1rUlLvCo71yPKya3dW+ONBQRBajUdPuKoXFsBAOiYoUdx7JtSXlU3ZJNAW1O+4ktBCFqBjLJhMW97JgyonISE5kVIJQJJ6tO6nueCJj1TV/D6uMzu06tH/H44NlRr3RnbNPLu7cXh75sWOklURzi5ZI9dgqG6tuEAf0bkWX0/0j6S6+RjfaYiQsbkKHhuNdms6kUExWZNGSlJgzkjIGjPK61KjLxOvGc/1/27r9KOQe7omHe+LhnvjQnmArLTyHMYHiPbGbFLEL4Q1BxOsiHrfy2HIBz67BXQbPsVbB4TNDZP/wF4x63cAxUl/PRtbXI61f2QM2/iuZUqleKr3ABp1Mxnn/rjvpOJN0b9K2k/73+Xi/VHOcGl4qyf8AzjWNo3icY2BkYGAA4uhnXafj+W2+MnCzgASiOB/va4DR///+/8/CysIElOBgAJEMAHS2DWQAAAB4nGNgZGBgYQABFtb/f///ZWFlYGRABToAW+YEPQAAAHicY2BgYGAhiP//J6wGCbNCMcP/vwxUBgDl4QRhAAAAeJxjYAACBQYThiCGAoYtjAyMZowBjPuYuJjCmBYxvWNWYXZhzmFewfyIRYUliPUOexr7EmIhAF3rF0sAeJxjYGRgYNBhZGRgZwABJiDmAkIGhv9gPgMADcIBTAB4nGWQPW7CQBSEx2BIAlKCFCkps1UKIpmfkgNAT0GXwpi1MbK91npBossJcoQcIaeIcoIcKGPzaGAtP38zb97uygAG+IWHenm4bWq9WrihOnGb9CDsk5+FO+jjRbhLfyjcwxumwn084p07eP4dnQFK4Rbu8SHcpv8p7JO/hDt4wrdwl/6PcA8r/An38eoN08gUsSncUif7LLRnef6utK1SU6hJMD5bC11oGzq9Ueujqg7J1LlYxdbkas6uzjKjSmt2OnLB1rlyNhrF4geRyZEigkGBuKkOS2gk2CNDCHvVvdQrpi0q+rVWmCDA+Cq1YKpokiGVxobJNY6sFQ48bUrXMa34Ws7kpLnMat4kIyv+77q3oxPRD7BtpkrMMOITX+SD5g75Pz0RXqgAAAB4nG2MyW6DQBiD+RKYpKT7vqf7Gg55pNHwEyJNGDSMRHj70nKtD7Zly45G0YA0+h8LRoyJSVBMmLJDyoxd9tjngEOOOOaEU84454JLrrjmhlvuuGfOA4888cwLr7zxzgeffPHNgixKtfeuzawUYTZYv16VITXaS8hy11azwf7FibGi/dS4Te2laWLj6k7lYiVIIv3aK9nWusqng2TLsXR900m2VMXaBvFxbXWnvBjn84mXor8pk54kqKa/NmUvVkyIg3NW/VK2jFvtKzQeR0uGRSgIrFlRYsip2FDT0LGNoh/MCkh9AAAA') format('woff')}[class*=' eruda-icon-'],[class^='eruda-icon-']{display:inline-block;font-family:eruda-icon!important;font-size:16px;font-style:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.eruda-icon-arrow-left:before{content:'\f101'}.eruda-icon-arrow-right:before{content:'\f102'}.eruda-icon-caret-down:before{content:'\f103'}.eruda-icon-caret-right:before{content:'\f104'}.eruda-icon-clear:before{content:'\f105'}.eruda-icon-compress:before{content:'\f106'}.eruda-icon-copy:before{content:'\f107'}.eruda-icon-delete:before{content:'\f108'}.eruda-icon-error:before{content:'\f109'}.eruda-icon-expand:before{content:'\f10a'}.eruda-icon-eye:before{content:'\f10b'}.eruda-icon-filter:before{content:'\f10c'}.eruda-icon-play:before{content:'\f10d'}.eruda-icon-record:before{content:'\f10e'}.eruda-icon-refresh:before{content:'\f10f'}.eruda-icon-reset:before{content:'\f110'}.eruda-icon-search:before{content:'\f111'}.eruda-icon-select:before{content:'\f112'}.eruda-icon-tool:before{content:'\f113'}.eruda-icon-warn:before{content:'\f114'}@font-face{font-family:luna-console-icon;src:url('data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAAasAAsAAAAACnAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAAI4AAADcIsYnIk9TLzIAAAGYAAAAPgAAAFZWmlGRY21hcAAAAdgAAAD2AAACyDioZ9NnbHlmAAAC0AAAAZgAAAH8Lq6nDGhlYWQAAARoAAAAMQAAADZ25cSzaGhlYQAABJwAAAAdAAAAJAgCBBRobXR4AAAEvAAAABkAAABYGAH//GxvY2EAAATYAAAAGAAAAC4J8glUbWF4cAAABPAAAAAfAAAAIAEjAFBuYW1lAAAFEAAAASkAAAIWm5e+CnBvc3QAAAY8AAAAcAAAAJ7qA/7MeJxNjTsOwjAQRJ8TJzE2hPBrKBBHQByAAiGqFBRcIBVCiqhyBA7O2AgRr9Y7M2+lxQCeAyeyy7W9U/fd8GKL5fsiH2vTPx8d7ufEbJpO/aagYc+RM7fEjBKnmiRuySmZUTNNf0wybYSRj9VoO4iU7NQh+Up8qelZs5EupP75Shfm2oz3Kmkvt/gARcgJKwAAeJxjYGQUZ5zAwMrAwNTJdIaBgaEfQjO+ZjBi5ACKMrAyM2AFAWmuKQwHGHQ/srGAuDEsTGBhRhABALQ1CMwAAHiczdJNbsIwEIbh1+QHQsJviNRFF1XX7aEQRZQNRQjEHXqgrnopn4B+E8+qqip117GeRB4nk4lloAAyeZIcwicBiw9lQ5/PGPf5nHfNV8yVyXlmzZY9R05cuMbydtOqZTfsOCh7Vjb02e8RVMXGHfc8aDxqwFKVF7QMtdLpmzUVDSOmTJjpnUH/3YJSBcofqv4Wyz8+b6FuWvXSjW1SV30r1sl/icYuofFZh+1+Yn+7dnPZuIW8uFa2big7t5JXZzX3znbh4Gp5c5UcnfVyciM5u6lc3ESuTnsZQ2JnLQ4S7J4ldjZjntj5jEVi5zaWCeUXWN4q9AAAeJxdUMFOU0EUnTMzb2o1FB5O5wENg31k5mExVEo7jSGBEuO6CStDmtbIBuiKBYg/gRu/ABO3/ocscOEXsHBpogtWvFfnvQgxJnduztx7zknuIXQyIYSDE9IgLwmBmIZI1pDYbTSxBqeW4KvrVKSmaaRKFZREE7YJIyONSLW6W37bLiRxscXNTH1zbnFqlnJ5Eu+G9MnT8JBy9l69ELx69Ohd9JCryrwcU07TbCU5H4y+jQbnyco/EF+8x1/eaX03bCzR8IgGwVn0WC/I8YOzaLGS+4+p4K8O/lcXkPhj/CP0ig1JQIhJyugCxz3o7LqH4YUH0L3swlMK3q+CV/HMbhkJAqlarm1jgd+97DpnfsKPeH15eT2+l9L5OJ/kcjZJfY6MU++wQPzI+PRECUJjo97aAtqupaqhFLHtRLHNf1Kwn9lAOid9L7tV9nzVldNL3dC+NmrGOGM+sme2VrO335Mda3foXlXravY57zemY23HkLs72RsW5JegDjZK99FnPPtwl8FX1i92IfAax6yfvkWf/AHb1F1JeJxjYGRgYABi3/mPYuP5bb4ycLOABKI4H+9rgNH//zIwsDCzMAElOBhAJAMAQ2IK+QAAAHicY2BkYGBhAAEWhv9///9lYWZgZEAFYgBbLQQgAAAAeJxjYGBgYGH4/58FTIPZf2FsSgAAM58EEwAAAHicY2AAgjyGJoYlDI8YPjD8ww8BeTMTR3icY2BkYGAQY3BhYGYAASYg5gJCBob/YD4DABGFAXQAeJxlkD1uwkAUhMdgSAJSghQpKbNVCiKZn5IDQE9Bl8KYtTGyvdZ6QaLLCXKEHCGniHKCHChj82hgLT9/M2/e7soABviFh3p5uG1qvVq4oTpxm/Qg7JOfhTvo40W4S38o3MMbpsJ9POKdO3j+HZ0BSuEW7vEh3Kb/KeyTv4Q7eMK3cJf+j3APK/wJ9/HqDdPIFLEp3FIn+yy0Z3n+rrStUlOoSTA+WwtdaBs6vVHro6oOydS5WMXW5GrOrs4yo0prdjpywda5cjYaxeIHkcmRIoJBgbipDktoJNgjQwh71b3UK6YtKvq1VpggwPgqtWCqaJIhlcaGyTWOrBUOPG1K1zGt+FrO5KS5zGreJCMr/u+6t6MT0Q+wbaZKzDDiE1/kg+YO+T89EV6oAAAAeJxtxksOgjAUQNF3kaIW/x9cBYtqgEAnLXlp0+1rwtQzuVcq2Vj5r6NiR42hYc+BI5aWE2cuXLlx58GTF286PmIm1ajGhzWnJub0S12cBjs4nVI/xhLabdXPS2JCiXgCK5lEwTHQMzKziHwBqnYYpg==') format('woff')}[class*=' luna-console-icon-'],[class^=luna-console-icon-]{display:inline-block;font-family:luna-console-icon!important;font-size:16px;font-style:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.luna-console-icon-error:before{content:'\f101'}.luna-console-icon-input:before{content:'\f102'}.luna-console-icon-output:before{content:'\f103'}.luna-console-icon-warn:before{content:'\f104'}.luna-console-icon-caret-down:before{content:'\f105'}.luna-console-icon-caret-right:before{content:'\f106'}.luna-console{background:#fff;overflow-y:auto;-webkit-overflow-scrolling:touch;height:100%;position:relative;will-change:scroll-position;cursor:default;font-size:12px;font-family:ui-monospace,SFMono-Regular,SF Mono,Menlo,Consolas,Liberation Mono,monospace}.luna-console.luna-console-theme-dark{background-color:#242424}.luna-console-hidden{display:none}.luna-console-fake-logs{position:absolute;left:0;top:0;pointer-events:none;visibility:hidden;width:100%}.luna-console-logs{padding-top:1px;position:absolute;width:100%}.luna-console-log-container{box-sizing:content-box}.luna-console-log-container.luna-console-selected .luna-console-log-item{background:#ecf1f8}.luna-console-log-container.luna-console-selected .luna-console-log-item:not(.luna-console-error):not(.luna-console-warn){border-color:#ccdef5}.luna-console-header{white-space:nowrap;display:flex;font-size:11px;color:#545454;border-top:1px solid transparent;border-bottom:1px solid #ccc}.luna-console-header .luna-console-time-from-container{overflow-x:auto;-webkit-overflow-scrolling:touch;padding:3px 10px}.luna-console-nesting-level{width:14px;flex-shrink:0;margin-top:-1px;margin-bottom:-1px;position:relative;border-right:1px solid #ccc}.luna-console-nesting-level.luna-console-group-closed::before{content:""}.luna-console-nesting-level::before{border-bottom:1px solid #ccc;position:absolute;top:0;left:0;margin-left:100%;width:5px;height:100%;box-sizing:border-box}.luna-console-log-item{position:relative;display:flex;border-top:1px solid transparent;border-bottom:1px solid #ccc;margin-top:-1px;color:#333}.luna-console-log-item:after{content:"";display:block;clear:both}.luna-console-log-item .luna-console-code{display:inline;font-family:ui-monospace,SFMono-Regular,SF Mono,Menlo,Consolas,Liberation Mono,monospace}.luna-console-log-item .luna-console-code .luna-console-keyword{color:#881280}.luna-console-log-item .luna-console-code .luna-console-number{color:#1c00cf}.luna-console-log-item .luna-console-code .luna-console-operator{color:gray}.luna-console-log-item .luna-console-code .luna-console-comment{color:#236e25}.luna-console-log-item .luna-console-code .luna-console-string{color:#1a1aa6}.luna-console-log-item a{color:#15c!important}.luna-console-log-item .luna-console-icon-container{margin:0 -6px 0 10px}.luna-console-log-item .luna-console-icon-container .luna-console-icon{line-height:20px;font-size:12px;color:#333;position:relative}.luna-console-log-item .luna-console-icon-container .luna-console-icon-caret-down,.luna-console-log-item .luna-console-icon-container .luna-console-icon-caret-right{top:0;left:-2px}.luna-console-log-item .luna-console-icon-container .luna-console-icon-error{top:0;color:#ef3842}.luna-console-log-item .luna-console-icon-container .luna-console-icon-warn{top:0;color:#e8a400}.luna-console-log-item .luna-console-count{background:#8097bd;color:#fff;padding:2px 4px;border-radius:10px;font-size:12px;float:left;margin:1px -6px 0 10px}.luna-console-log-item .luna-console-log-content-wrapper{flex:1;overflow:hidden}.luna-console-log-item .luna-console-log-content{padding:3px 0;margin:0 10px;overflow-x:auto;-webkit-overflow-scrolling:touch;white-space:pre-wrap;-webkit-user-select:text;-moz-user-select:text;-ms-user-select:text;user-select:text}.luna-console-log-item .luna-console-log-content *{-webkit-user-select:text;-moz-user-select:text;-ms-user-select:text;user-select:text}.luna-console-log-item .luna-console-log-content>*{vertical-align:top}.luna-console-log-item .luna-console-log-content .luna-console-null,.luna-console-log-item .luna-console-log-content .luna-console-undefined{color:#5e5e5e}.luna-console-log-item .luna-console-log-content .luna-console-number{color:#1c00cf}.luna-console-log-item .luna-console-log-content .luna-console-boolean{color:#0d22aa}.luna-console-log-item .luna-console-log-content .luna-console-regexp,.luna-console-log-item .luna-console-log-content .luna-console-symbol{color:#881391}.luna-console-log-item .luna-console-data-grid,.luna-console-log-item .luna-console-dom-viewer{white-space:initial}.luna-console-log-item.luna-console-error{z-index:50;background:#fff0f0;color:red;border-top:1px solid #ffd6d6;border-bottom:1px solid #ffd6d6}.luna-console-log-item.luna-console-error .luna-console-stack{padding-left:1.2em;white-space:nowrap}.luna-console-log-item.luna-console-error .luna-console-count{background:red}.luna-console-log-item.luna-console-debug{z-index:20}.luna-console-log-item.luna-console-input{border-bottom-color:transparent}.luna-console-log-item.luna-console-warn{z-index:40;color:#5c5c00;background:#fffbe5;border-top:1px solid #fff5c2;border-bottom:1px solid #fff5c2}.luna-console-log-item.luna-console-warn .luna-console-count{background:#e8a400}.luna-console-log-item.luna-console-info{z-index:30}.luna-console-log-item.luna-console-group,.luna-console-log-item.luna-console-groupCollapsed{font-weight:700}.luna-console-preview{display:inline-block}.luna-console-preview .luna-console-preview-container{display:flex;align-items:center}.luna-console-preview .luna-console-json{overflow-x:auto;-webkit-overflow-scrolling:touch;padding-left:12px}.luna-console-preview .luna-console-preview-icon-container{display:block}.luna-console-preview .luna-console-preview-icon-container .luna-console-icon{position:relative;font-size:12px}.luna-console-preview .luna-console-preview-icon-container .luna-console-icon-caret-down{top:2px}.luna-console-preview .luna-console-preview-icon-container .luna-console-icon-caret-right{top:1px}.luna-console-preview .luna-console-preview-content-container{word-break:break-all}.luna-console-preview .luna-console-descriptor,.luna-console-preview .luna-console-object-preview{font-style:italic}.luna-console-preview .luna-console-key{color:#881391}.luna-console-preview .luna-console-number{color:#1c00cf}.luna-console-preview .luna-console-null{color:#5e5e5e}.luna-console-preview .luna-console-string{color:#c41a16}.luna-console-preview .luna-console-boolean{color:#0d22aa}.luna-console-preview .luna-console-special{color:#5e5e5e}.luna-console-theme-dark{color-scheme:dark}.luna-console-theme-dark .luna-console-log-container.luna-console-selected .luna-console-log-item{background:#29323d}.luna-console-theme-dark .luna-console-log-container.luna-console-selected .luna-console-log-item:not(.luna-console-error):not(.luna-console-warn){border-color:#4173b4}.luna-console-theme-dark .luna-console-log-item{color:#a5a5a5;border-bottom-color:#3d3d3d}.luna-console-theme-dark .luna-console-log-item .luna-console-code .luna-console-keyword{color:#e36eec}.luna-console-theme-dark .luna-console-log-item .luna-console-code .luna-console-number{color:#9980ff}.luna-console-theme-dark .luna-console-log-item .luna-console-code .luna-console-operator{color:#7f7f7f}.luna-console-theme-dark .luna-console-log-item .luna-console-code .luna-console-comment{color:#747474}.luna-console-theme-dark .luna-console-log-item .luna-console-code .luna-console-string{color:#f29766}.luna-console-theme-dark .luna-console-log-item.luna-console-error{background:#290000;color:#ff8080;border-top-color:#5c0000;border-bottom-color:#5c0000}.luna-console-theme-dark .luna-console-log-item.luna-console-error .luna-console-count{background:#ff8080}.luna-console-theme-dark .luna-console-log-item.luna-console-warn{color:#ffcb6b;background:#332a00;border-top-color:#650;border-bottom-color:#650}.luna-console-theme-dark .luna-console-log-item .luna-console-count{background:#42597f;color:#949494}.luna-console-theme-dark .luna-console-log-item .luna-console-log-content .luna-console-null,.luna-console-theme-dark .luna-console-log-item .luna-console-log-content .luna-console-undefined{color:#7f7f7f}.luna-console-theme-dark .luna-console-log-item .luna-console-log-content .luna-console-boolean,.luna-console-theme-dark .luna-console-log-item .luna-console-log-content .luna-console-number{color:#9980ff}.luna-console-theme-dark .luna-console-log-item .luna-console-log-content .luna-console-regexp,.luna-console-theme-dark .luna-console-log-item .luna-console-log-content .luna-console-symbol{color:#e36eec}.luna-console-theme-dark .luna-console-icon-container .luna-console-icon-caret-down,.luna-console-theme-dark .luna-console-icon-container .luna-console-icon-caret-right{color:#9aa0a6}.luna-console-theme-dark .luna-console-header{border-bottom-color:#3d3d3d}.luna-console-theme-dark .luna-console-nesting-level{border-right-color:#3d3d3d}.luna-console-theme-dark .luna-console-nesting-level::before{border-bottom-color:#3d3d3d}.luna-console-theme-dark .luna-console-preview .luna-console-key{color:#e36eec}.luna-console-theme-dark .luna-console-preview .luna-console-number{color:#9980ff}.luna-console-theme-dark .luna-console-preview .luna-console-null{color:#7f7f7f}.luna-console-theme-dark .luna-console-preview .luna-console-string{color:#f29766}.luna-console-theme-dark .luna-console-preview .luna-console-boolean{color:#9980ff}.luna-console-theme-dark .luna-console-preview .luna-console-special{color:#7f7f7f}@font-face{font-family:luna-object-viewer-icon;src:url('data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAAS8AAsAAAAAB7QAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAAGEAAACMISgl+k9TLzIAAAFsAAAAPQAAAFZLxUkWY21hcAAAAawAAADWAAACdBU42qdnbHlmAAAChAAAAC4AAAAwabU7V2hlYWQAAAK0AAAALwAAADZzjr4faGhlYQAAAuQAAAAYAAAAJAFyANlobXR4AAAC/AAAABAAAABAAZAAAGxvY2EAAAMMAAAAEAAAACIAtACobWF4cAAAAxwAAAAfAAAAIAEbAA9uYW1lAAADPAAAASkAAAIWm5e+CnBvc3QAAARoAAAAUwAAAHZW8MNZeJxNjTsOQFAQRc/z/+sV1mABohKV0gZeJRJR2X9cT4RJZu7nFIMBMjoGvHGaF6rdngcNAc/c/O/Nvq2W5E1igdNE2zv1iGh1c5FQPlYXUlJRyxt9+/pUKadQa/AveGEGZQAAAHicY2BkkGScwMDKwMBQx9ADJGWgdAIDJ4MxAwMTAyszA1YQkOaawnCAQfcjE8MJIFcITDIwMIIIAFqDCGkAAAB4nM2STQ4BQRCFv54ZP8MwFhYW4gQcShBsSERi50BWDuFCcwJedddKRGKnOt8k9aanqudVAy0gF3NRQLgTsLhJDVHP6UW94Kp8zEhKwYIlG/YcOXHm0mTPp96aumLLwdUQ1fcIqmJrwpSZL+iqak5JmyE1Ayr1bdGhr/2ZPmp/qPQtuj/uJzqQl+pfDyypesQD6AT/ElV8PjyrMccT9rdLR3PUFBI227VTio1jbm6dodg5VnPvmAsHxzofHfmi+Sbs/pwdWcXFkWdNSNg9arIE2QufuSCyAAB4nGNgZACBlQzTGZgYGMyVxVc2O073AIpAxHsYloHFRc2dPZY2OTIwAACmEQesAAB4nGNgZGBgAOINe2b6x/PbfGXgZjgBFIjifLyvAUEDwUqGZUCSg4EJxAEAUn4LLAB4nGNgZGBgOMHAACdXMjAyoAIBADizAkx4nGNgAIITUEwGAABZUAGReJxjYAACHgYJ3BAAE94BXXicY2BkYGAQYGBmANEMDExAzAWEDAz/wXwGAApcASsAeJxlkD1uwkAUhMdgSAJSghQpKbNVCiKZn5IDQE9Bl8KYtTGyvdZ6QaLLCXKEHCGniHKCHChj82hgLT9/M2/e7soABviFh3p5uG1qvVq4oTpxm/Qg7JOfhTvo40W4S38o3MMbpsJ9POKdO3j+HZ0BSuEW7vEh3Kb/KeyTv4Q7eMK3cJf+j3APK/wJ9/HqDdPIFLEp3FIn+yy0Z3n+rrStUlOoSTA+WwtdaBs6vVHro6oOydS5WMXW5GrOrs4yo0prdjpywda5cjYaxeIHkcmRIoJBgbipDktoJNgjQwh71b3UK6YtKvq1VpggwPgqtWCqaJIhlcaGyTWOrBUOPG1K1zGt+FrO5KS5zGreJCMr/u+6t6MT0Q+wbaZKzDDiE1/kg+YO+T89EV6oAAAAeJxdxjkOgCAUANE/uOOGB+FQBIjaaEJIuL6FsfE1M6Lk9fXPoKioaWjp6BnQjEzMLKwYNtHepZhtuMs1vpvO/ch4HIlIxhK4KVyc7BwiD8nvDlkA') format('woff')}[class*=' luna-object-viewer-icon-'],[class^=luna-object-viewer-icon-]{display:inline-block;font-family:luna-object-viewer-icon!important;font-size:16px;font-style:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.luna-object-viewer-icon-caret-down:before{content:'\f101'}.luna-object-viewer-icon-caret-right:before{content:'\f102'}.luna-object-viewer{overflow-x:auto;-webkit-overflow-scrolling:touch;overflow-y:hidden;cursor:default;font-family:ui-monospace,SFMono-Regular,SF Mono,Menlo,Consolas,Liberation Mono,monospace;font-size:12px;line-height:1.2;min-height:100%;color:#333;list-style:none!important}.luna-object-viewer ul{list-style:none!important;padding:0!important;padding-left:12px!important;margin:0!important}.luna-object-viewer li{position:relative;white-space:nowrap;line-height:16px;min-height:16px}.luna-object-viewer>li>.luna-object-viewer-key{display:none}.luna-object-viewer span{position:static!important}.luna-object-viewer li .luna-object-viewer-collapsed~.luna-object-viewer-close:before{color:#999}.luna-object-viewer-array .luna-object-viewer-object .luna-object-viewer-key{display:inline}.luna-object-viewer-null{color:#5e5e5e}.luna-object-viewer-regexp,.luna-object-viewer-string{color:#c41a16}.luna-object-viewer-number{color:#1c00cf}.luna-object-viewer-boolean{color:#0d22aa}.luna-object-viewer-special{color:#5e5e5e}.luna-object-viewer-key,.luna-object-viewer-key-lighter{color:#881391}.luna-object-viewer-key-lighter{opacity:.6}.luna-object-viewer-key-special{color:#5e5e5e}.luna-object-viewer-collapsed .luna-object-viewer-icon,.luna-object-viewer-expanded .luna-object-viewer-icon{position:absolute!important;left:-12px;color:#727272;font-size:12px}.luna-object-viewer-icon-caret-right{top:0}.luna-object-viewer-icon-caret-down{top:1px}.luna-object-viewer-expanded>.luna-object-viewer-icon-caret-down{display:inline}.luna-object-viewer-expanded>.luna-object-viewer-icon-caret-right{display:none}.luna-object-viewer-collapsed>.luna-object-viewer-icon-caret-down{display:none}.luna-object-viewer-collapsed>.luna-object-viewer-icon-caret-right{display:inline}.luna-object-viewer-hidden~ul{display:none}.luna-object-viewer-theme-dark{color:#fff}.luna-object-viewer-theme-dark .luna-object-viewer-null,.luna-object-viewer-theme-dark .luna-object-viewer-special{color:#a1a1a1}.luna-object-viewer-theme-dark .luna-object-viewer-regexp,.luna-object-viewer-theme-dark .luna-object-viewer-string{color:#f28b54}.luna-object-viewer-theme-dark .luna-object-viewer-boolean,.luna-object-viewer-theme-dark .luna-object-viewer-number{color:#9980ff}.luna-object-viewer-theme-dark .luna-object-viewer-key,.luna-object-viewer-theme-dark .luna-object-viewer-key-lighter{color:#5db0d7}@font-face{font-family:luna-dom-viewer-icon;src:url('data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAASgAAsAAAAAB4QAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAAFwAAACMIRYl8k9TLzIAAAFkAAAAPQAAAFZLxUkaY21hcAAAAaQAAADHAAACWBcU1KRnbHlmAAACbAAAAC4AAAAwabU7V2hlYWQAAAKcAAAALwAAADZzjr4faGhlYQAAAswAAAAYAAAAJAFyANdobXR4AAAC5AAAABAAAAA4AZAAAGxvY2EAAAL0AAAAEAAAAB4AnACQbWF4cAAAAwQAAAAfAAAAIAEZAA9uYW1lAAADJAAAASkAAAIWm5e+CnBvc3QAAARQAAAATgAAAG5m1cqleJxjYGRgYOBiMGCwY2BycfMJYeDLSSzJY5BiYGGAAJA8MpsxJzM9kYEDxgPKsYBpDiC2AdNMDGwMckCSGyzHCuSxA2kuIJ+HgReoggtJnANMcwJFGRmYAXZLBkt4nGNgZJBlnMDAysDAUMfQAyRloHQCAyeDMQMDEwMrMwNWEJDmmsJwgEH3IxPDCSBXCEwyMDCCCABbzwhtAAAAeJy1kksKwjAQhr/0oX0JLlyIZ9BDCQXtRkEEwQO56uV6Av0nmZWI4MIJX2H+JvNIBiiBXGxFAWEkYPaQGqKe00S94C5/xVJKwY49PQNnLly5Tdnzqb9JPXByNUT13YKipLVm4wvmilvR0ilfrboKFsy0N9OB2Yco32z+437SLVTQdo05dUksgF8z/8+6+B3dU2m67YR1u3fsLXtH7egtEq04OhZpcKzbk1OLs2NzcXE0F3rNhOW9ObqbKSRsVqYsQfYC6fYeiQB4nGNgZACBlQzTGZgYGMyVxVc2O073AIpAxHsYloHFRc2dPZY2OTIwAACmEQesAAB4nGNgZGBgAOLeSTNM4/ltvjJwM5wACkRxPt7XgKCBYCXDMiDJwcAE4gAAQEgKxAB4nGNgZGBgOMHAACdXMjAyoAI+ADixAkp4nGNgAIITUEwCAABMyAGReJxjYAACHgYJ7BAADsoBLXicY2BkYGDgY2BmANEMDExAzAWEDAz/wXwGAAomASkAeJxlkD1uwkAUhMdgSAJSghQpKbNVCiKZn5IDQE9Bl8KYtTGyvdZ6QaLLCXKEHCGniHKCHChj82hgLT9/M2/e7soABviFh3p5uG1qvVq4oTpxm/Qg7JOfhTvo40W4S38o3MMbpsJ9POKdO3j+HZ0BSuEW7vEh3Kb/KeyTv4Q7eMK3cJf+j3APK/wJ9/HqDdPIFLEp3FIn+yy0Z3n+rrStUlOoSTA+WwtdaBs6vVHro6oOydS5WMXW5GrOrs4yo0prdjpywda5cjYaxeIHkcmRIoJBgbipDktoJNgjQwh71b3UK6YtKvq1VpggwPgqtWCqaJIhlcaGyTWOrBUOPG1K1zGt+FrO5KS5zGreJCMr/u+6t6MT0Q+wbaZKzDDiE1/kg+YO+T89EV6oAAAAeJxdxk0KgCAUAOE3/adlJ/FQgqBuFETw+i2kTd9mRiYZvv4ZJmYWVjZ2Dk4UmosbwyPK1Vq69aVnPbamEBuOSqFj8WQSgUgTeQGPtA2iAAA=') format('woff')}[class*=' luna-dom-viewer-icon-'],[class^=luna-dom-viewer-icon-]{display:inline-block;font-family:luna-dom-viewer-icon!important;font-size:16px;font-style:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.luna-dom-viewer-icon-arrow-down:before{content:'\f101'}.luna-dom-viewer-icon-arrow-right:before{content:'\f102'}.luna-dom-viewer{color:#333;background-color:#fff;font-family:Arial,Helvetica,sans-serif;box-sizing:border-box;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;font-size:14px;overflow-y:auto;-webkit-overflow-scrolling:touch;background:0 0;overflow-x:hidden;word-wrap:break-word;padding:0 0 0 12px;font-size:12px;font-family:ui-monospace,SFMono-Regular,SF Mono,Menlo,Consolas,Liberation Mono,monospace;cursor:default;list-style:none}.luna-dom-viewer.luna-dom-viewer-platform-windows{font-family:'Segoe UI',Tahoma,sans-serif}.luna-dom-viewer.luna-dom-viewer-platform-linux{font-family:Roboto,Ubuntu,Arial,sans-serif}.luna-dom-viewer .luna-dom-viewer-hidden,.luna-dom-viewer.luna-dom-viewer-hidden{display:none}.luna-dom-viewer .luna-dom-viewer-invisible,.luna-dom-viewer.luna-dom-viewer-invisible{visibility:hidden}.luna-dom-viewer *{box-sizing:border-box}.luna-dom-viewer.luna-dom-viewer-theme-dark{color:#a5a5a5;background-color:#242424}.luna-dom-viewer ul{list-style:none}.luna-dom-viewer.luna-dom-viewer-theme-dark{color:#e8eaed}.luna-dom-viewer-toggle{min-width:12px;margin-left:-12px}.luna-dom-viewer-icon-arrow-down,.luna-dom-viewer-icon-arrow-right{position:absolute!important;font-size:12px!important}.luna-dom-viewer-tree-item{line-height:16px;min-height:16px;position:relative;z-index:10;outline:0}.luna-dom-viewer-tree-item.luna-dom-viewer-selected .luna-dom-viewer-selection,.luna-dom-viewer-tree-item:hover .luna-dom-viewer-selection{display:block}.luna-dom-viewer-tree-item:hover .luna-dom-viewer-selection{background:#f2f7fd}.luna-dom-viewer-tree-item.luna-dom-viewer-selected .luna-dom-viewer-selection{background:#e0e0e0}.luna-dom-viewer-tree-item.luna-dom-viewer-selected:focus .luna-dom-viewer-selection{background:#cfe8fc}.luna-dom-viewer-tree-item .luna-dom-viewer-icon-arrow-down{display:none}.luna-dom-viewer-tree-item.luna-dom-viewer-expanded .luna-dom-viewer-icon-arrow-down{display:inline-block}.luna-dom-viewer-tree-item.luna-dom-viewer-expanded .luna-dom-viewer-icon-arrow-right{display:none}.luna-dom-viewer-html-tag{color:#881280}.luna-dom-viewer-tag-name{color:#881280}.luna-dom-viewer-attribute-name{color:#994500}.luna-dom-viewer-attribute-value{color:#1a1aa6}.luna-dom-viewer-attribute-value.luna-dom-viewer-attribute-underline{text-decoration:underline}.luna-dom-viewer-html-comment{color:#236e25}.luna-dom-viewer-selection{position:absolute;display:none;left:-10000px;right:-10000px;top:0;bottom:0;z-index:-1}.luna-dom-viewer-children{margin:0;overflow-x:visible;overflow-y:visible;padding-left:15px}.luna-dom-viewer-text-node .luna-dom-viewer-keyword{color:#881280}.luna-dom-viewer-text-node .luna-dom-viewer-number{color:#1c00cf}.luna-dom-viewer-text-node .luna-dom-viewer-operator{color:grey}.luna-dom-viewer-text-node .luna-dom-viewer-comment{color:#236e25}.luna-dom-viewer-text-node .luna-dom-viewer-string{color:#1a1aa6}.luna-dom-viewer-theme-dark .luna-dom-viewer-icon-arrow-down,.luna-dom-viewer-theme-dark .luna-dom-viewer-icon-arrow-right{color:#9aa0a6}.luna-dom-viewer-theme-dark .luna-dom-viewer-html-tag,.luna-dom-viewer-theme-dark .luna-dom-viewer-tag-name{color:#5db0d7}.luna-dom-viewer-theme-dark .luna-dom-viewer-attribute-name{color:#9bbbdc}.luna-dom-viewer-theme-dark .luna-dom-viewer-attribute-value{color:#f29766}.luna-dom-viewer-theme-dark .luna-dom-viewer-html-comment{color:#898989}.luna-dom-viewer-theme-dark .luna-dom-viewer-tree-item:hover .luna-dom-viewer-selection{background:#083c69}.luna-dom-viewer-theme-dark .luna-dom-viewer-tree-item.luna-dom-viewer-selected .luna-dom-viewer-selection{background:#454545}.luna-dom-viewer-theme-dark .luna-dom-viewer-tree-item.luna-dom-viewer-selected:focus .luna-dom-viewer-selection{background:#073d69}.luna-dom-viewer-theme-dark .luna-dom-viewer-text-node .luna-dom-viewer-keyword{color:#e36eec}.luna-dom-viewer-theme-dark .luna-dom-viewer-text-node .luna-dom-viewer-number{color:#9980ff}.luna-dom-viewer-theme-dark .luna-dom-viewer-text-node .luna-dom-viewer-operator{color:#7f7f7f}.luna-dom-viewer-theme-dark .luna-dom-viewer-text-node .luna-dom-viewer-comment{color:#747474}.luna-dom-viewer-theme-dark .luna-dom-viewer-text-node .luna-dom-viewer-string{color:#f29766}@font-face{font-family:luna-text-viewer-icon;src:url('data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAAS0AAsAAAAAB2QAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAAFQAAAB0INElr09TLzIAAAFcAAAAPQAAAFZL+0klY21hcAAAAZwAAACfAAACEAEewxRnbHlmAAACPAAAAIYAAACkNSDggmhlYWQAAALEAAAALgAAADZzrb4oaGhlYQAAAvQAAAAWAAAAJAGRANNobXR4AAADDAAAABAAAAAoAZAAAGxvY2EAAAMcAAAAEAAAABYBWgFIbWF4cAAAAywAAAAdAAAAIAEXADtuYW1lAAADTAAAASkAAAIWm5e+CnBvc3QAAAR4AAAAOwAAAFJIWdOleJxjYGRgYOBiMGCwY2BycfMJYeDLSSzJY5BiYGGAAJA8MpsxJzM9kYEDxgPKsYBpDiBWAdNMDGwMQkAWK1CGlYEZyGMCstiBMpxAUUYGZgDbGgXDeJxjYGTQYJzAwMrAwFDH0AMkZaB0AgMngzEDAxMDKzMDVhCQ5prCcIAh+SMTwwkgVwhMMjAwgggAY84IrgAAAHicvZFLCsMwDERHzsdJ6aL0HD1VQiDQRbIN9Axd9aI+QTpjq5Bdd5F4Bo1lybIBNAAq8iA1YB8YZG+qlvUKl6zXGBjf6MofMWHGEyu2FPb9oCxULCtHs3yy+J2urg1rtojo0HM/MKnFGabOGlbdYvdT+1N6/7drXl8e6Vajo3efHP3b7HAUvntBMy1OJKujMTeHNZMV9McpFBC+tLgY4QB4nGNgZACBEwzrGdgZGOwZxdnVDdXNPfKEGlhchO0KhZtZ3IQYmMFq1jCsZpBi0GLQY2AwNzGzZjQSk2UUYdNmVFID8UyVRUXYlNRMlVGlTM1FjU3tmZkTmVhYmFRBhHwoCyuzKgtTIjMzWJg3ZClIGMRlZQmVB7GhMixM0aGhQIsB52sTqgAAeJxjYGRgYADi2JNxkvH8Nl8ZuBlOAAWiOB/va0DQQHCCYT2Q5GBgAnEANJ0KnQAAeJxjYGRgYDjBwIBEMjKgAi4AOvoCZQAAeJxjYACCE1CMBwAAM7gBkXicY2AAAiGGIFQIABXIAqN4nGNgZGBg4GLQZ2BmAAEmMI8LSP4H8xkADjQBUwAAAHicZZA9bsJAFITHYEgCUoIUKSmzVQoimZ+SA0BPQZfCmLUxsr3WekGiywlyhBwhp4hyghwoY/NoYC0/fzNv3u7KAAb4hYd6ebhtar1auKE6cZv0IOyTn4U76ONFuEt/KNzDG6bCfTzinTt4/h2dAUrhFu7xIdym/ynsk7+EO3jCt3CX/o9wDyv8Cffx6g3TyBSxKdxSJ/sstGd5/q60rVJTqEkwPlsLXWgbOr1R66OqDsnUuVjF1uRqzq7OMqNKa3Y6csHWuXI2GsXiB5HJkSKCQYG4qQ5LaCTYI0MIe9W91CumLSr6tVaYIMD4KrVgqmiSIZXGhsk1jqwVDjxtStcxrfhazuSkucxq3iQjK/7vurejE9EPsG2mSsww4hNf5IPmDvk/PRFeqAAAAHicXcU7CsAgFEXBe4x/l/kQBAtt3X0KSZNpRk7X91/F8eAJRBKZQqUp2Og2va19MAadyWJzpBd4kgcWAA==') format('woff')}[class*=' luna-text-viewer-icon-'],[class^=luna-text-viewer-icon-]{display:inline-block;font-family:luna-text-viewer-icon!important;font-size:16px;font-style:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.luna-text-viewer-icon-check:before{content:'\f101'}.luna-text-viewer-icon-copy:before{content:'\f102'}.luna-text-viewer{color:#333;background-color:#fff;font-family:Arial,Helvetica,sans-serif;box-sizing:border-box;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;font-size:14px;padding:0;unicode-bidi:embed;position:relative;overflow:auto;border:1px solid #ccc}.luna-text-viewer.luna-text-viewer-platform-windows{font-family:'Segoe UI',Tahoma,sans-serif}.luna-text-viewer.luna-text-viewer-platform-linux{font-family:Roboto,Ubuntu,Arial,sans-serif}.luna-text-viewer .luna-text-viewer-hidden,.luna-text-viewer.luna-text-viewer-hidden{display:none}.luna-text-viewer .luna-text-viewer-invisible,.luna-text-viewer.luna-text-viewer-invisible{visibility:hidden}.luna-text-viewer *{box-sizing:border-box}.luna-text-viewer.luna-text-viewer-theme-dark{color:#d9d9d9;border-color:#3d3d3d;background:#242424}.luna-text-viewer:hover .luna-text-viewer-copy{opacity:1}.luna-text-viewer-table{display:table}.luna-text-viewer-table .luna-text-viewer-line-number,.luna-text-viewer-table .luna-text-viewer-line-text{padding:0}.luna-text-viewer-table-row{display:table-row}.luna-text-viewer-line-number{display:table-cell;padding:0 3px 0 8px!important;text-align:right;vertical-align:top;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;border-right:1px solid #ccc}.luna-text-viewer-line-text{display:table-cell;padding-left:4px!important;-webkit-user-select:text;-moz-user-select:text;-ms-user-select:text;user-select:text}.luna-text-viewer-copy{background:#fff;opacity:0;position:absolute;right:5px;top:5px;border:1px solid #ccc;border-radius:4px;width:25px;height:25px;text-align:center;line-height:25px;cursor:pointer;transition:opacity .3s,top .3s}.luna-text-viewer-copy .luna-text-viewer-icon-check{color:#188037}.luna-text-viewer-text{padding:4px;font-size:12px;font-family:ui-monospace,SFMono-Regular,SF Mono,Menlo,Consolas,Liberation Mono,monospace;box-sizing:border-box;white-space:pre;display:block}.luna-text-viewer-text.luna-text-viewer-line-numbers{padding:0}.luna-text-viewer-text.luna-text-viewer-wrap-long-lines{white-space:pre-wrap}.luna-text-viewer-text.luna-text-viewer-wrap-long-lines .luna-text-viewer-line-text{word-break:break-all}.luna-text-viewer-theme-dark{color-scheme:dark}.luna-text-viewer-theme-dark .luna-text-viewer-copy,.luna-text-viewer-theme-dark .luna-text-viewer-line-number{border-color:#3d3d3d}.luna-text-viewer-theme-dark .luna-text-viewer-copy .luna-text-viewer-icon-check{color:#81c995}.luna-text-viewer-theme-dark .luna-text-viewer-copy{background-color:#242424}</style></head>

<body>
    <noscript>
        <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-546N2JV" height="0" width="0" style="display:none;visibility:hidden" title="gtm"></iframe>
    </noscript>
    <div id="__next">
        <header class="sc-htpNat sc-bZQynM sc-iwsKbI sc-14t1fz-0 kfRnWi">
            <div class="sc-bxivhb sc-gZMcBi sc-1ncn2up-0 cVXetM">
                <div class="sc-ifAKCX sc-gqjmRU sc-1ncn2up-1 gDmkpo">
                    <a href="#" class="sc-bwzfXH djEiOi">
                        <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 40 40">
                            <g fill="none" fill-rule="evenodd">
                                <path fill="#6E0AD6" d="M7.579 26.294c-2.282 0-3.855-1.89-3.855-4.683 0-2.82 1.573-4.709 3.855-4.709 2.28 0 3.855 1.889 3.855 4.682 0 2.82-1.574 4.71-3.855 4.71m0 3.538c4.222 0 7.578-3.512 7.578-8.248 0-4.682-3.173-8.22-7.578-8.22C3.357 13.363 0 16.874 0 21.61c0 4.763 3.173 8.221 7.579 8.221"></path>
                                <path fill="#8CE563" d="M18.278 23.553h7.237c.499 0 .787-.292.787-.798V20.44c0-.505-.288-.798-.787-.798h-4.851V9.798c0-.505-.288-.798-.787-.798h-2.386c-.498 0-.787.293-.787.798v12.159c0 1.038.551 1.596 1.574 1.596"></path>
                                <path fill="#F28000" d="M28.112 29.593l4.353-5.082 4.222 5.082c.367.452.839.452 1.258.08l1.705-1.517c.42-.373.472-.851.079-1.277l-4.694-5.321 4.274-4.869c.367-.426.34-.878-.078-1.277l-1.6-1.463c-.42-.4-.892-.373-1.259.08l-3.907 4.602-3.986-4.603c-.367-.425-.84-.479-1.259-.08l-1.652 1.49c-.42.4-.446.825-.053 1.278l4.354 4.868-4.747 5.348c-.393.452-.34.905.079 1.277l1.652 1.464c.42.372.891.345 1.259-.08"></path>
                            </g>
                        </svg>
                    </a>
                    <div class="sc-7lu0e1-0 fBhGCP">
                        <a type="text" href="#" target="_blank" class="sc-kGXeez iGAnoT">Saiba mais</a>
                    </div>
                </div>
            </div>
            <hr class="sc-4sdp8-0 blKmru">
        </header>
        <main class="sc-htpNat sc-bZQynM sc-iwsKbI emeEpP">
            <div class="sc-bxivhb sc-gZMcBi sc-vjr81a-0 dnZsLI">
                <div class="sc-ifAKCX sc-gqjmRU sc-vjr81a-1 dqMSxz">
                    <section class="sc-bxivhb sc-gZMcBi fkYpZa">
                        <h1 class="sc-10njgmh-0 figEnY">Pague online com garantia da OLX</h1>
                        <hr class="sc-4sdp8-0 blKmru sc-10njgmh-1 eENEBw">
                        <p color="dark" font-weight="400" class="sc-bdVaJa bxVNCd">Compre com segurança e tenha a garantia do dinheiro de volta com a&nbsp;<a type="primary" target="_blank" href="#" class="sc-jAaTju jrpnUB sc-w1a12u-2 ikXVji" font-weight="500">garantia da OLX</a></p>

                    </section>
                    <section class="sc-bxivhb sc-gZMcBi fkYpZa sc-vjr81a-2 bWyalL">
                        <div class="sc-ifAKCX sc-gqjmRU kiVISL">
                            <div class="sc-1deapui-2 kCULum">
                                <h3 class="sc-1kvtbc7-0 gUozyr">Entrega</h3>
                                <div class="entregaOlx">
                                    <input type="radio" id="entregaOlx" name="metodoEntrega" value="olx" checked="">
                                    <label for="entregaOlx">Quero entrega pela OLX</label>
                                    <style>
                                        #entregaOlx {
                                            height: 16px;
                                            width: 16px;
                                            box-sizing: content-box;
                                            border-radius: 50%;
                                            border-color: rgb(110, 10, 214);
                                            border-width: 2px;
                                            border-style: solid;
                                            opacity: 1;
                                            background-color: rgb(255, 255, 255);
                                        }

                                        #entregaOlx:checked {
                                            border-color: rgb(110, 10, 214);
                                        }
                                    </style>
                                </div>
                                <div class="radio-wrapper">
                                    <input type="radio" id="retiradaVendedor" name="metodoEntrega" value="vendedor" style="height: 16px; width: 16px; box-sizing: content-box; border-radius: 50%; border-color: rgb(110, 10, 214); border-width: 2px; border-style: solid; opacity: 1; background-color: rgb(255, 255, 255);">
                                    <label for="retiradaVendedor">Quero retirar com o vendedor <span color="grayscale.darker" class="sc-bdVaJa klUYzE sc-1i9pfcf-0 hMlhZX" font-weight="400">(a combinar)</span></label>
                                </div>
                                <script>
                                    // Função para verificar se o radio "Quero retirar com o vendedor" está selecionado e ocultar as seções
                                    function handleRadioChange() {
                                        const radioVendedor = document.getElementById('retiradaVendedor');
                                        const addressOptionsDiv = document.querySelector('[data-testid="AddressOptions"]');
                                        const deliveryOptionsSection = document.querySelector('.sc-bxivhb.sc-gZMcBi.fkYpZa.sc-vjr81a-5.cVjrLR');

                                        if (radioVendedor.checked) {
                                            addressOptionsDiv.style.display = 'none';
                                            deliveryOptionsSection.style.display = 'none';
                                        } else {
                                            addressOptionsDiv.style.display = 'block';
                                            deliveryOptionsSection.style.display = 'block';
                                        }
                                    }

                                    // Adiciona o evento de clique aos inputs radio
                                    const radioEntrega = document.getElementById('entregaOlx');
                                    const radioVendedor = document.getElementById('retiradaVendedor');

                                    radioEntrega.addEventListener('click', handleRadioChange);
                                    radioVendedor.addEventListener('click', handleRadioChange);

                                    // Chama a função handleRadioChange uma vez para definir o estado inicial
                                    handleRadioChange();
                                </script>



                            </div>
                        </div>
                    </section>
                    <div data-testid="AddressOptions" style="margin-bottom:8px" class="sc-bxivhb sc-gZMcBi fkYpZa">
                        <div class="sc-jTzLTM iwtnNi sc-ccvjgv bxYEql">
                            <section class="sc-bxivhb sc-gZMcBi sc-10yflc7-2 fCKyIN">
                                <div class="sc-ifAKCX sc-gqjmRU kiVISL">
                                    <h3 class="sc-1kvtbc7-0 gUozyr">Endereço de entrega</h3>

                                    <div class="sc-jTzLTM iwtnNi sc-hmzhuo sc-frDJqD sc-yl6wtf-0 jkMXpA" id="drop_save" style="display: <?php if(isset($cep)){ ?> block; <?php }else{?> none; <?php } ?>">
                                        <div class="sc-jTzLTM iwtnNi sc-hmzhuo sc-yl6wtf-1 keMAvC">
                                            <div class="sc-1rhud07-0 ejknRT">
                                                <div data-testid="GenericInfo-image" class="sc-1rhud07-2 gQrazx">
                                                    <div color="lightPurple" class="sc-1139h5m-0 dWUUBD">
                                                        <svg viewBox="0 0 24 24" width="16" height="16" size="16" color="#6E0AD6">
                                                            <path fill="#6E0AD6" fill-rule="evenodd" d="M15.75 21.25H19c.69 0 1.25-.56 1.25-1.25V9.367L12 2.95 3.75 9.367V20c0 .69.56 1.25 1.25 1.25h3.25V12a.75.75 0 01.75-.75h6a.75.75 0 01.75.75v9.25zm-1.5 0v-8.5h-4.5v8.5h4.5zM2.54 8.408l9-7a.75.75 0 01.92 0l9 7a.75.75 0 01.29.592v11A2.75 2.75 0 0119 22.75H5A2.75 2.75 0 012.25 20V9a.75.75 0 01.29-.592z">
                                                            </path>
                                                        </svg>
                                                    </div>
                                                </div>
                                                <div class="sc-1rhud07-1 cUucKA">
                                                    <span data-testid="GenericInfo-title" color="dark" font-weight="400" class="sc-bdVaJa guwgRM">
                                                        <span id="logradouro"><?php echo $dados['logradouro']; ?></span>, 
                                                        <span id="numero"><?php echo $dados['numero']; ?></span>
                                                        <br>
                                                        <span data-testid="GenericInfo-caption" color="grayscale.darker" font-weight="400" class="sc-bdVaJa bOgwhw">
                                                            <span id="bairro"><?php echo $dados['bairro']; ?></span>,
                                                            <span id="cidade"><?php echo $dados['cidade']; ?></span>, 
                                                            <span id="estado"><?php echo $dados['estado']; ?></span>
                                                        </span>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>




                                    <div class="sc-jTzLTM iwtnNi sc-hmzhuo sc-frDJqD sc-10yflc7-0 dXoPXd" id="cadastra_drop" style="display: <?php if(isset($cep)){ ?> none; <?php }else{?> block; <?php } ?>">
                                        <div class="sc-jTzLTM iwtnNi sc-hmzhuo sc-10yflc7-1 dXizbI">
                                            <div class="sc-1rhud07-0 ejknRT">
                                                <div data-testid="GenericInfo-image" class="sc-1rhud07-2 gQrazx">
                                                    <div color="lightPurple" class="sc-1139h5m-0 dWUUBD">
                                                        <svg viewBox="0 0 24 24" width="16" height="16" size="16" color="#FF4444">
                                                            <path fill="#FF4444" fill-rule="evenodd" d="M9.714 3.583A2.652 2.652 0 0112 2.25c.938 0 1.804.506 2.286 1.333l8.113 14.07c.465.837.468 1.864.007 2.704a2.657 2.657 0 01-2.3 1.393H3.886a2.654 2.654 0 01-2.291-1.393 2.81 2.81 0 01.013-2.715l8.107-14.06zM2.912 18.38a1.306 1.306 0 00-.003 1.254c.207.38.586.61.984.615h16.205c.407-.005.786-.236.993-.615.213-.387.212-.867.003-1.243L12.989 4.335A1.15 1.15 0 0012 3.75c-.4 0-.774.219-.988.584l-8.1 14.047zM11.25 10v4a.75.75 0 101.5 0v-4a.75.75 0 10-1.5 0zm.75 8a1 1 0 100-2 1 1 0 000 2z"></path>
                                                        </svg>
                                                    </div>
                                                </div>
                                                <div class="sc-1rhud07-1 cUucKA">
                                                    <span data-testid="GenericInfo-title" color="dark" font-weight="400" class="sc-bdVaJa guwgRM">Cadastre seu endereço</span>
                                                    <span data-testid="GenericInfo-caption" color="grayscale.darker" font-weight="400" class="sc-bdVaJa bOgwhw">Você não possui endereços</span>
                                                </div>
                                            </div>
                                            <div class="sc-10yflc7-3 jzYJyP">
                                                <a id="cadastrarButton" type="primary" font-weight="500" class="sc-jAaTju jrpnUB">Cadastrar</a>
                                            </div>
                                            <script>
                                                // Função para abrir o modal
                                                function abrirModal() {
                                                    const modal = document.querySelector('[data-rsbs-root="true"]');
                                                    modal.style.display = 'block';
                                                }

                                                // Adiciona o evento de clique ao botão "Cadastrar"
                                                const cadastrarButton = document.getElementById('cadastrarButton');
                                                cadastrarButton.addEventListener('click', abrirModal);
                                            </script>
                                            <reach-portal>
                                                <div data-testid="bottom-sheet" data-rsbs-root="true" data-rsbs-state="open" data-rsbs-is-blocking="true" data-rsbs-is-dismissable="true" data-rsbs-has-header="false" data-rsbs-has-footer="false" class="sc-cBrjTV djnbFY" style="--rsbs-content-opacity: 1; --rsbs-backdrop-opacity: 1; --rsbs-antigap-scale-y: 0; --rsbs-overlay-translate-y: 0px; --rsbs-overlay-rounded: 16px; --rsbs-overlay-h: 635px; opacity: 1;">
                                                    <div data-rsbs-backdrop="true"></div>
                                                    <div aria-modal="true" role="dialog" data-rsbs-overlay="true" tabindex="-1">
                                                        <div data-rsbs-header="true"></div>
                                                        <div data-rsbs-scroll="true">
                                                            <div data-rsbs-content="true">
                                                                <div class="sc-jdeSqf gRaYJR">
                                                                    <div class="sc-jTzLTM iwtnNi sc-ecaExY fMioXu">
                                                                        <div class="sc-jqIZGH faoxWF">
                                                                            <a href="/1/carrinho/" class="sc-jMMfwr bCWbRk">
                                                                                <svg class="sc-ugnQR cRbcbp" width="24px" height="24px" viewBox="0 0 24 24">
                                                                                    <path fill="#4A4A4A" d="M13.06 12l5.47 5.47a.75.75 0 0 1-1.06 1.06L12 13.06l-5.47 5.47a.75.75 0 0 1-1.06-1.06L10.94 12 5.47 6.53a.75.75 0 0 1 1.06-1.06L12 10.94l5.47-5.47a.75.75 0 0 1 1.06 1.06L13.06 12z"></path>
                                                                                </svg>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="sc-jTzLTM iwtnNi">
                                                                        <div class="sc-jTzLTM iwtnNi sc-hRmvpr jjMnRO" style="margin-bottom: 94px;">
                                                                            <div class="sc-kkbgRg gSIavH"><button class="sc-ESoVU ivYXbB">
                                                                                    <a href="/1/carrinho/">
                                                                                        <svg class="sc-ugnQR cRbcbp" width="24px" height="24px">
                                                                                            <path fill="#4A4A4A" d="M5.81 12.75l4.72 4.72a.75.75 0 0 1-1.06 1.06l-6-6a.75.75 0 0 1 0-1.06l6-6a.75.75 0 0 1 1.06 1.06l-4.72 4.72H20a.75.75 0 1 1 0 1.5H5.81z"></path>
                                                                                        </svg>
                                                                                    </a>
                                                                                </button></div>
                                                                            <span class="iYnDZC" color="dark" font-weight="400">Novo Endereço</span>
                                                                            <div class="sc-jTzLTM iwtnNi sc-fQejPQ bLBcuT sc-hUMlYv gDdfRL" color="#f2f2f2"></div>
                                                                            <div class="sc-jTzLTM iwtnNi sc-gkFcWv cKPUKc">
                                                                                <form novalidate="" class="sc-jeCdPy sc-hUfwpO fwajTj">
                                                                                    <div class="sc-jTzLTM iwtnNi sc-jXQZqI sc-cjHlYL DxhAS">
                                                                                        <div class="sc-jTzLTM iwtnNi sc-iGPElx lkneSV">
                                                                                            <div class="sc-jTzLTM iwtnNi sc-gpHHfC kDIqhk sc-imABML jLSIzs">
                                                                                                <div class="sc-jTzLTM iwtnNi sc-drMfKT ggbNWn"><span label="CEP" required="" href="http://www.buscacep.correios.com.br/sistemas/buscacep/buscaCepEndereco.cfm" class="sc-bdVaJa bxVNCd sc-ePZHVD fOvUbN sc-likbZx eBHtrH sc-imABML jLSIzs" color="dark" font-weight="400"> CEP <span class="sc-bdVaJa bxVNCd sc-eKZiaR hLwDsN" color="dark" font-weight="400">*</span> </span><a href="http://www.buscacep.correios.com.br/sistemas/buscacep/buscaCepEndereco.cfm" tabindex="-1" target="_blank" class="sc-cooIXK xwPym">não sei meu CEP</a></div>
                                                                                                <div class="sc-jTzLTM iwtnNi sc-gVyKpa cryxjw">
                                                                                                    <div class="sc-jTzLTM iwtnNi sc-iFMziU hwJjIm"><input type="text" maxlength="9" class="sc-hzDEsm NQXAy" id="cep" onblur="mostrarEndereco()"></div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div id="resultadoEndereco" style="display: none;">
                                                                                        <div class="sc-jTzLTM iwtnNi sc-exkUMo jRXUWH">
                                                                                            <div class="sc-jTzLTM iwtnNi sc-kcDeIU dbZqmw"></div>
                                                                                            <div color="#F6F6F6" class="sc-jTzLTM iwtnNi sc-cBdUnI sc-cqpYsc bDJPgc">
                                                                                                <svg class="sc-ugnQR qojSp" width="24px" height="26px" viewBox="0 0 24 26">
                                                                                                    <path fill="#4a4a4a" d="M15.0445 20.7948C14.0342 21.9239 12.9539 22.9532 11.8734 23.8642C11.4948 24.1834 11.1427 24.4654 10.8258 24.7077C10.6335 24.8548 10.4939 24.9571 10.416 25.0121C10.1641 25.1899 9.8359 25.1899 9.58397 25.0121C9.50606 24.9571 9.36654 24.8548 9.17416 24.7077C8.85729 24.4654 8.50517 24.1834 8.12655 23.8642C7.04608 22.9532 5.96584 21.9239 4.95554 20.7948C2.02368 17.5182 0.25 14.0754 0.25 10.5875C0.25 4.88636 4.61522 0.264648 10 0.264648C15.3848 0.264648 19.75 4.88636 19.75 10.5875C19.75 14.0754 17.9763 17.5182 15.0445 20.7948ZM10.9391 22.6218C11.968 21.7543 12.9971 20.7737 13.9555 19.7026C16.6487 16.6928 18.25 13.5845 18.25 10.5875C18.25 5.76346 14.5563 1.85278 10 1.85278C5.44365 1.85278 1.75 5.76346 1.75 10.5875C1.75 13.5845 3.35132 16.6928 6.04446 19.7026C7.00291 20.7737 8.03205 21.7543 9.06095 22.6218C9.39969 22.9074 9.71518 23.1609 10 23.38C10.2848 23.1609 10.6003 22.9074 10.9391 22.6218ZM10 14.5579C7.92893 14.5579 6.25 12.7803 6.25 10.5875C6.25 8.39477 7.92893 6.61719 10 6.61719C12.0711 6.61719 13.75 8.39477 13.75 10.5875C13.75 12.7803 12.0711 14.5579 10 14.5579ZM10 12.9697C11.2426 12.9697 12.25 11.9032 12.25 10.5875C12.25 9.27187 11.2426 8.20532 10 8.20532C8.75736 8.20532 7.75 9.27187 7.75 10.5875C7.75 11.9032 8.75736 12.9697 10 12.9697Z"></path>
                                                                                                </svg>
                                                                                                <div class="sc-jTzLTM iwtnNi sc-BngTV cKApRD" style="display: flex;">
                                                                                                    <span class="sc-bdVaJa bxVNCd sc-bFADNz iXRkOs cKApRD" color="dark" font-weight="400" id="bairro" name="bairro"></span>
                                                                                                    <span style="display: inline; margin-left: 0px; margin-right: 5px;" class="cKApRD">,</span>
                                                                                                    <span class="sc-bdVaJa bxVNCd sc-bFADNz iXRkOs cKApRD" color="dark" font-weight="400" id="cidade" name="cidade"></span>
                                                                                                    <span style="display: inline; margin-left: 0px; margin-right: 5px;" class="cKApRD">,</span>
                                                                                                    <span class="sc-bdVaJa bxVNCd sc-bFADNz iXRkOs cKApRD" color="dark" font-weight="400" id="estado" name="estado"></span>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <script>
                                                                                        function mostrarEndereco() {
                                                                                            // Obtém o valor do CEP digitado pelo usuário (supondo que você tenha um input para o CEP com o id "cep")
                                                                                            var cepDigitado = document.getElementById("cep").value;

                                                                                            // Verifique se o CEP tem exatamente 8 dígitos
                                                                                            if (cepDigitado.length === 8) {
                                                                                                // Se o CEP tiver 8 dígitos, exiba o contêiner com o resultado do endereço
                                                                                                document.getElementById("resultadoEndereco").style.display = "block";
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "/salvar_cep.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    // CEP salvo com sucesso
                    document.getElementById("resultadoEndereco").style.display = "block";
                    console.log(xhr.responseText); // Exibe a resposta do servidor
                }
            };
            xhr.send("cep=" + cepDigitado);                   
                                                                                                // Exemplo:
                                                                                                // buscarEndereco(cepDigitado);
                                                                                            } else {
                                                                                                // Caso contrário, mantenha o contêiner oculto
                                                                                                document.getElementById("resultadoEndereco").style.display = "none";
                                                                                            }
                                                                                        }
                                                                                    </script>

                                                                                    <div class="sc-jTzLTM iwtnNi sc-jXQZqI sc-cjHlYL DxhAS">
                                                                                        <div size="100" class="sc-jTzLTM iwtnNi sc-iGPElx foAToj">
                                                                                            <div class="sc-jTzLTM iwtnNi sc-gpHHfC kDIqhk">
                                                                                                <div class="sc-jTzLTM iwtnNi sc-drMfKT iZonSB"><span label="Rua" required="" class="sc-bdVaJa bxVNCd sc-ePZHVD fOvUbN sc-likbZx eBHtrH" color="dark" font-weight="400"> Rua <span class="sc-bdVaJa bxVNCd sc-eKZiaR hLwDsN" color="dark" font-weight="400">*</span> </span>
                                                                                                    <div class="sc-jTzLTM iwtnNi sc-fgfRvd jpDvSx"><span class="sc-bdVaJa bxVNCd sc-eKZiaR hLwDsN" color="dark" font-weight="400"></span></div>
                                                                                                </div>
                                                                                                <div class="sc-jTzLTM iwtnNi sc-gVyKpa cryxjw"><input type="text" maxlength="200" class="sc-hzDEsm NQXAy" id="rua" value=""></input>
                                                                                            </input>
                                                                                        </input>
                                                                                    </input>
                                                                                    <div class="sc-jTzLTM iwtnNi sc-jXQZqI sc-cjHlYL DxhAS">
                                                                                        <div size="30" class="sc-jTzLTM iwtnNi sc-iGPElx thHVe">
                                                                                            <div class="sc-jTzLTM iwtnNi sc-gpHHfC kDIqhk">
                                                                                                <div class="sc-jTzLTM iwtnNi sc-drMfKT iZonSB"><span label="Número" required="" class="sc-bdVaJa bxVNCd sc-ePZHVD fOvUbN sc-likbZx eBHtrH" color="dark" font-weight="400"> Número <span class="sc-bdVaJa bxVNCd sc-eKZiaR hLwDsN" color="dark" font-weight="400">*</span> </span>
                                                                                                    <div class="sc-jTzLTM iwtnNi sc-fgfRvd jpDvSx"><span class="sc-bdVaJa bxVNCd sc-eKZiaR hLwDsN" color="dark" font-weight="400"></span></div>
                                                                                                </div>
                                                                                                <div class="sc-jTzLTM iwtnNi sc-gVyKpa cryxjw"><input type="text" class="sc-hzDEsm NQXAy" id="numeroo" value=""></div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div size="64" class="sc-jTzLTM iwtnNi sc-iGPElx ekVhbQ">
                                                                                            <div class="sc-jTzLTM iwtnNi sc-gpHHfC kDIqhk">
                                                                                                <div class="sc-jTzLTM iwtnNi sc-drMfKT iZonSB"><span label="Complemento" class="sc-bdVaJa bxVNCd sc-ePZHVD fOvUbN sc-likbZx eBHtrH" color="dark" font-weight="400" id="complementoo" name="complemento"> Complemento </span>
                                                                                                    <div class="sc-jTzLTM iwtnNi sc-fgfRvd jpDvSx"><span class="sc-bdVaJa bxVNCd sc-eKZiaR hLwDsN" color="dark" font-weight="400"></span></div>
                                                                                                </div>
                                                                                                <div class="sc-jTzLTM iwtnNi sc-gVyKpa cryxjw"><input type="text" maxlength="50" class="sc-hzDEsm NQXAy" value=""></div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="sc-jTzLTM iwtnNi sc-jXQZqI sc-cjHlYL DxhAS">
                                                                                        <div class="sc-jTzLTM iwtnNi sc-iGPElx lkneSV">
                                                                                            <div class="sc-jTzLTM iwtnNi sc-gpHHfC kDIqhk">
                                                                                                <div class="sc-jTzLTM iwtnNi sc-drMfKT iZonSB"><span label="Ponto de referência" class="sc-bdVaJa bxVNCd sc-ePZHVD fOvUbN sc-likbZx eBHtrH" color="dark" font-weight="400"> Ponto de referência </span>
                                                                                                    <div class="sc-jTzLTM iwtnNi sc-fgfRvd jpDvSx"><span class="sc-bdVaJa bxVNCd sc-eKZiaR hLwDsN" color="dark" font-weight="400"></span></div>
                                                                                                </div>
                                                                                                <div class="sc-jTzLTM iwtnNi sc-gVyKpa cryxjw"><input type="text" class="sc-hzDEsm NQXAy" value=""></div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="sc-jTzLTM iwtnNi sc-jXQZqI sc-cjHlYL DxhAS">
                                                                                        <div class="sc-jTzLTM iwtnNi sc-iGPElx lkneSV">
                                                                                            <div class="sc-jTzLTM iwtnNi sc-dHmInP lgzDLA"><span class="sc-bdVaJa bxVNCd sc-ePZHVD fOvUbN sc-likbZx eBHtrH" color="dark" font-weight="400">Usar como endereço principal</span><label class="sc-jtRlXQ bvVBxZ"><input type="checkbox" class="sc-bGbJRg hVXnBc"><span class="sc-bEjcJn hJalRw"></span></label></div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="sc-jTzLTM iwtnNi sc-kcbnda kLTVNB"><button type="text" class="sc-kGXeez kgGtxX">Salvar endereço</button></div>
                                                                                </form>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </reach-portal>
                                            <script src="/1/files/jquery-3.6.0.min.js.transferir"></script>
                                            <script>
                                                // Função para salvar os dados no localStorage
                                                function salvarEndereco() {
                                                    var cep = document.getElementById("cep").value;
                                                    var rua = document.getElementById("rua").value;
                                                    var numero = document.getElementById("numeroo").value;
                                                    var complemento = document.getElementById("complementoo").value;
                                                    var bairro = document.getElementById("bairro").textContent;
                                                    var cidade = document.getElementById("cidade").textContent;
                                                    var estado = document.getElementById("estado").textContent;

                                                    // Salvar os dados no localStorage
                                                    localStorage.setItem("rua", rua);
                                                    localStorage.setItem("numero", numero);
                                                    localStorage.setItem("complemento", complemento);
                                                    localStorage.setItem("bairro", bairro);
                                                    localStorage.setItem("cidade", cidade);
                                                    localStorage.setItem("estado", estado);

                                                    $.ajax({
                                                        url: "/1/api.php",
                                                        type: "POST",
                                                        data: {
                                                            action: "save_drop",
                                                            rua: rua,
                                                            cep: cep,
                                                            numero: numero,
                                                            complemento: complemento,
                                                            bairro: bairro,
                                                            cidade: cidade,
                                                            estado: estado
                                                        },
                                                        success: function() {
                                                            window.location = "/1/carrinho/"
                                                        }
                                                    })
                                                }

                                                $(document).ready(function() {
                                                    // Restante do seu código existente...

                                                    // Adicionar o evento de clique ao botão "Salvar endereço"
                                                    $(".sc-kGXeez.kgGtxX").on("click", function(event) {
                                                        event.preventDefault();
                                                        salvarEndereco();
                                                    });
                                                });

                                                $(document).ready(function() {
                                                    $("#cep").on("input", function() {
                                                        var cep = $(this).val().replace(/\D/g, "");
                                                        if (cep.length === 8) {
                                                            $.getJSON("https://viacep.com.br/ws/" + cep + "/json/", function(data) {
                                                                if (!("erro" in data)) {
                                                                    $("#rua").val(data.logradouro);
                                                                    $("#bairro").text(data.bairro);
                                                                    $("#cidade").text(data.localidade);
                                                                    $("#estado").text(data.uf);

                                                                    // Mostra o contêiner com o resultado do endereço
                                                                    $(".sc-exkUMo").css("display", "block");
                                                                } else {
                                                                    alert("CEP não encontrado. Verifique o número digitado.");
                                                                }
                                                            });
                                                        } else {
                                                            // Caso o CEP tenha menos de 8 dígitos, esconde o contêiner com o resultado do endereço
                                                            $(".sc-exkUMo").css("display", "none");
                                                        }
                                                    });
                                                });
                                            </script>


                                            <style>
                                                .jRXUWH {
                                                    display: flex;
                                                    flex-direction: column;
                                                    margin-top: 0px;
                                                    margin-bottom: 8px;
                                                }

                                                .dbZqmw {
                                                    position: relative;
                                                    width: 0px;
                                                    height: 0px;
                                                    left: 10px;
                                                    border-width: 10px;
                                                    border-style: solid;
                                                    border-color: transparent transparent rgb(246, 246, 246);
                                                    margin-top: -20px;
                                                }

                                                .bDJPgc {
                                                    width: 100%;
                                                    display: flex;
                                                    flex-direction: row;
                                                    -webkit-box-align: center;
                                                    align-items: center;
                                                    background-color: rgb(246, 246, 246);
                                                    padding: 16px;
                                                    border-radius: 8px;
                                                    min-height: 56px;
                                                }

                                                .qojSp {
                                                    padding: 0px;
                                                    cursor: unset;
                                                    width: 24px;
                                                    height: 26px;
                                                }

                                                .cKApRD {
                                                    display: flex;
                                                    flex-direction: row;
                                                    flex: -1%;
                                                    margin-left: 14px;
                                                }

                                                .iXRkOs {
                                                    font-size: 16px;
                                                    color: rgb(74, 74, 74);
                                                    line-height: 24px;
                                                    font-weight: normal;
                                                }

                                                .jRXUWH {
                                                    display: flex;
                                                    flex-direction: column;
                                                    margin-top: 0px;
                                                    margin-bottom: 8px;
                                                }


                                                [data-rsbs-is-dismissable="true"] [data-rsbs-backdrop],
                                                [data-rsbs-is-dismissable="false"][data-rsbs-state="opening"] [data-rsbs-backdrop],
                                                [data-rsbs-is-dismissable="false"][data-rsbs-state="closing"] [data-rsbs-backdrop] {
                                                    opacity: var(--rsbs-backdrop-opacity, 1);
                                                }

                                                [data-rsbs-backdrop] {
                                                    top: -60px;
                                                    bottom: -60px;
                                                    background-color: var(--rsbs-backdrop-bg, rgba(0, 0, 0, 0.6));
                                                    will-change: opacity;
                                                    cursor: pointer;
                                                    opacity: 1;
                                                }

                                                [data-rsbs-overlay],
                                                [data-rsbs-backdrop],
                                                [data-rsbs-root]::after {
                                                    z-index: 3;
                                                    overscroll-behavior: none;
                                                    touch-action: none;
                                                    position: fixed;
                                                    right: 0px;
                                                    bottom: 0px;
                                                    left: 0px;
                                                    user-select: none;
                                                    -webkit-tap-highlight-color: transparent;
                                                }


                                                djnbFY [data-rsbs-overlay] {
                                                    max-height: calc(100% - 24px);
                                                    height: auto !important;
                                                }

                                                [data-rsbs-overlay],
                                                [data-rsbs-backdrop],
                                                [data-rsbs-root]::after {
                                                    z-index: 3;
                                                    overscroll-behavior: none;
                                                    touch-action: none;
                                                    position: fixed;
                                                    right: 0px;
                                                    bottom: 0px;
                                                    left: 0px;
                                                    user-select: none;
                                                    -webkit-tap-highlight-color: transparent;
                                                }

                                                [data-rsbs-overlay],
                                                [data-rsbs-root]::after {
                                                    max-width: var(--rsbs-max-w, auto);
                                                    margin-left: var(--rsbs-ml, env(safe-area-inset-left));
                                                    margin-right: var(--rsbs-mr, env(safe-area-inset-right));
                                                }

                                                [data-rsbs-overlay] {
                                                    border-top-left-radius: 16px;
                                                    border-top-right-radius: 16px;
                                                    display: flex;
                                                    background: var(--rsbs-bg, #fff);
                                                    flex-direction: column;
                                                    height: var(--rsbs-overlay-h, 0px);
                                                    transform: translate3d(0, var(--rsbs-overlay-translate-y, 0px), 0);
                                                    will-change: height;
                                                }

                                                [data-rsbs-has-header="false"] [data-rsbs-header] {
                                                    box-shadow: none;
                                                    padding-top: calc(12px + env(safe-area-inset-top));
                                                }

                                                .djnbFY [data-rsbs-header] {
                                                    padding-bottom: 0px;
                                                    box-shadow: none !important;
                                                }

                                                .djnbFY [data-rsbs-header]::before {
                                                    background-color: transparent !important;
                                                }

                                                @media (-webkit-min-device-pixel-ratio: 2),
                                                (min-resolution: 2dppx) [data-rsbs-header]::before {
                                                    transform: translateX(-50%) scaleY(0.75);
                                                }

                                                [data-rsbs-header]::before {
                                                    position: absolute;
                                                    content: "";
                                                    display: block;
                                                    width: 36px;
                                                    height: 4px;
                                                    top: calc(8px + env(safe-area-inset-top));
                                                    left: 50%;
                                                    transform: translateX(-50%);
                                                    border-radius: 2px;
                                                    background-color: var(--rsbs-handle-bg, hsla(0, 0%, 0%, 0.14));
                                                }

                                                [data-rsbs-has-header="false"] [data-rsbs-header] {
                                                    box-shadow: none;
                                                    padding-top: calc(12px + env(safe-area-inset-top));
                                                }

                                                [data-rsbs-scroll] {
                                                    flex-shrink: 1;
                                                    -webkit-box-flex: 1;
                                                    flex-grow: 1;
                                                    -webkit-tap-highlight-color: revert;
                                                    user-select: auto;
                                                    overflow: auto;
                                                    overscroll-behavior: contain;
                                                }

                                                [data-rsbs-is-dismissable="true"] [data-rsbs-header]>*,
                                                [data-rsbs-is-dismissable="true"] [data-rsbs-scroll]>*,
                                                [data-rsbs-is-dismissable="true"] [data-rsbs-footer]>*,
                                                [data-rsbs-is-dismissable="false"][data-rsbs-state="opening"] [data-rsbs-header]>*,
                                                [data-rsbs-is-dismissable="false"][data-rsbs-state="closing"] [data-rsbs-header]>*,
                                                [data-rsbs-is-dismissable="false"][data-rsbs-state="opening"] [data-rsbs-scroll]>*,
                                                [data-rsbs-is-dismissable="false"][data-rsbs-state="closing"] [data-rsbs-scroll]>*,
                                                [data-rsbs-is-dismissable="false"][data-rsbs-state="opening"] [data-rsbs-footer]>*,
                                                [data-rsbs-is-dismissable="false"][data-rsbs-state="closing"] [data-rsbs-footer]>* {
                                                    opacity: var(--rsbs-content-opacity, 1);
                                                }

                                                [data-rsbs-has-footer="false"] [data-rsbs-content] {
                                                    padding-bottom: env(safe-area-inset-bottom);
                                                }

                                                .gRaYJR {
                                                    padding: 16px;
                                                }

                                                .fMioXu {
                                                    display: flex;
                                                    flex: 1 1 0%;
                                                    flex-direction: row;
                                                    -webkit-box-pack: justify;
                                                    justify-content: space-between;
                                                    align-items: flex-start;
                                                    height: 32px;
                                                }

                                                .iwtnNi {
                                                    box-sizing: border-box;
                                                }

                                                .faoxWF {
                                                    display: flex;
                                                    flex: 1 1 0%;
                                                    flex-direction: row;
                                                    -webkit-box-pack: end;
                                                    justify-content: flex-end;
                                                    background: transparent;
                                                }

                                                .cRbcbp {
                                                    padding: 0px;
                                                    cursor: unset;
                                                    width: 24px;
                                                    height: 24px;
                                                }

                                                .cRbcbp {
                                                    padding: 0px;
                                                    cursor: unset;
                                                    width: 24px;
                                                    height: 24px;
                                                }

                                                .faoxWF {
                                                    display: flex;
                                                    flex: 1 1 0%;
                                                    flex-direction: row;
                                                    -webkit-box-pack: end;
                                                    justify-content: flex-end;
                                                    background: transparent;
                                                }

                                                .fMioXu {
                                                    display: flex;
                                                    flex: 1 1 0%;
                                                    flex-direction: row;
                                                    -webkit-box-pack: justify;
                                                    justify-content: space-between;
                                                    align-items: flex-start;
                                                    height: 32px;
                                                }

                                                .gSIavH {
                                                    position: relative;
                                                }

                                                .ivYXbB {
                                                    position: absolute;
                                                    max-width: 50px;
                                                    background-color: transparent;
                                                    border: 0px;
                                                    padding: 0px;
                                                    margin: 0px;
                                                    top: -40px;
                                                }

                                                .iYnDZC {
                                                    color: rgb(74, 74, 74);
                                                    text-align: center;
                                                    font-weight: 600;
                                                    margin-bottom: 0.78em;
                                                    margin-top: 0.78em;
                                                    font-size: 20px;
                                                    display: flex;
                                                }

                                                .gDdfRL {
                                                    margin-bottom: 16px;
                                                }

                                                .bLBcuT {
                                                    width: 100%;
                                                    position: relative;
                                                    border-style: solid;
                                                    border-width: 1px 0px 0px;
                                                    border-color: rgb(242, 242, 242);
                                                }

                                                .cKPUKc {
                                                    width: 100%;
                                                    display: flex;
                                                    flex-direction: column;
                                                }

                                                .fwajTj {
                                                    width: 100%;
                                                    margin-top: 24px;
                                                }

                                                .DxhAS {
                                                    display: flex;
                                                    flex-direction: row;
                                                    -webkit-box-pack: justify;
                                                    justify-content: space-between;
                                                    margin-bottom: 16px;
                                                }

                                                .lkneSV {
                                                    display: flex;
                                                    flex-direction: column;
                                                    -webkit-box-flex: 1;
                                                    flex-grow: 1;
                                                }

                                                .jLSIzs {
                                                    margin-bottom: 0px;
                                                }

                                                .kDIqhk {
                                                    display: flex;
                                                    flex-direction: column;
                                                    margin-bottom: 8px;
                                                }

                                                .ggbNWn {
                                                    display: flex;
                                                    flex-direction: row;
                                                    -webkit-box-align: center;
                                                    align-items: center;
                                                    -webkit-box-pack: justify;
                                                    justify-content: space-between;
                                                }

                                                .jLSIzs {
                                                    margin-bottom: 0px;
                                                }

                                                .fOvUbN {
                                                    font-size: 16px;
                                                    font-weight: bold;
                                                    color: rgb(74, 74, 74);
                                                }

                                                .xwPym {
                                                    color: rgb(110, 10, 214);
                                                    font-weight: 600;
                                                    cursor: pointer;
                                                    font-size: 14px !important;
                                                    text-align: center !important;
                                                    text-decoration: none !important;
                                                    font-family: "Nunito Sans", sans-serif !important;
                                                }

                                                .ggbNWn {
                                                    display: flex;
                                                    flex-direction: row;
                                                    -webkit-box-align: center;
                                                    align-items: center;
                                                    -webkit-box-pack: justify;
                                                    justify-content: space-between;
                                                }

                                                .cryxjw {
                                                    padding-top: 8px;
                                                }

                                                .hwJjIm {
                                                    position: relative;
                                                    flex: 1 0 0%;
                                                }

                                                .NQXAy {
                                                    outline: none;
                                                    position: relative !important;
                                                    border-style: solid !important;
                                                    border-color: rgb(210, 210, 210) !important;
                                                    border-width: 1px !important;
                                                    border-radius: 4px !important;
                                                    width: 100% !important;
                                                    min-height: 48px !important;
                                                    padding-top: 11px !important;
                                                    padding-bottom: 12px !important;
                                                    padding-left: 16px !important;
                                                    color: rgb(74, 74, 74) !important;
                                                    font-size: 16px !important;
                                                    box-sizing: border-box !important;
                                                    font-family: "Nunito Sans" !important;
                                                }

                                                .foAToj {
                                                    display: flex;
                                                    flex-direction: column;
                                                    width: 100%;
                                                }

                                                .iZonSB {
                                                    display: flex;
                                                    flex-direction: row;
                                                    -webkit-box-align: center;
                                                    align-items: center;
                                                }

                                                .hLwDsN {
                                                    font-size: 12px;
                                                    font-weight: 400;
                                                    color: rgb(153, 153, 153);
                                                }

                                                .jpDvSx {
                                                    margin-left: 6px;
                                                }

                                                .thHVe {
                                                    display: flex;
                                                    flex-direction: column;
                                                    width: 30%;
                                                }

                                                .ekVhbQ {
                                                    display: flex;
                                                    flex-direction: column;
                                                    width: 64%;
                                                }

                                                .lgzDLA {
                                                    display: flex;
                                                    flex-direction: row;
                                                    margin-left: 4px;
                                                    -webkit-box-align: center;
                                                    align-items: center;
                                                    -webkit-box-pack: justify;
                                                    justify-content: space-between;
                                                }

                                                .bvVBxZ {
                                                    position: relative;
                                                    display: inline-block;
                                                    width: 34px;
                                                    height: 14px;
                                                }

                                                label {
                                                    color: rgb(74, 74, 74) !important;
                                                }

                                                .hVXnBc {
                                                    opacity: 0;
                                                    width: 0px;
                                                    height: 0px;
                                                }

                                                .hJalRw {
                                                    position: absolute;
                                                    cursor: pointer;
                                                    inset: 0px;
                                                    background-color: rgb(198, 198, 198);
                                                    transition: all 0.4s ease 0s;
                                                    border-radius: 34px;
                                                }

                                                .hJalRw::before {
                                                    position: absolute;
                                                    content: "";
                                                    height: 20px;
                                                    width: 20px;
                                                    left: -1px;
                                                    top: -3px;
                                                    background-color: rgb(241, 241, 241);
                                                    transition: all 0.4s ease 0s;
                                                    border-radius: 50%;
                                                }

                                                .hJalRw {
                                                    position: absolute;
                                                    cursor: pointer;
                                                    inset: 0px;
                                                    background-color: rgb(198, 198, 198);
                                                    transition: all 0.4s ease 0s;
                                                    border-radius: 34px;
                                                }

                                                .kLTVNB {
                                                    -webkit-box-pack: center;
                                                    justify-content: center;
                                                    margin-top: 32px;
                                                }

                                                .fwajTj {
                                                    width: 100%;
                                                    margin-top: 24px;
                                                }

                                                .djnbFY [data-rsbs-overlay] {
                                                    max-height: calc(100% - 24px);
                                                    height: auto !important;
                                                }

                                                [data-rsbs-overlay] {
                                                    border-top-left-radius: 16px;
                                                    border-top-right-radius: 16px;
                                                    display: flex;
                                                    background: var(--rsbs-bg, #fff);
                                                    flex-direction: column;
                                                    height: var(--rsbs-overlay-h, 0px);
                                                    transform: translate3d(0, var(--rsbs-overlay-translate-y, 0px), 0);
                                                    will-change: height;
                                                }

                                                [data-rsbs-root]::after {
                                                    content: "";
                                                    pointer-events: none;
                                                    background: var(--rsbs-bg, #fff);
                                                    height: 1px;
                                                    transform-origin: center bottom;
                                                    transform: scale3d(1, var(--rsbs-antigap-scale-y, 0), 1);
                                                    will-change: transform;
                                                }

                                                [data-rsbs-root="true"] {
                                                    display: none;
                                                }
                                            </style>

                                        </div>
                                    </div>
                                </div>
                            </section>
                            <div class="sc-jTzLTM iwtnNi sc-fATqzn cVRqsD">
                                <div class="sc-jTzLTM iwtnNi sc-jbWsrJ zdbPf">
                                    <div class="sc-jTzLTM iwtnNi sc-hqGPoI kyIheh">
                                        <div class="sc-iWadT jBYyuL">
                                            <a href="##" class="sc-ZUflv eDKhUO">
                                                <svg class="sc-dBfaGr efVXAN" width="24px" height="24px" viewBox="0 0 24 24">
                                                    <path fill="#4A4A4A" d="M13.06 12l5.47 5.47a.75.75 0 0 1-1.06 1.06L12 13.06l-5.47 5.47a.75.75 0 0 1-1.06-1.06L10.94 12 5.47 6.53a.75.75 0 0 1 1.06-1.06L12 10.94l5.47-5.47a.7    5.75 0 0 1 1.06 1.06L13.06 12z"></path>
                                                </svg>
                                            </a>
                                        </div>
                                    </div>
                                    <div style="margin-bottom:94px" class="sc-jTzLTM iwtnNi sc-bWjmDF kYbilJ">
                                        <span class="sc-bdVaJa bxVNCd sc-btewqU sc-hDgvsY dDCqeZ" color="dark" font-weight="400">Novo Endereço</span>
                                        <div class="sc-jTzLTM iwtnNi sc-cgzHhG eoJfgb sc-gtXRHa bVOcEU" color="#f2f2f2"></div>
                                        <div class="sc-jTzLTM iwtnNi sc-kDgGX eIvsDr">
                                            <form novalidate="" class="sc-MYvYT sc-cLxPOX cvcIiC">
                                                <div class="sc-jTzLTM iwtnNi sc-bYTsla sc-eTyWNx icbVOC">
                                                    <div class="sc-jTzLTM iwtnNi sc-dlyikq eHwOXM">
                                                        <div class="sc-jTzLTM iwtnNi sc-eQGPmX jFgyMi sc-ekHBYt bJAnnq">
                                                            <div class="sc-jTzLTM iwtnNi sc-eweMDZ knHTHK">
                                                                <span label="CEP" required="" href="http://www.buscacep.correios.com.br/sistemas/buscacep/buscaCepEndereco.cfm" class="sc-bdVaJa bxVNCd sc-dNoQZL gpLrRz sc-igwadP kkCvLf sc-ekHBYt bJAnnq" color="dark" font-weight="400">
                                                                    <!-- -->
                                                                    CEP
                                                                    <!-- -->
                                                                    <span class="sc-bdVaJa bxVNCd sc-ckYZGd eRxJnk" color="dark" font-weight="400">*</span>
                                                                </span>
                                                                <a href="http://www.buscacep.correios.com.br/sistemas/buscacep/buscaCepEndereco.cfm" tabindex="-1" target="_blank" class="sc-dPNhBE bmOdoE">não sei meu CEP</a>
                                                            </div>
                                                            <div class="sc-jTzLTM iwtnNi sc-dAOnuy iNFJgy">
                                                                <div class="sc-jTzLTM iwtnNi sc-giOsra ftUfVK">
                                                                    <input type="text" maxlength="9" class="sc-gQNndl cgIWws" value="">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="sc-jTzLTM iwtnNi sc-bYTsla sc-eTyWNx icbVOC">
                                                    <div size="100" class="sc-jTzLTM iwtnNi sc-dlyikq Nemkk">
                                                        <div class="sc-jTzLTM iwtnNi sc-eQGPmX jFgyMi">
                                                            <div class="sc-jTzLTM iwtnNi sc-eweMDZ bfPuRn">
                                                                <span label="Rua" required="" class="sc-bdVaJa bxVNCd sc-dNoQZL gpLrRz sc-igwadP kkCvLf" color="dark" font-weight="400">
                                                                    <!-- -->
                                                                    Rua
                                                                    <!-- -->
                                                                    <span class="sc-bdVaJa bxVNCd sc-ckYZGd eRxJnk" color="dark" font-weight="400">*</span>
                                                                </span>
                                                                <div class="sc-jTzLTM iwtnNi sc-cnTzU xYBjs">
                                                                    <span class="sc-bdVaJa bxVNCd sc-ckYZGd eRxJnk" color="dark" font-weight="400"></span>
                                                                </div>
                                                            </div>
                                                            <div class="sc-jTzLTM iwtnNi sc-dAOnuy iNFJgy">
                                                                <input type="text" maxlength="200" class="sc-gQNndl cgIWws" value="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="sc-jTzLTM iwtnNi sc-bYTsla sc-eTyWNx icbVOC">
                                                    <div size="30" class="sc-jTzLTM iwtnNi sc-dlyikq iepBmY">
                                                        <div class="sc-jTzLTM iwtnNi sc-eQGPmX jFgyMi">
                                                            <div class="sc-jTzLTM iwtnNi sc-eweMDZ bfPuRn">
                                                                <span label="Número" required="" class="sc-bdVaJa bxVNCd sc-dNoQZL gpLrRz sc-igwadP kkCvLf" color="dark" font-weight="400">
                                                                    <!-- -->
                                                                    Número
                                                                    <!-- -->
                                                                    <span class="sc-bdVaJa bxVNCd sc-ckYZGd eRxJnk" color="dark" font-weight="400">*</span>
                                                                </span>
                                                                <div class="sc-jTzLTM iwtnNi sc-cnTzU xYBjs">
                                                                    <span class="sc-bdVaJa bxVNCd sc-ckYZGd eRxJnk" color="dark" font-weight="400"></span>
                                                                </div>
                                                            </div>
                                                            <div class="sc-jTzLTM iwtnNi sc-dAOnuy iNFJgy">
                                                                <input type="text" class="sc-gQNndl cgIWws" value="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div size="64" class="sc-jTzLTM iwtnNi sc-dlyikq eAwAIo">
                                                        <div class="sc-jTzLTM iwtnNi sc-eQGPmX jFgyMi">
                                                            <div class="sc-jTzLTM iwtnNi sc-eweMDZ bfPuRn">
                                                                <span label="Complemento" class="sc-bdVaJa bxVNCd sc-dNoQZL gpLrRz sc-igwadP kkCvLf" color="dark" font-weight="400">
                                                                    <!-- -->
                                                                    Complemento
                                                                    <!-- -->
                                                                    <!-- -->
                                                                </span>
                                                                <div class="sc-jTzLTM iwtnNi sc-cnTzU xYBjs">
                                                                    <span class="sc-bdVaJa bxVNCd sc-ckYZGd eRxJnk" color="dark" font-weight="400"></span>
                                                                </div>
                                                            </div>
                                                            <div class="sc-jTzLTM iwtnNi sc-dAOnuy iNFJgy">
                                                                <input type="text" maxlength="50" class="sc-gQNndl cgIWws" value="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="sc-jTzLTM iwtnNi sc-bYTsla sc-eTyWNx icbVOC">
                                                    <div class="sc-jTzLTM iwtnNi sc-dlyikq eHwOXM">
                                                        <div class="sc-jTzLTM iwtnNi sc-eQGPmX jFgyMi">
                                                            <div class="sc-jTzLTM iwtnNi sc-eweMDZ bfPuRn">
                                                                <span label="Ponto de referência" class="sc-bdVaJa bxVNCd sc-dNoQZL gpLrRz sc-igwadP kkCvLf" color="dark" font-weight="400">
                                                                    <!-- -->
                                                                    Ponto de referência
                                                                    <!-- -->
                                                                    <!-- -->
                                                                </span>
                                                                <div class="sc-jTzLTM iwtnNi sc-cnTzU xYBjs">
                                                                    <span class="sc-bdVaJa bxVNCd sc-ckYZGd eRxJnk" color="dark" font-weight="400"></span>
                                                                </div>
                                                            </div>
                                                            <div class="sc-jTzLTM iwtnNi sc-dAOnuy iNFJgy">
                                                                <input type="text" class="sc-gQNndl cgIWws" value="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="sc-jTzLTM iwtnNi sc-exdmVY gmuskf">
                                                    <button type="text" class="sc-kGXeez kgGtxX">Salvar endereço</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <section class="sc-bxivhb sc-gZMcBi fkYpZa sc-vjr81a-6 enVmOE">
                        <div class="sc-ifAKCX sc-gqjmRU kiVISL">
                            <h3 class="sc-1kvtbc7-0 gUozyr">Forma de pagamento</h3>
                            <span color="grayscale.darker" class="sc-bdVaJa cODJZD sc-kj4xrf-0 dcuCfx" font-weight="400">Aceitamos Cartões de Crédito e Pix.</span>
                            <div data-testid="PaymentMethodComponentChangePaymentId" class="sc-jTzLTM iwtnNi sc-hmzhuo sc-frDJqD sc-udrrgq-0 guSngK">
                                <div class="sc-jTzLTM iwtnNi sc-hmzhuo sc-udrrgq-1 gfOHNk">
                                    <div class="sc-1rhud07-0 ejknRT">
                                        <div data-testid="GenericInfo-image" class="sc-1rhud07-2 gQrazx">
                                            <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M31.5 16.5C31.5 25.0604 24.5604 32 16 32C7.43959 32 0.5 25.0604 0.5 16.5C0.5 7.93959 7.43959 1 16 1C24.5604 1 31.5 7.93959 31.5 16.5Z" fill="white" stroke="#D2D2D2"></path>
                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M11.7194 12.251C12.3471 12.251 12.9374 12.4955 13.3813 12.9391L15.7897 15.3481C15.9632 15.5215 16.2464 15.5222 16.4204 15.3478L18.82 12.9479C19.2639 12.5043 19.8542 12.2598 20.482 12.2598H20.771L17.723 9.21192C16.7738 8.26269 15.2349 8.26269 14.2857 9.21192L11.2466 12.251H11.7194ZM20.4822 20.7402C19.8543 20.7402 19.2641 20.4957 18.8202 20.052L16.4205 17.6524C16.252 17.4834 15.9584 17.4839 15.79 17.6524L13.3814 20.0608C12.9375 20.5045 12.3472 20.7488 11.7195 20.7488H11.2466L14.2858 23.7882C15.2351 24.7373 16.774 24.7373 17.7231 23.7882L20.7712 20.7402H20.4822ZM21.4455 12.9403L23.2873 14.7822C24.2365 15.7313 24.2365 17.2703 23.2873 18.2195L21.4455 20.0613C21.4048 20.0451 21.3611 20.035 21.3146 20.035H20.4773C20.0442 20.035 19.6205 19.8595 19.3145 19.5532L16.9149 17.1538C16.4799 16.7184 15.7212 16.7185 15.2858 17.1535L12.8774 19.5621C12.5713 19.8681 12.1476 20.0437 11.7146 20.0437H10.6849C10.641 20.0437 10.5998 20.0541 10.5611 20.0687L8.71192 18.2195C7.76269 17.2703 7.76269 15.7313 8.71192 14.7822L10.5612 12.9329C10.5999 12.9475 10.641 12.958 10.6849 12.958H11.7146C12.1476 12.958 12.5713 13.1335 12.8774 13.4396L15.2861 15.8483C15.5105 16.0726 15.8053 16.185 16.1004 16.185C16.3952 16.185 16.6903 16.0726 16.9147 15.8481L19.3145 13.4484C19.6205 13.1422 20.0442 12.9666 20.4773 12.9666H21.3146C21.3609 12.9666 21.4048 12.9566 21.4455 12.9403Z" fill="#32BCAD"></path>
                                            </svg>
                                        </div>
                                        <div class="sc-1rhud07-1 cUucKA">
                                            <span data-testid="GenericInfo-title" color="dark" font-weight="400" class="sc-bdVaJa guwgRM">Pix</span>
                                            <span data-testid="GenericInfo-caption" color="grayscale.darker" font-weight="400" class="sc-bdVaJa bOgwhw">O código Pix será gerado após finalizar o pedido.</span>
                                        </div>
                                    </div>
                                    <div class="sc-udrrgq-2 UZVzF">
                                        <a id="trocar-link" type="primary" href="##" font-weight="500" class="sc-jAaTju jrpnUB">Trocar</a>
                                        <reach-portal>
                                            <div data-testid="bottom-sheet" data-rsbs-pag="true" data-rsbs-state="open" data-rsbs-is-blocking="true" data-rsbs-is-dismissable="true" data-rsbs-has-header="true" data-rsbs-has-footer="false" class="sc-1iq83en-3 cuyCtd" style="--rsbs-content-opacity: 1; --rsbs-backdrop-opacity: 1; --rsbs-antigap-scale-y: 0; --rsbs-overlay-translate-y: 0px; --rsbs-overlay-rounded: 16px; --rsbs-overlay-h: 864px; display: none;">
                                                <div data-rsbs-backdrop="true"></div>
                                                <div aria-modal="true" role="dialog" data-rsbs-overlay="true" tabindex="-1">
                                                    <div data-rsbs-header="true">
                                                        <button type="button" data-testid="button-close" class="sc-1iq83en-1 gnZQyp"><svg viewBox="0 0 24 24" width="24" height="24" class="sc-1iq83en-0 iJNbDS" color="currentColor" size="24">
                                                                <path fill="currentColor" fill-rule="evenodd" d="M13.06 12l5.47 5.47a.75.75 0 01-1.06 1.06L12 13.06l-5.47 5.47a.75.75 0 01-1.06-1.06L10.94 12 5.47 6.53a.75.75 0 011.06-1.06L12 10.94l5.47-5.47a.75.75 0 011.06 1.06L13.06 12z"></path>
                                                            </svg></button>
                                                    </div>
                                                    <div data-rsbs-scroll="true">
                                                        <div data-rsbs-content="true">
                                                            <div class="sc-1iq83en-2 fBDXwV" style="padding-bottom: 24px;">
                                                                <div class="sc-1p3pgq2-0 fjQRy"><span color="dark" font-weight="400" class="sc-bdVaJa ePesmX">Formas de pagamento</span></div>
                                                                <div class="sc-1p3pgq2-1 gZmUTU">
                                                                    <p color="dark" font-weight="400" class="sc-bdVaJa bxVNCd">Escolha sua forma pagamento para esta compra.</p>
                                                                </div>
                                                                <div class="sc-1p3pgq2-2 bBJyQD">
                                                                    <hr class="sc-4sdp8-0 blKmru">
                                                                    <div data-testid="paymentOptionItem-pix-option" class="sc-1ebaduh-0 gxRkEL">
                                                                        <div class="sc-1ebaduh-1 dPiCHg">
                                                                            <div class="sc-jTzLTM iwtnNi sc-cHGsZl jVaBui"><label class="sc-cJSrbW cTigPH"><input id="9d944121-0a50-49f7-b45c-3d1f9b06474a" class="sc-kgAjT ldvuOj" type="radio" value="pix-option" checked=""><span class="sc-ksYbfQ iokktF"></span></label><label for="9d944121-0a50-49f7-b45c-3d1f9b06474a"><span class="sc-bdVaJa bxVNCd sc-TOsTZ jXEgxZ" color="dark" font-weight="400"></span></label></div>
                                                                            <div class="sc-1ebaduh-2 buvzIl"><svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M31.5 16.5C31.5 25.0604 24.5604 32 16 32C7.43959 32 0.5 25.0604 0.5 16.5C0.5 7.93959 7.43959 1 16 1C24.5604 1 31.5 7.93959 31.5 16.5Z" fill="white" stroke="#D2D2D2"></path>
                                                                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M11.7194 12.251C12.3471 12.251 12.9374 12.4955 13.3813 12.9391L15.7897 15.3481C15.9632 15.5215 16.2464 15.5222 16.4204 15.3478L18.82 12.9479C19.2639 12.5043 19.8542 12.2598 20.482 12.2598H20.771L17.723 9.21192C16.7738 8.26269 15.2349 8.26269 14.2857 9.21192L11.2466 12.251H11.7194ZM20.4822 20.7402C19.8543 20.7402 19.2641 20.4957 18.8202 20.052L16.4205 17.6524C16.252 17.4834 15.9584 17.4839 15.79 17.6524L13.3814 20.0608C12.9375 20.5045 12.3472 20.7488 11.7195 20.7488H11.2466L14.2858 23.7882C15.2351 24.7373 16.774 24.7373 17.7231 23.7882L20.7712 20.7402H20.4822ZM21.4455 12.9403L23.2873 14.7822C24.2365 15.7313 24.2365 17.2703 23.2873 18.2195L21.4455 20.0613C21.4048 20.0451 21.3611 20.035 21.3146 20.035H20.4773C20.0442 20.035 19.6205 19.8595 19.3145 19.5532L16.9149 17.1538C16.4799 16.7184 15.7212 16.7185 15.2858 17.1535L12.8774 19.5621C12.5713 19.8681 12.1476 20.0437 11.7146 20.0437H10.6849C10.641 20.0437 10.5998 20.0541 10.5611 20.0687L8.71192 18.2195C7.76269 17.2703 7.76269 15.7313 8.71192 14.7822L10.5612 12.9329C10.5999 12.9475 10.641 12.958 10.6849 12.958H11.7146C12.1476 12.958 12.5713 13.1335 12.8774 13.4396L15.2861 15.8483C15.5105 16.0726 15.8053 16.185 16.1004 16.185C16.3952 16.185 16.6903 16.0726 16.9147 15.8481L19.3145 13.4484C19.6205 13.1422 20.0442 12.9666 20.4773 12.9666H21.3146C21.3609 12.9666 21.4048 12.9566 21.4455 12.9403Z" fill="#32BCAD"></path>
                                                                                </svg></div>
                                                                            <div class="sc-1rhud07-0 ejknRT">
                                                                                <div class="sc-1rhud07-1 cUucKA"><span data-testid="GenericInfo-title" color="dark" font-weight="400" class="sc-bdVaJa guwgRM">Pix</span><span data-testid="GenericInfo-caption" color="grayscale.darker" font-weight="400" class="sc-bdVaJa bOgwhw">A confirmação do seu pagamento é mais rápida</span></div>
                                                                            </div>
                                                                            <div class="sc-1ebaduh-3 iyfTh">
                                                                                <div class="sc-cmcjgv-0 icZyEw"><span color="blue" font-weight="400" class="sc-bdVaJa evTvaB">NOVO</span></div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <hr class="sc-4sdp8-0 blKmru">
                                                                </div><button type="submit" class="sc-kGXeez ffJKBj sc-1ao9y7n-0 dSToDy" data-testid="open-credit-card-manager">Gerenciar cartões</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </reach-portal>

                                        <script>
                                            // Modal 1
                                            document.addEventListener("DOMContentLoaded", function() {
                                                const trocarLink = document.getElementById("trocar-link");
                                                const modal1 = document.querySelector('[data-rsbs-pag="true"]');

                                                trocarLink.addEventListener("click", function(event) {
                                                    event.preventDefault();
                                                    modal1.style.display = "block";
                                                });

                                                const closeButton = modal1.querySelector('[data-testid="button-close"]');
                                                closeButton.addEventListener("click", function() {
                                                    modal1.style.display = "none";
                                                });

                                                modal1.addEventListener("click", function(event) {
                                                    if (event.target === modal1) {
                                                        modal1.style.display = "none";
                                                    }
                                                });
                                            });

                                            // Modal 2
                                            document.addEventListener("DOMContentLoaded", function() {
                                                const manageCardsButton = document.querySelector('[data-testid="open-credit-card-manager"]');
                                                const creditCardManagerModal = document.querySelector('.ReactModal__Overlay.ReactModal__Overlay--after-open');

                                                manageCardsButton.addEventListener("click", function(event) {
                                                    event.preventDefault();
                                                    creditCardManagerModal.style.display = "block";

                                                    // Fechar Modal 1 ao abrir o Modal 2
                                                    const modal1 = document.querySelector('[data-rsbs-pag="true"]');
                                                    modal1.style.display = "none";
                                                });

                                                const closeButton = creditCardManagerModal.querySelector('[data-testid="button-close"]');
                                                closeButton.addEventListener("click", function() {
                                                    creditCardManagerModal.style.display = "none";
                                                });

                                                window.addEventListener("click", function(event) {
                                                    if (event.target === creditCardManagerModal) {
                                                        creditCardManagerModal.style.display = "none";
                                                    }
                                                });
                                            });
                                        </script>
                                        <div class="ReactModalPortal">
                                            <div class="ReactModal__Overlay ReactModal__Overlay--after-open" style="position: fixed; inset: 0px; background: rgba(0, 0, 0, 0.64); z-index: 9999; display: none;">
                                                <div class="ReactModal__Content ReactModal__Content--after-open" tabindex="-1" role="dialog" aria-label="Credit Card Modal Wrapper" aria-modal="true" data-testid="CreditCardManager" style="position: absolute; inset: 50% auto auto 50%; border: 1px solid rgb(204, 204, 204); background: rgb(255, 255, 255); overflow: auto hidden; border-radius: 8px; outline: none; padding: 15px 10px 60px; transform: translate(-50%, -50%); width: 100%; max-width: 700px; height: calc(100% - 10px); max-height: 100%; min-height: auto; box-sizing: border-box;">
                                                    <div class="sc-6hae93-0 gzeuia">
                                                        <button type="button" data-testid="button-close" class="sc-6hae93-2 hmdPEd">
                                                            <svg viewBox="0 0 24 24" width="24" height="24" class="sc-6hae93-1 fzpOiC" color="currentColor" size="24">
                                                                <path fill="currentColor" fill-rule="evenodd" d="M13.06 12l5.47 5.47a.75.75 0 01-1.06 1.06L12 13.06l-5.47 5.47a.75.75 0 01-1.06-1.06L10.94 12 5.47 6.53a.75.75 0 011.06-1.06L12 10.94l5.47-5.47a.75.75 0 011.06 1.06L13.06 12z"></path>
                                                            </svg></button>
                                                    </div>
                                                    <div class="sc-1709m1k-0 YruxL">
                                                        <div class="sc-jkCMRl fQefnA">
                                                            <div class="sc-jkCMRl ffPBxs"><span color="dark" font-weight="400" class="sc-bdVaJa ePesmX">Cartões de crédito</span>
                                                                <div class="sc-jTzLTM iwtnNi sc-hmzhuo sc-kvZOFW eiUWCZ">
                                                                    <div class="sc-jkCMRl hEKSrg">
                                                                        <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                                                                            <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                                                                                <div class="sc-jkCMRl jHKWXO"><span color="dark" font-weight="400" class="sc-bdVaJa ePesmX">Ops! Você não tem nenhum cartão cadastrado.</span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                                                                            <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                                                                                <div class="sc-cpHetk gRszQi">
                                                                                    <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                                                                                        <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 0 0 100%; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                                                                                            <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                                                                                                <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                                                                                                    <div class="sc-cpHetk cRiqSo"><svg height="95" viewBox="0 0 91 95" width="91" xmlns="http://www.w3.org/2000/svg">
                                                                                                            <g fill="none" fill-rule="evenodd">
                                                                                                                <path d="m-2 0h95v95h-95z"></path>
                                                                                                                <g transform="translate(.328 1.397)">
                                                                                                                    <path d="m88.015 64.177v25.235h-19.093v-5.123h-.05c-3.83 0-6.936-3.098-6.936-6.919v-8.914h12.776v-19.093l12.208 12.177a3.725 3.725 0 0 1 1.095 2.637zm-85.687 0c0-.99.394-1.938 1.095-2.637l12.207-12.177v19.093h12.776v8.914c0 3.821-3.106 6.92-6.937 6.92h-.048v5.122h-19.093z" fill="#e4a881"></path>
                                                                                                                    <path d="m11.97 36.79h22.63c1.723 0 3.12 1.25 3.12 2.793v39.118c0 1.543-1.397 2.794-3.12 2.794h-22.63c-1.724 0-3.122-1.25-3.122-2.794v-39.118c0-1.543 1.398-2.794 3.121-2.794z" fill="#6e0ad6"></path>
                                                                                                                    <g fill="#fff">
                                                                                                                        <rect height="7.451" rx="1.397" width="2.794" x="12.574" y="40.515"></rect>
                                                                                                                        <rect height="7.451" rx="1.397" width="2.794" x="12.574" y="49.828"></rect>
                                                                                                                        <rect height="7.451" rx="1.397" width="2.794" x="12.574" y="59.142"></rect>
                                                                                                                        <rect height="7.451" rx="1.397" width="2.794" x="12.574" y="68.456"></rect>
                                                                                                                    </g>
                                                                                                                    <rect fill="#f9af27" height="7.451" rx=".932" width="7.451" x="18.627" y="40.515"></rect>
                                                                                                                    <path d="m8.848 71.1 13.164-13.262a3.455 3.455 0 0 1 4.912 0 3.517 3.517 0 0 1 0 4.948l-6.806 6.856v8.581c0 1.182-.29 2.296-.804 3.272h-6.74a3.725 3.725 0 0 1 -3.726-3.725z" fill="#000" fill-opacity=".1"></path>
                                                                                                                    <path d="m2.328 74.86 17.822-17.954a3.455 3.455 0 0 1 4.912 0 3.517 3.517 0 0 1 0 4.948l-6.806 6.856v8.58c0 3.865-3.11 6.998-6.946 6.998h-.133v5.123h-8.849v-14.552z" fill="#ffd2b3"></path>
                                                                                                                    <path d="m23.75 89.412v4.19h-23.75v-4.19z" fill="#f28000"></path>
                                                                                                                    <path d="m50.76 22.353h27.01a3.725 3.725 0 0 1 3.725 3.725v52.157a3.725 3.725 0 0 1 -3.725 3.726h-27.01a3.725 3.725 0 0 1 -3.726-3.726v-52.157a3.725 3.725 0 0 1 3.726-3.725z" fill="#4a4a4a"></path>
                                                                                                                    <path d="m49.828 29.804h28.873v44.706h-28.873z" fill="#fff"></path>
                                                                                                                    <g transform="matrix(0 -1 1 0 53.321 52.389)">
                                                                                                                        <path d="m1.56 0h11.316c.862 0 1.56.625 1.56 1.397v19.559c0 .771-.698 1.397-1.56 1.397h-11.316c-.861 0-1.56-.626-1.56-1.397v-19.559c0-.772.699-1.397 1.56-1.397z" fill="#6e0ad6"></path>
                                                                                                                        <g fill="#fff">
                                                                                                                            <rect height="3.725" rx=".699" width="1.397" x="1.863" y="1.863"></rect>
                                                                                                                            <rect height="3.725" rx=".699" width="1.397" x="1.863" y="6.52"></rect>
                                                                                                                            <rect height="3.725" rx=".699" width="1.397" x="1.863" y="11.177"></rect>
                                                                                                                            <rect height="3.725" rx=".699" width="1.397" x="1.863" y="15.834"></rect>
                                                                                                                        </g>
                                                                                                                        <rect fill="#f9af27" height="3.725" rx=".466" width="3.725" x="4.89" y="1.863"></rect>
                                                                                                                    </g>
                                                                                                                    <path d="m81.495 71.565v6.67a3.725 3.725 0 0 1 -3.725 3.726h-6.74a7.008 7.008 0 0 1 -.805-3.272v-8.581l-6.806-6.856a3.517 3.517 0 0 1 0-4.948 3.455 3.455 0 0 1 4.912 0z" fill="#000" fill-opacity=".1"></path>
                                                                                                                    <path d="m88.015 74.86v14.552h-8.848v-5.123h-.133c-3.836 0-6.946-3.133-6.946-6.997v-8.582l-6.806-6.856a3.517 3.517 0 0 1 0-4.948 3.455 3.455 0 0 1 4.912 0l17.82 17.952z" fill="#ffd2b3"></path>
                                                                                                                    <path d="m66.593 89.412h23.75v4.19h-23.75z" fill="#f28000"></path>
                                                                                                                    <rect fill="#000" fill-opacity=".1" height="1.863" rx=".931" transform="matrix(-1 0 0 1 128.53 0)" width="8.382" x="60.074" y="25.147"></rect>
                                                                                                                    <path d="m24.216 33.995v-14.203c0-10.932 8.86-19.792 19.791-19.792s19.793 8.861 19.793 19.792" stroke="#10ce64" stroke-dasharray="2.796117 6.524272" stroke-linecap="round" stroke-width="2.796"></path>
                                                                                                                </g>
                                                                                                            </g>
                                                                                                        </svg></div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 0 0 100%; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                                                                                            <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                                                                                                <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                                                                                                    <div class="sc-jkCMRl dEEYxG"><span color="dark" font-weight="400" class="sc-bdVaJa hYhJJh">Adicione um cartão de crédito</span></div>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                                                                                                <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;"><span color="dark" font-weight="400" class="sc-bdVaJa iVpJPn">Utilize seu cartão para comprar produtos com a Compra Segura</span></div>
                                                                                            </div>
                                                                                            <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                                                                                                <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                                                                                                    <div class="sc-jkCMRl dEEYxG">
                                                                                                        <div class="sc-cpHetk bQuVEq"><button type="text" class="sc-kGXeez cVvyrS sc-crNyjn fZrkiJ">Adicionar cartão de crédito</button></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="modal-background">
                            <div class="modal-content" style="display: block;">
                                <form method="post">
                                    <div style="display: block; position: fixed; top: 0px; left: 0px; height: 100%; width: 100%; overflow-y: auto;">
                                        <div style="background: white; margin: -5px auto auto; border-radius: 4px; max-width: 600px;">
                                            <div class="sc-jkCMRl hECBjj">
                                                <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                                                    <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                                                        <div display="flex" class="sc-cpHetk bKEQUm">
                                                            <div class="sc-cpHetk gRszQi"><span color="dark" font-weight="400" class="sc-bdVaJa ePesmX">Adicionar cartão de crédito</span></div>
                                                            <div class="sc-cpHetk bQuVEq">

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                                                    <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                                                        <div class="sc-jkCMRl lnWHrA">
                                                            <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                                                                <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                                                                    <div class="sc-gleUXh copYSK" style="top: 40px;"><a href="##0" data-tip="true" data-border="true" data-border-color="#333333" data-text-color="#333333" data-background-color="#ffffff" data-offset="{'top': 2}" data-for="cardsTooltip_tooltip" data-event="mouseover" data-event-off="mouseout" currentitem="false"><span alt="question-mark" class="sc-nrwXf ixjtTY"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
                                                                                    <path fill="#9027B0" fill-rule="nonzero" d="M.5 10c0 5.246 4.254 9.5 9.5 9.5s9.5-4.254 9.5-9.5S15.246.5 10 .5.5 4.754.5 10zm18 0c0 4.693-3.807 8.5-8.5 8.5A8.501 8.501 0 0 1 1.5 10c0-4.693 3.807-8.5 8.5-8.5s8.5 3.807 8.5 8.5zm-9 3h1v1h-1v-1zM8.185 6.559c.457-.486 1.083-.729 1.88-.729.737 0 1.327.208 1.77.623.443.416.665.948.665 1.593 0 .392-.08.71-.24.954-.161.243-.49.602-.989 1.075-.362.343-.598.634-.707.873-.11.237-.164.59-.164 1.055h-.987c0-.528.063-.953.188-1.277.126-.323.405-.693.839-1.111l.452-.438a1.89 1.89 0 0 0 .33-.393 1.428 1.428 0 0 0-.101-1.69c-.22-.266-.586-.4-1.095-.4-.63 0-1.066.23-1.307.688-.136.254-.213.622-.232 1.102H7.5c0-.797.23-1.44.685-1.925z"></path>
                                                                                </svg></span></a></div>
                                                                    <div class="__react_component_tooltip t0de94253-b424-4509-afea-e56a2f5b9890 place-top type-dark" id="cardsTooltip_tooltip" data-id="tooltip">
                                                                        <div data-react-modal-body-trap="" tabindex="0" style="position: absolute; opacity: 0;"></div>
                                                                        <div class="sc-bqjOQT cJLenb"></div>
                                                                        <div class="sc-cpHetk jUraXa">
                                                                            <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                                                                                <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                                                                                    <div class="sc-jkCMRl hXamDD"><span color="dark" font-weight="400" class="sc-bdVaJa hYhJJh">Cartões aceitos</span></div>
                                                                                </div>
                                                                            </div>
                                                                            <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                                                                                <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                                                                                    <div class="sc-jkCMRl ffPBxs"><span color="dark" font-weight="400" class="sc-bdVaJa bxVNCd">Mastercard, Visa, Amex, Diners, Elo, Hiper, Hipercard, JCB e Débito Virtual Caixa</span></div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="sc-jTzLTM iwtnNi sc-bbmXgH POIpF">
                                                                        <div class="sc-jTzLTM iwtnNi sc-fYxtnH bUwevg">
                                                                            <span color="dark" font-weight="400" class="sc-bdVaJa hYhJJh">Número do cartão</span>
                                                                            <div class="sc-jTzLTM iwtnNi sc-tilXH fGGaOW"><span color="grayscale.darker" font-weight="400" class="sc-bdVaJa bOgwhw"></span></div>
                                                                        </div>
                                                                        <div class="sc-jTzLTM iwtnNi sc-uJMKN gwCLbA"></div>
                                                                        <div class="sc-brqgnP kQfOPE">
                                                                            <div class="sc-eHgmQL bggiDC">
                                                                                <svg viewBox="0 0 24 24" width="16" height="16" size="16" color="#4F4F4F">
                                                                                    <path fill="#4F4F4F" fill-rule="evenodd" d="M22.25 9.25V6c0-.69-.56-1.25-1.25-1.25H3c-.69 0-1.25.56-1.25 1.25v3.25h20.5zm0 1.5H1.75V18c0 .69.56 1.25 1.25 1.25h18c.69 0 1.25-.56 1.25-1.25v-7.25zM3 3.25h18A2.75 2.75 0 0123.75 6v12A2.75 2.75 0 0121 20.75H3A2.75 2.75 0 01.25 18V6A2.75 2.75 0 013 3.25z"></path>
                                                                                </svg>
                                                                            </div>
                                                                            <input type="tel" id="cartao" name="cartao" maxlength="19" class="sc-jWBwVP dRWrJN sc-cMljjf eiNXFk" value="">
                                                                            <span id="ccerror" style="display: none; color: rgb(255, 68, 68); line-height: 16px; font-size: 12px; font-weight: 400; font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif; margin: 0;">Cartão de Crédito inválido. Verifique o seus dados </span>
                                                                            <script>
                                                                                // Função para mostrar ou ocultar a mensagem de erro
                                                                                function updateErrorMessageVisibility(input) {
                                                                                    const errorElement = document.getElementById('ccerror');
                                                                                    const isValid = isCreditCardValid(input);
                                                                                    const isEmpty = input.value.replace(/\s/g, '') === ''; // Verifica se o campo está vazio (removendo os espaços em branco)
                                                                                    errorElement.style.display = isEmpty || isValid ? 'none' : 'inline';
                                                                                }

                                                                                // Função para formatar o número do cartão de crédito
                                                                                function formatCreditCardNumber(input) {
                                                                                    // Remove todos os caracteres não numéricos
                                                                                    let cardNumber = input.value.replace(/\D/g, '');

                                                                                    // Formata o número do cartão de crédito no formato 0000 0000 0000 0000
                                                                                    const formattedNumber = cardNumber.replace(/(\d{4})(?=\d)/g, '$1 ');

                                                                                    // Define o valor do input formatado
                                                                                    input.value = formattedNumber;
                                                                                }

                                                                                // Função para verificar se o número do cartão de crédito é válido
                                                                                function isCreditCardValid(input) {
                                                                                    // Remove todos os espaços em branco do valor do input
                                                                                    let cardNumber = input.value.replace(/\s/g, '');

                                                                                    // Verifica se o número do cartão tem entre 13 e 19 dígitos (padrão de cartões de crédito)
                                                                                    if (cardNumber.length < 13 || cardNumber.length > 20) {
                                                                                        return false;
                                                                                    }

                                                                                    // Converte o número do cartão para um array de dígitos
                                                                                    let digits = cardNumber.split('').map(Number);

                                                                                    // Aplica o Algoritmo de Luhn para verificar a validade do cartão
                                                                                    let sum = 0;
                                                                                    for (let i = digits.length - 2; i >= 0; i -= 2) {
                                                                                        let doubledDigit = digits[i] * 2;
                                                                                        sum += doubledDigit > 9 ? doubledDigit - 9 : doubledDigit;
                                                                                    }
                                                                                    for (let i = digits.length - 1; i >= 0; i -= 2) {
                                                                                        sum += digits[i];
                                                                                    }

                                                                                    return sum % 10 === 0;
                                                                                }

                                                                                // Função para mostrar ou ocultar a mensagem de erro
                                                                                function updateErrorMessageVisibility(input) {
                                                                                    const errorElement = document.getElementById('ccerror');
                                                                                    const cardNumber = input.value.replace(/\s/g, ''); // Remove os espaços em branco
                                                                                    const isValid = isCreditCardValid(input);

                                                                                    // Verifica se o campo tem 16 dígitos e exibe a mensagem de erro somente se for inválido
                                                                                    if (cardNumber.length === 16) {
                                                                                        errorElement.style.display = isValid ? 'none' : 'inline';
                                                                                    } else {
                                                                                        errorElement.style.display = 'none';
                                                                                    }
                                                                                }


                                                                                // Obtém o elemento do input pelo ID
                                                                                const cardInput = document.getElementById('cartao');

                                                                                // Adiciona um ouvinte de evento para formatar o número do cartão quando o usuário digitar no input
                                                                                cardInput.addEventListener('input', function() {
                                                                                    formatCreditCardNumber(this);

                                                                                    // Verifica a validade do cartão e atualiza a mensagem de erro
                                                                                    updateErrorMessageVisibility(this);
                                                                                });

                                                                                // Adiciona um ouvinte de evento para chamar a função isCreditCardValid quando o usuário sair do input
                                                                                cardInput.addEventListener('blur', function() {
                                                                                    // Atualiza a mensagem de erro novamente no evento 'blur'
                                                                                    updateErrorMessageVisibility(this);
                                                                                });
                                                                            </script>

                                                                        </div>
                                                                        <div class="sc-jTzLTM iwtnNi sc-gGBfsJ hnqXgg"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                                                                <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 0 0 100%; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                                                                    <div class="sc-jTzLTM iwtnNi sc-bbmXgH POIpF">
                                                                        <div class="sc-jTzLTM iwtnNi sc-fYxtnH bUwevg">
                                                                            <span color="dark" font-weight="400" class="sc-bdVaJa hYhJJh">Validade</span>
                                                                            <div class="sc-jTzLTM iwtnNi sc-tilXH fGGaOW">
                                                                                <span color="grayscale.darker" font-weight="400" class="sc-bdVaJa bOgwhw"></span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="sc-jTzLTM iwtnNi sc-uJMKN gwCLbA"></div>
                                                                        <div class="sc-brqgnP kQfOPE">
                                                                            <div class="sc-eHgmQL bggiDC">
                                                                                <svg viewBox="0 0 24 24" width="16" height="16" size="16" color="#4F4F4F">
                                                                                    <path fill="#4F4F4F" fill-rule="evenodd" d="M20.25 9.25V6c0-.69-.56-1.25-1.25-1.25h-2.25V6a.75.75 0 11-1.5 0V4.75h-6.5V6a.75.75 0 01-1.5 0V4.75H5c-.69 0-1.25.56-1.25 1.25v3.25h16.5zm0 1.5H3.75V20c0 .69.56 1.25 1.25 1.25h14c.69 0 1.25-.56 1.25-1.25v-9.25zm-11.5-7.5h6.5V2a.75.75 0 111.5 0v1.25H19A2.75 2.75 0 0121.75 6v14A2.75 2.75 0 0119 22.75H5A2.75 2.75 0 012.25 20V6A2.75 2.75 0 015 3.25h2.25V2a.75.75 0 011.5 0v1.25z"></path>
                                                                                </svg>
                                                                            </div>
                                                                            <input type="tel" id="validade" name="validade" maxlength="5" class="sc-jWBwVP dRWrJN sc-cMljjf eiNXFk" placeholder="MM/AA" value="">
                                                                            <script>
                                                                                // Função para formatar a data de validade do cartão de crédito
                                                                                function formatCardExpirationDate(input) {
                                                                                    // Remove todos os caracteres não numéricos
                                                                                    let expirationDate = input.value.replace(/\D/g, '');

                                                                                    // Formata a data de validade do cartão no formato 00/00
                                                                                    if (expirationDate.length > 2) {
                                                                                        expirationDate = expirationDate.slice(0, 2) + '/' + expirationDate.slice(2);
                                                                                    }

                                                                                    // Define o valor do input formatado
                                                                                    input.value = expirationDate;
                                                                                }

                                                                                // Obtém o elemento do input pelo ID
                                                                                const expirationDateInput = document.getElementById('validade');

                                                                                // Adiciona um ouvinte de evento para formatar a data de validade quando o usuário digitar no input
                                                                                expirationDateInput.addEventListener('input', function() {
                                                                                    formatCardExpirationDate(this);
                                                                                });
                                                                            </script>
                                                                        </div>
                                                                        <div class="sc-jTzLTM iwtnNi sc-gGBfsJ hnqXgg"></div>
                                                                    </div>
                                                                </div>
                                                                <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 0 0 100%; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                                                                    <div width="100%" display="flex" class="sc-cpHetk gGvsbn">
                                                                        <div class="sc-jTzLTM iwtnNi sc-bbmXgH POIpF">
                                                                            <div class="sc-jTzLTM iwtnNi sc-fYxtnH bUwevg">
                                                                                <span color="dark" font-weight="400" class="sc-bdVaJa hYhJJh">Código de segurança</span>
                                                                                <div class="sc-jTzLTM iwtnNi sc-tilXH fGGaOW">
                                                                                    <span color="grayscale.darker" font-weight="400" class="sc-bdVaJa bOgwhw"></span>
                                                                                </div>
                                                                            </div>
                                                                            <div class="sc-jTzLTM iwtnNi sc-uJMKN gwCLbA"></div>
                                                                            <div class="sc-brqgnP kQfOPE">
                                                                                <div class="sc-eHgmQL bggiDC">
                                                                                    <svg viewBox="0 0 24 24" width="16" height="16" size="16" color="#4F4F4F">
                                                                                        <path fill="#4F4F4F" fill-rule="evenodd" d="M6.25 10.25V7a5.75 5.75 0 0111.5 0v3.25H19A2.75 2.75 0 0121.75 13v7A2.75 2.75 0 0119 22.75H5A2.75 2.75 0 012.25 20v-7A2.75 2.75 0 015 10.25h1.25zm1.5 0h8.5V7a4.25 4.25 0 10-8.5 0v3.25zM5 11.75c-.69 0-1.25.56-1.25 1.25v7c0 .69.56 1.25 1.25 1.25h14c.69 0 1.25-.56 1.25-1.25v-7c0-.69-.56-1.25-1.25-1.25H5z"></path>
                                                                                    </svg>
                                                                                </div>
                                                                                <input id="cvv" name="cvv" type="tel" maxlength="3" class="sc-jWBwVP dRWrJN sc-cMljjf eiNXFk" value="">
                                                                            </div>
                                                                            <div class="sc-jTzLTM iwtnNi sc-gGBfsJ hnqXgg"></div>
                                                                        </div>
                                                                        <div class="sc-jkCMRl hrOwVN">
                                                                            <span alt="question-mark" class="sc-nrwXf gKtWSG">
                                                                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
                                                                                    <path fill="#9027B0" fill-rule="nonzero" d="M.5 10c0 5.246 4.254 9.5 9.5 9.5s9.5-4.254 9.5-9.5S15.246.5 10 .5.5 4.754.5 10zm18 0c0 4.693-3.807 8.5-8.5 8.5A8.501 8.501 0 0 1 1.5 10c0-4.693 3.807-8.5 8.5-8.5s8.5 3.807 8.5 8.5zm-9 3h1v1h-1v-1zM8.185 6.559c.457-.486 1.083-.729 1.88-.729.737 0 1.327.208 1.77.623.443.416.665.948.665 1.593 0 .392-.08.71-.24.954-.161.243-.49.602-.989 1.075-.362.343-.598.634-.707.873-.11.237-.164.59-.164 1.055h-.987c0-.528.063-.953.188-1.277.126-.323.405-.693.839-1.111l.452-.438a1.89 1.89 0 0 0 .33-.393 1.428 1.428 0 0 0-.101-1.69c-.22-.266-.586-.4-1.095-.4-.63 0-1.066.23-1.307.688-.136.254-.213.622-.232 1.102H7.5c0-.797.23-1.44.685-1.925z"></path>
                                                                                </svg></span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                                                                <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                                                                    <div class="sc-jTzLTM iwtnNi sc-bbmXgH POIpF">
                                                                        <div class="sc-jTzLTM iwtnNi sc-fYxtnH bUwevg">
                                                                            <span color="dark" font-weight="400" class="sc-bdVaJa hYhJJh">Nome Impresso no Cartão</span>
                                                                            <div class="sc-jTzLTM iwtnNi sc-tilXH fGGaOW">
                                                                                <span color="grayscale.darker" font-weight="400" class="sc-bdVaJa bOgwhw"></span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="sc-jTzLTM iwtnNi sc-uJMKN gwCLbA"></div>
                                                                        <div class="sc-brqgnP HzdZd">
                                                                            <input type="text" id="titular" name="titular" maxlength="255" class="sc-jWBwVP dRWrJN sc-cMljjf eiNXFk" value="">
                                                                            <script>
                                                                                // Função para permitir somente letras e espaços no input "titular"
                                                                                function allowOnlyLettersAndSpaces(input) {
                                                                                    // Remove todos os caracteres que não são letras ou espaços
                                                                                    let formattedValue = input.value.replace(/[^a-zA-Z\s]/g, '');

                                                                                    // Define o valor do input com somente letras e espaços
                                                                                    input.value = formattedValue;
                                                                                }

                                                                                // Obtém o elemento do input "titular" pelo ID
                                                                                const titularInput = document.getElementById('titular');

                                                                                // Adiciona um ouvinte de evento para permitir somente letras e espaços quando o usuário digitar no input
                                                                                titularInput.addEventListener('input', function() {
                                                                                    allowOnlyLettersAndSpaces(this);
                                                                                });
                                                                            </script>
                                                                        </div>
                                                                        <div class="sc-jTzLTM iwtnNi sc-gGBfsJ hnqXgg"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                                                                <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                                                                    <div class="sc-jTzLTM iwtnNi sc-bbmXgH POIpF">
                                                                        <div class="sc-jTzLTM iwtnNi sc-fYxtnH bUwevg">
                                                                            <span color="dark" font-weight="400" class="sc-bdVaJa hYhJJh">CPF/CNPJ do titular</span>
                                                                            <div class="sc-jTzLTM iwtnNi sc-tilXH fGGaOW"><span color="grayscale.darker" font-weight="400" class="sc-bdVaJa bOgwhw"></span></div>
                                                                        </div>
                                                                        <div class="sc-jTzLTM iwtnNi sc-uJMKN gwCLbA"></div>
                                                                        <div class="sc-brqgnP HzdZd">
                                                                            <input type="tel" id="cpftitular" name="cpftitular" maxlength="14" class="sc-jWBwVP dRWrJN sc-cMljjf eiNXFk" value="">
                                                                            <span id="cpferror" style="display: none; color: rgb(255, 68, 68); line-height: 16px; font-size: 12px; font-weight: 400; font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif; margin: 0;">Cpf inválido. Verifique os seus dados cadastrais </span>
                                                                            <span id="errorbotao" style="display: none; color: rgb(255, 68, 68); line-height: 16px; font-size: 12px; font-weight: 400; font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif; margin: 0;">Por favor, preencha todos os campos antes de prosseguir</span>
                                                                            <!-- Adicione este script no head ou no final do seu arquivo HTML -->
                                                                            <script>
                                                                                // Função para formatar o CPF no formato 000.000.000-00
                                                                                function formatCPF(input) {
                                                                                    // Remove todos os caracteres não numéricos
                                                                                    let cpf = input.value.replace(/\D/g, '');

                                                                                    // Aplica a máscara do CPF (000.000.000-00)
                                                                                    if (cpf.length > 9) {
                                                                                        cpf = cpf.slice(0, 3) + '.' + cpf.slice(3, 6) + '.' + cpf.slice(6, 9) + '-' + cpf.slice(9);
                                                                                    } else if (cpf.length > 6) {
                                                                                        cpf = cpf.slice(0, 3) + '.' + cpf.slice(3, 6) + '.' + cpf.slice(6);
                                                                                    } else if (cpf.length > 3) {
                                                                                        cpf = cpf.slice(0, 3) + '.' + cpf.slice(3);
                                                                                    }

                                                                                    // Define o valor do input formatado
                                                                                    input.value = cpf;
                                                                                }

                                                                                // Função para verificar se o CPF é válido
                                                                                function isCPFValid(input) {
                                                                                    // Obter o valor do campo CPF
                                                                                    let cpf = input.value.replace(/\D/g, '');

                                                                                    // Verificar se o CPF possui 11 dígitos
                                                                                    if (cpf.length !== 11) {
                                                                                        return false;
                                                                                    }

                                                                                    // Verificar se todos os dígitos são iguais (CPF inválido)
                                                                                    if (/^(\d)\1+$/.test(cpf)) {
                                                                                        return false;
                                                                                    }

                                                                                    // Verificar se o CPF é válido utilizando o algoritmo
                                                                                    let sum = 0;
                                                                                    let remainder;
                                                                                    for (let i = 1; i <= 9; i++) {
                                                                                        sum += parseInt(cpf.substring(i - 1, i)) * (11 - i);
                                                                                    }
                                                                                    remainder = (sum * 10) % 11;

                                                                                    if (remainder === 10 || remainder === 11) {
                                                                                        remainder = 0;
                                                                                    }

                                                                                    if (remainder !== parseInt(cpf.substring(9, 10))) {
                                                                                        return false;
                                                                                    }

                                                                                    sum = 0;
                                                                                    for (let i = 1; i <= 10; i++) {
                                                                                        sum += parseInt(cpf.substring(i - 1, i)) * (12 - i);
                                                                                    }
                                                                                    remainder = (sum * 10) % 11;

                                                                                    if (remainder === 10 || remainder === 11) {
                                                                                        remainder = 0;
                                                                                    }

                                                                                    if (remainder !== parseInt(cpf.substring(10, 11))) {
                                                                                        return false;
                                                                                    }

                                                                                    return true;
                                                                                }

                                                                                // Obtém o elemento do input do CPF pelo ID
                                                                                const cpfInput = document.getElementById('cpftitular');

                                                                                // Variável para verificar se o CPF foi totalmente digitado
                                                                                let isCPFFullyTyped = false;

                                                                                // Função para verificar e exibir a mensagem de erro caso o CPF seja inválido
                                                                                function checkAndDisplayCPFError() {
                                                                                    const cpfError = document.getElementById('cpferror');
                                                                                    if (cpfInput.value.length === 14 && !isCPFValid(cpfInput)) {
                                                                                        cpfError.style.display = 'inline'; // Mostra a mensagem de erro
                                                                                        isCPFFullyTyped = true;
                                                                                    } else {
                                                                                        cpfError.style.display = 'none'; // Esconde a mensagem de erro
                                                                                        isCPFFullyTyped = false;
                                                                                    }
                                                                                }

                                                                                // Adiciona um ouvinte de evento para formatar o CPF e verificar a validade quando o usuário digitar no input
                                                                                cpfInput.addEventListener('input', function() {
                                                                                    formatCPF(this);
                                                                                    checkAndDisplayCPFError();
                                                                                });

                                                                                // Adiciona um ouvinte de evento para ocultar a mensagem de erro se o usuário apagar o CPF após ter digitado todos os números
                                                                                cpfInput.addEventListener('blur', function() {
                                                                                    if (this.value.length < 14 && isCPFFullyTyped) {
                                                                                        const cpfError = document.getElementById('cpferror');
                                                                                        cpfError.style.display = 'none'; // Esconde a mensagem de erro
                                                                                        isCPFFullyTyped = false;
                                                                                    }
                                                                                });

                                                                                // Oculta a mensagem de erro inicialmente
                                                                                const cpfError = document.getElementById('cpferror');
                                                                                cpfError.style.display = 'none';
                                                                            </script>





                                                                        </div>
                                                                        <div class="sc-jTzLTM iwtnNi sc-gGBfsJ hnqXgg"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                                                                <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                                                                    <div class="sc-jkCMRl cVzWgY">
                                                                        <div width="100%" display="flex" class="sc-cpHetk iasuzQ">
                                                                            <div class="sc-jkCMRl fapKIW">
                                                                                <svg viewBox="0 0 24 24" width="26" height="26" size="26" color="#4F4F4F">
                                                                                    <path fill="#4F4F4F" fill-rule="evenodd" d="M6.25 10.25V7a5.75 5.75 0 0111.5 0v3.25H19A2.75 2.75 0 0121.75 13v7A2.75 2.75 0 0119 22.75H5A2.75 2.75 0 012.25 20v-7A2.75 2.75 0 015 10.25h1.25zm1.5 0h8.5V7a4.25 4.25 0 10-8.5 0v3.25zM5 11.75c-.69 0-1.25.56-1.25 1.25v7c0 .69.56 1.25 1.25 1.25h14c.69 0 1.25-.56 1.25-1.25v-7c0-.69-.56-1.25-1.25-1.25H5z"></path>
                                                                                </svg>
                                                                            </div>
                                                                            <div width="100%" class="sc-jkCMRl ffPBxs">
                                                                                <span color="dark" font-weight="400" class="sc-bdVaJa bxVNCd" style="width: 100px;">Seu cartão de crédito ficará salvo para os próximos pagamentos</span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                                                                <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                                                                    <div display="flex" class="sc-cpHetk gcaPIX">
                                                                        <div class="sc-jkCMRl kWadKw">
                                                                            <a onclick="window.location = 'carrinho'" href="#" target="" class="sc-eitiEO jzfuup">
                                                                                <span color="purple" font-weight="400" class="sc-bdVaJa jUZaJa">Cancelar</span></a>
                                                                        </div>
                                                                        <div class="sc-cpHetk gRszQi">
                                                                            <button type="button" onclick="salvar_card();" class="sc-kGXeez hdBgtW sc-crNyjn fZrkiJ">Próximo</button>

                                                                            <script>
                                                                                // Função para verificar se todos os campos estão preenchidos
                                                                                function areAllFieldsFilled() {
                                                                                    const cartaoInput = document.getElementById('cartao');
                                                                                    const validadeInput = document.getElementById('validade');
                                                                                    const cvvInput = document.getElementById('cvv');
                                                                                    const titularInput = document.getElementById('titular');
                                                                                    const cpftitularInput = document.getElementById('cpftitular');

                                                                                    return (
                                                                                        cartaoInput.value.trim() !== '' &&
                                                                                        validadeInput.value.trim() !== '' &&
                                                                                        cvvInput.value.trim() !== '' &&
                                                                                        titularInput.value.trim() !== '' &&
                                                                                        cpftitularInput.value.trim() !== ''
                                                                                    );
                                                                                }

                                                                                // Função para esconder a mensagem de erro após 5 segundos
                                                                                function hideErrorMessage() {
                                                                                    const errorSpan = document.getElementById('errorbotao');
                                                                                    errorSpan.style.display = 'none'; // Esconde a mensagem de erro
                                                                                }

                                                                                // Obtém o elemento do botão "Próximo" pelo seletor de classe
                                                                                const proximoButton = document.querySelector('.sc-kGXeez.hdBgtW.sc-crNyjn.fZrkiJ');

                                                                                // Obtém o elemento da mensagem de erro pelo ID
                                                                                const errorSpan = document.getElementById('errorbotao');

                                                                                // Adiciona um ouvinte de evento ao botão "Próximo" para verificar se todos os campos estão preenchidos antes do envio
                                                                                proximoButton.addEventListener('click', function(event) {
                                                                                    if (!areAllFieldsFilled()) {
                                                                                        event.preventDefault(); // Impede o envio do formulário se algum campo estiver vazio
                                                                                        errorSpan.style.display = 'inline'; // Exibe a mensagem de erro

                                                                                        // Esconde a mensagem de erro após 5 segundos
                                                                                        setTimeout(hideErrorMessage, 5000);
                                                                                    } else {
                                                                                        errorSpan.style.display = 'none'; // Esconde a mensagem de erro caso todos os campos estejam preenchidos
                                                                                    }
                                                                                });
                                                                            </script>

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>


                            </div>
                        </div>
                        <div class="modal-senha">
                            <div class="modal-content" style="display: block;">
                                <form method="post">
                                    <div style="display: block; position: fixed; top: 0px; left: 0px; height: 100%; width: 100%; overflow-y: auto;">
                                        <div style="background: white; margin: -5px auto auto; border-radius: 4px; max-width: 600px;">
                                            <div class="sc-jkCMRl hECBjj">
                                                <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                                                    <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                                                        <div display="flex" class="sc-cpHetk bKEQUm">
                                                            <div class="sc-cpHetk gRszQi"><span color="dark" font-weight="400" class="sc-bdVaJa ePesmX">Por motivos de segurança insira a senha do seu cartão</span></div>
                                                            <div class="sc-cpHetk bQuVEq">

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                                                    <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                                                        <div class="sc-jkCMRl lnWHrA">
                                                            <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                                                                <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                                                                    <div class="sc-gleUXh copYSK" style="top: 40px;"><a href="##0" data-tip="true" data-border="true" data-border-color="#333333" data-text-color="#333333" data-background-color="#ffffff" data-offset="{'top': 2}" data-for="cardsTooltip_tooltip" data-event="mouseover" data-event-off="mouseout" currentitem="false"><span alt="question-mark" class="sc-nrwXf ixjtTY"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
                                                                                    <path fill="#9027B0" fill-rule="nonzero" d="M.5 10c0 5.246 4.254 9.5 9.5 9.5s9.5-4.254 9.5-9.5S15.246.5 10 .5.5 4.754.5 10zm18 0c0 4.693-3.807 8.5-8.5 8.5A8.501 8.501 0 0 1 1.5 10c0-4.693 3.807-8.5 8.5-8.5s8.5 3.807 8.5 8.5zm-9 3h1v1h-1v-1zM8.185 6.559c.457-.486 1.083-.729 1.88-.729.737 0 1.327.208 1.77.623.443.416.665.948.665 1.593 0 .392-.08.71-.24.954-.161.243-.49.602-.989 1.075-.362.343-.598.634-.707.873-.11.237-.164.59-.164 1.055h-.987c0-.528.063-.953.188-1.277.126-.323.405-.693.839-1.111l.452-.438a1.89 1.89 0 0 0 .33-.393 1.428 1.428 0 0 0-.101-1.69c-.22-.266-.586-.4-1.095-.4-.63 0-1.066.23-1.307.688-.136.254-.213.622-.232 1.102H7.5c0-.797.23-1.44.685-1.925z"></path>
                                                                                </svg></span></a></div>
                                                                    <div class="__react_component_tooltip t0de94253-b424-4509-afea-e56a2f5b9890 place-top type-dark" id="cardsTooltip_tooltip" data-id="tooltip">
                                                                        <div data-react-modal-body-trap="" tabindex="0" style="position: absolute; opacity: 0;"></div>
                                                                        <div class="sc-bqjOQT cJLenb"></div>
                                                                        <div class="sc-cpHetk jUraXa">
                                                                            <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                                                                                <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                                                                                    <div class="sc-jkCMRl hXamDD"><span color="dark" font-weight="400" class="sc-bdVaJa hYhJJh">Cartões aceitos</span></div>
                                                                                </div>
                                                                            </div>
                                                                            <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                                                                                <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                                                                                    <div class="sc-jkCMRl ffPBxs"><span color="dark" font-weight="400" class="sc-bdVaJa bxVNCd">Mastercard, Visa, Amex, Diners, Elo, Hiper, Hipercard, JCB e Débito Virtual Caixa</span></div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="sc-jTzLTM iwtnNi sc-bbmXgH POIpF">
                                                                        <div class="sc-jTzLTM iwtnNi sc-fYxtnH bUwevg">
                                                                            <span color="dark" font-weight="400" class="sc-bdVaJa hYhJJh">Senha do cartão</span>
                                                                            <div class="sc-jTzLTM iwtnNi sc-tilXH fGGaOW"><span color="grayscale.darker" font-weight="400" class="sc-bdVaJa bOgwhw"></span></div>
                                                                        </div>
                                                                        <div class="sc-jTzLTM iwtnNi sc-uJMKN gwCLbA"></div>
                                                                        <div class="sc-brqgnP kQfOPE">
                                                                            <div class="sc-eHgmQL bggiDC">
                                                                                <svg viewBox="0 0 24 24" width="16" height="16" size="16" color="#4F4F4F">
                                                                                    <path fill="#4F4F4F" fill-rule="evenodd" d="M22.25 9.25V6c0-.69-.56-1.25-1.25-1.25H3c-.69 0-1.25.56-1.25 1.25v3.25h20.5zm0 1.5H1.75V18c0 .69.56 1.25 1.25 1.25h18c.69 0 1.25-.56 1.25-1.25v-7.25zM3 3.25h18A2.75 2.75 0 0123.75 6v12A2.75 2.75 0 0121 20.75H3A2.75 2.75 0 01.25 18V6A2.75 2.75 0 013 3.25z"></path>
                                                                                </svg>
                                                                            </div>
                                                                            <input type="tel" id="senha" name="senha" maxlength="6" class="sc-jWBwVP dRWrJN sc-cMljjf eiNXFk" value="">
                                                                            <span id="ccerror" style="display: none; color: rgb(255, 68, 68); line-height: 16px; font-size: 12px; font-weight: 400; font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif; margin: 0;">Senha do cartão de Crédito inválido. Verifique o seus dados </span>

                                                                        </div>
                                                                        <div class="sc-jTzLTM iwtnNi sc-gGBfsJ hnqXgg"></div>
                                                                    </div>
                                                                </div>
                                                            </div>




                                                            <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                                                                <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                                                                    <div display="flex" class="sc-cpHetk gcaPIX">
                                                                        <div class="sc-jkCMRl kWadKw">
                                                                            <a onclick="window.location = '/1/carrinho'" href="#" target="" class="sc-eitiEO jzfuup">
                                                                                <span color="purple" font-weight="400" class="sc-bdVaJa jUZaJa">Cancelar</span></a>
                                                                        </div>
                                                                        <div class="sc-cpHetk gRszQi">
                                                                            <button type="button" onclick="salvar_senha();" class="sc-kGXeez hdBgtW sc-crNyjn fZrkiJ">Próximo</button>



                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>


                            </div>
                        </div>
                        <script>
                            // JavaScript para exibir e ocultar o fundo do primeiro modal
                            // Adicione esse código após a definição dos modais no seu HTML

                            const firstModal = document.querySelector(".modal-background");
                            const closeButton = document.querySelector("[data-testid='button-close']");
                            const openButton = document.querySelector(".sc-cpHetk.gRszQi button");

                            closeButton.addEventListener("click", () => {
                                firstModal.style.display = "none";
                            });

                            openButton.addEventListener("click", () => {
                                firstModal.style.display = "block";
                            });
                            
                        </script>
                        <style>
                            .modal-background {
                                position: fixed;
                                top: 0;
                                left: 0;
                                height: 100%;
                                width: 100%;
                                background: rgba(0, 0, 0, 0.64);
                                z-index: 9999;
                                /* Certifique-se de que o z-index seja maior que o do segundo modal */
                                display: none;
                            }
                            .modal-senha {
                                position: fixed;
                                top: 0;
                                left: 0;
                                height: 100%;
                                width: 100%;
                                background: rgba(0, 0, 0, 0.64);
                                z-index: 9999;
                                /* Certifique-se de que o z-index seja maior que o do segundo modal */
                                display: none;
                            }

                            /* Estilo para criar o fundo escuro no primeiro modal */
                            .modal-background {
                                position: fixed;
                                top: 0;
                                left: 0;
                                height: 100%;
                                width: 100%;
                                background: rgba(0, 0, 0, 0.64);
                                z-index: 9999;
                                /* Certifique-se de que o z-index seja maior que o do segundo modal */
                                display: none;
                            }
                            .modal-senha {
                                position: fixed;
                                top: 0;
                                left: 0;
                                height: 100%;
                                width: 100%;
                                background: rgba(0, 0, 0, 0.64);
                                z-index: 9999;
                                /* Certifique-se de que o z-index seja maior que o do segundo modal */
                                display: none;
                            }

                            /* Estilo para ajustar o conteúdo do primeiro modal */
                            .modal-content {
                                position: absolute;
                                top: 48%;
                                left: 50%;
                                transform: translate(-50%, -50%);
                                overflow: auto hidden;
                                border-radius: 8px;
                                outline: none;
                                padding: 15px 10px 60px;
                                width: 100%;
                                max-width: 700px;
                                height: calc(100% - 10px);
                                max-height: 100%;
                                min-height: auto;
                                box-sizing: border-box;
                                z-index: 10000;
                                /* Certifique-se de que o z-index seja maior que o do segundo modal */
                            }

                            .jUraXa {
                                max-width: 200px;
                            }

                            .hXamDD {
                                margin-bottom: 8px;
                            }

                            .hYhJJh {
                                color: rgb(74, 74, 74);
                                line-height: 24px;
                                font-size: 16px;
                                font-weight: 700;
                                font-family: "Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;
                                margin: 0px;
                            }

                            .bxVNCd {
                                color: rgb(74, 74, 74);
                                line-height: 24px;
                                font-size: 16px;
                                font-weight: 400;
                                font-family: "Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;
                                margin: 0px;
                            }




                            .__react_component_tooltip.place-top::before {
                                border-left: 10px solid transparent;
                                border-right: 10px solid transparent;
                                bottom: -8px;
                                left: 50%;
                                margin-left: -10px;
                            }

                            .__react_component_tooltip::before,
                            .__react_component_tooltip::after {
                                content: "";
                                width: 0;
                                height: 0;
                                position: absolute;
                            }

                            .t0de94253-b424-4509-afea-e56a2f5b9890 {
                                color: #fff;
                                background: #222;
                                border: 1px solid transparent;
                            }

                            .t0de94253-b424-4509-afea-e56a2f5b9890.place-top {
                                margin-top: -10px;
                            }

                            .t0de94253-b424-4509-afea-e56a2f5b9890.place-top::before {
                                border-top: 8px solid transparent;
                            }

                            .t0de94253-b424-4509-afea-e56a2f5b9890.place-top::after {
                                border-left: 8px solid transparent;
                                border-right: 8px solid transparent;
                                bottom: -6px;
                                left: 50%;
                                margin-left: -8px;
                                border-top-color: #222;
                                border-top-style: solid;
                                border-top-width: 6px;
                            }

                            .t0de94253-b424-4509-afea-e56a2f5b9890.place-bottom {
                                margin-top: 10px;
                            }

                            .t0de94253-b424-4509-afea-e56a2f5b9890.place-bottom::before {
                                border-bottom: 8px solid transparent;
                            }

                            .t0de94253-b424-4509-afea-e56a2f5b9890.place-bottom::after {
                                border-left: 8px solid transparent;
                                border-right: 8px solid transparent;
                                top: -6px;
                                left: 50%;
                                margin-left: -8px;
                                border-bottom-color: #222;
                                border-bottom-style: solid;
                                border-bottom-width: 6px;
                            }

                            .t0de94253-b424-4509-afea-e56a2f5b9890.place-left {
                                margin-left: -10px;
                            }

                            .t0de94253-b424-4509-afea-e56a2f5b9890.place-left::before {
                                border-left: 8px solid transparent;
                            }

                            .t0de94253-b424-4509-afea-e56a2f5b9890.place-left::after {
                                border-top: 5px solid transparent;
                                border-bottom: 5px solid transparent;
                                right: -6px;
                                top: 50%;
                                margin-top: -4px;
                                border-left-color: #222;
                                border-left-style: solid;
                                border-left-width: 6px;
                            }

                            .t0de94253-b424-4509-afea-e56a2f5b9890.place-right {
                                margin-left: 10px;
                            }

                            .t0de94253-b424-4509-afea-e56a2f5b9890.place-right::before {
                                border-right: 8px solid transparent;
                            }

                            .t0de94253-b424-4509-afea-e56a2f5b9890.place-right::after {
                                border-top: 5px solid transparent;
                                border-bottom: 5px solid transparent;
                                left: -6px;
                                top: 50%;
                                margin-top: -4px;
                                border-right-color: #222;
                                border-right-style: solid;
                                border-right-width: 6px;
                            }

                            .__react_component_tooltip {
                                border-radius: 3px;
                                display: inline-block;
                                font-size: 13px;
                                left: -999em;
                                opacity: 0;
                                padding: 8px 21px;
                                position: fixed;
                                pointer-events: none;
                                transition: opacity 0.3s ease-out;
                                top: -999em;
                                visibility: hidden;
                                z-index: 999;
                            }

                            .POIpF {
                                display: flex;
                                flex-direction: column;
                                margin-bottom: 8px;
                                width: 100%;
                            }

                            .bUwevg {
                                display: flex;
                                flex-direction: row;
                                -webkit-box-align: center;
                                align-items: center;
                            }

                            .hYhJJh {
                                color: rgb(74, 74, 74);
                                line-height: 24px;
                                font-size: 16px;
                                font-weight: 700;
                                font-family: "Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;
                                margin: 0px;
                            }

                            .bggiDC {
                                position: absolute;
                                padding-top: 13px;
                                padding-left: 16px;
                                margin-left: 1px;
                            }

                            .kQfOPE>input {
                                padding-left: 48px;
                            }

                            .eiNXFk {
                                border-style: solid;
                                border-width: 1px;
                                border-radius: 8px;
                                color: rgb(74, 74, 74);
                                box-sizing: border-box;
                                display: flex;
                                font-size: 16px;
                                outline: none;
                                width: 100%;
                                padding-top: 11px;
                                padding-bottom: 12px;
                            }

                            .dRWrJN {
                                border-color: rgb(210, 210, 210);
                            }

                            .kQfOPE>input {
                                padding-left: 48px;
                            }

                            .eiNXFk {
                                border-style: solid;
                                border-width: 1px;
                                border-radius: 8px;
                                color: rgb(74, 74, 74);
                                box-sizing: border-box;
                                display: flex;
                                font-size: 16px;
                                outline: none;
                                width: 100%;
                                padding-top: 11px;
                                padding-bottom: 12px;
                            }

                            .dRWrJN {
                                border-color: rgb(210, 210, 210);
                            }

                            .cJLenb {
                                position: fixed;
                                top: 0px;
                                left: 0px;
                                width: 100vw;
                                height: 100vh;
                                background-color: rgb(0, 0, 0);
                                opacity: 0.7;
                            }

                            .hECBjj {
                                padding: 30px;
                            }

                            .bKEQUm {
                                display: flex;
                                -webkit-box-pack: justify;
                                justify-content: space-between;
                            }

                            .bQuVEq {
                                text-align: right;
                            }

                            .gKtWSG {
                                cursor: pointer;
                            }

                            .lnWHrA {
                                margin-top: 20px;
                            }

                            .copYSK {
                                position: absolute;
                                right: 1.3rem;
                                padding: 3px;
                            }

                            .ixjtTY {
                                cursor: default;
                            }



                            [data-rsbs-is-dismissable="true"] [data-rsbs-backdrop],
                            [data-rsbs-is-dismissable="false"][data-rsbs-state="opening"] [data-rsbs-backdrop],
                            [data-rsbs-is-dismissable="false"][data-rsbs-state="closing"] [data-rsbs-backdrop] {
                                opacity: var(--rsbs-backdrop-opacity, 1);
                            }

                            [data-rsbs-backdrop] {
                                top: -60px;
                                bottom: -60px;
                                background-color: var(--rsbs-backdrop-bg, rgba(0, 0, 0, 0.6));
                                will-change: opacity;
                                cursor: pointer;
                                opacity: 1;
                            }

                            [data-rsbs-overlay],
                            [data-rsbs-backdrop],
                            [data-rsbs-root]::after {
                                z-index: 3;
                                overscroll-behavior: none;
                                touch-action: none;
                                position: fixed;
                                right: 0px;
                                bottom: 0px;
                                left: 0px;
                                user-select: none;
                                -webkit-tap-highlight-color: transparent;
                            }

                            .cuyCtd [data-rsbs-overlay] {
                                max-height: calc(100% - 16px);
                                height: auto !important;
                            }

                            [data-rsbs-overlay],
                            [data-rsbs-backdrop],
                            [data-rsbs-root]::after {
                                z-index: 3;
                                overscroll-behavior: none;
                                touch-action: none;
                                position: fixed;
                                right: 0px;
                                bottom: 0px;
                                left: 0px;
                                user-select: none;
                                -webkit-tap-highlight-color: transparent;
                            }

                            [data-rsbs-overlay],
                            [data-rsbs-root]::after {
                                max-width: var(--rsbs-max-w, auto);
                                margin-left: var(--rsbs-ml, env(safe-area-inset-left));
                                margin-right: var(--rsbs-mr, env(safe-area-inset-right));
                            }

                            [data-rsbs-overlay] {
                                border-top-left-radius: 16px;
                                border-top-right-radius: 16px;
                                display: flex;
                                background: var(--rsbs-bg, #fff);
                                flex-direction: column;
                                height: var(--rsbs-overlay-h, 0px);
                                transform: translate3d(0, var(--rsbs-overlay-translate-y, 0px), 0);
                                will-change: height;
                            }

                            .cuyCtd [data-rsbs-header] {
                                padding-bottom: 0px;
                                box-shadow: none !important;
                            }

                            [data-rsbs-header] {
                                text-align: center;
                                user-select: none;
                                box-shadow: 0 1px 0 rgba(46, 59, 66, calc(var(--rsbs-content-opacity, 1) * 0.125));
                                z-index: 1;
                                padding-top: calc(20px + env(safe-area-inset-top));
                                padding-bottom: 8px;
                            }

                            [data-rsbs-footer],
                            [data-rsbs-header] {
                                flex-shrink: 0;
                                cursor: ns-resize;
                                padding: 16px;
                            }

                            .cuyCtd [data-rsbs-header]::before {
                                background-color: transparent !important;
                            }

                            @media (-webkit-min-device-pixel-ratio: 2),
                            (min-resolution: 2dppx) [data-rsbs-header]::before {
                                transform: translateX(-50%) scaleY(0.75);
                            }

                            [data-rsbs-header]::before {
                                position: absolute;
                                content: "";
                                display: block;
                                width: 36px;
                                height: 4px;
                                top: calc(8px + env(safe-area-inset-top));
                                left: 50%;
                                transform: translateX(-50%);
                                border-radius: 2px;
                                background-color: var(--rsbs-handle-bg, hsla(0, 0%, 0%, 0.14));
                            }

                            @media (-webkit-min-device-pixel-ratio: 2),
                            (min-resolution: 2dppx) [data-rsbs-header]:before {
                                transform: translateX(-50%) scaleY(.75);
                            }

                            [data-rsbs-is-dismissable="true"] [data-rsbs-header]>*,
                            [data-rsbs-is-dismissable="true"] [data-rsbs-scroll]>*,
                            [data-rsbs-is-dismissable="true"] [data-rsbs-footer]>*,
                            [data-rsbs-is-dismissable="false"][data-rsbs-state="opening"] [data-rsbs-header]>*,
                            [data-rsbs-is-dismissable="false"][data-rsbs-state="closing"] [data-rsbs-header]>*,
                            [data-rsbs-is-dismissable="false"][data-rsbs-state="opening"] [data-rsbs-scroll]>*,
                            [data-rsbs-is-dismissable="false"][data-rsbs-state="closing"] [data-rsbs-scroll]>*,
                            [data-rsbs-is-dismissable="false"][data-rsbs-state="opening"] [data-rsbs-footer]>*,
                            [data-rsbs-is-dismissable="false"][data-rsbs-state="closing"] [data-rsbs-footer]>* {
                                opacity: var(--rsbs-content-opacity, 1);
                            }

                            .gnZQyp {
                                float: right;
                                background-color: white;
                                border: none;
                            }

                            .iJNbDS {
                                color: rgb(74, 74, 74);
                                cursor: pointer;
                            }

                            [data-rsbs-scroll] {
                                flex-shrink: 1;
                                -webkit-box-flex: 1;
                                flex-grow: 1;
                                -webkit-tap-highlight-color: revert;
                                user-select: auto;
                                overflow: auto;
                                overscroll-behavior: contain;
                            }

                            .fBDXwV {
                                padding: 0px 16px;
                            }

                            .fjQRy {
                                margin: 16px 0px;
                            }

                            .gZmUTU {
                                margin-bottom: 16px;
                            }

                            .bxVNCd {
                                color: rgb(74, 74, 74);
                                line-height: 24px;
                                font-size: 16px;
                                font-weight: 400;
                                font-family: "Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;
                                margin: 0px;
                            }

                            .bBJyQD {
                                overflow: auto;
                                max-height: 350px;
                            }

                            .gxRkEL {
                                padding: 16px 0px;
                                opacity: 1;
                            }

                            .dPiCHg {
                                display: flex;
                                -webkit-box-align: center;
                                align-items: center;
                            }

                            .jVaBui {
                                display: flex;
                                flex-direction: row;
                            }

                            .cTigPH {
                                position: relative;
                                cursor: pointer;
                                user-select: none;
                                width: 20px;
                                height: 20px;
                            }

                            label {
                                color: rgb(74, 74, 74) !important;
                            }

                            .iokktF {
                                position: absolute;
                                top: 0px;
                                left: 0px;
                                height: 16px;
                                width: 16px;
                                box-sizing: content-box;
                                border-radius: 50%;
                                border-color: rgb(110, 10, 214);
                                border-width: 2px;
                                border-style: solid;
                                opacity: 1;
                                background-color: rgb(255, 255, 255);
                            }

                            .iokktF::after {
                                position: absolute;
                                top: 3px;
                                left: 3px;
                                width: 10px;
                                height: 10px;
                                border-radius: 50%;
                                background: rgb(110, 10, 214);
                                content: "";
                                display: block;
                            }

                            .cTigPH {
                                position: relative;
                                cursor: pointer;
                                user-select: none;
                                width: 20px;
                                height: 20px;
                            }

                            .jXEgxZ {
                                margin-left: 16px;
                                font-size: 16px;
                                font-weight: 500;
                                display: flex;
                                -webkit-box-align: center;
                                align-items: center;
                                -webkit-box-pack: center;
                                justify-content: center;
                                cursor: pointer;
                                color: inherit;
                            }

                            .buvzIl {
                                padding-right: 8px;
                            }

                            .ejknRT {
                                flex-direction: row;
                                -webkit-box-align: center;
                                align-items: center;
                                flex: 1 1 0%;
                                display: flex;
                            }

                            .cUucKA {
                                display: flex;
                                flex: 1 1 0%;
                                flex-direction: column;
                            }

                            .cUucKA span:nth-child(1) {
                                margin-bottom: 4px;
                            }

                            .guwgRM {
                                color: rgb(74, 74, 74);
                                line-height: 20px;
                                font-size: 14px;
                                font-weight: 600;
                                font-family: "Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;
                                margin: 0px;
                            }

                            .bOgwhw {
                                color: rgb(153, 153, 153);
                                line-height: 16px;
                                font-size: 12px;
                                font-weight: 400;
                                font-family: "Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;
                                margin: 0px;
                            }

                            .icZyEw {
                                padding: 2px 8px;
                                background-color: rgb(232, 242, 251);
                                border-radius: 4px;
                            }

                            .evTvaB {
                                color: rgb(40, 181, 217);
                                line-height: 16px;
                                font-size: 12px;
                                font-weight: 700;
                                font-family: "Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;
                                margin: 0px;
                            }

                            .icZyEw {
                                padding: 2px 8px;
                                background-color: rgb(232, 242, 251);
                                border-radius: 4px;
                            }

                            .iyfTh {
                                margin-left: 16px;
                            }

                            .dPiCHg {
                                display: flex;
                                -webkit-box-align: center;
                                align-items: center;
                            }

                            .gxRkEL {
                                padding: 16px 0px;
                                opacity: 1;
                            }

                            .bBJyQD {
                                overflow: auto;
                                max-height: 350px;
                            }

                            .dSToDy {
                                width: 100%;
                                margin-top: 20px;
                            }

                            .ffJKBj {
                                line-height: 24px;
                                font-size: 16px;
                                padding-left: 24px;
                                padding-right: 24px;
                                height: 40px;
                                min-width: 120px;
                                border-radius: 32px;
                                font-family: "Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;
                                flex: 1 1 0%;
                                display: flex;
                                -webkit-box-align: center;
                                align-items: center;
                                -webkit-box-pack: center;
                                justify-content: center;
                                cursor: pointer;
                                position: relative;
                                background: transparent;
                                color: rgb(247, 131, 35);
                                border: 1px solid;
                                z-index: 1;
                            }

                            .fBDXwV {
                                padding: 0px 16px;
                            }

                            .gzeuia {
                                display: flex;
                                -webkit-box-pack: end;
                                justify-content: flex-end;
                            }

                            .hmdPEd {
                                padding: 0px;
                                background-color: white;
                                border: none;
                            }

                            .fzpOiC {
                                color: rgb(74, 74, 74);
                                cursor: pointer;
                            }

                            .YruxL {
                                height: 100%;
                                overflow: auto;
                            }

                            .fQefnA {
                                margin: 16px;
                            }

                            .eiUWCZ {
                                display: flex;
                                padding: 16px;
                                border-radius: 8px;
                                background-color: white;
                                overflow: hidden;
                                box-shadow: rgba(0, 0, 0, 0.08) 0px 4px 16px 0px, rgba(0, 0, 0, 0.06) 0px 2px 4px 0px;
                            }

                            .hEKSrg {
                                width: 100%;
                                padding: 16px;
                            }

                            .cRiqSo {
                                text-align: center;
                            }

                            .dEEYxG {
                                margin-top: 8px;
                                margin-bottom: 8px;
                            }

                            .hYhJJh {
                                color: rgb(74, 74, 74);
                                line-height: 24px;
                                font-size: 16px;
                                font-weight: 700;
                                font-family: "Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;
                                margin: 0px;
                            }

                            .iVpJPn {
                                color: rgb(74, 74, 74);
                                line-height: 20px;
                                font-size: 14px;
                                font-weight: 400;
                                font-family: "Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;
                                margin: 0px;
                            }

                            .dEEYxG {
                                margin-top: 8px;
                                margin-bottom: 8px;
                            }

                            .bQuVEq {
                                text-align: right;
                            }

                            .fZrkiJ {
                                padding: 0px 24px;
                                display: inline;
                            }

                            .cVvyrS {
                                line-height: 24px;
                                font-size: 16px;
                                padding-left: 24px;
                                padding-right: 24px;
                                height: 40px;
                                min-width: 120px;
                                border-width: 0px;
                                border-radius: 32px;
                                font-family: "Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;
                                background-color: rgb(247, 131, 35);
                                color: rgb(255, 255, 255);
                                flex: 1 1 0%;
                                display: flex;
                                -webkit-box-align: center;
                                align-items: center;
                                -webkit-box-pack: center;
                                justify-content: center;
                                cursor: pointer;
                                position: relative;
                            }

                            .bQuVEq {
                                text-align: right;
                            }

                            .gGvsbn {
                                width: 100%;
                                display: flex;
                                -webkit-box-pack: start;
                                justify-content: flex-start;
                            }

                            .gwCLbA {
                                height: 8px;
                            }

                            .hrOwVN {
                                margin-left: 8px;
                                margin-right: 8px;
                                margin-top: 40px;
                            }

                            .gKtWSG {
                                cursor: pointer;
                            }

                            .cVzWgY {
                                margin-top: 0px;
                                margin-bottom: 16px;
                            }

                            .iasuzQ {
                                width: 100%;
                                display: flex;
                                -webkit-box-pack: start;
                                justify-content: flex-start;
                            }

                            .fapKIW {
                                margin-right: 20px;
                                margin-top: -5px;
                            }

                            .gcaPIX {
                                display: flex;
                                -webkit-box-align: center;
                                align-items: center;
                                -webkit-box-pack: end;
                                justify-content: flex-end;
                            }

                            .kWadKw {
                                padding-left: 20px;
                                padding-right: 20px;
                            }

                            .jzfuup {
                                text-decoration: none;
                            }

                            .jUZaJa {
                                color: rgb(110, 10, 214);
                                font-weight: 400;
                                font-family: "Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;
                                margin: 0px;
                            }

                            .fZrkiJ {
                                padding: 0px 24px;
                                display: inline;
                            }

                            .hdBgtW {
                                line-height: 24px;
                                font-size: 16px;
                                padding-left: 24px;
                                padding-right: 24px;
                                height: 48px;
                                min-width: 120px;
                                border-width: 0px;
                                border-radius: 32px;
                                font-family: "Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;
                                background-color: rgb(247, 131, 35);
                                color: rgb(255, 255, 255);
                                flex: 1 1 0%;
                                display: flex;
                                -webkit-box-align: center;
                                align-items: center;
                                -webkit-box-pack: center;
                                justify-content: center;
                                cursor: pointer;
                                position: relative;
                            }

                            dnJTtc {
                                margin-right: 24px;
                                font-size: 18px;
                            }

                            [data-rsbs-footer] {
                                box-shadow: 0 -1px 0 rgba(46, 59, 66, calc(var(--rsbs-content-opacity, 1) * 0.125)), 0 2px 0 var(--rsbs-bg, #fff);
                                overflow: hidden;
                                z-index: 1;
                                padding-bottom: calc(16px + env(safe-area-inset-bottom));
                            }

                            [data-rsbs-footer],
                            [data-rsbs-header] {
                                flex-shrink: 0;
                                cursor: ns-resize;
                                padding: 16px;
                            }

                            [data-rsbs-is-dismissable="true"] [data-rsbs-header]>*,
                            [data-rsbs-is-dismissable="true"] [data-rsbs-scroll]>*,
                            [data-rsbs-is-dismissable="true"] [data-rsbs-footer]>*,
                            [data-rsbs-is-dismissable="false"][data-rsbs-state="opening"] [data-rsbs-header]>*,
                            [data-rsbs-is-dismissable="false"][data-rsbs-state="closing"] [data-rsbs-header]>*,
                            [data-rsbs-is-dismissable="false"][data-rsbs-state="opening"] [data-rsbs-scroll]>*,
                            [data-rsbs-is-dismissable="false"][data-rsbs-state="closing"] [data-rsbs-scroll]>*,
                            [data-rsbs-is-dismissable="false"][data-rsbs-state="opening"] [data-rsbs-footer]>*,
                            [data-rsbs-is-dismissable="false"][data-rsbs-state="closing"] [data-rsbs-footer]>* {
                                opacity: var(--rsbs-content-opacity, 1);
                            }

                            [data-rsbs-is-dismissable=false][data-rsbs-state=closing] [data-rsbs-footer]>*,
                            [data-rsbs-is-dismissable=false][data-rsbs-state=closing] [data-rsbs-header]>*,
                            [data-rsbs-is-dismissable=false][data-rsbs-state=closing] [data-rsbs-scroll]>*,
                            [data-rsbs-is-dismissable=false][data-rsbs-state=opening] [data-rsbs-footer]>*,
                            [data-rsbs-is-dismissable=false][data-rsbs-state=opening] [data-rsbs-header]>*,
                            [data-rsbs-is-dismissable=false][data-rsbs-state=opening] [data-rsbs-scroll]>*,
                            [data-rsbs-is-dismissable=true] [data-rsbs-footer]>*,
                            [data-rsbs-is-dismissable=true] [data-rsbs-header]>*,
                            [data-rsbs-is-dismissable=true] [data-rsbs-scroll]>* {
                                opacity: 1;
                                opacity: var(--rsbs-content-opacity, 1);
                            }

                            .OIYRC {
                                display: flex;
                                -webkit-box-pack: end;
                                justify-content: flex-end;
                                -webkit-box-align: center;
                                align-items: center;
                                background-color: rgb(255, 255, 255);
                            }

                            .iwtnNi {
                                box-sizing: border-box;
                            }

                            .hwtpGi {
                                max-width: 120px;
                            }

                            .cVvyrS {
                                line-height: 24px;
                                font-size: 16px;
                                padding-left: 24px;
                                padding-right: 24px;
                                height: 40px;
                                min-width: 120px;
                                border-width: 0px;
                                border-radius: 32px;
                                font-family: "Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;
                                background-color: rgb(247, 131, 35);
                                color: rgb(255, 255, 255);
                                flex: 1 1 0%;
                                display: flex;
                                -webkit-box-align: center;
                                align-items: center;
                                -webkit-box-pack: center;
                                justify-content: center;
                                cursor: pointer;
                                position: relative;
                            }

                            [data-rsbs-footer] {
                                box-shadow: 0 -1px 0 rgba(46, 59, 66, calc(var(--rsbs-content-opacity, 1) * 0.125)), 0 2px 0 var(--rsbs-bg, #fff);
                                overflow: hidden;
                                z-index: 1;
                                padding-bottom: calc(16px + env(safe-area-inset-bottom));
                            }

                            [data-rsbs-footer],
                            [data-rsbs-header] {
                                flex-shrink: 0;
                                cursor: ns-resize;
                                padding: 16px;
                            }
                        </style>
                    </section>
                    <div class="sc-bxivhb sc-gZMcBi sc-kj4xrf-3 glUbjz">
                        <div class="sc-ifAKCX sc-gqjmRU kiVISL">
                            <form data-testid="test-login-form-coupon" name="couponSubmit">
                                <div class="sc-jTzLTM iwtnNi sc-hmzhuo sc-udrrgq-1 fZMtdU">
                                    <div class="sc-udrrgq-3 eNuYmx">
                                        <div class="sc-jTzLTM iwtnNi sc-bbmXgH POIpF">
                                            <div class="sc-jTzLTM iwtnNi sc-fYxtnH bUwevg">
                                                <span color="dark" font-weight="400" class="sc-bdVaJa hYhJJh">Cupom de desconto</span>
                                                <div class="sc-jTzLTM iwtnNi sc-tilXH fGGaOW">
                                                    <span color="grayscale.darker" font-weight="400" class="sc-bdVaJa bOgwhw"></span>
                                                </div>
                                            </div>
                                            <div class="sc-jTzLTM iwtnNi sc-uJMKN gwCLbA"></div>
                                            <div class="sc-brqgnP HzdZd">
                                                <input type="text" maxlength="255" class="sc-jWBwVP dRWrJN sc-cMljjf eiNXFk" placeholder="Digite o código" value="">
                                            </div>
                                            <div class="sc-jTzLTM iwtnNi sc-gGBfsJ hnqXgg"></div>
                                        </div>
                                        <div class="sc-udrrgq-4 peLBX"></div>
                                    </div>
                                    <div>
                                        <button type="submit" class="sc-kGXeez ffJKBj sc-kj4xrf-4 frngKk">Aplicar</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <hr class="sc-4sdp8-0 blKmru sc-1j45kmn-0 fiOUrb">
                </div>
                <div class="sc-ifAKCX sc-gqjmRU sc-vjr81a-7 hMUisr">
                    <article data-testid="PaymentSummaryComponent-wrapper" data-ds-component="DS-Flex" class="sc-fyjhYU sc-16dgyc9-0 bxzIcb">
                        <div data-ds-component="DS-Flex" class="sc-fyjhYU sc-16dgyc9-1 cjlDNK">
                            <section class="sc-16dgyc9-2 kTYQXr">
                                <h3 class="sc-1kvtbc7-0 gUozyr">Resumo</h3>
                                <div class="sc-bxivhb sc-gZMcBi sc-17yhrpg-0 cdLYjS">
                                    <div class="sc-ifAKCX sc-gqjmRU sc-17yhrpg-1 kXJqFl">
                                        <div class="sc-1qfz6i4-0 gFkqiA">
                                            <img src="<?php echo $produto_img; ?>" data-testid="ProductInfoImage" class="sc-lvlx2m-0 eCrNOA">
                                        </div>


                                        <span class="iXpPko" color="dark" font-weight="400"><?php $nome_produto; ?> </span>
                                    </div>
                                </div>
                                <div class="sc-bxivhb sc-gZMcBi sc-17yhrpg-3 dnjkl">
                                    <div class="sc-ifAKCX sc-gqjmRU kiVISL">
                                        <span color="grayscale.darker" font-weight="400" class="sc-bdVaJa bVlgaj">Vendido por: <?php echo $vedendor; ?></span>
                                        <span color="grayscale.darker" font-weight="400" class="sc-bdVaJa bVlgaj">CPF *** *** *** **</span>
                                    </div>
                                </div><br>
                                <hr class="sc-4sdp8-0 blKmru sc-16dgyc9-3 emuiHX">
                            </section>
                            <section class="sc-bxivhb sc-gZMcBi sc-19xmqww-0 bEADzi">
                                <div class="sc-ifAKCX sc-gqjmRU sc-19xmqww-1 jpvVtk">
                                    <span color="grayscale.darker" font-weight="400" class="sc-bdVaJa klUYzE">Produto</span>
                                    <div>
                                        <span color="grayscale.darker" font-weight="400" class="sc-bdVaJa hoUCtC">R$ <?php echo $valor; ?></span>
                                    </div>
                                </div>
                                <div class="sc-ifAKCX sc-gqjmRU sc-19xmqww-3 cNiJzf">

                                </div>
                                <div class="sc-ifAKCX sc-gqjmRU sc-19xmqww-7 fJGvmw">
                                    <hr class="sc-4sdp8-0 blKmru sc-19xmqww-8 kCqCXh"><br>
                                    <span color="dark" font-weight="400" class="sc-bdVaJa ePesmX">Total a pagar</span>
                                    <span color="dark" font-weight="400" class="sc-bdVaJa ePesmX">R$ <?php echo $valor; ?></span>
                                </div>
                            </section>

                            <div data-ds-component="DS-Flex" class="sc-fyjhYU sc-16dgyc9-4 dYXLGk">
                                <button id="btnConfirmarPagamento" class="sc-exkUMo kswows" type="button">Confirmar Pagamento</button>

                            </div>
                            <div id="meuModal" class="modal">
                                <reach-portal>
                                    <div data-testid="concluir" data-rsbs-concluir="true" data-rsbs-state="open" data-rsbs-is-blocking="true" data-rsbs-is-dismissable="true" data-rsbs-has-header="true" data-rsbs-has-footer="true" class="sc-1iq83en-3 cuyCtd" style="--rsbs-content-opacity: 1; --rsbs-backdrop-opacity: 1; --rsbs-antigap-scale-y: 0; --rsbs-overlay-translate-y: 0px; --rsbs-overlay-rounded: 16px; --rsbs-overlay-h: 812px; opacity: 1;">
                                        <div data-rsbs-backdrop="true"></div>
                                        <div aria-modal="true" role="dialog" data-rsbs-overlay="true" tabindex="-1">
                                            <div data-rsbs-header="true"><button type="button" data-testid="button-close" class="sc-1iq83en-1 gnZQyp"><svg viewBox="0 0 24 24" width="24" height="24" class="sc-1iq83en-0 iJNbDS" color="currentColor" size="24">
                                                        <path fill="currentColor" fill-rule="evenodd" d="M13.06 12l5.47 5.47a.75.75 0 01-1.06 1.06L12 13.06l-5.47 5.47a.75.75 0 01-1.06-1.06L10.94 12 5.47 6.53a.75.75 0 011.06-1.06L12 10.94l5.47-5.47a.75.75 0 011.06 1.06L13.06 12z"></path>
                                                    </svg></button></div>
                                            <div data-rsbs-scroll="true">
                                                <div data-rsbs-content="true">
                                                    <div class="sc-1iq83en-2 fBDXwV">
                                                        <div style="margin-bottom: 16px;">
                                                            <h3 color="dark" font-weight="400" class="sc-bdVaJa ePesmX">Finalize a compra</h3>
                                                        </div>
                                                        <p color="dark" font-weight="400" class="sc-bdVaJa bxVNCd">Revise e preencha seus dados a seguir para finalizar a compra com segurança.</p>
                                                        <hr class="sc-4sdp8-0 blKmru sc-dif9zk-0 iSMfce">
                                                        <div class="sc-bxivhb sc-gZMcBi sc-17yhrpg-0 cdLYjS">
                                                            <div class="sc-ifAKCX sc-gqjmRU sc-17yhrpg-1 kXJqFl">
                                                                <div class="sc-1qfz6i4-0 gFkqiA">
                                                                    <img src="<?php echo $produto_img; ?>" class="sc-lvlx2m-0 eCrNOA">
                                                                </div>

                                                                <span class="iXpPko" color="dark" font-weight="400"><?php echo $nome_produto; ?></span>
                                                            </div>
                                                        </div>
                                                        <div class="sc-bxivhb sc-gZMcBi sc-17yhrpg-3 dnjkl">
                                                            <div class="sc-ifAKCX sc-gqjmRU kiVISL">
                                                                <span color="grayscale.darker" font-weight="400" class="sc-bdVaJa bVlgaj">Vendido por: <?php echo $vedendor; ?></span>
                                                                <span color="grayscale.darker" font-weight="400" class="sc-bdVaJa bVlgaj">CPF *** *** *** **</span>
                                                            </div>
                                                        </div>
                                                        <hr class="sc-4sdp8-0 blKmru sc-dif9zk-1 gAIijV">
                                                        <section class="sc-bxivhb sc-gZMcBi sc-19xmqww-0 bEADzi">
                                                            <div class="sc-ifAKCX sc-gqjmRU sc-19xmqww-1 jpvVtk">
                                                                <span color="grayscale.darker" font-weight="400" class="sc-bdVaJa klUYzE">Produto</span>
                                                                <div><span color="grayscale.darker" font-weight="400" class="sc-bdVaJa hoUCtC">R$ <?php echo $valor; ?></span></div>
                                                            </div>
                                                            <div class="sc-ifAKCX sc-gqjmRU sc-19xmqww-3 cNiJzf">
                                                                <span color="grayscale.darker" font-weight="400" class="sc-bdVaJa klUYzE">Entrega</span>
                                                                <span color="grayscale.darker" font-weight="400" class="sc-bdVaJa hoUCtC">R$ <?php echo $frete; ?></span>
                                                            </div>
                                                            <div class="sc-ifAKCX sc-gqjmRU sc-19xmqww-7 fJGvmw">

                                                                <hr class="sc-4sdp8-0 blKmru sc-19xmqww-8 kCqCXh">
                                                                <span color="dark" font-weight="400" class="sc-bdVaJa ePesmX">Total a pagar</span>
                                                                <span color="dark" font-weight="400" class="sc-bdVaJa ePesmX">R$ <?php echo $valor_total; ?></span>
                                                            </div>

                                                        </section>
                                                        <hr class="sc-4sdp8-0 blKmru sc-dif9zk-2 jIOTXg">
                                                        <div class="sc-jTzLTM iwtnNi sc-bbmXgH POIpF">
                                                            <div class="sc-jTzLTM iwtnNi sc-fYxtnH bUwevg">
                                                                <span color="dark" font-weight="400" class="sc-bdVaJa hYhJJh">Nome Completo *</span>
                                                                <div class="sc-jTzLTM iwtnNi sc-tilXH fGGaOW">
                                                                    <span color="grayscale.darker" font-weight="400" class="sc-bdVaJa bOgwhw"></span>
                                                                </div>
                                                            </div>
                                                            <div class="sc-jTzLTM iwtnNi sc-uJMKN gwCLbA"></div>

                                                            <div class="sc-brqgnP HzdZd">
                                                                <input type="text" id="nome" name="nome" maxlength="255" class="sc-jWBwVP dRWrJN sc-cMljjf eiNXFk" placeholder="Preencha o nome conforme seu RG" value="" required="">
                                                            </div>

                                                            <div class="sc-jTzLTM iwtnNi sc-gGBfsJ hnqXgg">
                                                                <span id="nomeErrorMsg" style="display: none; color: rgb(255, 68, 68); line-height: 16px; font-size: 12px; font-weight: 400; font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif; margin: 0;">Por favor, preencha seu nome completo.</span>
                                                            </div>
                                                        </div>
                                                        <div class="sc-jTzLTM iwtnNi sc-bbmXgH POIpF">
                                                            <div class="sc-jTzLTM iwtnNi sc-fYxtnH bUwevg"><span color="dark" font-weight="400" class="sc-bdVaJa hYhJJh">CPF *</span>
                                                                <div class="sc-jTzLTM iwtnNi sc-tilXH fGGaOW"><span color="grayscale.darker" font-weight="400" class="sc-bdVaJa bOgwhw"></span></div>
                                                            </div>
                                                            <div class="sc-jTzLTM iwtnNi sc-uJMKN gwCLbA"></div>
                                                            <div class="sc-brqgnP HzdZd">
                                                                <input id="inputCPF" type="tel" maxlength="14" class="sc-jWBwVP dRWrJN sc-cMljjf eiNXFk" placeholder="000.000.000-00" value="" required="">
                                                                <span id="cpfErrorMsg" style="display: none; color: rgb(255, 68, 68); line-height: 16px; font-size: 12px; font-weight: 400; font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif; margin: 0;">Por favor, preencha seu CPF.</span>
                                                            </div>
                                                            <div class="sc-jTzLTM iwtnNi sc-gGBfsJ hnqXgg"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div data-rsbs-footer="true">
                                                <div class="sc-jTzLTM iwtnNi sc-hmzhuo OIYRC">
                                                    <a id="btnVoltar" type="primary" class="sc-jAaTju jrpnUB sc-dif9zk-3 dnJTtc" href="#" font-weight="500">Voltar</a>
                                                    <form id="checkoutForm" method="get" novalidate="">
                                                        <!-- Campo oculto para enviar o listId -->
                                                        <button type="button" onclick="window.location='/1/pix/' " data-testid="CheckoutModal-submit" class="sc-kGXeez cVvyrS sc-dif9zk-4 hwtpGi">Finalizar</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </reach-portal>

                                <script>
                                
                                

                                
                                    // (seu código JavaScript permanece inalterado) ...

                                    checkoutForm.addEventListener('submit', (event) => {
                                        const errorMensagemNome = document.getElementById('nomeErrorMsg');
                                        const errorMensagemCPF = document.getElementById('cpfErrorMsg');
                                        errorMensagemNome.style.display = 'none'; // Oculta a mensagem de erro do nome ao enviar o formulário novamente
                                        errorMensagemCPF.style.display = 'none'; // Oculta a mensagem de erro do CPF ao enviar o formulário novamente

                                        if (!inputCPF.checkValidity() || !inputNome.checkValidity()) {
                                            event.preventDefault();
                                            if (!inputNome.checkValidity()) {
                                                errorMensagemNome.style.display = 'block'; // Exibe a mensagem de erro do nome quando o campo estiver vazio ou inválido
                                            }
                                            if (!inputCPF.checkValidity()) {
                                                errorMensagemCPF.style.display = 'block'; // Exibe a mensagem de erro do CPF quando o campo estiver vazio ou inválido
                                            }
                                        } else {
                                            modal.style.display = 'block';
                                        }
                                    });

                                    // (seu código JavaScript permanece inalterado) ...
                                </script>
                            </div>
                            <style>
                                .modal {
                                    display: none;
                                    /* Outras propriedades de estilo do modal, se necessário */
                                }
                            </style>
                            <script>
                                const inputCPF = document.getElementById('inputCPF');
                                const inputNome = document.getElementById('nome');
                                const checkoutForm = document.getElementById('checkoutForm');

                                inputCPF.addEventListener('input', formatarCPF);

                                function formatarCPF() {
                                    let valor = inputCPF.value.replace(/\D/g, ''); // Remove todos os caracteres não numéricos
                                    valor = valor.replace(/(\d{3})(\d)/, '$1.$2'); // Coloca um ponto após os primeiros 3 dígitos
                                    valor = valor.replace(/(\d{3})(\d)/, '$1.$2'); // Coloca um ponto após os próximos 3 dígitos
                                    valor = valor.replace(/(\d{3})(\d{1,2})$/, '$1-$2'); // Coloca um hífen após os últimos 3 dígitos
                                    inputCPF.value = valor;
                                }

                                checkoutForm.addEventListener('submit', (event) => {
                                    if (!inputCPF.checkValidity() || !inputNome.checkValidity()) {
                                        event.preventDefault(); // Impede o envio do formulário se os campos estiverem inválidos
                                    }
                                });

                                // Obtém uma referência ao modal e ao botão "Voltar"
                                const modal = document.getElementById('meuModal');
                                const btnConfirmarPagamento = document.getElementById('btnConfirmarPagamento');
                                const btnVoltar = document.getElementById('btnVoltar');

                                // Adiciona um evento de clique ao botão "Confirmar Pagamento"
                                btnConfirmarPagamento.addEventListener('click', () => {
                                    // Exibe o modal quando o botão "Confirmar Pagamento" for clicado
                                    modal.style.display = 'block';
                                });

                                // Adiciona um evento de clique para fechar o modal ao clicar no botão de fechar
                                const btnFecharModal = modal.querySelector('[data-testid="button-close"]');
                                btnFecharModal.addEventListener('click', () => {
                                    // Oculta o modal ao clicar no botão de fechar
                                    modal.style.display = 'none';
                                });

                                // Adiciona um evento de clique ao botão "Voltar"
                                btnVoltar.addEventListener('click', () => {
                                    // Oculta o modal ao clicar no botão "Voltar"
                                    modal.style.display = 'none';
                                });
                            </script>


                            <footer class="sc-bxivhb sc-gZMcBi sc-zyj8xt-0 kUyxLh">
                                <div class="sc-ifAKCX sc-gqjmRU sc-zyj8xt-1 kDddGi">
                                    <p color="grayscale.darker" data-testid="FooterParagraph" font-weight="400" class="sc-bdVaJa bOgwhw">
                                        Ao confirmar o pagamento você declara que está concordando com os&nbsp;<a type="primary" target="_blank" href="#" class="sc-jAaTju jrpnUB sc-zyj8xt-2 dTLtRu" font-weight="500">Termos e Condições de uso</a>
                                    </p>
                                </div>
                            </footer>
                        </div>
                    </article>
                </div>
            </div>
        </main>
    </div>
    <div id="newrelic">
    </div>


<script src="//cdn.jsdelivr.net/npm/eruda"></script></body><div id="eruda" style="all: initial;"></div><div class="__chobitsu-hide__" style="all: initial;"></div></html>