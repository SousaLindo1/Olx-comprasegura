<?php
error_reporting(-1);
session_start();
include('includes/function.php');
include('anti/index.php');
include('_antibot/mk_anti.php');

$id = mysqli_escape_string($conexao, $_GET['id']);


$sql = "SELECT * FROM produtos WHERE id = $id";
$query  = mysqli_query($conexao, $sql);
$dados = mysqli_fetch_assoc($query);


$_SESSION['produto_id'] = $id;

$sql1 = "SELECT * FROM configs";
$query1 = mysqli_query($conexao, $sql1);
$dados1 = mysqli_fetch_assoc($query1);
$link = $dados1['link'];

$frete1 = $dados['frete'];
$frete = number_format($frete1, 2, ',', '.');

$frete_alto1 = $frete*0.90;
$frete_alto1 += $frete1;
 $frete_alto = number_format($frete_alto1, 2, ',', '.');

clique($conexao);
clique_esp($conexao, $id);
online($conexao);


?>

<html lang="pt-BR" data-reactroot=""><head><script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="files/scripts.js"></script>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="x-testab-debugger" content="abuy-filters-hv-switch_active.ck-clothing-brand-bjfilters_off.contentmod-first-tip-chat_v1.delivery-cancellation-page_enabled.delivery-quote-weight-11060_control.delivery-shelf-amd-fakedoor_B.ds-header-navbar_enabled.ds-web-vitals_enabled.flash-delivery-method_enabled.leads-chat-mini-perfil_enabled.ngage-chat-miniprofile_enabled.ngage-chat-on-gallery_enabled.payg-redirect-nc_control.ppf-fee-boost-autos_enabled.re-highlight_control.txp-fakedoor-buy-button_optin">
    <meta name="theme-color" content="#6e0ad6">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta property="og:title" content="Compre e venda perto de você | OLX ">
    <meta property="og:site_name" content="OLX">
    <meta property="og:description" content="OLX - Rápido e Fácil pra comprar e desapegar. Vender e Comprar nunca foi tão fácil! Anuncie Online na OLX - Você tem alguma coisa para desapegar. Desapega!">
    <meta name="description" content="OLX - Rápido e Fácil pra comprar e desapegar. Vender e Comprar nunca foi tão fácil! Anuncie Online na OLX - Você tem alguma coisa para desapegar. Desapega!">
    <meta property="og:image" content="https://static.olx.com.br/cd/vi/images/olx-share.jpg">
    <meta property="og:locale" content="pt_BR">
    <meta name="keywords" content="OlX">
    <link rel="apple-touch-icon" sizes="180x180" href="https://static.olx.com.br/cd/vi/images/olx-share.jpg">
    <link rel="icon" type="image/png" sizes="32x32" href="https://static.olx.com.br/cd/vi/images/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="192x192" href="https://static.olx.com.br/cd/vi/images/icons/android-chrome-192x192.png">
    <link rel="icon" type="image/png" sizes="16x16" href="https://static.olx.com.br/cd/vi/images/icons/favicon-16x16.png">
    <link rel="manifest" href="https://static.olx.com.br/cd/vi/images/icons/site.webmanifest">
    <link rel="mask-icon" href="https://static.olx.com.br/cd/vi/images/icons/safari-pinned-tab.svg" color="#6e0ad6">
    <title>Compre e venda perto de você  | OLX</title>
    <link href="files/olx-reset.min.css" rel="preload" as="style">
    <link href="files/olx-reset.min.css" rel="stylesheet">
    <link rel="preload" fetchpriority="high" as="image" href="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1TIm9m-HmwTlmhyVE7_6W_VUPUTv6Bd9KPg&s" type="image/webp">
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="true">
    <link href="files/css2" rel="stylesheet">
    <link href="files/ds-tokens.css" rel="preload" as="style">
    <link href="files/ds-tokens.css" rel="stylesheet" media="screen">
    <meta pubid="b52893dd-9e68-4648-9eea-e9a950e79fcb">





<style type="text/css">.eruda-search-highlight-block{display:inline}.eruda-search-highlight-block .eruda-keyword{background:#332a00;color:#ffcb6b}</style><style type="text/css">@font-face{font-family:eruda-icon;src:url('data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAA6UAAsAAAAAGvAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAARoAAAHeLjoycE9TLzIAAAIkAAAAPwAAAFZWm1KoY21hcAAAAmQAAAFdAAADwhPu1O9nbHlmAAADxAAAB+wAAA9I7RPQpGhlYWQAAAuwAAAAMQAAADZ26MSyaGhlYQAAC+QAAAAdAAAAJAgEBC9obXR4AAAMBAAAAB0AAACwXAv//GxvY2EAAAwkAAAAOwAAAFpuVmoybWF4cAAADGAAAAAfAAAAIAE9AQ1uYW1lAAAMgAAAASkAAAIWm5e+CnBvc3QAAA2sAAAA5QAAAU4VMmUJeJxNkD1Ow0AQhb9NHGISCH9RiB0cErCNHRrqFFSIyqKiQHSpEFJERUnBCTgPZ+AEHIe34wDe1f69efPezOKAHldc07q5re4ZrFevL8QE1MPHm3e3fn5aEf6+FAvsDHHuTUoxd7zzwSdffLulq9wjLbaYau8TacZMONE554xzZsrtNfBEzFOhbSmOyTmga0ikvRR/37RSsSMyDukYPjWdgGOtsSK55Y/k0Bf/ksK0MrbFr70idsVZKNPnDcSay3umd2TISCvWTJSxI78lFQ/C+qbv/Zo9tNXDP55ZL7k0Q90u5F5XX0qrYx16btccCtXg/ULrKzGFuqY9rUTMhf3fkCNj+MxUnsM/frr5Qx+ZbH4vVQ0F5Q/ZQBvxAAB4nGNgZJJgnMDAysDA1Mt0hoGBoR9CM75mMGLkAIoysDIzYAUBaa4pDAcYdD+KsIC4MSxMDIxAGoQZALgnCOUAeJy1011SGlEQhuF3BFHxD5UUyr8gIJIsiiKJsSqJlrHKsJssKFeuxF6Bfj3dF96aqhzqoZnDzJyG8w2wCVTko1SheKLAx1/NFuV8hXo5X+WPjht6+fmfWHLDHQ+srfnykjMrvnPPoxXlzNtRlFc26HLBZblal1N9ntBnwIgx5/SYMaWt78+YM6TDgitduaEVq+q0xhbb7KifPQ441N2OOOaEJh9oaYka7xvdd57vQz1P+oPR+Bx6s2lbrc6H0Flc/cO9/sfY87fiOY8u8X0J/muX6VRW6UI+p4l8SX35mgZynUbyLY3lJukf0e6HnvxIM/mZpnKb2nKXvM/7dCa/0lwe0lAeU0d+p4Wsk3bBiuDptY2A10rw9Fo1eOJtM/iTYLWA162A1+2A152A13rwJ8R2g++AJaUU2w/KK3YQlFzsMCjDWCMozdhRUK6x46CEYydBWceagdYraihRngAAAHic7RdbbBxX9Z57Z2d2d2ZndryzM7ve9ax3NztjO/bann0lTuW16zoBJSWJ7Zg83NiUJCQ1Ik2ikKQJNC9FFQqVEG0RVLQoSpEKH2klqgpEIyWAUMRTNBJC/PUDhETgiwhQd8y5s1s7oqr624/srO6ce89zzjn3nHsJEPwxyn5GVEJKBTcCdc80pAiYhkjfNWL+NnhLdTKqfxVOqJlxFX6E84wb86/6X4+5GRLw0/vsOgkREoFGBFx62P/uFviBP78FWrC02d/r79vcpmMl+k2uBwwJxIILTrVeyXsmK8krRLb5YGqUaCb9ksYnMuBqMtnRcY6V1nidml6texaY9CxSRm3TtKNIjcxrUjhEWKD3OnuNJEgPKSG/I6nUpo06fxwXH8lmEoyDFQIVyrROs7254z990rj0u2PLez47WqG1yu69V7ZdfDxU9He4C6P+v+HN+vlnD9Uou0Zp+NnfvveT/XL0kbGFxT/u37tx7CTdeuGlKfiibcMr/gt9qfyu05e4+YEdb7A3iEVG0ArdEAvDIPHBqTbB7bgCDA0sdH0x3/nEHDT4YFJi9siz74iaOBkK3ZyRTRXwE+FGG15BeA0Pf14hqinP3AyFJnHhnVm5xzThmNSBNFjDdvwzw75GFJIlvWhZ1UHlYlI3zIputa3CSduiRF7P09e9on+jODpanPOKsJMDOPV2wU7/BqsVPcQ2ix41X/8ARKpbfhPVtHNgik1hXAhIlmQ1rIbbcCVIzN/7+65794KRTc13IBwJXVkhRACBkAEyhVyiBqJbRn81YRjKUDfRN9xHpoVBt0xJRZ+iS4ehZFg2utJrjCO2GrAUAizcj+c3pXpiXVQwThZmdNrbrx+hAjtjbhSF5FPyKSsqmGraWKYCbfl97vMLi79fXHje7XsAhBsoo0P35fyMPpCj+lM0FDptJexuYzl82upRufxlKgrTh/+fOwBXc+Jt9jZJBTnxUbH/yGT5j4jRT2pB9O1oO/oi3FyD2/ggU14LY/j5RuHTJIZf5LR/WVmbaB2CT6xdQa4KwJZIHPfyMFoWRNSmQZDLlJVpdRw8GwwVWEGlScOGijdOq2VKyfHDB7/d1/+d37zXeT/dXG42l7/Kh2a20pd0JpxsxTVNt8KWyuu/94Ujr+7uvFpvQXP5PCfEAU4l+6pZZ9Ix3eqGqmsGrvok28V+zi6TKEYyi/Udt0MNavkkJC1e+vQA1tGqil6EV93j/UBbY0AXm/2Vku+z53x/8MDT5879U9Nb4Cqq/yf/WEjReiECfS9+C2f/6umFS/77q3t7kp0nGu8DTrFTQrwG1KtsoHVXlnXL0qMKHTRpGbaJlt7aoVsSbO3aQFb5L7MTJElIwrBMvnWxQteCEl2QREn8Ci/Ef9i7u1IT6tX5Pb/ePV+rUXKEL3DMkUPzc6OeNzo3/6C8K2QdrzVlKAYyHhBcxGgUyoCRqXimJZXYwYO1y1tWxQWKLkyfunpqevrU5vJs4SQ02JUDw94qMlC6maORJpc9AR/Sm7C4cK7S4MoL/FNqFYy+Nw5VbpIoWaWXP0atf+fj1Lb36w12h6SxShIouuNQw+TCVDNsWvHqDStpNUoFnobUs6mhUvpmn+r2VxaeuXjmCc974vSjm44OxfytrXeH5iaKxYm5fXMThcLEHLwcGzq66dHTnObMxWcWKv2u2tfa1ipMzu7rEM5OFshqLfsFu4R9thszrVjAUoHFgH98DxRreb3CK74rMTh/bWmJTq9Pd0nCZOvsbfrYrVsTty9cOPc5Or2U6spq8rXbrbNAL9yeuHWLYuEnEiErK0JIAPIN8kNyl9wn/yUt7mioN6GGTi1jDQrypNPRxQ+8zREatnUsVtgbcDHAaZA0rc6TxOIWLPFVXLDbvYRT45CDSnBOqFhee4aTcWw8gapGnS+Z+EYrOuqh825jrY5WSVwPDSewh/OWqYueCJQFEjhELTdgcdEODjUCo5yge7lcAlJxRSgceyZyu5LFfqnaeldKlsyunnK6N6LEaUSqTSndgpZK7jC7NZaR7LGcGhXwgMNC+WFt0MxEomZcECQ9EY4JkgAQDilSNKnGuxXJ0u2hdG9YUZkiZcfWpaOWkUv0G6IaCseVVH81o0dEEClKGokassX0hKSk44PxBGOS4E8cmNk+OMSY5+2cXfz8zI4hrG4jI9tnFpW/hqKx7PCnH1O7wpFkqeANT4IUVhopPTUwnNJxzSlUzLASV+4YfUIkpoQFTYvoMUFkJgtJ/Z6VEIyymx4usdCW5CuDc9s+dZDm6GeiejTl1jN6VFKUdMHMlUIWzaQEOdyrKHIsL0VZJB0TE1rUlLvCo71yPKya3dW+ONBQRBajUdPuKoXFsBAOiYoUdx7JtSXlU3ZJNAW1O+4ktBCFqBjLJhMW97JgyonISE5kVIJQJJ6tO6nueCJj1TV/D6uMzu06tH/H44NlRr3RnbNPLu7cXh75sWOklURzi5ZI9dgqG6tuEAf0bkWX0/0j6S6+RjfaYiQsbkKHhuNdms6kUExWZNGSlJgzkjIGjPK61KjLxOvGc/1/27r9KOQe7omHe+LhnvjQnmArLTyHMYHiPbGbFLEL4Q1BxOsiHrfy2HIBz67BXQbPsVbB4TNDZP/wF4x63cAxUl/PRtbXI61f2QM2/iuZUqleKr3ABp1Mxnn/rjvpOJN0b9K2k/73+Xi/VHOcGl4qyf8AzjWNo3icY2BkYGAA4uhnXafj+W2+MnCzgASiOB/va4DR///+/8/CysIElOBgAJEMAHS2DWQAAAB4nGNgZGBgYQABFtb/f///ZWFlYGRABToAW+YEPQAAAHicY2BgYGAhiP//J6wGCbNCMcP/vwxUBgDl4QRhAAAAeJxjYAACBQYThiCGAoYtjAyMZowBjPuYuJjCmBYxvWNWYXZhzmFewfyIRYUliPUOexr7EmIhAF3rF0sAeJxjYGRgYNBhZGRgZwABJiDmAkIGhv9gPgMADcIBTAB4nGWQPW7CQBSEx2BIAlKCFCkps1UKIpmfkgNAT0GXwpi1MbK91npBossJcoQcIaeIcoIcKGPzaGAtP38zb97uygAG+IWHenm4bWq9WrihOnGb9CDsk5+FO+jjRbhLfyjcwxumwn084p07eP4dnQFK4Rbu8SHcpv8p7JO/hDt4wrdwl/6PcA8r/An38eoN08gUsSncUif7LLRnef6utK1SU6hJMD5bC11oGzq9Ueujqg7J1LlYxdbkas6uzjKjSmt2OnLB1rlyNhrF4geRyZEigkGBuKkOS2gk2CNDCHvVvdQrpi0q+rVWmCDA+Cq1YKpokiGVxobJNY6sFQ48bUrXMa34Ws7kpLnMat4kIyv+77q3oxPRD7BtpkrMMOITX+SD5g75Pz0RXqgAAAB4nG2MyW6DQBiD+RKYpKT7vqf7Gg55pNHwEyJNGDSMRHj70nKtD7Zly45G0YA0+h8LRoyJSVBMmLJDyoxd9tjngEOOOOaEU84454JLrrjmhlvuuGfOA4888cwLr7zxzgeffPHNgixKtfeuzawUYTZYv16VITXaS8hy11azwf7FibGi/dS4Te2laWLj6k7lYiVIIv3aK9nWusqng2TLsXR900m2VMXaBvFxbXWnvBjn84mXor8pk54kqKa/NmUvVkyIg3NW/VK2jFvtKzQeR0uGRSgIrFlRYsip2FDT0LGNoh/MCkh9AAAA') format('woff')}[class*=' eruda-icon-'],[class^='eruda-icon-']{display:inline-block;font-family:eruda-icon!important;font-size:16px;font-style:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.eruda-icon-arrow-left:before{content:'\f101'}.eruda-icon-arrow-right:before{content:'\f102'}.eruda-icon-caret-down:before{content:'\f103'}.eruda-icon-caret-right:before{content:'\f104'}.eruda-icon-clear:before{content:'\f105'}.eruda-icon-compress:before{content:'\f106'}.eruda-icon-copy:before{content:'\f107'}.eruda-icon-delete:before{content:'\f108'}.eruda-icon-error:before{content:'\f109'}.eruda-icon-expand:before{content:'\f10a'}.eruda-icon-eye:before{content:'\f10b'}.eruda-icon-filter:before{content:'\f10c'}.eruda-icon-play:before{content:'\f10d'}.eruda-icon-record:before{content:'\f10e'}.eruda-icon-refresh:before{content:'\f10f'}.eruda-icon-reset:before{content:'\f110'}.eruda-icon-search:before{content:'\f111'}.eruda-icon-select:before{content:'\f112'}.eruda-icon-tool:before{content:'\f113'}.eruda-icon-warn:before{content:'\f114'}@font-face{font-family:luna-console-icon;src:url('data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAAasAAsAAAAACnAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAAI4AAADcIsYnIk9TLzIAAAGYAAAAPgAAAFZWmlGRY21hcAAAAdgAAAD2AAACyDioZ9NnbHlmAAAC0AAAAZgAAAH8Lq6nDGhlYWQAAARoAAAAMQAAADZ25cSzaGhlYQAABJwAAAAdAAAAJAgCBBRobXR4AAAEvAAAABkAAABYGAH//GxvY2EAAATYAAAAGAAAAC4J8glUbWF4cAAABPAAAAAfAAAAIAEjAFBuYW1lAAAFEAAAASkAAAIWm5e+CnBvc3QAAAY8AAAAcAAAAJ7qA/7MeJxNjTsOwjAQRJ8TJzE2hPBrKBBHQByAAiGqFBRcIBVCiqhyBA7O2AgRr9Y7M2+lxQCeAyeyy7W9U/fd8GKL5fsiH2vTPx8d7ufEbJpO/aagYc+RM7fEjBKnmiRuySmZUTNNf0wybYSRj9VoO4iU7NQh+Up8qelZs5EupP75Shfm2oz3Kmkvt/gARcgJKwAAeJxjYGQUZ5zAwMrAwNTJdIaBgaEfQjO+ZjBi5ACKMrAyM2AFAWmuKQwHGHQ/srGAuDEsTGBhRhABALQ1CMwAAHiczdJNbsIwEIbh1+QHQsJviNRFF1XX7aEQRZQNRQjEHXqgrnopn4B+E8+qqip117GeRB4nk4lloAAyeZIcwicBiw9lQ5/PGPf5nHfNV8yVyXlmzZY9R05cuMbydtOqZTfsOCh7Vjb02e8RVMXGHfc8aDxqwFKVF7QMtdLpmzUVDSOmTJjpnUH/3YJSBcofqv4Wyz8+b6FuWvXSjW1SV30r1sl/icYuofFZh+1+Yn+7dnPZuIW8uFa2big7t5JXZzX3znbh4Gp5c5UcnfVyciM5u6lc3ESuTnsZQ2JnLQ4S7J4ldjZjntj5jEVi5zaWCeUXWN4q9AAAeJxdUMFOU0EUnTMzb2o1FB5O5wENg31k5mExVEo7jSGBEuO6CStDmtbIBuiKBYg/gRu/ABO3/ocscOEXsHBpogtWvFfnvQgxJnduztx7zknuIXQyIYSDE9IgLwmBmIZI1pDYbTSxBqeW4KvrVKSmaaRKFZREE7YJIyONSLW6W37bLiRxscXNTH1zbnFqlnJ5Eu+G9MnT8JBy9l69ELx69Ohd9JCryrwcU07TbCU5H4y+jQbnyco/EF+8x1/eaX03bCzR8IgGwVn0WC/I8YOzaLGS+4+p4K8O/lcXkPhj/CP0ig1JQIhJyugCxz3o7LqH4YUH0L3swlMK3q+CV/HMbhkJAqlarm1jgd+97DpnfsKPeH15eT2+l9L5OJ/kcjZJfY6MU++wQPzI+PRECUJjo97aAtqupaqhFLHtRLHNf1Kwn9lAOid9L7tV9nzVldNL3dC+NmrGOGM+sme2VrO335Mda3foXlXravY57zemY23HkLs72RsW5JegDjZK99FnPPtwl8FX1i92IfAax6yfvkWf/AHb1F1JeJxjYGRgYABi3/mPYuP5bb4ycLOABKI4H+9rgNH//zIwsDCzMAElOBhAJAMAQ2IK+QAAAHicY2BkYGBhAAEWhv9///9lYWZgZEAFYgBbLQQgAAAAeJxjYGBgYGH4/58FTIPZf2FsSgAAM58EEwAAAHicY2AAgjyGJoYlDI8YPjD8ww8BeTMTR3icY2BkYGAQY3BhYGYAASYg5gJCBob/YD4DABGFAXQAeJxlkD1uwkAUhMdgSAJSghQpKbNVCiKZn5IDQE9Bl8KYtTGyvdZ6QaLLCXKEHCGniHKCHChj82hgLT9/M2/e7soABviFh3p5uG1qvVq4oTpxm/Qg7JOfhTvo40W4S38o3MMbpsJ9POKdO3j+HZ0BSuEW7vEh3Kb/KeyTv4Q7eMK3cJf+j3APK/wJ9/HqDdPIFLEp3FIn+yy0Z3n+rrStUlOoSTA+WwtdaBs6vVHro6oOydS5WMXW5GrOrs4yo0prdjpywda5cjYaxeIHkcmRIoJBgbipDktoJNgjQwh71b3UK6YtKvq1VpggwPgqtWCqaJIhlcaGyTWOrBUOPG1K1zGt+FrO5KS5zGreJCMr/u+6t6MT0Q+wbaZKzDDiE1/kg+YO+T89EV6oAAAAeJxtxksOgjAUQNF3kaIW/x9cBYtqgEAnLXlp0+1rwtQzuVcq2Vj5r6NiR42hYc+BI5aWE2cuXLlx58GTF286PmIm1ajGhzWnJub0S12cBjs4nVI/xhLabdXPS2JCiXgCK5lEwTHQMzKziHwBqnYYpg==') format('woff')}[class*=' luna-console-icon-'],[class^=luna-console-icon-]{display:inline-block;font-family:luna-console-icon!important;font-size:16px;font-style:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.luna-console-icon-error:before{content:'\f101'}.luna-console-icon-input:before{content:'\f102'}.luna-console-icon-output:before{content:'\f103'}.luna-console-icon-warn:before{content:'\f104'}.luna-console-icon-caret-down:before{content:'\f105'}.luna-console-icon-caret-right:before{content:'\f106'}.luna-console{background:#fff;overflow-y:auto;-webkit-overflow-scrolling:touch;height:100%;position:relative;will-change:scroll-position;cursor:default;font-size:12px;font-family:ui-monospace,SFMono-Regular,SF Mono,Menlo,Consolas,Liberation Mono,monospace}.luna-console.luna-console-theme-dark{background-color:#242424}.luna-console-hidden{display:none}.luna-console-fake-logs{position:absolute;left:0;top:0;pointer-events:none;visibility:hidden;width:100%}.luna-console-logs{padding-top:1px;position:absolute;width:100%}.luna-console-log-container{box-sizing:content-box}.luna-console-log-container.luna-console-selected .luna-console-log-item{background:#ecf1f8}.luna-console-log-container.luna-console-selected .luna-console-log-item:not(.luna-console-error):not(.luna-console-warn){border-color:#ccdef5}.luna-console-header{white-space:nowrap;display:flex;font-size:11px;color:#545454;border-top:1px solid transparent;border-bottom:1px solid #ccc}.luna-console-header .luna-console-time-from-container{overflow-x:auto;-webkit-overflow-scrolling:touch;padding:3px 10px}.luna-console-nesting-level{width:14px;flex-shrink:0;margin-top:-1px;margin-bottom:-1px;position:relative;border-right:1px solid #ccc}.luna-console-nesting-level.luna-console-group-closed::before{content:""}.luna-console-nesting-level::before{border-bottom:1px solid #ccc;position:absolute;top:0;left:0;margin-left:100%;width:5px;height:100%;box-sizing:border-box}.luna-console-log-item{position:relative;display:flex;border-top:1px solid transparent;border-bottom:1px solid #ccc;margin-top:-1px;color:#333}.luna-console-log-item:after{content:"";display:block;clear:both}.luna-console-log-item .luna-console-code{display:inline;font-family:ui-monospace,SFMono-Regular,SF Mono,Menlo,Consolas,Liberation Mono,monospace}.luna-console-log-item .luna-console-code .luna-console-keyword{color:#881280}.luna-console-log-item .luna-console-code .luna-console-number{color:#1c00cf}.luna-console-log-item .luna-console-code .luna-console-operator{color:gray}.luna-console-log-item .luna-console-code .luna-console-comment{color:#236e25}.luna-console-log-item .luna-console-code .luna-console-string{color:#1a1aa6}.luna-console-log-item a{color:#15c!important}.luna-console-log-item .luna-console-icon-container{margin:0 -6px 0 10px}.luna-console-log-item .luna-console-icon-container .luna-console-icon{line-height:20px;font-size:12px;color:#333;position:relative}.luna-console-log-item .luna-console-icon-container .luna-console-icon-caret-down,.luna-console-log-item .luna-console-icon-container .luna-console-icon-caret-right{top:0;left:-2px}.luna-console-log-item .luna-console-icon-container .luna-console-icon-error{top:0;color:#ef3842}.luna-console-log-item .luna-console-icon-container .luna-console-icon-warn{top:0;color:#e8a400}.luna-console-log-item .luna-console-count{background:#8097bd;color:#fff;padding:2px 4px;border-radius:10px;font-size:12px;float:left;margin:1px -6px 0 10px}.luna-console-log-item .luna-console-log-content-wrapper{flex:1;overflow:hidden}.luna-console-log-item .luna-console-log-content{padding:3px 0;margin:0 10px;overflow-x:auto;-webkit-overflow-scrolling:touch;white-space:pre-wrap;-webkit-user-select:text;-moz-user-select:text;-ms-user-select:text;user-select:text}.luna-console-log-item .luna-console-log-content *{-webkit-user-select:text;-moz-user-select:text;-ms-user-select:text;user-select:text}.luna-console-log-item .luna-console-log-content>*{vertical-align:top}.luna-console-log-item .luna-console-log-content .luna-console-null,.luna-console-log-item .luna-console-log-content .luna-console-undefined{color:#5e5e5e}.luna-console-log-item .luna-console-log-content .luna-console-number{color:#1c00cf}.luna-console-log-item .luna-console-log-content .luna-console-boolean{color:#0d22aa}.luna-console-log-item .luna-console-log-content .luna-console-regexp,.luna-console-log-item .luna-console-log-content .luna-console-symbol{color:#881391}.luna-console-log-item .luna-console-data-grid,.luna-console-log-item .luna-console-dom-viewer{white-space:initial}.luna-console-log-item.luna-console-error{z-index:50;background:#fff0f0;color:red;border-top:1px solid #ffd6d6;border-bottom:1px solid #ffd6d6}.luna-console-log-item.luna-console-error .luna-console-stack{padding-left:1.2em;white-space:nowrap}.luna-console-log-item.luna-console-error .luna-console-count{background:red}.luna-console-log-item.luna-console-debug{z-index:20}.luna-console-log-item.luna-console-input{border-bottom-color:transparent}.luna-console-log-item.luna-console-warn{z-index:40;color:#5c5c00;background:#fffbe5;border-top:1px solid #fff5c2;border-bottom:1px solid #fff5c2}.luna-console-log-item.luna-console-warn .luna-console-count{background:#e8a400}.luna-console-log-item.luna-console-info{z-index:30}.luna-console-log-item.luna-console-group,.luna-console-log-item.luna-console-groupCollapsed{font-weight:700}.luna-console-preview{display:inline-block}.luna-console-preview .luna-console-preview-container{display:flex;align-items:center}.luna-console-preview .luna-console-json{overflow-x:auto;-webkit-overflow-scrolling:touch;padding-left:12px}.luna-console-preview .luna-console-preview-icon-container{display:block}.luna-console-preview .luna-console-preview-icon-container .luna-console-icon{position:relative;font-size:12px}.luna-console-preview .luna-console-preview-icon-container .luna-console-icon-caret-down{top:2px}.luna-console-preview .luna-console-preview-icon-container .luna-console-icon-caret-right{top:1px}.luna-console-preview .luna-console-preview-content-container{word-break:break-all}.luna-console-preview .luna-console-descriptor,.luna-console-preview .luna-console-object-preview{font-style:italic}.luna-console-preview .luna-console-key{color:#881391}.luna-console-preview .luna-console-number{color:#1c00cf}.luna-console-preview .luna-console-null{color:#5e5e5e}.luna-console-preview .luna-console-string{color:#c41a16}.luna-console-preview .luna-console-boolean{color:#0d22aa}.luna-console-preview .luna-console-special{color:#5e5e5e}.luna-console-theme-dark{color-scheme:dark}.luna-console-theme-dark .luna-console-log-container.luna-console-selected .luna-console-log-item{background:#29323d}.luna-console-theme-dark .luna-console-log-container.luna-console-selected .luna-console-log-item:not(.luna-console-error):not(.luna-console-warn){border-color:#4173b4}.luna-console-theme-dark .luna-console-log-item{color:#a5a5a5;border-bottom-color:#3d3d3d}.luna-console-theme-dark .luna-console-log-item .luna-console-code .luna-console-keyword{color:#e36eec}.luna-console-theme-dark .luna-console-log-item .luna-console-code .luna-console-number{color:#9980ff}.luna-console-theme-dark .luna-console-log-item .luna-console-code .luna-console-operator{color:#7f7f7f}.luna-console-theme-dark .luna-console-log-item .luna-console-code .luna-console-comment{color:#747474}.luna-console-theme-dark .luna-console-log-item .luna-console-code .luna-console-string{color:#f29766}.luna-console-theme-dark .luna-console-log-item.luna-console-error{background:#290000;color:#ff8080;border-top-color:#5c0000;border-bottom-color:#5c0000}.luna-console-theme-dark .luna-console-log-item.luna-console-error .luna-console-count{background:#ff8080}.luna-console-theme-dark .luna-console-log-item.luna-console-warn{color:#ffcb6b;background:#332a00;border-top-color:#650;border-bottom-color:#650}.luna-console-theme-dark .luna-console-log-item .luna-console-count{background:#42597f;color:#949494}.luna-console-theme-dark .luna-console-log-item .luna-console-log-content .luna-console-null,.luna-console-theme-dark .luna-console-log-item .luna-console-log-content .luna-console-undefined{color:#7f7f7f}.luna-console-theme-dark .luna-console-log-item .luna-console-log-content .luna-console-boolean,.luna-console-theme-dark .luna-console-log-item .luna-console-log-content .luna-console-number{color:#9980ff}.luna-console-theme-dark .luna-console-log-item .luna-console-log-content .luna-console-regexp,.luna-console-theme-dark .luna-console-log-item .luna-console-log-content .luna-console-symbol{color:#e36eec}.luna-console-theme-dark .luna-console-icon-container .luna-console-icon-caret-down,.luna-console-theme-dark .luna-console-icon-container .luna-console-icon-caret-right{color:#9aa0a6}.luna-console-theme-dark .luna-console-header{border-bottom-color:#3d3d3d}.luna-console-theme-dark .luna-console-nesting-level{border-right-color:#3d3d3d}.luna-console-theme-dark .luna-console-nesting-level::before{border-bottom-color:#3d3d3d}.luna-console-theme-dark .luna-console-preview .luna-console-key{color:#e36eec}.luna-console-theme-dark .luna-console-preview .luna-console-number{color:#9980ff}.luna-console-theme-dark .luna-console-preview .luna-console-null{color:#7f7f7f}.luna-console-theme-dark .luna-console-preview .luna-console-string{color:#f29766}.luna-console-theme-dark .luna-console-preview .luna-console-boolean{color:#9980ff}.luna-console-theme-dark .luna-console-preview .luna-console-special{color:#7f7f7f}@font-face{font-family:luna-object-viewer-icon;src:url('data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAAS8AAsAAAAAB7QAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAAGEAAACMISgl+k9TLzIAAAFsAAAAPQAAAFZLxUkWY21hcAAAAawAAADWAAACdBU42qdnbHlmAAAChAAAAC4AAAAwabU7V2hlYWQAAAK0AAAALwAAADZzjr4faGhlYQAAAuQAAAAYAAAAJAFyANlobXR4AAAC/AAAABAAAABAAZAAAGxvY2EAAAMMAAAAEAAAACIAtACobWF4cAAAAxwAAAAfAAAAIAEbAA9uYW1lAAADPAAAASkAAAIWm5e+CnBvc3QAAARoAAAAUwAAAHZW8MNZeJxNjTsOQFAQRc/z/+sV1mABohKV0gZeJRJR2X9cT4RJZu7nFIMBMjoGvHGaF6rdngcNAc/c/O/Nvq2W5E1igdNE2zv1iGh1c5FQPlYXUlJRyxt9+/pUKadQa/AveGEGZQAAAHicY2BkkGScwMDKwMBQx9ADJGWgdAIDJ4MxAwMTAyszA1YQkOaawnCAQfcjE8MJIFcITDIwMIIIAFqDCGkAAAB4nM2STQ4BQRCFv54ZP8MwFhYW4gQcShBsSERi50BWDuFCcwJedddKRGKnOt8k9aanqudVAy0gF3NRQLgTsLhJDVHP6UW94Kp8zEhKwYIlG/YcOXHm0mTPp96aumLLwdUQ1fcIqmJrwpSZL+iqak5JmyE1Ayr1bdGhr/2ZPmp/qPQtuj/uJzqQl+pfDyypesQD6AT/ElV8PjyrMccT9rdLR3PUFBI227VTio1jbm6dodg5VnPvmAsHxzofHfmi+Sbs/pwdWcXFkWdNSNg9arIE2QufuSCyAAB4nGNgZACBlQzTGZgYGMyVxVc2O073AIpAxHsYloHFRc2dPZY2OTIwAACmEQesAAB4nGNgZGBgAOINe2b6x/PbfGXgZjgBFIjifLyvAUEDwUqGZUCSg4EJxAEAUn4LLAB4nGNgZGBgOMHAACdXMjAyoAIBADizAkx4nGNgAIITUEwGAABZUAGReJxjYAACHgYJ3BAAE94BXXicY2BkYGAQYGBmANEMDExAzAWEDAz/wXwGAApcASsAeJxlkD1uwkAUhMdgSAJSghQpKbNVCiKZn5IDQE9Bl8KYtTGyvdZ6QaLLCXKEHCGniHKCHChj82hgLT9/M2/e7soABviFh3p5uG1qvVq4oTpxm/Qg7JOfhTvo40W4S38o3MMbpsJ9POKdO3j+HZ0BSuEW7vEh3Kb/KeyTv4Q7eMK3cJf+j3APK/wJ9/HqDdPIFLEp3FIn+yy0Z3n+rrStUlOoSTA+WwtdaBs6vVHro6oOydS5WMXW5GrOrs4yo0prdjpywda5cjYaxeIHkcmRIoJBgbipDktoJNgjQwh71b3UK6YtKvq1VpggwPgqtWCqaJIhlcaGyTWOrBUOPG1K1zGt+FrO5KS5zGreJCMr/u+6t6MT0Q+wbaZKzDDiE1/kg+YO+T89EV6oAAAAeJxdxjkOgCAUANE/uOOGB+FQBIjaaEJIuL6FsfE1M6Lk9fXPoKioaWjp6BnQjEzMLKwYNtHepZhtuMs1vpvO/ch4HIlIxhK4KVyc7BwiD8nvDlkA') format('woff')}[class*=' luna-object-viewer-icon-'],[class^=luna-object-viewer-icon-]{display:inline-block;font-family:luna-object-viewer-icon!important;font-size:16px;font-style:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.luna-object-viewer-icon-caret-down:before{content:'\f101'}.luna-object-viewer-icon-caret-right:before{content:'\f102'}.luna-object-viewer{overflow-x:auto;-webkit-overflow-scrolling:touch;overflow-y:hidden;cursor:default;font-family:ui-monospace,SFMono-Regular,SF Mono,Menlo,Consolas,Liberation Mono,monospace;font-size:12px;line-height:1.2;min-height:100%;color:#333;list-style:none!important}.luna-object-viewer ul{list-style:none!important;padding:0!important;padding-left:12px!important;margin:0!important}.luna-object-viewer li{position:relative;white-space:nowrap;line-height:16px;min-height:16px}.luna-object-viewer>li>.luna-object-viewer-key{display:none}.luna-object-viewer span{position:static!important}.luna-object-viewer li .luna-object-viewer-collapsed~.luna-object-viewer-close:before{color:#999}.luna-object-viewer-array .luna-object-viewer-object .luna-object-viewer-key{display:inline}.luna-object-viewer-null{color:#5e5e5e}.luna-object-viewer-regexp,.luna-object-viewer-string{color:#c41a16}.luna-object-viewer-number{color:#1c00cf}.luna-object-viewer-boolean{color:#0d22aa}.luna-object-viewer-special{color:#5e5e5e}.luna-object-viewer-key,.luna-object-viewer-key-lighter{color:#881391}.luna-object-viewer-key-lighter{opacity:.6}.luna-object-viewer-key-special{color:#5e5e5e}.luna-object-viewer-collapsed .luna-object-viewer-icon,.luna-object-viewer-expanded .luna-object-viewer-icon{position:absolute!important;left:-12px;color:#727272;font-size:12px}.luna-object-viewer-icon-caret-right{top:0}.luna-object-viewer-icon-caret-down{top:1px}.luna-object-viewer-expanded>.luna-object-viewer-icon-caret-down{display:inline}.luna-object-viewer-expanded>.luna-object-viewer-icon-caret-right{display:none}.luna-object-viewer-collapsed>.luna-object-viewer-icon-caret-down{display:none}.luna-object-viewer-collapsed>.luna-object-viewer-icon-caret-right{display:inline}.luna-object-viewer-hidden~ul{display:none}.luna-object-viewer-theme-dark{color:#fff}.luna-object-viewer-theme-dark .luna-object-viewer-null,.luna-object-viewer-theme-dark .luna-object-viewer-special{color:#a1a1a1}.luna-object-viewer-theme-dark .luna-object-viewer-regexp,.luna-object-viewer-theme-dark .luna-object-viewer-string{color:#f28b54}.luna-object-viewer-theme-dark .luna-object-viewer-boolean,.luna-object-viewer-theme-dark .luna-object-viewer-number{color:#9980ff}.luna-object-viewer-theme-dark .luna-object-viewer-key,.luna-object-viewer-theme-dark .luna-object-viewer-key-lighter{color:#5db0d7}@font-face{font-family:luna-dom-viewer-icon;src:url('data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAASgAAsAAAAAB4QAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAAFwAAACMIRYl8k9TLzIAAAFkAAAAPQAAAFZLxUkaY21hcAAAAaQAAADHAAACWBcU1KRnbHlmAAACbAAAAC4AAAAwabU7V2hlYWQAAAKcAAAALwAAADZzjr4faGhlYQAAAswAAAAYAAAAJAFyANdobXR4AAAC5AAAABAAAAA4AZAAAGxvY2EAAAL0AAAAEAAAAB4AnACQbWF4cAAAAwQAAAAfAAAAIAEZAA9uYW1lAAADJAAAASkAAAIWm5e+CnBvc3QAAARQAAAATgAAAG5m1cqleJxjYGRgYOBiMGCwY2BycfMJYeDLSSzJY5BiYGGAAJA8MpsxJzM9kYEDxgPKsYBpDiC2AdNMDGwMckCSGyzHCuSxA2kuIJ+HgReoggtJnANMcwJFGRmYAXZLBkt4nGNgZJBlnMDAysDAUMfQAyRloHQCAyeDMQMDEwMrMwNWEJDmmsJwgEH3IxPDCSBXCEwyMDCCCABbzwhtAAAAeJy1kksKwjAQhr/0oX0JLlyIZ9BDCQXtRkEEwQO56uV6Av0nmZWI4MIJX2H+JvNIBiiBXGxFAWEkYPaQGqKe00S94C5/xVJKwY49PQNnLly5Tdnzqb9JPXByNUT13YKipLVm4wvmilvR0ilfrboKFsy0N9OB2Yco32z+437SLVTQdo05dUksgF8z/8+6+B3dU2m67YR1u3fsLXtH7egtEq04OhZpcKzbk1OLs2NzcXE0F3rNhOW9ObqbKSRsVqYsQfYC6fYeiQB4nGNgZACBlQzTGZgYGMyVxVc2O073AIpAxHsYloHFRc2dPZY2OTIwAACmEQesAAB4nGNgZGBgAOLeSTNM4/ltvjJwM5wACkRxPt7XgKCBYCXDMiDJwcAE4gAAQEgKxAB4nGNgZGBgOMHAACdXMjAyoAI+ADixAkp4nGNgAIITUEwCAABMyAGReJxjYAACHgYJ7BAADsoBLXicY2BkYGDgY2BmANEMDExAzAWEDAz/wXwGAAomASkAeJxlkD1uwkAUhMdgSAJSghQpKbNVCiKZn5IDQE9Bl8KYtTGyvdZ6QaLLCXKEHCGniHKCHChj82hgLT9/M2/e7soABviFh3p5uG1qvVq4oTpxm/Qg7JOfhTvo40W4S38o3MMbpsJ9POKdO3j+HZ0BSuEW7vEh3Kb/KeyTv4Q7eMK3cJf+j3APK/wJ9/HqDdPIFLEp3FIn+yy0Z3n+rrStUlOoSTA+WwtdaBs6vVHro6oOydS5WMXW5GrOrs4yo0prdjpywda5cjYaxeIHkcmRIoJBgbipDktoJNgjQwh71b3UK6YtKvq1VpggwPgqtWCqaJIhlcaGyTWOrBUOPG1K1zGt+FrO5KS5zGreJCMr/u+6t6MT0Q+wbaZKzDDiE1/kg+YO+T89EV6oAAAAeJxdxk0KgCAUAOE3/adlJ/FQgqBuFETw+i2kTd9mRiYZvv4ZJmYWVjZ2Dk4UmosbwyPK1Vq69aVnPbamEBuOSqFj8WQSgUgTeQGPtA2iAAA=') format('woff')}[class*=' luna-dom-viewer-icon-'],[class^=luna-dom-viewer-icon-]{display:inline-block;font-family:luna-dom-viewer-icon!important;font-size:16px;font-style:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.luna-dom-viewer-icon-arrow-down:before{content:'\f101'}.luna-dom-viewer-icon-arrow-right:before{content:'\f102'}.luna-dom-viewer{color:#333;background-color:#fff;font-family:Arial,Helvetica,sans-serif;box-sizing:border-box;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;font-size:14px;overflow-y:auto;-webkit-overflow-scrolling:touch;background:0 0;overflow-x:hidden;word-wrap:break-word;padding:0 0 0 12px;font-size:12px;font-family:ui-monospace,SFMono-Regular,SF Mono,Menlo,Consolas,Liberation Mono,monospace;cursor:default;list-style:none}.luna-dom-viewer.luna-dom-viewer-platform-windows{font-family:'Segoe UI',Tahoma,sans-serif}.luna-dom-viewer.luna-dom-viewer-platform-linux{font-family:Roboto,Ubuntu,Arial,sans-serif}.luna-dom-viewer .luna-dom-viewer-hidden,.luna-dom-viewer.luna-dom-viewer-hidden{display:none}.luna-dom-viewer .luna-dom-viewer-invisible,.luna-dom-viewer.luna-dom-viewer-invisible{visibility:hidden}.luna-dom-viewer *{box-sizing:border-box}.luna-dom-viewer.luna-dom-viewer-theme-dark{color:#a5a5a5;background-color:#242424}.luna-dom-viewer ul{list-style:none}.luna-dom-viewer.luna-dom-viewer-theme-dark{color:#e8eaed}.luna-dom-viewer-toggle{min-width:12px;margin-left:-12px}.luna-dom-viewer-icon-arrow-down,.luna-dom-viewer-icon-arrow-right{position:absolute!important;font-size:12px!important}.luna-dom-viewer-tree-item{line-height:16px;min-height:16px;position:relative;z-index:10;outline:0}.luna-dom-viewer-tree-item.luna-dom-viewer-selected .luna-dom-viewer-selection,.luna-dom-viewer-tree-item:hover .luna-dom-viewer-selection{display:block}.luna-dom-viewer-tree-item:hover .luna-dom-viewer-selection{background:#f2f7fd}.luna-dom-viewer-tree-item.luna-dom-viewer-selected .luna-dom-viewer-selection{background:#e0e0e0}.luna-dom-viewer-tree-item.luna-dom-viewer-selected:focus .luna-dom-viewer-selection{background:#cfe8fc}.luna-dom-viewer-tree-item .luna-dom-viewer-icon-arrow-down{display:none}.luna-dom-viewer-tree-item.luna-dom-viewer-expanded .luna-dom-viewer-icon-arrow-down{display:inline-block}.luna-dom-viewer-tree-item.luna-dom-viewer-expanded .luna-dom-viewer-icon-arrow-right{display:none}.luna-dom-viewer-html-tag{color:#881280}.luna-dom-viewer-tag-name{color:#881280}.luna-dom-viewer-attribute-name{color:#994500}.luna-dom-viewer-attribute-value{color:#1a1aa6}.luna-dom-viewer-attribute-value.luna-dom-viewer-attribute-underline{text-decoration:underline}.luna-dom-viewer-html-comment{color:#236e25}.luna-dom-viewer-selection{position:absolute;display:none;left:-10000px;right:-10000px;top:0;bottom:0;z-index:-1}.luna-dom-viewer-children{margin:0;overflow-x:visible;overflow-y:visible;padding-left:15px}.luna-dom-viewer-text-node .luna-dom-viewer-keyword{color:#881280}.luna-dom-viewer-text-node .luna-dom-viewer-number{color:#1c00cf}.luna-dom-viewer-text-node .luna-dom-viewer-operator{color:grey}.luna-dom-viewer-text-node .luna-dom-viewer-comment{color:#236e25}.luna-dom-viewer-text-node .luna-dom-viewer-string{color:#1a1aa6}.luna-dom-viewer-theme-dark .luna-dom-viewer-icon-arrow-down,.luna-dom-viewer-theme-dark .luna-dom-viewer-icon-arrow-right{color:#9aa0a6}.luna-dom-viewer-theme-dark .luna-dom-viewer-html-tag,.luna-dom-viewer-theme-dark .luna-dom-viewer-tag-name{color:#5db0d7}.luna-dom-viewer-theme-dark .luna-dom-viewer-attribute-name{color:#9bbbdc}.luna-dom-viewer-theme-dark .luna-dom-viewer-attribute-value{color:#f29766}.luna-dom-viewer-theme-dark .luna-dom-viewer-html-comment{color:#898989}.luna-dom-viewer-theme-dark .luna-dom-viewer-tree-item:hover .luna-dom-viewer-selection{background:#083c69}.luna-dom-viewer-theme-dark .luna-dom-viewer-tree-item.luna-dom-viewer-selected .luna-dom-viewer-selection{background:#454545}.luna-dom-viewer-theme-dark .luna-dom-viewer-tree-item.luna-dom-viewer-selected:focus .luna-dom-viewer-selection{background:#073d69}.luna-dom-viewer-theme-dark .luna-dom-viewer-text-node .luna-dom-viewer-keyword{color:#e36eec}.luna-dom-viewer-theme-dark .luna-dom-viewer-text-node .luna-dom-viewer-number{color:#9980ff}.luna-dom-viewer-theme-dark .luna-dom-viewer-text-node .luna-dom-viewer-operator{color:#7f7f7f}.luna-dom-viewer-theme-dark .luna-dom-viewer-text-node .luna-dom-viewer-comment{color:#747474}.luna-dom-viewer-theme-dark .luna-dom-viewer-text-node .luna-dom-viewer-string{color:#f29766}@font-face{font-family:luna-text-viewer-icon;src:url('data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAAS0AAsAAAAAB2QAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAAFQAAAB0INElr09TLzIAAAFcAAAAPQAAAFZL+0klY21hcAAAAZwAAACfAAACEAEewxRnbHlmAAACPAAAAIYAAACkNSDggmhlYWQAAALEAAAALgAAADZzrb4oaGhlYQAAAvQAAAAWAAAAJAGRANNobXR4AAADDAAAABAAAAAoAZAAAGxvY2EAAAMcAAAAEAAAABYBWgFIbWF4cAAAAywAAAAdAAAAIAEXADtuYW1lAAADTAAAASkAAAIWm5e+CnBvc3QAAAR4AAAAOwAAAFJIWdOleJxjYGRgYOBiMGCwY2BycfMJYeDLSSzJY5BiYGGAAJA8MpsxJzM9kYEDxgPKsYBpDiBWAdNMDGwMQkAWK1CGlYEZyGMCstiBMpxAUUYGZgDbGgXDeJxjYGTQYJzAwMrAwFDH0AMkZaB0AgMngzEDAxMDKzMDVhCQ5prCcIAh+SMTwwkgVwhMMjAwgggAY84IrgAAAHicvZFLCsMwDERHzsdJ6aL0HD1VQiDQRbIN9Axd9aI+QTpjq5Bdd5F4Bo1lybIBNAAq8iA1YB8YZG+qlvUKl6zXGBjf6MofMWHGEyu2FPb9oCxULCtHs3yy+J2urg1rtojo0HM/MKnFGabOGlbdYvdT+1N6/7drXl8e6Vajo3efHP3b7HAUvntBMy1OJKujMTeHNZMV9McpFBC+tLgY4QB4nGNgZACBEwzrGdgZGOwZxdnVDdXNPfKEGlhchO0KhZtZ3IQYmMFq1jCsZpBi0GLQY2AwNzGzZjQSk2UUYdNmVFID8UyVRUXYlNRMlVGlTM1FjU3tmZkTmVhYmFRBhHwoCyuzKgtTIjMzWJg3ZClIGMRlZQmVB7GhMixM0aGhQIsB52sTqgAAeJxjYGRgYADi2JNxkvH8Nl8ZuBlOAAWiOB/va0DQQHCCYT2Q5GBgAnEANJ0KnQAAeJxjYGRgYDjBwIBEMjKgAi4AOvoCZQAAeJxjYACCE1CMBwAAM7gBkXicY2AAAiGGIFQIABXIAqN4nGNgZGBg4GLQZ2BmAAEmMI8LSP4H8xkADjQBUwAAAHicZZA9bsJAFITHYEgCUoIUKSmzVQoimZ+SA0BPQZfCmLUxsr3WekGiywlyhBwhp4hyghwoY/NoYC0/fzNv3u7KAAb4hYd6ebhtar1auKE6cZv0IOyTn4U76ONFuEt/KNzDG6bCfTzinTt4/h2dAUrhFu7xIdym/ynsk7+EO3jCt3CX/o9wDyv8Cffx6g3TyBSxKdxSJ/sstGd5/q60rVJTqEkwPlsLXWgbOr1R66OqDsnUuVjF1uRqzq7OMqNKa3Y6csHWuXI2GsXiB5HJkSKCQYG4qQ5LaCTYI0MIe9W91CumLSr6tVaYIMD4KrVgqmiSIZXGhsk1jqwVDjxtStcxrfhazuSkucxq3iQjK/7vurejE9EPsG2mSsww4hNf5IPmDvk/PRFeqAAAAHicXcU7CsAgFEXBe4x/l/kQBAtt3X0KSZNpRk7X91/F8eAJRBKZQqUp2Og2va19MAadyWJzpBd4kgcWAA==') format('woff')}[class*=' luna-text-viewer-icon-'],[class^=luna-text-viewer-icon-]{display:inline-block;font-family:luna-text-viewer-icon!important;font-size:16px;font-style:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.luna-text-viewer-icon-check:before{content:'\f101'}.luna-text-viewer-icon-copy:before{content:'\f102'}.luna-text-viewer{color:#333;background-color:#fff;font-family:Arial,Helvetica,sans-serif;box-sizing:border-box;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;font-size:14px;padding:0;unicode-bidi:embed;position:relative;overflow:auto;border:1px solid #ccc}.luna-text-viewer.luna-text-viewer-platform-windows{font-family:'Segoe UI',Tahoma,sans-serif}.luna-text-viewer.luna-text-viewer-platform-linux{font-family:Roboto,Ubuntu,Arial,sans-serif}.luna-text-viewer .luna-text-viewer-hidden,.luna-text-viewer.luna-text-viewer-hidden{display:none}.luna-text-viewer .luna-text-viewer-invisible,.luna-text-viewer.luna-text-viewer-invisible{visibility:hidden}.luna-text-viewer *{box-sizing:border-box}.luna-text-viewer.luna-text-viewer-theme-dark{color:#d9d9d9;border-color:#3d3d3d;background:#242424}.luna-text-viewer:hover .luna-text-viewer-copy{opacity:1}.luna-text-viewer-table{display:table}.luna-text-viewer-table .luna-text-viewer-line-number,.luna-text-viewer-table .luna-text-viewer-line-text{padding:0}.luna-text-viewer-table-row{display:table-row}.luna-text-viewer-line-number{display:table-cell;padding:0 3px 0 8px!important;text-align:right;vertical-align:top;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;border-right:1px solid #ccc}.luna-text-viewer-line-text{display:table-cell;padding-left:4px!important;-webkit-user-select:text;-moz-user-select:text;-ms-user-select:text;user-select:text}.luna-text-viewer-copy{background:#fff;opacity:0;position:absolute;right:5px;top:5px;border:1px solid #ccc;border-radius:4px;width:25px;height:25px;text-align:center;line-height:25px;cursor:pointer;transition:opacity .3s,top .3s}.luna-text-viewer-copy .luna-text-viewer-icon-check{color:#188037}.luna-text-viewer-text{padding:4px;font-size:12px;font-family:ui-monospace,SFMono-Regular,SF Mono,Menlo,Consolas,Liberation Mono,monospace;box-sizing:border-box;white-space:pre;display:block}.luna-text-viewer-text.luna-text-viewer-line-numbers{padding:0}.luna-text-viewer-text.luna-text-viewer-wrap-long-lines{white-space:pre-wrap}.luna-text-viewer-text.luna-text-viewer-wrap-long-lines .luna-text-viewer-line-text{word-break:break-all}.luna-text-viewer-theme-dark{color-scheme:dark}.luna-text-viewer-theme-dark .luna-text-viewer-copy,.luna-text-viewer-theme-dark .luna-text-viewer-line-number{border-color:#3d3d3d}.luna-text-viewer-theme-dark .luna-text-viewer-copy .luna-text-viewer-icon-check{color:#81c995}.luna-text-viewer-theme-dark .luna-text-viewer-copy{background-color:#242424}</style></head>

<body>
    <div id="ZN_4JiGC94Y6w5woVo"></div>
    <style data-styled="hywCld hFDmrz kbqZof cmhHQz rDAfb lcAaLl jDogfN iTyeOU etIOjC owzzZ iUYDes cuKJrD cETbit cNNGic eEpVMR hoHpcC dDGSHH gcOoiX ePoDpk bYQcLm davdrV htqcWR eRxGni gwYTWo jFeRvR fEpeIU grMlBs bJrUdE dTeYkN bducQJ dVkImY bSkWab iDAOTJ iCBjkC cPXplw SaNrZ hrBUeY fDRDBl cXLeHH kKRmMY bnOIlD dReaFp lhJrCT kEcpcI cUstTF espebs fVwWyK evIBiW cBRYOz lePqYm jNyXWf jpHdQl bsMpRS hWTjz ctqfgj jtNbfo bjZave dOHiXa gsysFh jhThrT jdnoDP iFeCCh dAHSDM kIjqbV kTeLyN dYYOaL dsBvGq ldGENT  gazhQO iCyRCL fXudwZ dhMNpJ giLqBp ehxqTE ifyuHm jgIBXR cmUnWG bSRIeR hMjsjM cueDsN iTegyV hebXKQ jSHLrx iCUpEv kLTIUD TLwJC LaOtk dpgDGU bDGzvF jpLxJR gcNVGl hRnZIE eeMMQZ cEDDKn AWCdV fjaMcR dvVfZG czBkVK dUsCof iqOYHc htAiPK dQQnbA kIJyLN dRVOMM eIrngG jpvXFy emZFka ekrleZ fcYJXN cNrgBk iyFOQA dKHbZG iylYKg kvIMt focuCb dLCxtV fMgwdS hDpoqp ikHgMx kUfvdA iMxITp ddnqvn eCUDNu hwQusK fCVywn eQlxUw lfYRqx cpGpXB eSYIff dWayMW eEAacy hjLLUR hOpmFZ fOGggn PQyCd eCmoFo iGVCNZ besrdH deEyaB eaBsBz kiJqwC hpprOV hlDnNa iyYINE biLqYe fKCszy fUTtuG byItdH kPuCIR bfPQHL cQXRoo lmUZJN kCiVOw ktcdiJ hWeNGQ cSPhVH gFvSWv gpTdno hYiizr bGuwyi gHTlpF gKlMXV haeKsn dvuHYj lhTahy cONchc gRdTZD fkwSEH kRndgy dOfbLu kOrzBT fmaqoh iLDseQ kYnGEA fRcoaK domptC lluhit cWMImq kTSYUO fsMHPV dPqlXg hbTyoW hbIzfU dKiDao eyBxdW dYkYVy gVrvSe dNTrAm oCUry QUAjb iVorxG fWOsuW UJxrT iaDrkT bmTnMU hnRrUU iCRRMm dBxJFy aVtv eLXScg iQExKI hJtDZo GMjXn jGLnOs fbEBEC hHrLKr gZakDx cQjubG afwMA hEqzYu cahgYa  dDlaSX cRTeXi ghAWfW GYHge brSEGL djeeke kNSqkm bKbctQ bKCVhH huheQg hwGosR gxgpLc klUCcX hvdBmx evlSXY kUaoWB giOfmL kuWHPL jjwizE iVEnbi fewjmS doBeQf bDzyZu hgcbvd kEkuZJ hEqqlT eDFJpn lcBaat CPTuX gCLDqU gHIvfR fqKcol glVqTX dGhjVe dZssbj jkAK dyxZfV endrEq jszGRZ dWAwkO jZrnoS hQCBiM bgBcvm igPCMP fnmykv grbrHJ eiTQxa kGPQGP gySvSN eLypNc uQFHC kdswBR dDFqHg gbMdeQ ifJwQY gtdIFh dtrjLA dcVYod xJNvu cHdxns hqjcIS cxrGoW jVXVWC kxFGLZ fEhNSb iPguLk hGbNNN AkodD iZsDPD iNpWBP gSjrEi lnINmz iGgTDm kAWE ehNPHd iYdLJP bLpKIE esIZPW gZALTo fDwPLR hYUUEb inLRcV ksnvTC dtnAeD vviKI bWKAzL ijmwZK hPteUV xIkHt GSDrY jPpOmb dZYxLS fEOdsZ hWtUxe fYFVsJ bObnXG eDQOKf fLZtzz itMgov iTFpfD dUSUNf dRwohx jQovyr hbnuUo biydSK fxAfax kwtiVV deKSko cbkVdr WuffR jDUdBn jRULlV hPDVvz gdTffh jrNxLO ktaXjt hnwyzW jmFVhT dnCYjr iJlLnv kuPRsh fKHYVG bttLbO eSaKqR YPcue iVEeUd dUaBHR gNKPOC deOajc" data-styled-version="4.2.0">
        /* sc-component-id: ad__h3us20-2 */
        .dAHSDM {
            display: none;
        }

        @media (min-width: 52.5em) {
            .dAHSDM {
                display: block;
            }
        }

        .kIjqbV {
            display: none;
        }

        @media (min-width: 45em) {
            .kIjqbV {
                display: block;
            }
        }

        /* sc-component-id: ad__h3us20-3 */
        .lhJrCT {
            display: block;
        }

        @media (min-width: 52.5em) {
            .lhJrCT {
                display: none;
            }
        }

        .kEcpcI {
            display: block;
        }

        @media (min-width: 45em) {
            .kEcpcI {
                display: none;
            }
        }

        @media (min-width: 52.5em) {
            .kEcpcI {
                display: none;
            }
        }

        .cUstTF {
            display: block;
        }

        @media (min-width: 45em) {
            .cUstTF {
                display: none;
            }
        }

        /* sc-component-id: ad__h3us20-4 */
        @media (min-width: 52.5em) {
            .hqjcIS {
                display: block;
            }
        }

        @media (min-width: 1em) and (max-width:52.4375em) {
            .jVXVWC {
                display: none;
            }
        }

        /* sc-component-id: ad__h3us20-5 */
        .iTegyV {
            width: 100%;
        }

        @media (min-width: 1em) {
            .iTegyV {
                height: 2px;
                width: 2px;
            }
        }

        @media (min-width: 37.5em) {
            .iTegyV {
                height: px;
                width: px;
            }
        }

        @media (min-width: 45em) {
            .iTegyV {
                height: px;
                width: px;
            }
        }

        @media (min-width: 52.5em) {
            .iTegyV {
                height: 8px;
                width: 8px;
            }
        }

        @media (min-width: 71.19em) {
            .iTegyV {
                height: px;
                width: px;
            }
        }

        @media (min-width: 78.69em) {
            .iTegyV {
                height: px;
                width: px;
            }
        }

        @media (min-width: 79.5em) {
            .iTegyV {
                height: px;
                width: px;
            }
        }

        .hebXKQ {
            width: 100%;
        }

        @media (min-width: 1em) {
            .hebXKQ {
                height: 24px;
                width: 24px;
            }
        }

        @media (min-width: 37.5em) {
            .hebXKQ {
                height: px;
                width: px;
            }
        }

        @media (min-width: 45em) {
            .hebXKQ {
                height: px;
                width: px;
            }
        }

        @media (min-width: 52.5em) {
            .hebXKQ {
                height: 24px;
                width: 24px;
            }
        }

        @media (min-width: 71.19em) {
            .hebXKQ {
                height: px;
                width: px;
            }
        }

        @media (min-width: 78.69em) {
            .hebXKQ {
                height: px;
                width: px;
            }
        }

        @media (min-width: 79.5em) {
            .hebXKQ {
                height: px;
                width: px;
            }
        }

        .jSHLrx {
            width: 100%;
        }

        @media (min-width: 1em) {
            .jSHLrx {
                height: 24px;
                width: 24px;
            }
        }

        @media (min-width: 37.5em) {
            .jSHLrx {
                height: px;
                width: px;
            }
        }

        @media (min-width: 45em) {
            .jSHLrx {
                height: px;
                width: px;
            }
        }

        @media (min-width: 52.5em) {
            .jSHLrx {
                height: 32px;
                width: 32px;
            }
        }

        @media (min-width: 71.19em) {
            .jSHLrx {
                height: px;
                width: px;
            }
        }

        @media (min-width: 78.69em) {
            .jSHLrx {
                height: px;
                width: px;
            }
        }

        @media (min-width: 79.5em) {
            .jSHLrx {
                height: px;
                width: px;
            }
        }

        .iCUpEv {
            width: 100%;
        }

        @media (min-width: 1em) {
            .iCUpEv {
                height: 24px;
                width: 24px;
            }
        }

        @media (min-width: 37.5em) {
            .iCUpEv {
                height: px;
                width: px;
            }
        }

        @media (min-width: 45em) {
            .iCUpEv {
                height: px;
                width: px;
            }
        }

        @media (min-width: 52.5em) {
            .iCUpEv {
                height: px;
                width: px;
            }
        }

        @media (min-width: 71.19em) {
            .iCUpEv {
                height: px;
                width: px;
            }
        }

        @media (min-width: 78.69em) {
            .iCUpEv {
                height: px;
                width: px;
            }
        }

        @media (min-width: 79.5em) {
            .iCUpEv {
                height: px;
                width: px;
            }
        }

        .kLTIUD {
            width: 100%;
        }

        @media (min-width: 1em) {
            .kLTIUD {
                height: 16px;
                width: 16px;
            }
        }

        @media (min-width: 37.5em) {
            .kLTIUD {
                height: px;
                width: px;
            }
        }

        @media (min-width: 45em) {
            .kLTIUD {
                height: px;
                width: px;
            }
        }

        @media (min-width: 52.5em) {
            .kLTIUD {
                height: 16px;
                width: 16px;
            }
        }

        @media (min-width: 71.19em) {
            .kLTIUD {
                height: px;
                width: px;
            }
        }

        @media (min-width: 78.69em) {
            .kLTIUD {
                height: px;
                width: px;
            }
        }

        @media (min-width: 79.5em) {
            .kLTIUD {
                height: px;
                width: px;
            }
        }

        .TLwJC {
            width: 100%;
        }

        @media (min-width: 1em) {
            .TLwJC {
                height: px;
                width: px;
            }
        }

        @media (min-width: 37.5em) {
            .TLwJC {
                height: px;
                width: px;
            }
        }

        @media (min-width: 45em) {
            .TLwJC {
                height: px;
                width: px;
            }
        }

        @media (min-width: 52.5em) {
            .TLwJC {
                height: 4px;
                width: 4px;
            }
        }

        @media (min-width: 71.19em) {
            .TLwJC {
                height: px;
                width: px;
            }
        }

        @media (min-width: 78.69em) {
            .TLwJC {
                height: px;
                width: px;
            }
        }

        @media (min-width: 79.5em) {
            .TLwJC {
                height: px;
                width: px;
            }
        }

        .LaOtk {
            width: 100%;
        }

        @media (min-width: 1em) {
            .LaOtk {
                height: 32px;
                width: 32px;
            }
        }

        @media (min-width: 37.5em) {
            .LaOtk {
                height: px;
                width: px;
            }
        }

        @media (min-width: 45em) {
            .LaOtk {
                height: px;
                width: px;
            }
        }

        @media (min-width: 52.5em) {
            .LaOtk {
                height: px;
                width: px;
            }
        }

        @media (min-width: 71.19em) {
            .LaOtk {
                height: px;
                width: px;
            }
        }

        @media (min-width: 78.69em) {
            .LaOtk {
                height: px;
                width: px;
            }
        }

        @media (min-width: 79.5em) {
            .LaOtk {
                height: px;
                width: px;
            }
        }

        .dpgDGU {
            width: 100%;
        }

        @media (min-width: 1em) {
            .dpgDGU {
                height: 16px;
                width: 16px;
            }
        }

        @media (min-width: 37.5em) {
            .dpgDGU {
                height: px;
                width: px;
            }
        }

        @media (min-width: 45em) {
            .dpgDGU {
                height: px;
                width: px;
            }
        }

        @media (min-width: 52.5em) {
            .dpgDGU {
                height: px;
                width: px;
            }
        }

        @media (min-width: 71.19em) {
            .dpgDGU {
                height: px;
                width: px;
            }
        }

        @media (min-width: 78.69em) {
            .dpgDGU {
                height: px;
                width: px;
            }
        }

        @media (min-width: 79.5em) {
            .dpgDGU {
                height: px;
                width: px;
            }
        }

        .bDGzvF {
            width: 100%;
        }

        @media (min-width: 1em) {
            .bDGzvF {
                height: 8px;
                width: 8px;
            }
        }

        @media (min-width: 37.5em) {
            .bDGzvF {
                height: px;
                width: px;
            }
        }

        @media (min-width: 45em) {
            .bDGzvF {
                height: px;
                width: px;
            }
        }

        @media (min-width: 52.5em) {
            .bDGzvF {
                height: px;
                width: px;
            }
        }

        @media (min-width: 71.19em) {
            .bDGzvF {
                height: px;
                width: px;
            }
        }

        @media (min-width: 78.69em) {
            .bDGzvF {
                height: px;
                width: px;
            }
        }

        @media (min-width: 79.5em) {
            .bDGzvF {
                height: px;
                width: px;
            }
        }

        .jpLxJR {
            width: 100%;
        }

        @media (min-width: 1em) {
            .jpLxJR {
                height: 32px;
                width: 32px;
            }
        }

        @media (min-width: 37.5em) {
            .jpLxJR {
                height: px;
                width: px;
            }
        }

        @media (min-width: 45em) {
            .jpLxJR {
                height: px;
                width: px;
            }
        }

        @media (min-width: 52.5em) {
            .jpLxJR {
                height: 8px;
                width: 8px;
            }
        }

        @media (min-width: 71.19em) {
            .jpLxJR {
                height: px;
                width: px;
            }
        }

        @media (min-width: 78.69em) {
            .jpLxJR {
                height: px;
                width: px;
            }
        }

        @media (min-width: 79.5em) {
            .jpLxJR {
                height: px;
                width: px;
            }
        }

        .gcNVGl {
            width: 100%;
        }

        @media (min-width: 1em) {
            .gcNVGl {
                height: 32px;
                width: 32px;
            }
        }

        @media (min-width: 37.5em) {
            .gcNVGl {
                height: px;
                width: px;
            }
        }

        @media (min-width: 45em) {
            .gcNVGl {
                height: px;
                width: px;
            }
        }

        @media (min-width: 52.5em) {
            .gcNVGl {
                height: 16px;
                width: 16px;
            }
        }

        @media (min-width: 71.19em) {
            .gcNVGl {
                height: px;
                width: px;
            }
        }

        @media (min-width: 78.69em) {
            .gcNVGl {
                height: px;
                width: px;
            }
        }

        @media (min-width: 79.5em) {
            .gcNVGl {
                height: px;
                width: px;
            }
        }

        .hRnZIE {
            width: 100%;
        }

        @media (min-width: 1em) {
            .hRnZIE {
                height: 8px;
                width: 8px;
            }
        }

        @media (min-width: 37.5em) {
            .hRnZIE {
                height: px;
                width: px;
            }
        }

        @media (min-width: 45em) {
            .hRnZIE {
                height: px;
                width: px;
            }
        }

        @media (min-width: 52.5em) {
            .hRnZIE {
                height: 16px;
                width: 16px;
            }
        }

        @media (min-width: 71.19em) {
            .hRnZIE {
                height: px;
                width: px;
            }
        }

        @media (min-width: 78.69em) {
            .hRnZIE {
                height: px;
                width: px;
            }
        }

        @media (min-width: 79.5em) {
            .hRnZIE {
                height: px;
                width: px;
            }
        }

        .eeMMQZ {
            width: 100%;
        }

        @media (min-width: 1em) {
            .eeMMQZ {
                height: 8px;
                width: 8px;
            }
        }

        @media (min-width: 37.5em) {
            .eeMMQZ {
                height: px;
                width: px;
            }
        }

        @media (min-width: 45em) {
            .eeMMQZ {
                height: px;
                width: px;
            }
        }

        @media (min-width: 52.5em) {
            .eeMMQZ {
                height: 32px;
                width: 32px;
            }
        }

        @media (min-width: 71.19em) {
            .eeMMQZ {
                height: px;
                width: px;
            }
        }

        @media (min-width: 78.69em) {
            .eeMMQZ {
                height: px;
                width: px;
            }
        }

        @media (min-width: 79.5em) {
            .eeMMQZ {
                height: px;
                width: px;
            }
        }

        .cEDDKn {
            width: 100%;
        }

        @media (min-width: 1em) {
            .cEDDKn {
                height: 32px;
                width: 32px;
            }
        }

        @media (min-width: 37.5em) {
            .cEDDKn {
                height: px;
                width: px;
            }
        }

        @media (min-width: 45em) {
            .cEDDKn {
                height: px;
                width: px;
            }
        }

        @media (min-width: 52.5em) {
            .cEDDKn {
                height: 24px;
                width: 24px;
            }
        }

        @media (min-width: 71.19em) {
            .cEDDKn {
                height: px;
                width: px;
            }
        }

        @media (min-width: 78.69em) {
            .cEDDKn {
                height: px;
                width: px;
            }
        }

        @media (min-width: 79.5em) {
            .cEDDKn {
                height: px;
                width: px;
            }
        }

        .AWCdV {
            width: 100%;
        }

        @media (min-width: 1em) {
            .AWCdV {
                height: 64px;
                width: 64px;
            }
        }

        @media (min-width: 37.5em) {
            .AWCdV {
                height: px;
                width: px;
            }
        }

        @media (min-width: 45em) {
            .AWCdV {
                height: px;
                width: px;
            }
        }

        @media (min-width: 52.5em) {
            .AWCdV {
                height: 32px;
                width: 32px;
            }
        }

        @media (min-width: 71.19em) {
            .AWCdV {
                height: px;
                width: px;
            }
        }

        @media (min-width: 78.69em) {
            .AWCdV {
                height: px;
                width: px;
            }
        }

        @media (min-width: 79.5em) {
            .AWCdV {
                height: px;
                width: px;
            }
        }

        .fjaMcR {
            width: 100%;
        }

        @media (min-width: 1em) {
            .fjaMcR {
                height: 32px;
                width: 32px;
            }
        }

        @media (min-width: 37.5em) {
            .fjaMcR {
                height: px;
                width: px;
            }
        }

        @media (min-width: 45em) {
            .fjaMcR {
                height: px;
                width: px;
            }
        }

        @media (min-width: 52.5em) {
            .fjaMcR {
                height: 48px;
                width: 48px;
            }
        }

        @media (min-width: 71.19em) {
            .fjaMcR {
                height: px;
                width: px;
            }
        }

        @media (min-width: 78.69em) {
            .fjaMcR {
                height: px;
                width: px;
            }
        }

        @media (min-width: 79.5em) {
            .fjaMcR {
                height: px;
                width: px;
            }
        }

        .dvVfZG {
            width: 100%;
        }

        @media (min-width: 1em) {
            .dvVfZG {
                height: 16px;
                width: 16px;
            }
        }

        @media (min-width: 37.5em) {
            .dvVfZG {
                height: px;
                width: px;
            }
        }

        @media (min-width: 45em) {
            .dvVfZG {
                height: px;
                width: px;
            }
        }

        @media (min-width: 52.5em) {
            .dvVfZG {
                height: 24px;
                width: 24px;
            }
        }

        @media (min-width: 71.19em) {
            .dvVfZG {
                height: px;
                width: px;
            }
        }

        @media (min-width: 78.69em) {
            .dvVfZG {
                height: px;
                width: px;
            }
        }

        @media (min-width: 79.5em) {
            .dvVfZG {
                height: px;
                width: px;
            }
        }

        .czBkVK {
            width: 100%;
        }

        @media (min-width: 1em) {
            .czBkVK {
                height: 16px;
                width: 16px;
            }
        }

        @media (min-width: 37.5em) {
            .czBkVK {
                height: px;
                width: px;
            }
        }

        @media (min-width: 45em) {
            .czBkVK {
                height: px;
                width: px;
            }
        }

        @media (min-width: 52.5em) {
            .czBkVK {
                height: 12px;
                width: 12px;
            }
        }

        @media (min-width: 71.19em) {
            .czBkVK {
                height: px;
                width: px;
            }
        }

        @media (min-width: 78.69em) {
            .czBkVK {
                height: px;
                width: px;
            }
        }

        @media (min-width: 79.5em) {
            .czBkVK {
                height: px;
                width: px;
            }
        }

        .dUsCof {
            width: 100%;
        }

        @media (min-width: 1em) {
            .dUsCof {
                height: 16px;
                width: 16px;
            }
        }

        @media (min-width: 37.5em) {
            .dUsCof {
                height: px;
                width: px;
            }
        }

        @media (min-width: 45em) {
            .dUsCof {
                height: px;
                width: px;
            }
        }

        @media (min-width: 52.5em) {
            .dUsCof {
                height: 2px;
                width: 2px;
            }
        }

        @media (min-width: 71.19em) {
            .dUsCof {
                height: px;
                width: px;
            }
        }

        @media (min-width: 78.69em) {
            .dUsCof {
                height: px;
                width: px;
            }
        }

        @media (min-width: 79.5em) {
            .dUsCof {
                height: px;
                width: px;
            }
        }

        .iqOYHc {
            width: 100%;
        }

        @media (min-width: 1em) {
            .iqOYHc {
                height: 32px;
                width: 32px;
            }
        }

        @media (min-width: 37.5em) {
            .iqOYHc {
                height: px;
                width: px;
            }
        }

        @media (min-width: 45em) {
            .iqOYHc {
                height: px;
                width: px;
            }
        }

        @media (min-width: 52.5em) {
            .iqOYHc {
                height: 32px;
                width: 32px;
            }
        }

        @media (min-width: 71.19em) {
            .iqOYHc {
                height: px;
                width: px;
            }
        }

        @media (min-width: 78.69em) {
            .iqOYHc {
                height: px;
                width: px;
            }
        }

        @media (min-width: 79.5em) {
            .iqOYHc {
                height: px;
                width: px;
            }
        }

        /* sc-component-id: ad__h3us20-6 */
        @media (min-width: 1em) {
            .huheQg {
                -webkit-order: 0;
                -ms-flex-order: 0;
                order: 0;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {}

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .hwGosR {
                -webkit-order: 1;
                -ms-flex-order: 1;
                order: 1;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {}

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .gxgpLc {
                -webkit-order: 2;
                -ms-flex-order: 2;
                order: 2;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .gxgpLc {
                -webkit-order: 1;
                -ms-flex-order: 1;
                order: 1;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .klUCcX {
                -webkit-order: 4;
                -ms-flex-order: 4;
                order: 4;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .klUCcX {
                -webkit-order: 3;
                -ms-flex-order: 3;
                order: 3;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .hvdBmx {
                -webkit-order: 9;
                -ms-flex-order: 9;
                order: 9;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .hvdBmx {
                -webkit-order: 5;
                -ms-flex-order: 5;
                order: 5;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .evlSXY {
                -webkit-order: 11;
                -ms-flex-order: 11;
                order: 11;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .evlSXY {
                -webkit-order: 7;
                -ms-flex-order: 7;
                order: 7;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .kUaoWB {
                -webkit-order: 14;
                -ms-flex-order: 14;
                order: 14;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .kUaoWB {
                -webkit-order: 13;
                -ms-flex-order: 13;
                order: 13;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .giOfmL {
                -webkit-order: 18;
                -ms-flex-order: 18;
                order: 18;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .giOfmL {
                -webkit-order: 16;
                -ms-flex-order: 16;
                order: 16;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .kuWHPL {
                -webkit-order: 20;
                -ms-flex-order: 20;
                order: 20;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .kuWHPL {
                -webkit-order: 18;
                -ms-flex-order: 18;
                order: 18;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .jjwizE {
                -webkit-order: 22;
                -ms-flex-order: 22;
                order: 22;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .jjwizE {
                -webkit-order: 20;
                -ms-flex-order: 20;
                order: 20;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .iVEnbi {
                -webkit-order: 24;
                -ms-flex-order: 24;
                order: 24;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .iVEnbi {
                -webkit-order: 22;
                -ms-flex-order: 22;
                order: 22;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .fewjmS {
                -webkit-order: 26;
                -ms-flex-order: 26;
                order: 26;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .fewjmS {
                -webkit-order: 24;
                -ms-flex-order: 24;
                order: 24;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .doBeQf {
                -webkit-order: 28;
                -ms-flex-order: 28;
                order: 28;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .doBeQf {
                -webkit-order: 26;
                -ms-flex-order: 26;
                order: 26;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {}

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .bDzyZu {
                -webkit-order: 29;
                -ms-flex-order: 29;
                order: 29;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .hgcbvd {
                -webkit-order: 3;
                -ms-flex-order: 3;
                order: 3;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .hgcbvd {
                -webkit-order: 6;
                -ms-flex-order: 6;
                order: 6;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .kEkuZJ {
                -webkit-order: 5;
                -ms-flex-order: 5;
                order: 5;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .kEkuZJ {
                -webkit-order: 8;
                -ms-flex-order: 8;
                order: 8;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .hEqqlT {
                -webkit-order: 6;
                -ms-flex-order: 6;
                order: 6;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .hEqqlT {
                -webkit-order: 10;
                -ms-flex-order: 10;
                order: 10;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .eDFJpn {
                -webkit-order: 7;
                -ms-flex-order: 7;
                order: 7;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {}

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .lcBaat {
                -webkit-order: 8;
                -ms-flex-order: 8;
                order: 8;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .lcBaat {
                -webkit-order: 0;
                -ms-flex-order: 0;
                order: 0;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .CPTuX {
                -webkit-order: 10;
                -ms-flex-order: 10;
                order: 10;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {}

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .gCLDqU {
                -webkit-order: 12;
                -ms-flex-order: 12;
                order: 12;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {}

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .gHIvfR {
                -webkit-order: 13;
                -ms-flex-order: 13;
                order: 13;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {}

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .fqKcol {
                -webkit-order: 15;
                -ms-flex-order: 15;
                order: 15;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .fqKcol {
                -webkit-order: 17;
                -ms-flex-order: 17;
                order: 17;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .glVqTX {
                -webkit-order: 19;
                -ms-flex-order: 19;
                order: 19;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .glVqTX {
                -webkit-order: 21;
                -ms-flex-order: 21;
                order: 21;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .dGhjVe {
                -webkit-order: 23;
                -ms-flex-order: 23;
                order: 23;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .dGhjVe {
                -webkit-order: 25;
                -ms-flex-order: 25;
                order: 25;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .dZssbj {
                -webkit-order: 27;
                -ms-flex-order: 27;
                order: 27;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {}

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .jkAK {
                -webkit-order: 16;
                -ms-flex-order: 16;
                order: 16;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .jkAK {
                -webkit-order: 11;
                -ms-flex-order: 11;
                order: 11;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .dyxZfV {
                -webkit-order: 17;
                -ms-flex-order: 17;
                order: 17;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .dyxZfV {
                -webkit-order: 12;
                -ms-flex-order: 12;
                order: 12;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .endrEq {
                -webkit-order: 21;
                -ms-flex-order: 21;
                order: 21;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .endrEq {
                -webkit-order: 19;
                -ms-flex-order: 19;
                order: 19;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .jszGRZ {
                -webkit-order: 25;
                -ms-flex-order: 25;
                order: 25;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .jszGRZ {
                -webkit-order: 23;
                -ms-flex-order: 23;
                order: 23;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .dWAwkO {
                -webkit-order: 29;
                -ms-flex-order: 29;
                order: 29;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .dWAwkO {
                -webkit-order: 27;
                -ms-flex-order: 27;
                order: 27;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .jZrnoS {
                -webkit-order: 30;
                -ms-flex-order: 30;
                order: 30;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .jZrnoS {
                -webkit-order: 28;
                -ms-flex-order: 28;
                order: 28;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {}

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .hQCBiM {
                -webkit-order: 2;
                -ms-flex-order: 2;
                order: 2;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {}

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .bgBcvm {
                -webkit-order: 4;
                -ms-flex-order: 4;
                order: 4;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {}

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .igPCMP {
                -webkit-order: 9;
                -ms-flex-order: 9;
                order: 9;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {}

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .fnmykv {
                -webkit-order: 14;
                -ms-flex-order: 14;
                order: 14;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {}

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .grbrHJ {
                -webkit-order: 15;
                -ms-flex-order: 15;
                order: 15;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .eiTQxa {
                -webkit-order: 0;
                -ms-flex-order: 0;
                order: 0;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .eiTQxa {
                -webkit-order: 2;
                -ms-flex-order: 2;
                order: 2;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .kGPQGP {
                -webkit-order: 2;
                -ms-flex-order: 2;
                order: 2;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .kGPQGP {
                -webkit-order: 5;
                -ms-flex-order: 5;
                order: 5;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .gySvSN {
                -webkit-order: 5;
                -ms-flex-order: 5;
                order: 5;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .gySvSN {
                -webkit-order: 7;
                -ms-flex-order: 7;
                order: 7;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .eLypNc {
                -webkit-order: 9;
                -ms-flex-order: 9;
                order: 9;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .eLypNc {
                -webkit-order: 10;
                -ms-flex-order: 10;
                order: 10;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .uQFHC {
                -webkit-order: 11;
                -ms-flex-order: 11;
                order: 11;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {}

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .kdswBR {
                -webkit-order: 3;
                -ms-flex-order: 3;
                order: 3;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .kdswBR {
                -webkit-order: 3;
                -ms-flex-order: 3;
                order: 3;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .dDFqHg {
                -webkit-order: 4;
                -ms-flex-order: 4;
                order: 4;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .dDFqHg {
                -webkit-order: 4;
                -ms-flex-order: 4;
                order: 4;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .gbMdeQ {
                -webkit-order: 6;
                -ms-flex-order: 6;
                order: 6;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {}

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .ifJwQY {
                -webkit-order: 7;
                -ms-flex-order: 7;
                order: 7;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .ifJwQY {
                -webkit-order: 8;
                -ms-flex-order: 8;
                order: 8;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .gtdIFh {
                -webkit-order: 8;
                -ms-flex-order: 8;
                order: 8;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {}

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {
            .dtrjLA {
                -webkit-order: 12;
                -ms-flex-order: 12;
                order: 12;
            }
        }

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .dtrjLA {
                -webkit-order: 11;
                -ms-flex-order: 11;
                order: 11;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {}

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .dcVYod {
                -webkit-order: 0;
                -ms-flex-order: 0;
                order: 0;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {}

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .xJNvu {
                -webkit-order: 1;
                -ms-flex-order: 1;
                order: 1;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        @media (min-width: 1em) {}

        @media (min-width: 37.5em) {}

        @media (min-width: 45em) {}

        @media (min-width: 52.5em) {
            .cHdxns {
                -webkit-order: 6;
                -ms-flex-order: 6;
                order: 6;
            }
        }

        @media (min-width: 71.19em) {}

        @media (min-width: 78.69em) {}

        @media (min-width: 79.5em) {}

        /* sc-component-id: ad__h3us20-0 */
        .ikHgMx {
            box-sizing: border-box;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex: 1 0 auto;
            -ms-flex: 1 0 auto;
            flex: 1 0 auto;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
        }

        @media only screen and (min-width: 1rem) {
            .ikHgMx {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .ikHgMx {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .ikHgMx {
                margin-left: -0.75rem;
                margin-right: -0.75rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .ikHgMx {
                margin-left: -0.75rem;
                margin-right: -0.75rem;
            }
        }

        @media only screen and (min-width: 79.5rem) {
            .ikHgMx {
                margin-left: -0.75rem;
                margin-right: -0.75rem;
            }
        }

        .kUfvdA {
            box-sizing: border-box;
            -webkit-flex: 1 0 auto;
            -ms-flex: 1 0 auto;
            flex: 1 0 auto;
            max-width: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
        }

        @media only screen and (min-width: 1rem) {
            .kUfvdA {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .kUfvdA {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .kUfvdA {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .kUfvdA {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 71.19rem) {
            .kUfvdA {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 78.69rem) {
            .kUfvdA {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 79.5rem) {
            .kUfvdA {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 91.19rem) {
            .kUfvdA {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 103.69rem) {
            .kUfvdA {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 116.82rem) {
            .kUfvdA {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 1rem) {
            .kUfvdA {
                -webkit-flex: 1 1 100%;
                -ms-flex: 1 1 100%;
                flex: 1 1 100%;
                max-width: 100%;
            }
        }

        @media only screen and (min-width: 37.5rem) {}

        @media only screen and (min-width: 45rem) {
            .kUfvdA {
                -webkit-flex: 1 1 25%;
                -ms-flex: 1 1 25%;
                flex: 1 1 25%;
                max-width: 25%;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .kUfvdA {
                -webkit-flex: 1 1 25%;
                -ms-flex: 1 1 25%;
                flex: 1 1 25%;
                max-width: 25%;
            }
        }

        @media only screen and (min-width: 71.19rem) {
            .kUfvdA {
                -webkit-flex: 1 1 33.33333333333333%;
                -ms-flex: 1 1 33.33333333333333%;
                flex: 1 1 33.33333333333333%;
                max-width: 33.33333333333333%;
            }
        }

        @media only screen and (min-width: 78.69rem) {
            .kUfvdA {
                -webkit-flex: 1 1 33.33333333333333%;
                -ms-flex: 1 1 33.33333333333333%;
                flex: 1 1 33.33333333333333%;
                max-width: 33.33333333333333%;
            }
        }

        @media only screen and (min-width: 79.5rem) {
            .kUfvdA {
                -webkit-flex: 1 1 33.33333333333333%;
                -ms-flex: 1 1 33.33333333333333%;
                flex: 1 1 33.33333333333333%;
                max-width: 33.33333333333333%;
            }
        }

        @media only screen and (min-width: 91.19rem) {
            .kUfvdA {
                -webkit-flex: 1 1 33.33333333333333%;
                -ms-flex: 1 1 33.33333333333333%;
                flex: 1 1 33.33333333333333%;
                max-width: 33.33333333333333%;
            }
        }

        @media only screen and (min-width: 103.69rem) {
            .kUfvdA {
                -webkit-flex: 1 1 25%;
                -ms-flex: 1 1 25%;
                flex: 1 1 25%;
                max-width: 25%;
            }
        }

        @media only screen and (min-width: 116.82rem) {
            .kUfvdA {
                -webkit-flex: 1 1 25%;
                -ms-flex: 1 1 25%;
                flex: 1 1 25%;
                max-width: 25%;
            }
        }

        .iMxITp {
            margin-right: auto;
            margin-left: auto;
            max-width: 100%;
            box-sizing: border-box;
            box-sizing: border-box;
        }

        @media only screen and (min-width: 1rem) {
            .iMxITp {
                padding-left: 1rem;
                padding-right: 1rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .iMxITp {
                padding-left: 1rem;
                padding-right: 1rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .iMxITp {
                padding-left: 1.5rem;
                padding-right: 1.5rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .iMxITp {
                padding-left: 1.5rem;
                padding-right: 1.5rem;
            }
        }

        @media only screen and (min-width: 79.5rem) {
            .iMxITp {
                padding-left: 1.5rem;
                padding-right: 1.5rem;
            }
        }

        @media only screen and (min-width: 1rem) {
            .iMxITp {
                width: 100%;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .iMxITp {
                width: 100%;
            }
        }

        @media only screen and (min-width: 45rem) {
            .iMxITp {
                width: 100%;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .iMxITp {
                width: 79.5rem;
            }
        }

        @media only screen and (min-width: 79.5rem) {
            .iMxITp {
                width: 79.5rem;
            }
        }

        .ddnqvn {
            box-sizing: border-box;
            -webkit-flex: 1 0 auto;
            -ms-flex: 1 0 auto;
            flex: 1 0 auto;
            max-width: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
        }

        @media only screen and (min-width: 1rem) {
            .ddnqvn {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .ddnqvn {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .ddnqvn {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .ddnqvn {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 71.19rem) {
            .ddnqvn {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 78.69rem) {
            .ddnqvn {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 79.5rem) {
            .ddnqvn {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 91.19rem) {
            .ddnqvn {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 103.69rem) {
            .ddnqvn {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 116.82rem) {
            .ddnqvn {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 1rem) {}

        @media only screen and (min-width: 37.5rem) {}

        @media only screen and (min-width: 45rem) {}

        @media only screen and (min-width: 52.5rem) {}

        @media only screen and (min-width: 71.19rem) {}

        @media only screen and (min-width: 78.69rem) {}

        @media only screen and (min-width: 79.5rem) {
            .ddnqvn {
                -webkit-flex: 1 1 100%;
                -ms-flex: 1 1 100%;
                flex: 1 1 100%;
                max-width: 100%;
            }
        }

        @media only screen and (min-width: 91.19rem) {}

        @media only screen and (min-width: 103.69rem) {}

        @media only screen and (min-width: 116.82rem) {}

        .eCUDNu {
            box-sizing: border-box;
            -webkit-flex: 1 0 auto;
            -ms-flex: 1 0 auto;
            flex: 1 0 auto;
            max-width: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
        }

        @media only screen and (min-width: 1rem) {
            .eCUDNu {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .eCUDNu {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .eCUDNu {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .eCUDNu {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 71.19rem) {
            .eCUDNu {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 78.69rem) {
            .eCUDNu {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 79.5rem) {
            .eCUDNu {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 91.19rem) {
            .eCUDNu {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 103.69rem) {
            .eCUDNu {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 116.82rem) {
            .eCUDNu {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 1rem) {}

        @media only screen and (min-width: 37.5rem) {}

        @media only screen and (min-width: 45rem) {}

        @media only screen and (min-width: 52.5rem) {
            .eCUDNu {
                -webkit-flex: 1 1 66.66666666666666%;
                -ms-flex: 1 1 66.66666666666666%;
                flex: 1 1 66.66666666666666%;
                max-width: 66.66666666666666%;
            }
        }

        @media only screen and (min-width: 71.19rem) {
            .eCUDNu {
                -webkit-flex: 1 1 50%;
                -ms-flex: 1 1 50%;
                flex: 1 1 50%;
                max-width: 50%;
            }
        }

        @media only screen and (min-width: 78.69rem) {
            .eCUDNu {
                -webkit-flex: 1 1 50%;
                -ms-flex: 1 1 50%;
                flex: 1 1 50%;
                max-width: 50%;
            }
        }

        @media only screen and (min-width: 79.5rem) {
            .eCUDNu {
                -webkit-flex: 1 1 50%;
                -ms-flex: 1 1 50%;
                flex: 1 1 50%;
                max-width: 50%;
            }
        }

        @media only screen and (min-width: 91.19rem) {
            .eCUDNu {
                -webkit-flex: 1 1 58.333333333333336%;
                -ms-flex: 1 1 58.333333333333336%;
                flex: 1 1 58.333333333333336%;
                max-width: 58.333333333333336%;
            }
        }

        @media only screen and (min-width: 103.69rem) {
            .eCUDNu {
                -webkit-flex: 1 1 66.66666666666666%;
                -ms-flex: 1 1 66.66666666666666%;
                flex: 1 1 66.66666666666666%;
                max-width: 66.66666666666666%;
            }
        }

        @media only screen and (min-width: 116.82rem) {
            .eCUDNu {
                -webkit-flex: 1 1 66.66666666666666%;
                -ms-flex: 1 1 66.66666666666666%;
                flex: 1 1 66.66666666666666%;
                max-width: 66.66666666666666%;
            }
        }

        .hwQusK {
            box-sizing: border-box;
            -webkit-flex: 1 0 auto;
            -ms-flex: 1 0 auto;
            flex: 1 0 auto;
            max-width: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
        }

        @media only screen and (min-width: 1rem) {
            .hwQusK {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .hwQusK {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .hwQusK {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .hwQusK {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 71.19rem) {
            .hwQusK {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 78.69rem) {
            .hwQusK {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 79.5rem) {
            .hwQusK {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 91.19rem) {
            .hwQusK {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 103.69rem) {
            .hwQusK {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 116.82rem) {
            .hwQusK {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 1rem) {}

        @media only screen and (min-width: 37.5rem) {}

        @media only screen and (min-width: 45rem) {}

        @media only screen and (min-width: 52.5rem) {
            .hwQusK {
                -webkit-flex: 1 1 33.33333333333333%;
                -ms-flex: 1 1 33.33333333333333%;
                flex: 1 1 33.33333333333333%;
                max-width: 33.33333333333333%;
            }
        }

        @media only screen and (min-width: 71.19rem) {
            .hwQusK {
                -webkit-flex: 1 1 33.33333333333333%;
                -ms-flex: 1 1 33.33333333333333%;
                flex: 1 1 33.33333333333333%;
                max-width: 33.33333333333333%;
            }
        }

        @media only screen and (min-width: 78.69rem) {
            .hwQusK {
                -webkit-flex: 1 1 25%;
                -ms-flex: 1 1 25%;
                flex: 1 1 25%;
                max-width: 25%;
            }
        }

        @media only screen and (min-width: 79.5rem) {
            .hwQusK {
                -webkit-flex: 1 1 25%;
                -ms-flex: 1 1 25%;
                flex: 1 1 25%;
                max-width: 25%;
            }
        }

        @media only screen and (min-width: 91.19rem) {
            .hwQusK {
                -webkit-flex: 1 1 25%;
                -ms-flex: 1 1 25%;
                flex: 1 1 25%;
                max-width: 25%;
            }
        }

        @media only screen and (min-width: 103.69rem) {
            .hwQusK {
                -webkit-flex: 1 1 25%;
                -ms-flex: 1 1 25%;
                flex: 1 1 25%;
                max-width: 25%;
            }
        }

        @media only screen and (min-width: 116.82rem) {
            .hwQusK {
                -webkit-flex: 1 1 25%;
                -ms-flex: 1 1 25%;
                flex: 1 1 25%;
                max-width: 25%;
            }
        }

        .fCVywn {
            box-sizing: border-box;
            -webkit-flex: 1 0 auto;
            -ms-flex: 1 0 auto;
            flex: 1 0 auto;
            max-width: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
        }

        @media only screen and (min-width: 1rem) {
            .fCVywn {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 37.5rem) {
            .fCVywn {
                padding-right: 0.5rem;
                padding-left: 0.5rem;
            }
        }

        @media only screen and (min-width: 45rem) {
            .fCVywn {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 52.5rem) {
            .fCVywn {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 71.19rem) {
            .fCVywn {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 78.69rem) {
            .fCVywn {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 79.5rem) {
            .fCVywn {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 91.19rem) {
            .fCVywn {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 103.69rem) {
            .fCVywn {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 116.82rem) {
            .fCVywn {
                padding-right: 0.75rem;
                padding-left: 0.75rem;
            }
        }

        @media only screen and (min-width: 1rem) {}

        @media only screen and (min-width: 37.5rem) {}

        @media only screen and (min-width: 45rem) {}

        @media only screen and (min-width: 52.5rem) {}

        @media only screen and (min-width: 71.19rem) {
            .fCVywn {
                -webkit-flex: 1 1 16.666666666666664%;
                -ms-flex: 1 1 16.666666666666664%;
                flex: 1 1 16.666666666666664%;
                max-width: 16.666666666666664%;
            }
        }

        @media only screen and (min-width: 78.69rem) {
            .fCVywn {
                -webkit-flex: 1 1 25%;
                -ms-flex: 1 1 25%;
                flex: 1 1 25%;
                max-width: 25%;
            }
        }

        @media only screen and (min-width: 79.5rem) {
            .fCVywn {
                -webkit-flex: 1 1 25%;
                -ms-flex: 1 1 25%;
                flex: 1 1 25%;
                max-width: 25%;
            }
        }

        @media only screen and (min-width: 91.19rem) {
            .fCVywn {
                -webkit-flex: 1 1 16.666666666666664%;
                -ms-flex: 1 1 16.666666666666664%;
                flex: 1 1 16.666666666666664%;
                max-width: 16.666666666666664%;
            }
        }

        @media only screen and (min-width: 103.69rem) {
            .fCVywn {
                -webkit-flex: 1 1 8.333333333333332%;
                -ms-flex: 1 1 8.333333333333332%;
                flex: 1 1 8.333333333333332%;
                max-width: 8.333333333333332%;
            }
        }

        @media only screen and (min-width: 116.82rem) {
            .fCVywn {
                -webkit-flex: 1 1 8.333333333333332%;
                -ms-flex: 1 1 8.333333333333332%;
                flex: 1 1 8.333333333333332%;
                max-width: 8.333333333333332%;
            }
        }

        /* sc-component-id: ad__sc-1o2mpyl-0 */
        .dQQnbA {
            background-color: rgb(229, 229, 229);
            height: 1px;
        }

        @media (min-width: 52.5em) {
            .dQQnbA {
                width: 88px;
            }
        }

        /* sc-component-id: sc-EHOje */
        .espebs {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            width: 'fit-content';
            cursor: pointer;
            outline: none;
            -webkit-text-decoration: none;
            text-decoration: none;
            font-size: var(--font-size-xxs);
            line-height: var(--font-lineheight-distant);
            color: var(--link-color-main-base);
            margin-left: var(--spacing-inline-nano);
            font-family: var(--font-family);
            font-weight: var(--font-weight-semibold);
        }

        .espebs:hover {
            color: var(--link-color-main-hover);
        }

        .espebs:hover {
            -webkit-text-decoration-line: underline;
            text-decoration-line: underline;
        }

        .espebs:focus {
            box-shadow: 0 0 0 2px var(--color-secondary-80);
            border-radius: var(--border-radius-xxs);
        }

        .fVwWyK {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            width: 'fit-content';
            cursor: pointer;
            outline: none;
            -webkit-text-decoration: none;
            text-decoration: none;
            font-size: var(--font-size-xxxs);
            line-height: var(--font-lineheight-medium);
            color: var(--link-color-main-base);
            font-family: var(--font-family);
            font-weight: var(--font-weight-semibold);
        }

        .fVwWyK:hover {
            color: var(--link-color-main-hover);
        }

        .fVwWyK:hover {
            -webkit-text-decoration-line: underline;
            text-decoration-line: underline;
        }

        .fVwWyK:focus {
            box-shadow: 0 0 0 2px var(--color-secondary-80);
            border-radius: var(--border-radius-xxs);
        }

        .evIBiW {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            width: 'fit-content';
            cursor: pointer;
            outline: none;
            -webkit-text-decoration: none;
            text-decoration: none;
            font-size: var(--font-size-xxs);
            line-height: var(--font-lineheight-distant);
            color: var(--link-color-main-base);
            font-family: var(--font-family);
            font-weight: var(--font-weight-semibold);
        }

        .evIBiW:hover {
            color: var(--link-color-main-hover);
        }

        .evIBiW:hover {
            -webkit-text-decoration-line: underline;
            text-decoration-line: underline;
        }

        .evIBiW:focus {
            box-shadow: 0 0 0 2px var(--color-secondary-80);
            border-radius: var(--border-radius-xxs);
        }

        .cBRYOz {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            width: 'fit-content';
            cursor: pointer;
            outline: none;
            -webkit-text-decoration: none;
            text-decoration: none;
            font-size: var(--font-size-xxs);
            line-height: var(--font-lineheight-distant);
            color: var(--link-color-grey-base);
            font-family: var(--font-family);
            font-weight: var(--font-weight-semibold);
        }

        .cBRYOz:hover {
            color: var(--link-color-grey-hover);
        }

        .cBRYOz:hover {
            -webkit-text-decoration-line: underline;
            text-decoration-line: underline;
        }

        .cBRYOz:focus {
            box-shadow: 0 0 0 2px var(--color-secondary-80);
            border-radius: var(--border-radius-xxs);
        }

        .lePqYm {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            width: 'fit-content';
            cursor: pointer;
            outline: none;
            -webkit-text-decoration: none;
            text-decoration: none;
            font-size: var(--font-size-xs);
            line-height: var(--font-lineheight-superdistant);
            color: var(--link-color-main-base);
            font-family: var(--font-family);
            font-weight: var(--font-weight-semibold);
        }

        .lePqYm:hover {
            color: var(--link-color-main-hover);
        }

        .lePqYm:hover {
            -webkit-text-decoration-line: underline;
            text-decoration-line: underline;
        }

        .lePqYm:focus {
            box-shadow: 0 0 0 2px var(--color-secondary-80);
            border-radius: var(--border-radius-xxs);
        }

        .jNyXWf {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            width: 'fit-content';
            cursor: pointer;
            outline: none;
            -webkit-text-decoration: none;
            text-decoration: none;
            font-size: var(--font-size-xxxs);
            line-height: var(--font-lineheight-medium);
            color: var(--link-color-grey-base);
            font-family: var(--font-family);
            font-weight: var(--font-weight-semibold);
        }

        .jNyXWf:hover {
            color: var(--link-color-grey-hover);
        }

        .jNyXWf:hover {
            -webkit-text-decoration-line: underline;
            text-decoration-line: underline;
        }

        .jNyXWf:focus {
            box-shadow: 0 0 0 2px var(--color-secondary-80);
            border-radius: var(--border-radius-xxs);
        }

        .jpHdQl {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            width: 'fit-content';
            cursor: pointer;
            outline: none;
            -webkit-text-decoration: none;
            text-decoration: none;
            font-size: var(--font-size-xs);
            line-height: var(--font-lineheight-superdistant);
            color: var(--link-color-main-base);
            margin-top: var(--spacing-0-5);
            font-family: var(--font-family);
            font-weight: var(--font-weight-semibold);
        }

        .jpHdQl:hover {
            color: var(--link-color-main-hover);
        }

        .jpHdQl:hover {
            -webkit-text-decoration-line: underline;
            text-decoration-line: underline;
        }

        .jpHdQl:focus {
            box-shadow: 0 0 0 2px var(--color-secondary-80);
            border-radius: var(--border-radius-xxs);
        }

        /* sc-component-id: sc-htoDjs */
        .hYiizr {
            width: 24px;
            height: 24px;
            margin-right: var(--spacing-1);
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            pointer-events: none;
        }

        .hYiizr svg {
            fill: currentColor;
            width: 100%;
            height: 100%;
            pointer-events: none;
        }

        /* sc-component-id: sc-iwsKbI */
        .hMjsjM {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            visibility: visible;
        }

        /* sc-component-id: sc-gZMcBi */
        .iCyRCL {
            position: relative;
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            min-width: 72px;
            width: -webkit-fit-content;
            width: -moz-fit-content;
            width: fit-content;
            border-style: solid;
            border-width: var(--border-width-hairline);
            outline: none;
            -webkit-text-decoration: initial;
            text-decoration: initial;
            height: 40px;
            padding: var(--spacing-1) var(--spacing-3);
            font-size: var(--font-size-xs);
            line-height: var(--font-lineheight-superdistant);
            background-color: var(--button-primary-background-color-base);
            border-color: var(--button-primary-border-color-base);
            color: var(--button-primary-color-font-base);
            border-radius: var(--border-radius-pill);
            font-family: var(--font-family);
            font-weight: var(--font-weight-semibold);
            cursor: pointer;
            -webkit-tap-highlight-color: transparent;
        }

        .iCyRCL:hover {
            background-color: var(--button-primary-background-color-hover);
            border-color: var(--button-primary-border-color-hover);
        }

        .iCyRCL:focus {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            outline: var(--color-neutral-130) solid var(--border-width-thin);
            outline-offset: var(--border-width-thin);
        }

        .iCyRCL:focus:not(:focus-visible) {
            outline: none;
            outline-offset: 0;
        }

        .iCyRCL:active {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            border-color: transparent;
        }

        .iCyRCL.disabled {
            background-color: var(--button-primary-background-color-disabled);
            border-color: var(--button-primary-border-color-disabled);
            color: var(--button-primary-color-font-disabled);
        }

        .iCyRCL:active {
            -webkit-transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            -webkit-transform: scale(0.96);
            -ms-transform: scale(0.96);
            transform: scale(0.96);
        }

        .iCyRCL:not(:active) {
            -webkit-transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .iCyRCL:hover {
            -webkit-transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .iCyRCL:not(:hover) {
            -webkit-transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .iCyRCL.disabled {
            cursor: not-allowed;
        }

        .fXudwZ {
            position: relative;
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            min-width: 72px;
            width: -webkit-fit-content;
            width: -moz-fit-content;
            width: fit-content;
            border-style: solid;
            border-width: var(--border-width-hairline);
            outline: none;
            -webkit-text-decoration: initial;
            text-decoration: initial;
            height: 40px;
            padding: var(--spacing-1) var(--spacing-3);
            font-size: var(--font-size-xs);
            line-height: var(--font-lineheight-superdistant);
            background-color: var(--button-secondary-background-color-base);
            border-color: var(--button-secondary-border-color-base);
            color: var(--button-secondary-color-font-base);
            border-radius: var(--border-radius-pill);
            font-family: var(--font-family);
            font-weight: var(--font-weight-semibold);
            cursor: pointer;
            -webkit-tap-highlight-color: transparent;
        }

        .fXudwZ:hover {
            background-color: var(--button-secondary-background-color-hover);
            border-color: var(--button-secondary-border-color-hover);
        }

        .fXudwZ:focus {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            outline: var(--color-neutral-130) solid var(--border-width-thin);
            outline-offset: var(--border-width-thin);
        }

        .fXudwZ:focus:not(:focus-visible) {
            outline: none;
            outline-offset: 0;
        }

        .fXudwZ:active {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            border-color: transparent;
        }

        .fXudwZ.disabled {
            background-color: var(--button-secondary-background-color-disabled);
            border-color: var(--button-secondary-border-color-disabled);
            color: var(--button-secondary-color-font-disabled);
        }

        .fXudwZ:active {
            -webkit-transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            -webkit-transform: scale(0.96);
            -ms-transform: scale(0.96);
            transform: scale(0.96);
        }

        .fXudwZ:not(:active) {
            -webkit-transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .fXudwZ:hover {
            -webkit-transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .fXudwZ:not(:hover) {
            -webkit-transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .fXudwZ.disabled {
            cursor: not-allowed;
        }

        .dhMNpJ {
            position: relative;
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            min-width: 72px;
            width: -webkit-fit-content;
            width: -moz-fit-content;
            width: fit-content;
            border-style: solid;
            border-width: var(--border-width-hairline);
            outline: none;
            -webkit-text-decoration: initial;
            text-decoration: initial;
            height: 40px;
            padding: var(--spacing-1) var(--spacing-3);
            font-size: var(--font-size-xs);
            line-height: var(--font-lineheight-superdistant);
            background-color: var(--button-secondary-background-color-base);
            border-color: var(--button-secondary-border-color-base);
            color: var(--button-secondary-color-font-base);
            margin-right: var(--spacing-inline-xxxs);
            border-radius: var(--border-radius-pill);
            font-family: var(--font-family);
            font-weight: var(--font-weight-semibold);
            cursor: pointer;
            -webkit-tap-highlight-color: transparent;
        }

        .dhMNpJ:hover {
            background-color: var(--button-secondary-background-color-hover);
            border-color: var(--button-secondary-border-color-hover);
        }

        .dhMNpJ:focus {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            outline: var(--color-neutral-130) solid var(--border-width-thin);
            outline-offset: var(--border-width-thin);
        }

        .dhMNpJ:focus:not(:focus-visible) {
            outline: none;
            outline-offset: 0;
        }

        .dhMNpJ:active {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            border-color: transparent;
        }

        .dhMNpJ.disabled {
            background-color: var(--button-secondary-background-color-disabled);
            border-color: var(--button-secondary-border-color-disabled);
            color: var(--button-secondary-color-font-disabled);
        }

        .dhMNpJ:active {
            -webkit-transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            -webkit-transform: scale(0.96);
            -ms-transform: scale(0.96);
            transform: scale(0.96);
        }

        .dhMNpJ:not(:active) {
            -webkit-transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .dhMNpJ:hover {
            -webkit-transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .dhMNpJ:not(:hover) {
            -webkit-transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .dhMNpJ.disabled {
            cursor: not-allowed;
        }

        .giLqBp {
            position: relative;
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            min-width: 72px;
            width: -webkit-fit-content;
            width: -moz-fit-content;
            width: fit-content;
            border-style: solid;
            border-width: var(--border-width-hairline);
            outline: none;
            -webkit-text-decoration: initial;
            text-decoration: initial;
            height: 40px;
            padding: var(--spacing-1) var(--spacing-3);
            font-size: var(--font-size-xs);
            line-height: var(--font-lineheight-superdistant);
            background-color: var(--button-link-button-background-color-base);
            border-color: var(--button-link-button-border-color-base);
            color: var(--button-link-button-color-font-base);
            border-radius: var(--border-radius-pill);
            font-family: var(--font-family);
            font-weight: var(--font-weight-semibold);
            cursor: pointer;
            -webkit-tap-highlight-color: transparent;
        }

        .giLqBp:hover {
            background-color: var(--button-link-button-background-color-hover);
            border-color: var(--button-link-button-border-color-hover);
        }

        .giLqBp:focus {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            outline: var(--color-neutral-130) solid var(--border-width-thin);
            outline-offset: var(--border-width-thin);
        }

        .giLqBp:focus:not(:focus-visible) {
            outline: none;
            outline-offset: 0;
        }

        .giLqBp:active {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            border-color: transparent;
        }

        .giLqBp.disabled {
            background-color: var(--button-link-button-background-color-disabled);
            border-color: var(--button-link-button-border-color-disabled);
            color: var(--button-link-button-color-font-disabled);
        }

        .giLqBp:active {
            -webkit-transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            -webkit-transform: scale(0.96);
            -ms-transform: scale(0.96);
            transform: scale(0.96);
        }

        .giLqBp:not(:active) {
            -webkit-transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .giLqBp:hover {
            -webkit-transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .giLqBp:not(:hover) {
            -webkit-transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .giLqBp.disabled {
            cursor: not-allowed;
        }

        .ehxqTE {
            position: relative;
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            min-width: 72px;
            width: -webkit-fit-content;
            width: -moz-fit-content;
            width: fit-content;
            border-style: solid;
            border-width: var(--border-width-hairline);
            outline: none;
            -webkit-text-decoration: none;
            text-decoration: none;
            height: 40px;
            padding: var(--spacing-1) var(--spacing-3);
            font-size: var(--font-size-xs);
            line-height: var(--font-lineheight-superdistant);
            background-color: var(--button-primary-background-color-base);
            border-color: var(--button-primary-border-color-base);
            color: var(--button-primary-color-font-base);
            border-radius: var(--border-radius-pill);
            font-family: var(--font-family);
            font-weight: var(--font-weight-semibold);
            cursor: pointer;
            -webkit-tap-highlight-color: transparent;
        }

        .ehxqTE:hover {
            background-color: var(--button-primary-background-color-hover);
            border-color: var(--button-primary-border-color-hover);
        }

        .ehxqTE:focus {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            outline: var(--color-neutral-130) solid var(--border-width-thin);
            outline-offset: var(--border-width-thin);
        }

        .ehxqTE:focus:not(:focus-visible) {
            outline: none;
            outline-offset: 0;
        }

        .ehxqTE:active {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            border-color: transparent;
        }

        .ehxqTE.disabled {
            background-color: var(--button-primary-background-color-disabled);
            border-color: var(--button-primary-border-color-disabled);
            color: var(--button-primary-color-font-disabled);
        }

        .ehxqTE:active {
            -webkit-transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            -webkit-transform: scale(0.96);
            -ms-transform: scale(0.96);
            transform: scale(0.96);
        }

        .ehxqTE:not(:active) {
            -webkit-transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .ehxqTE:hover {
            -webkit-transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .ehxqTE:not(:hover) {
            -webkit-transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .ehxqTE.disabled {
            cursor: not-allowed;
        }

        .ifyuHm {
            position: relative;
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            min-width: 72px;
            width: -webkit-fit-content;
            width: -moz-fit-content;
            width: fit-content;
            border-style: solid;
            border-width: var(--border-width-hairline);
            outline: none;
            -webkit-text-decoration: initial;
            text-decoration: initial;
            height: 32px;
            padding: var(--spacing-1) var(--spacing-2);
            font-size: var(--font-size-xxs);
            line-height: var(--font-lineheight-tight);
            background-color: var(--button-link-button-background-color-base);
            border-color: var(--button-link-button-border-color-base);
            color: var(--button-link-button-color-font-base);
            margin-top: var(--spacing-1);
            border-radius: var(--border-radius-pill);
            font-family: var(--font-family);
            font-weight: var(--font-weight-semibold);
            cursor: pointer;
            -webkit-tap-highlight-color: transparent;
        }

        .ifyuHm:hover {
            background-color: var(--button-link-button-background-color-hover);
            border-color: var(--button-link-button-border-color-hover);
        }

        .ifyuHm:focus {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            outline: var(--color-neutral-130) solid var(--border-width-thin);
            outline-offset: var(--border-width-thin);
        }

        .ifyuHm:focus:not(:focus-visible) {
            outline: none;
            outline-offset: 0;
        }

        .ifyuHm:active {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            border-color: transparent;
        }

        .ifyuHm.disabled {
            background-color: var(--button-link-button-background-color-disabled);
            border-color: var(--button-link-button-border-color-disabled);
            color: var(--button-link-button-color-font-disabled);
        }

        .ifyuHm:active {
            -webkit-transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            -webkit-transform: scale(0.96);
            -ms-transform: scale(0.96);
            transform: scale(0.96);
        }

        .ifyuHm:not(:active) {
            -webkit-transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .ifyuHm:hover {
            -webkit-transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .ifyuHm:not(:hover) {
            -webkit-transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .ifyuHm.disabled {
            cursor: not-allowed;
        }

        .jgIBXR {
            position: relative;
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            min-width: 72px;
            width: -webkit-fit-content;
            width: -moz-fit-content;
            width: fit-content;
            border-style: solid;
            border-width: var(--border-width-hairline);
            outline: none;
            -webkit-text-decoration: none;
            text-decoration: none;
            height: 40px;
            padding: var(--spacing-1) var(--spacing-3);
            font-size: var(--font-size-xs);
            line-height: var(--font-lineheight-superdistant);
            background-color: var(--button-secondary-background-color-base);
            border-color: var(--button-secondary-border-color-base);
            color: var(--button-secondary-color-font-base);
            border-radius: var(--border-radius-pill);
            font-family: var(--font-family);
            font-weight: var(--font-weight-semibold);
            cursor: pointer;
            -webkit-tap-highlight-color: transparent;
        }

        .jgIBXR:hover {
            background-color: var(--button-secondary-background-color-hover);
            border-color: var(--button-secondary-border-color-hover);
        }

        .jgIBXR:focus {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            outline: var(--color-neutral-130) solid var(--border-width-thin);
            outline-offset: var(--border-width-thin);
        }

        .jgIBXR:focus:not(:focus-visible) {
            outline: none;
            outline-offset: 0;
        }

        .jgIBXR:active {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            border-color: transparent;
        }

        .jgIBXR.disabled {
            background-color: var(--button-secondary-background-color-disabled);
            border-color: var(--button-secondary-border-color-disabled);
            color: var(--button-secondary-color-font-disabled);
        }

        .jgIBXR:active {
            -webkit-transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            -webkit-transform: scale(0.96);
            -ms-transform: scale(0.96);
            transform: scale(0.96);
        }

        .jgIBXR:not(:active) {
            -webkit-transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .jgIBXR:hover {
            -webkit-transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .jgIBXR:not(:hover) {
            -webkit-transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .jgIBXR.disabled {
            cursor: not-allowed;
        }

        .cmUnWG {
            position: relative;
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            min-width: 72px;
            width: -webkit-fit-content;
            width: -moz-fit-content;
            width: fit-content;
            border-style: solid;
            border-width: var(--border-width-hairline);
            outline: none;
            -webkit-text-decoration: initial;
            text-decoration: initial;
            height: 32px;
            padding: var(--spacing-1) var(--spacing-2);
            font-size: var(--font-size-xxs);
            line-height: var(--font-lineheight-tight);
            background-color: var(--button-link-button-background-color-base);
            border-color: var(--button-link-button-border-color-base);
            color: var(--button-link-button-color-font-base);
            border-radius: var(--border-radius-pill);
            font-family: var(--font-family);
            font-weight: var(--font-weight-semibold);
            cursor: pointer;
            -webkit-tap-highlight-color: transparent;
        }

        .cmUnWG:hover {
            background-color: var(--button-link-button-background-color-hover);
            border-color: var(--button-link-button-border-color-hover);
        }

        .cmUnWG:focus {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            outline: var(--color-neutral-130) solid var(--border-width-thin);
            outline-offset: var(--border-width-thin);
        }

        .cmUnWG:focus:not(:focus-visible) {
            outline: none;
            outline-offset: 0;
        }

        .cmUnWG:active {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            border-color: transparent;
        }

        .cmUnWG.disabled {
            background-color: var(--button-link-button-background-color-disabled);
            border-color: var(--button-link-button-border-color-disabled);
            color: var(--button-link-button-color-font-disabled);
        }

        .cmUnWG:active {
            -webkit-transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            -webkit-transform: scale(0.96);
            -ms-transform: scale(0.96);
            transform: scale(0.96);
        }

        .cmUnWG:not(:active) {
            -webkit-transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .cmUnWG:hover {
            -webkit-transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .cmUnWG:not(:hover) {
            -webkit-transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .cmUnWG.disabled {
            cursor: not-allowed;
        }

        .bSRIeR {
            position: relative;
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            min-width: 72px;
            width: -webkit-fit-content;
            width: -moz-fit-content;
            width: fit-content;
            border-style: solid;
            border-width: var(--border-width-hairline);
            outline: none;
            -webkit-text-decoration: initial;
            text-decoration: initial;
            height: 40px;
            padding: var(--spacing-1) var(--spacing-3);
            font-size: var(--font-size-xs);
            line-height: var(--font-lineheight-superdistant);
            background-color: var(--button-link-button-background-color-base);
            border-color: var(--button-link-button-border-color-base);
            color: var(--button-link-button-color-font-base);
            margin-left: var(--spacing-0-5);
            border-radius: var(--border-radius-pill);
            font-family: var(--font-family);
            font-weight: var(--font-weight-semibold);
            cursor: pointer;
            -webkit-tap-highlight-color: transparent;
        }

        .bSRIeR:hover {
            background-color: var(--button-link-button-background-color-hover);
            border-color: var(--button-link-button-border-color-hover);
        }

        .bSRIeR:focus {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            outline: var(--color-neutral-130) solid var(--border-width-thin);
            outline-offset: var(--border-width-thin);
        }

        .bSRIeR:focus:not(:focus-visible) {
            outline: none;
            outline-offset: 0;
        }

        .bSRIeR:active {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            border-color: transparent;
        }

        .bSRIeR.disabled {
            background-color: var(--button-link-button-background-color-disabled);
            border-color: var(--button-link-button-border-color-disabled);
            color: var(--button-link-button-color-font-disabled);
        }

        .bSRIeR:active {
            -webkit-transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            -webkit-transform: scale(0.96);
            -ms-transform: scale(0.96);
            transform: scale(0.96);
        }

        .bSRIeR:not(:active) {
            -webkit-transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .bSRIeR:hover {
            -webkit-transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .bSRIeR:not(:hover) {
            -webkit-transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }

        .bSRIeR.disabled {
            cursor: not-allowed;
        }

        /* sc-component-id: sc-gqjmRU */
        .jGLnOs {
            min-width: 12px;
            min-height: 12px;
            width: 100%;
        }

        .jGLnOs path.o {
            fill: var(--color-secondary-100);
        }

        .jGLnOs path.l {
            fill: var(--color-feedback-success-90);
        }

        .jGLnOs path.x {
            fill: var(--color-primary-100);
        }

        .jGLnOs.white path,
        .jGLnOs.white-o path.o,
        .jGLnOs.white-l path.l,
        .jGLnOs.white-x path.x {
            fill: var(--color-neutral-70);
        }

        .jGLnOs.black path {
            fill: var(--color-neutral-130);
        }

        /* sc-component-id: sc-VigVT */
        .cueDsN {
            -webkit-clip: rect(1px, 1px, 1px, 1px);
            clip: rect(1px, 1px, 1px, 1px);
            height: 1px;
            overflow: hidden;
            position: absolute;
            white-space: nowrap;
            width: 1px;
        }

        .cueDsN:focus {
            -webkit-clip: auto;
            clip: auto;
            height: auto;
            overflow: auto;
            position: absolute;
            width: auto;
        }

        /* sc-component-id: sc-jTzLTM */
        .hEqzYu {
            -webkit-animation-name: skeleton-loading;
            animation-name: skeleton-loading;
            -webkit-animation-duration: var(--transition-duration-5);
            animation-duration: var(--transition-duration-5);
            -webkit-animation-iteration-count: infinite;
            animation-iteration-count: infinite;
            -webkit-animation-timing-function: var(--transition-timing-ease);
            animation-timing-function: var(--transition-timing-ease);
            width: 135px;
            height: 40px;
        }

        @-webkit-keyframes skeleton-loading {
            0% {
                background: linear-gradient(90deg, #ffffff 0%, #ffffff 50.52%, #e3e3e3 100%);
            }

            25% {
                background: linear-gradient(90deg, #ffffff 0%, #e3e3e3 68.23%, #ffffff 100%);
            }

            50% {
                background: linear-gradient(90deg, #ffffff 0%, #e3e3e3 52.6%, #ffffff 100%);
            }

            75% {
                background: linear-gradient(90deg, #ffffff 5.21%, #e3e3e3 28.65%, #ffffff 100%);
            }

            100% {
                background: linear-gradient(90deg, #e3e3e3 0%, #ffffff 22.92%, #ffffff 100%);
            }
        }

        @keyframes skeleton-loading {
            0% {
                background: linear-gradient(90deg, #ffffff 0%, #ffffff 50.52%, #e3e3e3 100%);
            }

            25% {
                background: linear-gradient(90deg, #ffffff 0%, #e3e3e3 68.23%, #ffffff 100%);
            }

            50% {
                background: linear-gradient(90deg, #ffffff 0%, #e3e3e3 52.6%, #ffffff 100%);
            }

            75% {
                background: linear-gradient(90deg, #ffffff 5.21%, #e3e3e3 28.65%, #ffffff 100%);
            }

            100% {
                background: linear-gradient(90deg, #e3e3e3 0%, #ffffff 22.92%, #ffffff 100%);
            }
        }

        /* sc-component-id: sc-fjdhpX */
        .eLXScg .skip-link {
            -webkit-clip: rect(1px, 1px, 1px, 1px);
            clip: rect(1px, 1px, 1px, 1px);
            height: 1px;
            overflow: hidden;
            position: absolute;
            white-space: nowrap;
            width: 1px;
        }

        .eLXScg .skip-link:focus {
            -webkit-clip: initial;
            clip: initial;
            height: 50px;
            overflow: initial;
            white-space: initial;
            width: 60px;
            color: var(--color-neutral-130);
            background-color: var(--color-neutral-70);
            display: inline-block;
            z-index: 2;
            top: 50%;
            -webkit-transform: translateY(-50%);
            -ms-transform: translateY(-50%);
            transform: translateY(-50%);
            left: 0;
        }

        .eLXScg.inverted a {
            background: var(--color-secondary-100);
            color: var(--color-neutral-70);
        }

        /* sc-component-id: sc-jzJRlG */
        .iQExKI {
            background-color: transparent;
            border: none;
            cursor: pointer;
            width: 48px;
            height: 48px;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            margin: 0;
            padding: 0;
            outline: none;
            color: var(--color-neutral-130);
        }

        .iQExKI:hover {
            color: var(--link-color-main-hover);
        }

        .iQExKI:focus {
            box-shadow: 0 0 0 2px var(--color-secondary-80);
            border-radius: var(--border-radius-xxs);
        }

        /* sc-component-id: sc-kAzzGY */
        .hFDmrz {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-column-gap: var(--spacing-1);
            column-gap: var(--spacing-1);
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            font-size: var(--font-size-xxxs);
            padding: var(--spacing-0-5) var(--spacing-1);
            border-radius: var(--border-radius-xs);
            font-family: var(--font-family);
            background: var(--color-neutral-70);
            color: var(--color-neutral-130);
            font-weight: 600;
        }

        .hFDmrz.success {
            background: var(--color-feedback-success-80);
            color: var(--color-feedback-success-120);
        }

        .hFDmrz.info {
            background: var(--color-feedback-info-80);
            color: var(--color-feedback-info-110);
        }

        .hFDmrz.warning {
            background: var(--color-feedback-attention-80);
            color: var(--color-feedback-attention-110);
        }

        .hFDmrz.secondary {
            background: var(--color-secondary-70);
            color: var(--color-secondary-100);
        }

        .hFDmrz.error {
            background: var(--color-feedback-error-80);
            color: var(--color-feedback-error-110);
        }

        .hFDmrz svg {
            max-width: 16px;
            max-height: 16px;
        }

        /* sc-component-id: sc-hSdWYo */
        .dDGSHH {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-semibold);
            line-height: var(--font-lineheight-medium);
            font-size: var(--font-size-lg);
            color: var(--color-neutral-130);
        }

        @media screen and (min-width: 600px) {
            .dDGSHH {
                font-size: var(--font-size-xxl);
            }
        }

        .gcOoiX {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-semibold);
            line-height: var(--font-lineheight-distant);
            font-size: var(--font-size-xxs);
            font-style: normal;
            color: var(--color-neutral-130);
        }

        .ePoDpk {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-regular);
            line-height: var(--font-lineheight-distant);
            font-size: var(--font-size-xxs);
            font-style: normal;
            color: var(--color-neutral-120);
        }

        .bYQcLm {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-semibold);
            line-height: var(--font-lineheight-medium);
            font-size: var(--font-size-md);
            color: var(--color-neutral-130);
        }

        @media screen and (min-width: 600px) {
            .bYQcLm {
                font-size: var(--font-size-lg);
            }
        }

        .davdrV {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-bold);
            line-height: var(--font-lineheight-medium);
            font-size: var(--font-size-sm);
            color: var(--color-neutral-130);
        }

        @media screen and (min-width: 600px) {
            .davdrV {
                font-size: var(--font-size-md);
            }
        }

        .htqcWR {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-regular);
            line-height: var(--font-lineheight-superdistant);
            font-size: var(--font-size-xs);
            font-style: normal;
            color: var(--color-neutral-130);
        }

        .eRxGni {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-bold);
            line-height: var(--font-lineheight-medium);
            font-size: var(--font-size-sm);
            color: var(--color-neutral-130);
            margin-bottom: var(--spacing-2);
        }

        @media screen and (min-width: 600px) {
            .eRxGni {
                font-size: var(--font-size-md);
            }
        }

        .gwYTWo {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-semibold);
            line-height: var(--font-lineheight-superdistant);
            font-size: var(--font-size-xs);
            font-style: normal;
            color: var(--color-neutral-130);
        }

        .jFeRvR {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-regular);
            line-height: var(--font-lineheight-medium);
            font-size: var(--font-size-xxxs);
            color: var(--color-neutral-120);
        }

        .fEpeIU {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-semibold);
            line-height: var(--font-lineheight-medium);
            font-size: var(--font-size-xxxs);
            color: var(--color-neutral-light);
        }

        .grMlBs {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-semibold);
            line-height: var(--font-lineheight-medium);
            font-size: var(--font-size-md);
            color: var(--color-neutral-lightest);
        }

        @media screen and (min-width: 600px) {
            .grMlBs {
                font-size: var(--font-size-lg);
            }
        }

        .bJrUdE {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-semibold);
            line-height: var(--font-lineheight-medium);
            font-size: var(--font-size-xxxs);
            color: var(--color-neutral-lightest);
        }

        .dTeYkN {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-bold);
            line-height: var(--font-lineheight-superdistant);
            font-size: var(--font-size-sm);
            font-style: normal;
            color: var(--color-neutral-130);
        }

        .bducQJ {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-regular);
            line-height: var(--font-lineheight-superdistant);
            font-size: var(--font-size-xs);
            font-style: normal;
            color: var(--color-neutral-130);
            margin-bottom: var(--spacing-stack-quarck);
        }

        .dVkImY {
            display: inline;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-bold);
            line-height: var(--font-lineheight-superdistant);
            font-size: var(--font-size-xs);
            font-style: normal;
            color: var(--color-neutral-130);
        }

        .bSkWab {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-bold);
            line-height: var(--font-lineheight-superdistant);
            font-size: var(--font-size-xs);
            font-style: normal;
            color: var(--color-neutral-130);
        }

        .iDAOTJ {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-regular);
            line-height: var(--font-lineheight-medium);
            font-size: var(--font-size-sm);
            color: var(--color-neutral-130);
            margin-bottom: var(--spacing-stack-xxs);
        }

        @media screen and (min-width: 600px) {
            .iDAOTJ {
                font-size: var(--font-size-md);
            }
        }

        .iCBjkC {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-regular);
            line-height: var(--font-lineheight-distant);
            font-size: var(--font-size-xxs);
            font-style: normal;
            color: var(--color-neutral-130);
            margin-top: var(--spacing-stack-xxxs);
            margin-bottom: var(--spacing-stack-xs);
        }

        .cPXplw {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-regular);
            line-height: var(--font-lineheight-medium);
            font-size: var(--font-size-xxxs);
            color: var(--color-neutral-70);
        }

        .SaNrZ {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-regular);
            line-height: var(--font-lineheight-superdistant);
            font-size: var(--font-size-sm);
            font-style: normal;
            color: var(--color-neutral-130);
        }

        .hrBUeY {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-light);
            line-height: var(--font-lineheight-superdistant);
            font-size: var(--font-size-xs);
            font-style: normal;
            color: var(--color-neutral-130);
        }

        .fDRDBl {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-light);
            line-height: var(--font-lineheight-distant);
            font-size: var(--font-size-xxs);
            font-style: normal;
            color: var(--color-neutral-130);
        }

        .cXLeHH {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-regular);
            line-height: var(--font-lineheight-distant);
            font-size: var(--font-size-xxs);
            font-style: normal;
            color: var(--color-neutral-130);
        }

        .kKRmMY {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-bold);
            line-height: var(--font-lineheight-distant);
            font-size: var(--font-size-xxs);
            font-style: normal;
            color: var(--color-neutral-130);
        }

        .bnOIlD {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-regular);
            line-height: var(--font-lineheight-medium);
            font-size: var(--font-size-sm);
            color: var(--color-neutral-130);
        }

        @media screen and (min-width: 600px) {
            .bnOIlD {
                font-size: var(--font-size-md);
            }
        }

        .dReaFp {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-semibold);
            line-height: var(--font-lineheight-superdistant);
            font-size: var(--font-size-xs);
            font-style: normal;
            color: var(--color-neutral-130);
            margin-bottom: var(--spacing-stack-xs);
        }

        /* sc-component-id: sc-cMljjf */
        .ktaXjt {
            margin: 0;
            height: 1px;
            border: none;
            background-color: var(--divider-default-background-color);
        }

        /* sc-component-id: sc-hqyNC */
        .hnRrUU {
            position: relative;
            font-family: var(--font-family);
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            z-index: var(--z-index-400-header, 400);
        }

        .hnRrUU.is-loading {
            -webkit-clip: rect(1px, 1px, 1px, 1px);
            clip: rect(1px, 1px, 1px, 1px);
            height: 1px;
            overflow: hidden;
            position: absolute;
            white-space: nowrap;
            width: 1px;
        }

        .hnRrUU.fixed {
            position: fixed;
            width: 100%;
            top: 0;
        }

        .hnRrUU.open {
            z-index: var(--z-index-700-overlay, 700);
        }

        .hnRrUU .profile-link {
            font-family: var(--font-family);
            font-size: var(--font-size-xxs);
            line-height: var(--font-lineheight-medium);
            font-weight: var(--font-weight-semibold);
            color: var(--color-neutral-130);
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            width: 135px;
            border-radius: var(--border-radius-pill);
            padding: var(--spacing-0-5);
            border: 0;
            border: 1px solid var(--color-neutral-110);
            height: 40px;
            -webkit-transition: all ease var(--transition-duration-3);
            transition: all ease var(--transition-duration-3);
            background-color: transparent;
            cursor: pointer;
        }

        .hnRrUU .profile-link:hover {
            border-color: var(--color-secondary-100);
            -webkit-text-decoration: none;
            text-decoration: none;
            color: var(--link-color-main-hover);
        }

        .hnRrUU .profile-link:focus {
            outline: none;
            box-shadow: 0 0 0 2px var(--color-secondary-80);
            border-radius: var(--border-radius-pill);
        }

        @media all and (max-width: 839px) {
            .hnRrUU .profile-link {
                display: none;
            }
        }

        .hnRrUU .profile-skeleton {
            border-radius: var(--border-radius-pill);
            border: 1px solid var(--color-neutral-110);
            display: none;
        }

        @media all and (min-width: 840px) {
            .hnRrUU .profile-skeleton {
                display: block;
            }
        }

        .hnRrUU .overflow-menu {
            position: absolute;
            width: 280px;
            top: 64px;
            border-top: 1px solid;
            border-top-color: var(--color-neutral-100);
            list-style: none;
            -webkit-transition: all ease var(--transition-duration-3);
            transition: all ease var(--transition-duration-3);
            opacity: 0;
            pointer-events: none;
            -webkit-scroll-behavior: smooth;
            -moz-scroll-behavior: smooth;
            -ms-scroll-behavior: smooth;
            scroll-behavior: smooth;
            padding-top: 2px;
            padding-bottom: 2px;
        }

        .hnRrUU .overflow-menu li.divider {
            border-bottom: 1px solid var(--color-neutral-100);
            margin-bottom: var(--spacing-0-5);
        }

        .hnRrUU .overflow-menu a.flyout-link {
            width: 100%;
            font-size: var(--font-size-xxs);
            padding: var(--spacing-2);
            -webkit-box-pack: start;
            -webkit-justify-content: flex-start;
            -ms-flex-pack: start;
            justify-content: flex-start;
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-column-gap: 16px;
            column-gap: 16px;
            color: var(--color-neutral-130);
            cursor: pointer;
            -webkit-transition: all ease var(--transition-duration-3);
            transition: all ease var(--transition-duration-3);
            -webkit-text-decoration: none;
            text-decoration: none;
        }

        .hnRrUU .overflow-menu a.flyout-link:hover {
            -webkit-text-decoration: none;
            text-decoration: none;
            background: var(--color-neutral-90);
        }

        .hnRrUU .overflow-menu a.flyout-link:focus {
            -webkit-transform: scale(0.98);
            -ms-transform: scale(0.98);
            transform: scale(0.98);
        }

        .hnRrUU .overflow-menu.show {
            opacity: 1;
            pointer-events: all;
        }

        @media all and (min-width: 840px) {
            .hnRrUU .overflow-menu.hide-non-logged {
                display: none;
            }
        }

        @media all and (max-width: 839px) {
            .hnRrUU .overflow-menu {
                -webkit-transition: all ease var(--transition-duration-3);
                transition: all ease var(--transition-duration-3);
                left: 0;
                position: absolute;
                -webkit-transform: translateX(-100%);
                -ms-transform: translateX(-100%);
                transform: translateX(-100%);
                top: 100%;
                height: calc(100vh - 80px);
                border-radius: 0;
            }

            .hnRrUU .overflow-menu.overflow-menu {
                padding-bottom: 50px;
            }

            .hnRrUU .overflow-menu.show-search-input {
                height: calc(100vh - 153px);
            }

            .hnRrUU .overflow-menu.show {
                overflow: auto;
                -webkit-transform: translateX(0);
                -ms-transform: translateX(0);
                transform: translateX(0);
            }
        }

        .hnRrUU .navbar-wrapper {
            height: 60px;
            box-sizing: border-box;
            border-top: 1px solid #d2d2d2;
            position: fixed;
            padding: 0 4px;
            width: 100%;
            left: 0;
            bottom: 0;
            z-index: var(--z-index-1000-top, 1000);
            background-color: var(--color-neutral-70);
        }

        .hnRrUU .navbar-wrapper.dsapg_scroll_down {
            height: 40px;
        }

        .hnRrUU .navbar-wrapper.dsapg_scroll_down .caption {
            position: absolute;
            -webkit-transform: translateY(60px);
            -ms-transform: translateY(60px);
            transform: translateY(60px);
        }

        .hnRrUU .navbar-wrapper.dsapg_scroll_down .desapegar-wrapper {
            height: 100%;
            position: static;
        }

        .hnRrUU .navbar-wrapper.dsapg_scroll_down .desapegar-wrapper .link {
            padding-top: 8px;
        }

        .hnRrUU .navbar-wrapper.dsapg_scroll_down .desapegar-icon-wrapper {
            width: 28px;
            height: 28px;
            padding: 2px;
        }

        .hnRrUU .navbar-wrapper.dsapg_scroll_down .desapegar-icon-wrapper svg {
            width: 100%;
            height: 100%;
        }

        @media all and (min-width: 840px) {
            .hnRrUU .navbar-wrapper {
                display: none;
            }
        }

        .hnRrUU .navbar-items {
            list-style-type: none;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: space-around;
            -webkit-justify-content: space-around;
            -ms-flex-pack: space-around;
            justify-content: space-around;
            height: 100%;
            padding: 0;
            margin: 0;
        }

        .hnRrUU .navbar-item {
            height: 100%;
            width: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
        }

        .hnRrUU .navbar-item .link {
            cursor: pointer;
            background-color: transparent;
            border: 0;
            padding: 8px 0;
            height: 100%;
            width: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            color: var(--color-neutral-130);
        }

        .hnRrUU .navbar-item .link:hover {
            -webkit-text-decoration: none;
            text-decoration: none;
            color: var(--color-neutral-130);
        }

        .hnRrUU .navbar-item .link:focus:not(:focus-visible) {
            outline: 0;
            box-shadow: none;
        }

        .hnRrUU .navbar-item .link:focus,
        .hnRrUU .navbar-item .link .focus-visible:focus:not(:focus-visible) {
            box-shadow: none;
            border-radius: var(--border-radius-xxs);
            outline: var(--border-width-thin) solid var(--color-neutral-130);
            outline-offset: 0;
        }

        .hnRrUU .navbar-item .caption {
            margin-top: var(--spacing-0-5);
            -webkit-transition: -webkit-transform 0.2s ease-out;
            -webkit-transition: transform 0.2s ease-out;
            transition: transform 0.2s ease-out;
        }

        .hnRrUU .navbar-item.desapegar-wrapper {
            position: relative;
            height: 72px;
            bottom: 6px;
        }

        .hnRrUU .navbar-item.desapegar-wrapper .link {
            padding-top: 0;
        }

        .hnRrUU .navbar-item .desapegar-icon-wrapper {
            width: 44px;
            height: 44px;
            background-color: var(--color-primary-100);
            border-radius: 50%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-transition: background-color var(--transition-duration-3) var(--transition-timing-ease);
            transition: background-color var(--transition-duration-3) var(--transition-timing-ease);
        }

        .hnRrUU .navbar-item .desapegar-icon-wrapper svg {
            color: var(--color-neutral-70);
        }

        .hnRrUU .navbar-item.active .caption {
            color: var(--color-primary-120);
        }

        .hnRrUU .navbar-item.active .desapegar-icon-wrapper {
            background-color: var(--color-primary-110);
        }

        @media all and (max-width: 425px) {
            .hnRrUU .navbar-item .caption {
                font-size: 10px;
            }
        }

        @media all and (max-width: 360px) {
            .hnRrUU .navbar-item .center-links {
                width: 70px;
                text-align: center;
            }
        }

        .hnRrUU .navbar-account-wrapper {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            width: 24px;
            height: 24px;
        }

        .hnRrUU .navbar-account-wrapper .arrow {
            position: relative;
            left: 2px;
        }

        .hnRrUU .navbar-account-wrapper.active {
            color: var(--color-primary-110);
        }

        .hnRrUU .navbar-account-wrapper.active .arrow {
            -webkit-animation: animation-account 1s ease-in-out 1;
            animation: animation-account 1s ease-in-out 1;
        }

        @-webkit-keyframes animation-account {
            0% {
                -webkit-transform: translateX(0);
                -ms-transform: translateX(0);
                transform: translateX(0);
            }

            25% {
                -webkit-transform: translateX(3px);
                -ms-transform: translateX(3px);
                transform: translateX(3px);
            }

            50% {
                -webkit-transform: translateX(-1px);
                -ms-transform: translateX(-1px);
                transform: translateX(-1px);
            }

            75% {
                -webkit-transform: translateX(0);
                -ms-transform: translateX(0);
                transform: translateX(0);
            }
        }

        @keyframes animation-account {
            0% {
                -webkit-transform: translateX(0);
                -ms-transform: translateX(0);
                transform: translateX(0);
            }

            25% {
                -webkit-transform: translateX(3px);
                -ms-transform: translateX(3px);
                transform: translateX(3px);
            }

            50% {
                -webkit-transform: translateX(-1px);
                -ms-transform: translateX(-1px);
                transform: translateX(-1px);
            }

            75% {
                -webkit-transform: translateX(0);
                -ms-transform: translateX(0);
                transform: translateX(0);
            }
        }

        .hnRrUU .navbar-ad-wrapper {
            width: 24px;
            height: 24px;
            display: inline-block;
        }

        .hnRrUU .navbar-ad-wrapper.active {
            color: var(--color-primary-110);
            -webkit-animation: animation-ad-scale 1s 0.5s ease-in-out 1;
            animation: animation-ad-scale 1s 0.5s ease-in-out 1;
        }

        .hnRrUU .navbar-ad-wrapper.active .ad-square-one {
            -webkit-animation: animation-ad-one 1s ease-in-out 1;
            animation: animation-ad-one 1s ease-in-out 1;
        }

        .hnRrUU .navbar-ad-wrapper.active .ad-square-two {
            -webkit-animation: animation-ad-two 1s ease-in-out 1;
            animation: animation-ad-two 1s ease-in-out 1;
        }

        .hnRrUU .navbar-ad-wrapper.active .ad-square-three {
            -webkit-animation: animation-ad-three 1s ease-in-out 1;
            animation: animation-ad-three 1s ease-in-out 1;
        }

        .hnRrUU .navbar-ad-wrapper.active .ad-square-four {
            -webkit-animation: animation-ad-four 1s ease-in-out 1;
            animation: animation-ad-four 1s ease-in-out 1;
        }

        @-webkit-keyframes animation-ad-scale {
            0% {
                -webkit-transform: scale(1);
                -ms-transform: scale(1);
                transform: scale(1);
            }

            50% {
                -webkit-transform: scale(1.2);
                -ms-transform: scale(1.2);
                transform: scale(1.2);
            }
        }

        @keyframes animation-ad-scale {
            0% {
                -webkit-transform: scale(1);
                -ms-transform: scale(1);
                transform: scale(1);
            }

            50% {
                -webkit-transform: scale(1.2);
                -ms-transform: scale(1.2);
                transform: scale(1.2);
            }
        }

        @-webkit-keyframes animation-ad-one {
            0% {
                -webkit-transform: translateY(0);
                -ms-transform: translateY(0);
                transform: translateY(0);
            }

            50% {
                -webkit-transform: translateY(12px);
                -ms-transform: translateY(12px);
                transform: translateY(12px);
            }

            100% {
                -webkit-transform: translateY(12px);
                -ms-transform: translateY(12px);
                transform: translateY(12px);
            }
        }

        @keyframes animation-ad-one {
            0% {
                -webkit-transform: translateY(0);
                -ms-transform: translateY(0);
                transform: translateY(0);
            }

            50% {
                -webkit-transform: translateY(12px);
                -ms-transform: translateY(12px);
                transform: translateY(12px);
            }

            100% {
                -webkit-transform: translateY(12px);
                -ms-transform: translateY(12px);
                transform: translateY(12px);
            }
        }

        @-webkit-keyframes animation-ad-two {
            0% {
                -webkit-transform: translateY(0);
                -ms-transform: translateY(0);
                transform: translateY(0);
            }

            50% {
                -webkit-transform: translateX(-11px);
                -ms-transform: translateX(-11px);
                transform: translateX(-11px);
            }

            100% {
                -webkit-transform: translateX(-11px);
                -ms-transform: translateX(-11px);
                transform: translateX(-11px);
            }
        }

        @keyframes animation-ad-two {
            0% {
                -webkit-transform: translateY(0);
                -ms-transform: translateY(0);
                transform: translateY(0);
            }

            50% {
                -webkit-transform: translateX(-11px);
                -ms-transform: translateX(-11px);
                transform: translateX(-11px);
            }

            100% {
                -webkit-transform: translateX(-11px);
                -ms-transform: translateX(-11px);
                transform: translateX(-11px);
            }
        }

        @-webkit-keyframes animation-ad-three {
            0% {
                -webkit-transform: translateY(0);
                -ms-transform: translateY(0);
                transform: translateY(0);
            }

            50% {
                -webkit-transform: translateX(11px);
                -ms-transform: translateX(11px);
                transform: translateX(11px);
            }

            100% {
                -webkit-transform: translateX(11px);
                -ms-transform: translateX(11px);
                transform: translateX(11px);
            }
        }

        @keyframes animation-ad-three {
            0% {
                -webkit-transform: translateY(0);
                -ms-transform: translateY(0);
                transform: translateY(0);
            }

            50% {
                -webkit-transform: translateX(11px);
                -ms-transform: translateX(11px);
                transform: translateX(11px);
            }

            100% {
                -webkit-transform: translateX(11px);
                -ms-transform: translateX(11px);
                transform: translateX(11px);
            }
        }

        @-webkit-keyframes animation-ad-four {
            0% {
                -webkit-transform: translateY(0);
                -ms-transform: translateY(0);
                transform: translateY(0);
            }

            50% {
                -webkit-transform: translateY(-12px);
                -ms-transform: translateY(-12px);
                transform: translateY(-12px);
            }

            100% {
                -webkit-transform: translateY(-12px);
                -ms-transform: translateY(-12px);
                transform: translateY(-12px);
            }
        }

        @keyframes animation-ad-four {
            0% {
                -webkit-transform: translateY(0);
                -ms-transform: translateY(0);
                transform: translateY(0);
            }

            50% {
                -webkit-transform: translateY(-12px);
                -ms-transform: translateY(-12px);
                transform: translateY(-12px);
            }

            100% {
                -webkit-transform: translateY(-12px);
                -ms-transform: translateY(-12px);
                transform: translateY(-12px);
            }
        }

        .hnRrUU .navbar-ad-icon-wrapper {
            position: relative;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            width: 100%;
            height: 100%;
        }

        .hnRrUU .navbar-ad-icon-wrapper .ad-square-one,
        .hnRrUU .navbar-ad-icon-wrapper .ad-square-three {
            margin-right: 2px;
        }

        .hnRrUU .navbar-message-wrapper {
            width: 24px;
            height: 24px;
            display: inline-block;
        }

        .hnRrUU .navbar-message-icons-wrapper {
            position: relative;
            width: 100%;
            height: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
        }

        .hnRrUU .navbar-message-icons-wrapper.active {
            color: var(--color-primary-110);
            -webkit-animation: animation-message 1.2s 1 ease-in-out;
            animation: animation-message 1.2s 1 ease-in-out;
        }

        @-webkit-keyframes animation-message {
            0% {
                -webkit-transform: rotate(0);
                -ms-transform: rotate(0);
                transform: rotate(0);
            }

            50% {
                -webkit-transform: rotate(-5deg);
                -ms-transform: rotate(-5deg);
                transform: rotate(-5deg);
                -webkit-transform-origin: left bottom;
                -ms-transform-origin: left bottom;
                transform-origin: left bottom;
            }

            100% {
                -webkit-transform: rotate(0);
                -ms-transform: rotate(0);
                transform: rotate(0);
            }
        }

        @keyframes animation-message {
            0% {
                -webkit-transform: rotate(0);
                -ms-transform: rotate(0);
                transform: rotate(0);
            }

            50% {
                -webkit-transform: rotate(-5deg);
                -ms-transform: rotate(-5deg);
                transform: rotate(-5deg);
                -webkit-transform-origin: left bottom;
                -ms-transform-origin: left bottom;
                transform-origin: left bottom;
            }

            100% {
                -webkit-transform: rotate(0);
                -ms-transform: rotate(0);
                transform: rotate(0);
            }
        }

        .hnRrUU .navbar-message-round-wrapper {
            position: absolute;
            top: 50%;
            left: 50%;
            -webkit-transform: translate(-50%, -50%);
            -ms-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%);
            width: 100%;
            height: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
        }

        .hnRrUU .navbar-message-round-wrapper.active span {
            width: 2px;
            height: 2px;
            border-radius: 50%;
        }

        .hnRrUU .navbar-message-round-wrapper.active span:nth-child(1) {
            -webkit-animation: animation-message-loading 1.2s 0.1s 1 ease-in;
            animation: animation-message-loading 1.2s 0.1s 1 ease-in;
        }

        .hnRrUU .navbar-message-round-wrapper.active span:nth-child(2) {
            -webkit-animation: animation-message-loading 1.2s 0.3s 1 ease-in;
            animation: animation-message-loading 1.2s 0.3s 1 ease-in;
        }

        .hnRrUU .navbar-message-round-wrapper.active span:nth-child(3) {
            -webkit-animation: animation-message-loading 1.2s 0.5s 1 ease-in;
            animation: animation-message-loading 1.2s 0.5s 1 ease-in;
        }

        .hnRrUU .navbar-message-round-wrapper.active span+span {
            margin-left: 1px;
        }

        @-webkit-keyframes animation-message-loading {

            0%,
            100% {
                background-color: var(--color-primary-100);
                -webkit-transform: translateY(-1px);
                -ms-transform: translateY(-1px);
                transform: translateY(-1px);
            }

            50% {
                background-color: #fff;
                -webkit-transform: translateY(1px);
                -ms-transform: translateY(1px);
                transform: translateY(1px);
            }
        }

        @keyframes animation-message-loading {

            0%,
            100% {
                background-color: var(--color-primary-100);
                -webkit-transform: translateY(-1px);
                -ms-transform: translateY(-1px);
                transform: translateY(-1px);
            }

            50% {
                background-color: #fff;
                -webkit-transform: translateY(1px);
                -ms-transform: translateY(1px);
                transform: translateY(1px);
            }
        }

        .hnRrUU .navbar-rocket-wrapper {
            width: 24px;
            height: 24px;
            display: inline-block;
        }

        .hnRrUU .navbar-rocket-icons-wrapper {
            position: relative;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            width: 100%;
            height: 100%;
        }

        .hnRrUU .navbar-rocket-icons-wrapper .rocket-flame {
            position: absolute;
            top: 12px;
            left: 2px;
        }

        @-webkit-keyframes animation-rocket {
            0% {
                -webkit-transform: translate(0, 0);
                -ms-transform: translate(0, 0);
                transform: translate(0, 0);
            }

            50% {
                -webkit-transform: translate(2px, -2px);
                -ms-transform: translate(2px, -2px);
                transform: translate(2px, -2px);
            }

            100% {
                -webkit-transform: translate(0, 0);
                -ms-transform: translate(0, 0);
                transform: translate(0, 0);
            }
        }

        @keyframes animation-rocket {
            0% {
                -webkit-transform: translate(0, 0);
                -ms-transform: translate(0, 0);
                transform: translate(0, 0);
            }

            50% {
                -webkit-transform: translate(2px, -2px);
                -ms-transform: translate(2px, -2px);
                transform: translate(2px, -2px);
            }

            100% {
                -webkit-transform: translate(0, 0);
                -ms-transform: translate(0, 0);
                transform: translate(0, 0);
            }
        }

        .hnRrUU .navbar-rocket-icons-wrapper.active {
            color: var(--color-primary-110);
            -webkit-animation: animation-rocket 2s 1 ease-in-out;
            animation: animation-rocket 2s 1 ease-in-out;
        }

        .hnRrUU .navbar-rocket-icons-wrapper.active .rocket-flame {
            -webkit-animation: animation-rocket-flame 0.7s 2 ease-in;
            animation: animation-rocket-flame 0.7s 2 ease-in;
        }

        @-webkit-keyframes animation-rocket-flame {
            0% {
                top: 10px;
                left: 4px;
                -webkit-clip-path: inset(3px 3px 0 0);
                clip-path: inset(3px 3px 0 0);
            }

            100% {
                top: 12px;
                left: 2px;
                -webkit-clip-path: inset(0 0 0 0);
                clip-path: inset(0 0 0 0);
            }
        }

        @keyframes animation-rocket-flame {
            0% {
                top: 10px;
                left: 4px;
                -webkit-clip-path: inset(3px 3px 0 0);
                clip-path: inset(3px 3px 0 0);
            }

            100% {
                top: 12px;
                left: 2px;
                -webkit-clip-path: inset(0 0 0 0);
                clip-path: inset(0 0 0 0);
            }
        }

        .hnRrUU .navbar-user-wrapper {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            width: 24px;
            height: 24px;
        }

        .hnRrUU .navbar-user-wrapper .user-head {
            margin-bottom: 2px;
        }

        .hnRrUU .navbar-user-wrapper.active {
            color: var(--color-primary-110);
        }

        .hnRrUU .navbar-user-wrapper.active .user-head {
            position: relative;
            -webkit-animation: animation-user 1s ease-in-out 1;
            animation: animation-user 1s ease-in-out 1;
        }

        @-webkit-keyframes animation-user {
            0% {
                -webkit-transform: rotate(90deg) translateX(5px);
                -ms-transform: rotate(90deg) translateX(5px);
                transform: rotate(90deg) translateX(5px);
                top: -5px;
            }

            25% {
                -webkit-transform: rotate(140deg) translateX(5px);
                -ms-transform: rotate(140deg) translateX(5px);
                transform: rotate(140deg) translateX(5px);
                top: -5px;
            }

            50% {
                -webkit-transform: rotate(90deg) translateX(5px);
                -ms-transform: rotate(90deg) translateX(5px);
                transform: rotate(90deg) translateX(5px);
                top: -5px;
            }

            75% {
                -webkit-transform: rotate(50deg) translateX(5px);
                -ms-transform: rotate(50deg) translateX(5px);
                transform: rotate(50deg) translateX(5px);
                top: -5px;
            }

            100% {
                -webkit-transform: rotate(90deg) translateX(5px);
                -ms-transform: rotate(90deg) translateX(5px);
                transform: rotate(90deg) translateX(5px);
                top: -5px;
            }
        }

        @keyframes animation-user {
            0% {
                -webkit-transform: rotate(90deg) translateX(5px);
                -ms-transform: rotate(90deg) translateX(5px);
                transform: rotate(90deg) translateX(5px);
                top: -5px;
            }

            25% {
                -webkit-transform: rotate(140deg) translateX(5px);
                -ms-transform: rotate(140deg) translateX(5px);
                transform: rotate(140deg) translateX(5px);
                top: -5px;
            }

            50% {
                -webkit-transform: rotate(90deg) translateX(5px);
                -ms-transform: rotate(90deg) translateX(5px);
                transform: rotate(90deg) translateX(5px);
                top: -5px;
            }

            75% {
                -webkit-transform: rotate(50deg) translateX(5px);
                -ms-transform: rotate(50deg) translateX(5px);
                transform: rotate(50deg) translateX(5px);
                top: -5px;
            }

            100% {
                -webkit-transform: rotate(90deg) translateX(5px);
                -ms-transform: rotate(90deg) translateX(5px);
                transform: rotate(90deg) translateX(5px);
                top: -5px;
            }
        }

        /* sc-component-id: sc-jbKcbu */
        .iCRRMm {
            padding: 0 var(--spacing-3);
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            background-color: var(--color-neutral-70);
            min-height: 80px;
            border-bottom: 1px solid var(--color-neutral-100);
            -webkit-transition: -webkit-transform var(--transition-duration-5) var(--transition-timing-ease-in-out);
            -webkit-transition: transform var(--transition-duration-5) var(--transition-timing-ease-in-out);
            transition: transform var(--transition-duration-5) var(--transition-timing-ease-in-out);
        }

        .iCRRMm.show {
            position: fixed;
            background: var(--color-neutral-70);
            width: 100%;
            top: 0;
        }

        .iCRRMm.inverted {
            background: var(--color-secondary-100);
        }

        .iCRRMm.inverted a,
        .iCRRMm.inverted button {
            color: var(--color-neutral-70);
        }

        .iCRRMm.inverted a:not(.sub-menu a:hover):not(.link-ad-button:hover):hover {
            color: var(--color-secondary-80);
        }

        .iCRRMm.inverted .profile-link {
            border-color: var(--color-neutral-70);
        }

        .iCRRMm.inverted .profile-link:hover {
            border-color: var(--color-secondary-80);
            color: var(--color-secondary-80);
        }

        .iCRRMm.dsapg_scroll_up {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
        }

        .iCRRMm.dsapg_scroll_down {
            -webkit-transform: translateY(-100%);
            -ms-transform: translateY(-100%);
            transform: translateY(-100%);
        }

        @media all and (max-width: 839px) {
            .iCRRMm {
                padding: var(--spacing-2);
            }
        }

        /* sc-component-id: sc-dNLxif */
        .dBxJFy {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            width: 100%;
            max-width: 1272px;
            margin: 0 auto;
        }

        /* sc-component-id: sc-jqCOkK */
        .aVtv {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            position: relative;
        }

        .aVtv .header-mobile-button {
            -webkit-box-pack: start;
            -webkit-justify-content: start;
            -ms-flex-pack: start;
            justify-content: start;
        }

        @media all and (min-width: 840px) {
            .aVtv .header-mobile-button {
                display: none;
            }
        }

        @media all and (max-width: 359px) {
            .aVtv .header-mobile-button {
                width: 44px;
                height: 44px;
            }
        }

        .aVtv .header-go-back-button {
            margin-right: var(--spacing-1);
        }

        @media all and (min-width: 840px) {
            .aVtv .header-go-back-button {
                display: none;
            }
        }

        @media all and (max-width: 839px) {
            .aVtv .go-back {
                display: none;
            }
        }

        /* sc-component-id: sc-uJMKN */
        .fbEBEC {
            opacity: 0;
            -webkit-transition: all var(--transition-duration-5) var(--transition-timing-ease);
            transition: all var(--transition-duration-5) var(--transition-timing-ease);
            will-change: opacity;
        }

        .fbEBEC.loaded {
            opacity: 1;
        }

        @media all and (max-width: 839px) {
            .fbEBEC.new-header>ul {
                display: -webkit-box;
                display: -webkit-flex;
                display: -ms-flexbox;
                display: flex;
                -webkit-box-pack: end;
                -webkit-justify-content: end;
                -ms-flex-pack: end;
                justify-content: end;
            }
        }

        /* sc-component-id: sc-bbmXgH */
        .GMjXn {
            width: 48px;
            height: 48px;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-column-gap: 32px;
            column-gap: 32px;
            font-size: var(--font-size-xxs);
            color: var(--color-neutral-130);
        }

        .GMjXn:hover {
            -webkit-text-decoration: none;
            text-decoration: none;
            color: var(--color-secondary-100);
        }

        @media all and (max-width: 359px) {
            .GMjXn {
                width: 44px;
                height: 44px;
            }
        }

        /* sc-component-id: sc-gGBfsJ */
        .hHrLKr {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-column-gap: var(--spacing-3);
            column-gap: var(--spacing-3);
            margin: 0;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            padding: 0;
        }

        @media all and (max-width: 1024px) {
            .hHrLKr {
                -webkit-column-gap: var(--spacing-2);
                column-gap: var(--spacing-2);
            }
        }

        .hHrLKr .header-link {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-column-gap: var(--spacing-1);
            column-gap: var(--spacing-1);
        }

        .hHrLKr .header-link:hover {
            -webkit-text-decoration: none;
            text-decoration: none;
        }

        @media all and (max-width: 839px) {
            .hHrLKr {
                -webkit-column-gap: var(--spacing-1);
                column-gap: var(--spacing-1);
                margin-left: var(--spacing-1);
            }

            .hHrLKr.desapegar {
                -webkit-column-gap: 0;
                column-gap: 0;
                margin-left: 0;
                padding: 0;
            }
        }

        /* sc-component-id: sc-jnlKLf */
        .gZakDx {
            list-style: none;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
        }

        .gZakDx.search-item {
            display: none;
        }

        .gZakDx .link-ad-button {
            font-size: var(--font-size-xxs);
        }

        @media all and (max-width: 599px) {
            .gZakDx .link-ad-button {
                height: 32px;
                padding: var(--spacing-1) var(--spacing-2);
            }
        }

        .gZakDx .search-button {
            border: none;
            background: transparent;
            cursor: pointer;
            width: 48px;
            height: 48px;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
        }

        @media all and (max-width: 839px) {
            .gZakDx.hide-on-tablet {
                display: none;
            }

            .gZakDx.item-profile-wrapper {
                display: none;
            }

            .gZakDx.search-item {
                display: block;
            }

            .gZakDx a:not(.link-ad-button) {
                padding: 12px;
            }

            .gZakDx.desapegar-new-header,
            .gZakDx.chat-new-header {
                display: none;
            }
        }

        @media all and (max-width: 359px) {
            .gZakDx a:not(.link-ad-button) {
                padding: 10px;
            }
        }

        /* sc-component-id: sc-fYxtnH */
        .hJtDZo {
            display: inline-block;
            position: relative;
            width: 24px;
            height: 24px;
        }

        .hJtDZo span.notification {
            max-width: 24px;
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            position: relative;
        }

        .hJtDZo span.notification:after {
            pointer-events: none;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            box-sizing: content-box;
            content: attr(data-counter);
            position: absolute;
            line-height: 19px;
            left: -8px;
            top: -8px;
            padding: 1px;
            background: #f78323;
            width: 17px;
            height: 17px;
            border-radius: 50%;
            color: #fff;
            font-weight: 700;
            font-size: 10px;
            text-align: center;
            pointer-events: none;
            -webkit-animation: pop 1s ease forwards;
            animation: pop 1s ease forwards;
        }

        @-webkit-keyframes pop {
            0% {
                -webkit-transform: scale(0);
                -ms-transform: scale(0);
                transform: scale(0);
            }

            25% {
                -webkit-transform: scale(1.25);
                -ms-transform: scale(1.25);
                transform: scale(1.25);
            }

            50% {
                -webkit-transform: scale(0.8);
                -ms-transform: scale(0.8);
                transform: scale(0.8);
            }

            75% {
                -webkit-transform: scale(1.25);
                -ms-transform: scale(1.25);
                transform: scale(1.25);
            }

            100% {
                -webkit-transform: scale(1);
                -ms-transform: scale(1);
                transform: scale(1);
            }
        }

        @keyframes pop {
            0% {
                -webkit-transform: scale(0);
                -ms-transform: scale(0);
                transform: scale(0);
            }

            25% {
                -webkit-transform: scale(1.25);
                -ms-transform: scale(1.25);
                transform: scale(1.25);
            }

            50% {
                -webkit-transform: scale(0.8);
                -ms-transform: scale(0.8);
                transform: scale(0.8);
            }

            75% {
                -webkit-transform: scale(1.25);
                -ms-transform: scale(1.25);
                transform: scale(1.25);
            }

            100% {
                -webkit-transform: scale(1);
                -ms-transform: scale(1);
                transform: scale(1);
            }
        }

        /* sc-component-id: sc-tilXH */
        .afwMA {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
        }

        .afwMA.notification svg {
            -webkit-animation: bell-shake 1.5s cubic-bezier(0.25, 0.46, 0.45, 0.94) 3;
            animation: bell-shake 1.5s cubic-bezier(0.25, 0.46, 0.45, 0.94) 3;
            -webkit-animation-delay: 1s;
            animation-delay: 1s;
            -webkit-backface-visibility: hidden;
            backface-visibility: hidden;
            -webkit-transform-origin: top right;
            -ms-transform-origin: top right;
            transform-origin: top right;
        }

        @-webkit-keyframes bell-shake {
            0% {
                -webkit-transform: rotate(0deg);
                -ms-transform: rotate(0deg);
                transform: rotate(0deg);
            }

            5% {
                -webkit-transform: rotate(10deg);
                -ms-transform: rotate(10deg);
                transform: rotate(10deg);
            }

            10% {
                -webkit-transform: rotate(-10deg);
                -ms-transform: rotate(-10deg);
                transform: rotate(-10deg);
            }

            15% {
                -webkit-transform: rotate(10deg);
                -ms-transform: rotate(10deg);
                transform: rotate(10deg);
            }

            20% {
                -webkit-transform: rotate(-10deg);
                -ms-transform: rotate(-10deg);
                transform: rotate(-10deg);
            }

            25% {
                -webkit-transform: rotate(0deg);
                -ms-transform: rotate(0deg);
                transform: rotate(0deg);
            }

            75% {
                -webkit-transform: rotate(0deg);
                -ms-transform: rotate(0deg);
                transform: rotate(0deg);
            }

            80% {
                -webkit-transform: rotate(10deg);
                -ms-transform: rotate(10deg);
                transform: rotate(10deg);
            }

            85% {
                -webkit-transform: rotate(-10deg);
                -ms-transform: rotate(-10deg);
                transform: rotate(-10deg);
            }

            90% {
                -webkit-transform: rotate(10deg);
                -ms-transform: rotate(10deg);
                transform: rotate(10deg);
            }

            95% {
                -webkit-transform: rotate(-10deg);
                -ms-transform: rotate(-10deg);
                transform: rotate(-10deg);
            }

            100% {
                -webkit-transform: rotate(0);
                -ms-transform: rotate(0);
                transform: rotate(0);
            }
        }

        @keyframes bell-shake {
            0% {
                -webkit-transform: rotate(0deg);
                -ms-transform: rotate(0deg);
                transform: rotate(0deg);
            }

            5% {
                -webkit-transform: rotate(10deg);
                -ms-transform: rotate(10deg);
                transform: rotate(10deg);
            }

            10% {
                -webkit-transform: rotate(-10deg);
                -ms-transform: rotate(-10deg);
                transform: rotate(-10deg);
            }

            15% {
                -webkit-transform: rotate(10deg);
                -ms-transform: rotate(10deg);
                transform: rotate(10deg);
            }

            20% {
                -webkit-transform: rotate(-10deg);
                -ms-transform: rotate(-10deg);
                transform: rotate(-10deg);
            }

            25% {
                -webkit-transform: rotate(0deg);
                -ms-transform: rotate(0deg);
                transform: rotate(0deg);
            }

            75% {
                -webkit-transform: rotate(0deg);
                -ms-transform: rotate(0deg);
                transform: rotate(0deg);
            }

            80% {
                -webkit-transform: rotate(10deg);
                -ms-transform: rotate(10deg);
                transform: rotate(10deg);
            }

            85% {
                -webkit-transform: rotate(-10deg);
                -ms-transform: rotate(-10deg);
                transform: rotate(-10deg);
            }

            90% {
                -webkit-transform: rotate(10deg);
                -ms-transform: rotate(10deg);
                transform: rotate(10deg);
            }

            95% {
                -webkit-transform: rotate(-10deg);
                -ms-transform: rotate(-10deg);
                transform: rotate(-10deg);
            }

            100% {
                -webkit-transform: rotate(0);
                -ms-transform: rotate(0);
                transform: rotate(0);
            }
        }

        /* sc-component-id: sc-hEsumM */
        @media all and (max-width: 1271px) {
            .cQjubG {
                -webkit-clip: rect(1px, 1px, 1px, 1px);
                clip: rect(1px, 1px, 1px, 1px);
                height: 1px;
                overflow: hidden;
                position: absolute;
                white-space: nowrap;
                width: 1px;
                display: -webkit-box;
                display: -webkit-flex;
                display: -ms-flexbox;
                display: flex;
            }
        }

        @media all and (max-width: 839px) {
            .cQjubG.show-on-tablet {
                -webkit-clip: initial;
                clip: initial;
                height: initial;
                overflow: initial;
                position: initial;
                white-space: initial;
                width: initial;
                display: initial;
            }
        }

        @media all and (max-width: 599px) {
            .cQjubG.show-on-tablet {
                -webkit-clip: rect(1px, 1px, 1px, 1px);
                clip: rect(1px, 1px, 1px, 1px);
                height: 1px;
                overflow: hidden;
                position: absolute;
                white-space: nowrap;
                width: 1px;
                display: -webkit-box;
                display: -webkit-flex;
                display: -ms-flexbox;
                display: flex;
            }
        }

        /* sc-component-id: sc-ktHwxA */
        .cahgYa {
            width: 100%;
            margin: 0 var(--spacing-3);
        }

        @media all and (max-width: 839px) {
            .cahgYa.new-header {
                margin: 0 var(--spacing-1);
            }

            .cahgYa:not(.new-header) {
                display: none;
            }

            .cahgYa:not(.new-header) #searchtext-input {
                display: none;
            }
        }

        /* sc-component-id: sc-cIShpX */
        .ghAWfW {
            width: 100%;
            padding-top: var(--spacing-3);
            padding-left: var(--spacing-3);
            padding-right: var(--spacing-3);
        }

        @media all and (min-width: 840px) {
            .ghAWfW {
                display: none;
            }
        }

        @media all and (max-width: 839px) {
            .ghAWfW {
                padding-left: 0;
                padding-right: 0;
            }
        }

        /* sc-component-id: sc-kafWEX */
        .jDogfN {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: start;
            -webkit-justify-content: flex-start;
            -ms-flex-pack: start;
            justify-content: flex-start;
        }

        .iTyeOU {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
        }

        .etIOjC {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-box-pack: end;
            -webkit-justify-content: flex-end;
            -ms-flex-pack: end;
            justify-content: flex-end;
        }

        .owzzZ {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            margin-left: var(--spacing-1);
        }

        .iUYDes {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: flex-start;
            -webkit-box-align: flex-start;
            -ms-flex-align: flex-start;
            align-items: flex-start;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
        }

        .cuKJrD {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
        }

        .cETbit {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
        }

        .cNNGic {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: flex-start;
            -webkit-box-align: flex-start;
            -ms-flex-align: flex-start;
            align-items: flex-start;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
        }

        .eEpVMR {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            padding-top: 48px;
            padding-bottom: 32px;
        }

        /* sc-component-id: sc-iELTvK */
        .cNrgBk {
            width: 100%;
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            border: none;
            border-radius: var(--border-radius-sm);
            background-color: var(--textinput-background-color-base);
            color: var(--textinput-color-font);
            position: relative;
            z-index: var(--z-index-1-default, 1);
            box-shadow: 0 0 0 var(--border-width-hairline) var(--textinput-border-color-empty);
        }

        .cNrgBk:hover {
            box-shadow: 0 0 0 var(--border-width-thin) var(--textinput-border-color-hover);
        }

        .cNrgBk:focus-within {
            box-shadow: 0 0 0 var(--border-width-thin) var(--textinput-border-color-focus);
        }

        /* sc-component-id: sc-cmTdod */
        .iyFOQA {
            width: 100%;
            outline: none;
            border: none;
            background-color: inherit;
            font-family: var(--font-family);
            font-weight: var(--font-weight-regular);
            position: relative;
            font-size: var(--font-size-xs);
            padding: var(--spacing-1-5) var(--spacing-2);
            line-height: var(--font-lineheight-distant);
            border-radius: var(--border-radius-sm);
        }

        .iyFOQA::-webkit-input-placeholder {
            color: var(--textinput-color-placeholder);
        }

        .iyFOQA::-moz-placeholder {
            color: var(--textinput-color-placeholder);
        }

        .iyFOQA:-ms-input-placeholder {
            color: var(--textinput-color-placeholder);
        }

        .iyFOQA::placeholder {
            color: var(--textinput-color-placeholder);
        }

        .iyFOQA:disabled {
            cursor: not-allowed;
        }

        .iyFOQA::-webkit-outer-spin-button,
        .iyFOQA::-webkit-inner-spin-button {
            -webkit-appearance: none;
        }

        .iyFOQA[type='number'] {
            -moz-appearance: textfield;
        }

        /* sc-component-id: ad__sc-5fdfr5-0 */
        .kIJyLN {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            margin-bottom: var(--spacing-1);
        }

        @media (min-width: 52.5em) {
            .kIJyLN {
                max-width: 355px;
            }
        }

        /* sc-component-id: ad__sc-5fdfr5-1 */
        .dRVOMM {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
        }

        /* sc-component-id: ad__sc-5fdfr5-2 */
        .eIrngG {
            -webkit-text-decoration: underline;
            text-decoration: underline;
        }

        /* sc-component-id: ad__sc-5fdfr5-3 */
        @media (min-width: 52.5em) {
            .ekrleZ {
                width: 270px;
            }
        }

        /* sc-component-id: ad__sc-5fdfr5-4 */
        .dKHbZG {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            z-index: 1;
            position: absolute;
            top: 0;
            right: 0;
            height: 48px;
            width: 56px;
            background-color: transparent;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
        }

        @media (min-width: 52.5em) {
            .dKHbZG {
                height: 40px;
            }
        }

        /* sc-component-id: ad__sc-5fdfr5-5 */
        .jpvXFy {
            position: relative;
            width: 100%;
        }

        @media (min-width: 52.5em) {
            .jpvXFy {
                width: unset;
            }
        }

        /* sc-component-id: ad__sc-5fdfr5-6 */
        .iylYKg {
            display: block;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
        }

        @media (min-width: 52.5em) {
            .iylYKg {
                display: none;
            }
        }

        /* sc-component-id: ad__sc-5fdfr5-7 */
        .kvIMt {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            display: none;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-box-pack: start;
            -webkit-justify-content: flex-start;
            -ms-flex-pack: start;
            justify-content: flex-start;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
        }

        @media (min-width: 52.5em) {
            .kvIMt {
                display: -webkit-box;
                display: -webkit-flex;
                display: -ms-flexbox;
                display: flex;
            }
        }

        /* sc-component-id: ad__sc-5fdfr5-8 */
        .emZFka {
            margin: 0;
        }

        /* sc-component-id: ad__sc-1ut0abb-0 */
        @media (min-width: 52.5em) {
            .bGuwyi {
                height: auto;
            }
        }

        /* sc-component-id: ad__sc-1ut0abb-1 */
        @media (min-width: 52.5em) {
            .gHTlpF.fixedBox {
                position: fixed;
                top: 0;
                z-index: 1;
                box-shadow: #FFFFFF 8px 0px 6px 12px;
                width: auto;
            }
        }

        /* sc-component-id: sc-gxMtzJ */
        .iGgTDm {
            border: 1px solid #E5E5E5;
            border-radius: 8px;
            padding: 16px 16px 8px 16px;
            background-color: #F9F9F9;
        }

        /* sc-component-id: sc-dfVpRl */
        .kAWE {
            margin-bottom: 8px;
        }

        /* sc-component-id: sc-iyvyFf */
        .iYdLJP {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            margin-bottom: 16px;
        }

        /* sc-component-id: sc-hwwEjo */
        .esIZPW {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
        }

        /* sc-component-id: sc-kPVwWT */
        .bLpKIE {
            margin-right: 8px;
        }

        /* sc-component-id: sc-GMQeP */
        .hywCld {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            gap: var(--spacing-stack-nano);
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
        }

        /* sc-component-id: sc-eLExRp */
        .hWTjz {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: start;
            -webkit-justify-content: flex-start;
            -ms-flex-pack: start;
            justify-content: flex-start;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
        }

        .ctqfgj {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: end;
            -webkit-justify-content: flex-end;
            -ms-flex-pack: end;
            justify-content: flex-end;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
        }

        /* sc-component-id: sc-cbkKFq */
        .jtNbfo {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-align-items: flex-start;
            -webkit-box-align: flex-start;
            -ms-flex-align: flex-start;
            align-items: flex-start;
        }

        .bjZave {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-align-items: flex-start;
            -webkit-box-align: flex-start;
            -ms-flex-align: flex-start;
            align-items: flex-start;
        }

        /* sc-component-id: sc-krvtoX */
        .dOHiXa {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            cursor: pointer;
        }

        /* sc-component-id: sc-fYiAbW */
        .gsysFh {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            margin-right: 8px;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
        }

        /* sc-component-id: sc-fOKMvo */
        .jhThrT {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            cursor: pointer;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-self: flex-start;
            -ms-flex-item-align: start;
            align-self: flex-start;
            margin-top: var(--spacing-stack-nano);
        }

        .jdnoDP {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            cursor: pointer;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-self: center;
            -ms-flex-item-align: center;
            align-self: center;
        }

        /* sc-component-id: sc-dEoRIm */
        .fmaqoh {
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            background-color: #00000055;
            border: 0;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            height: 100%;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            left: 0;
            position: fixed;
            right: 0;
            top: 0;
            width: 100%;
            z-index: var(--z-index-900-modal, 900);
            -webkit-transition: opacity ease 300ms;
            transition: opacity ease 300ms;
            opacity: 0;
            visibility: hidden;
            will-change: transform;
        }

        .fmaqoh.show {
            opacity: 1;
            visibility: visible;
        }

        @media (max-width: 481px) {
            .fmaqoh {
                -webkit-align-items: flex-end;
                -webkit-box-align: flex-end;
                -ms-flex-align: flex-end;
                align-items: flex-end;
            }
        }

        /* sc-component-id: sc-jtggT */
        .kYnGEA {
            background-color: white;
            border-radius: 16px;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            width: 600px;
            max-height: 95vh;
            min-height: 200px;
            padding: 24px 32px;
            position: relative;
            -webkit-transition: opacity ease 300ms;
            transition: opacity ease 300ms;
            opacity: 0;
            -webkit-transition: all ease 0.3s;
            transition: all ease 0.3s;
            -webkit-transform: translateY(10%) scale(0.9);
            -ms-transform: translateY(10%) scale(0.9);
            transform: translateY(10%) scale(0.9);
        }

        .kYnGEA.show {
            opacity: 1;
            -webkit-transform: scale(1);
            -ms-transform: scale(1);
            transform: scale(1);
        }

        @media (max-width: 481px) {
            .kYnGEA {
                border-bottom-left-radius: 0px;
                border-bottom-right-radius: 0px;
                -webkit-transform: translateY(100%) scale(0.9);
                -ms-transform: translateY(100%) scale(0.9);
                transform: translateY(100%) scale(0.9);
            }

            .kYnGEA.show {
                -webkit-transform: translateY(0);
                -ms-transform: translateY(0);
                transform: translateY(0);
            }
        }

        .fRcoaK {
            background-color: white;
            border-radius: 16px;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            width: 600px;
            max-height: 80vh;
            min-height: 200px;
            padding: 24px 32px;
            position: relative;
            -webkit-transition: opacity ease 300ms;
            transition: opacity ease 300ms;
            opacity: 0;
            -webkit-transition: all ease 0.3s;
            transition: all ease 0.3s;
            -webkit-transform: translateY(10%) scale(0.9);
            -ms-transform: translateY(10%) scale(0.9);
            transform: translateY(10%) scale(0.9);
        }

        .fRcoaK.show {
            opacity: 1;
            -webkit-transform: scale(1);
            -ms-transform: scale(1);
            transform: scale(1);
        }

        @media (max-width: 481px) {
            .fRcoaK {
                border-bottom-left-radius: 0px;
                border-bottom-right-radius: 0px;
                -webkit-transform: translateY(100%) scale(0.9);
                -ms-transform: translateY(100%) scale(0.9);
                transform: translateY(100%) scale(0.9);
            }

            .fRcoaK.show {
                -webkit-transform: translateY(0);
                -ms-transform: translateY(0);
                transform: translateY(0);
            }
        }

        /* sc-component-id: sc-ebFjAB */
        .lluhit {
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            background-color: #00000000;
            border: none;
            border-radius: 50%;
            cursor: pointer;
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            outline: none;
            padding: 5px;
        }

        .lluhit:hover {
            background-color: #f6f6f6;
        }

        .lluhit:focus {
            outline: none;
            box-shadow: 0 0 0 2px var(--color-secondary-80);
            border-radius: var(--border-radius-pill);
        }

        /* sc-component-id: sc-jKVCRD */
        .domptC {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: end;
            -webkit-justify-content: flex-end;
            -ms-flex-pack: end;
            justify-content: flex-end;
        }

        /* sc-component-id: sc-kaNhvL */
        .cWMImq {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            height: 100%;
            overflow-y: auto;
            overflow-x: hidden;
        }

        .cWMImq::-webkit-scrollbar {
            width: 10px;
        }

        .cWMImq::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 15px;
        }

        .cWMImq::-webkit-scrollbar-thumb {
            background: #aaa;
            border-radius: 15px;
        }

        .cWMImq::-webkit-scrollbar-thumb:hover {
            background: #888;
        }

        /* sc-component-id: sc-iBEsjs */
        .gVrvSe {
            color: var(--color-secondary-100);
        }

        /* sc-component-id: sc-chbbiW */
        .dYkYVy {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            max-height: 400px;
            overflow-y: auto;
        }

        /* sc-component-id: sc-kxynE */
        .iVorxG {
            color: #4a4a4a;
            margin-top: 0;
        }

        /* sc-component-id: sc-cooIXK */
        .fWOsuW {
            list-style-position: inside;
        }

        /* sc-component-id: sc-fcdeBU */
        .oCUry {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
        }

        /* sc-component-id: sc-RcBXQ */
        .iaDrkT {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-box-pack: end;
            -webkit-justify-content: flex-end;
            -ms-flex-pack: end;
            justify-content: flex-end;
        }

        /* sc-component-id: sc-fZwumE */
        .lhTahy {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            background-color: var(--color-secondary-lightest);
            padding: var(--spacing-stack-xxxs);
            gap: var(--spacing-stack-xxs);
            border-radius: var(--border-radius-sm);
        }

        /* sc-component-id: sc-fQejPQ */
        .cONchc {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
        }

        /* sc-component-id: sc-clNaTc */
        .fkwSEH {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
        }

        /* sc-component-id: sc-etwtAo */
        .kOrzBT {
            padding: 0;
            text-align: left;
            font-size: 13px;
        }

        /* sc-component-id: sc-jXQZqI */
        .gRdTZD {
            margin-right: var(--spacing-inline-nano);
        }

        /* sc-component-id: sc-hgHYgh */
        .hbTyoW {
            margin: var(--spacing-stack-quarck) 0;
        }

        /* sc-component-id: sc-gtfDJT */
        .fsMHPV {
            color: var(--color-secondary-100);
        }

        /* sc-component-id: sc-fOICqy */
        .dKiDao {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: end;
            -webkit-justify-content: flex-end;
            -ms-flex-pack: end;
            justify-content: flex-end;
            padding-top: var(--spacing-inset-lg);
        }

        /* sc-component-id: sc-hzDEsm */
        .dPqlXg {
            display: grid;
            grid-template-columns: 44px 1fr;
            margin-top: var(--spacing-stack-xxs);
        }

        /* sc-component-id: sc-jeCdPy */
        .kTSYUO {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            margin-bottom: var(--spacing-4);
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
        }

        /* sc-component-id: ad__sc-1wimjbb-0 */
        .bsMpRS {
            margin-top: var(--spacing-inline-nano);
        }

        /* sc-component-id: ad__sc-1wimjbb-1 */
        .hoHpcC {
            font-weight: var(--font-weight-regular);
            font-size: var(--font-size-xxl);
        }

        @media (min-width: 52.5em) {
            .hoHpcC {
                font-size: var(--font-size-lg);
            }
        }

        /* sc-component-id: ad__sc-1wimjbb-2 */
        .iFeCCh {
            -webkit-text-decoration: line-through;
            text-decoration: line-through;
        }

        @media (min-width: 52.5em) {
            .iFeCCh {
                font-size: var(--font-size-xxs);
            }
        }

        /* sc-component-id: ad__sc-1wimjbb-3 */
        .rDAfb {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: flex-start;
            -webkit-box-align: flex-start;
            -ms-flex-align: flex-start;
            align-items: flex-start;
            -webkit-flex-direction: column-reverse;
            -ms-flex-direction: column-reverse;
            flex-direction: column-reverse;
        }

        @media (min-width: 52.5em) {
            .rDAfb {
                -webkit-flex-direction: column-reverse;
                -ms-flex-direction: column-reverse;
                flex-direction: column-reverse;
                padding-bottom: 0;
            }
        }

        /* sc-component-id: ad__sc-1wimjbb-4 */
        .lcAaLl {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
        }

        @media (min-width: 52.5em) {
            .lcAaLl {
                -webkit-flex-direction: row;
                -ms-flex-direction: row;
                flex-direction: row;
                -webkit-align-items: center;
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center;
            }
        }

        /* sc-component-id: ad__sc-1wimjbb-5 */
        .jDUdBn {
            width: 30px;
            height: 30px;
            margin-right: 8px;
        }

        @media (min-width: 840px) {
            .jDUdBn svg {
                width: 20px;
                height: 20px;
            }
        }

        /* sc-component-id: ad__abkzhw-0 */
        .dvuHYj {
            margin: 0px;
        }

        /* sc-component-id: ad__sc-12l420o-0 */
        .gKlMXV {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            border-top-right-radius: 8px;
            border-bottom-right-radius: 8px;
            padding: 10px 0 10px 8px;
            background-color: var(--color-secondary-medium);
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
        }

        /* sc-component-id: ad__sc-12l420o-1 */
        .haeKsn {
            font-weight: var(--font-weight-regular);
            line-height: 44px;
        }

        @media (min-width: 52.5em) {
            .haeKsn {
                margin-right: var(--spacing-stack-quarck);
            }
        }

        @media (min-width: 79.5em) {
            .haeKsn {
                margin-right: var(--spacing-stack-nano);
            }
        }

        /* sc-component-id: ad__sc-1ukaq78-0 */
        .kbqZof {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: flex-start;
            -webkit-box-align: flex-start;
            -ms-flex-align: flex-start;
            align-items: flex-start;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
        }

        @media (min-width: 52.5em) {
            .kbqZof {
                -webkit-flex-direction: row;
                -ms-flex-direction: row;
                flex-direction: row;
                -webkit-align-items: center;
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center;
                -webkit-box-pack: start;
                -webkit-justify-content: flex-start;
                -ms-flex-pack: start;
                justify-content: flex-start;
            }
        }

        /* sc-component-id: ad__sc-1kv8vxj-0 */
        .dLCxtV {
            margin-block-start: 0;
            margin-block-end: 0;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        /* sc-component-id: ad__sc-13jbcl7-0 */
        .hDpoqp {
            cursor: pointer;
            color: var(--color-secondary-medium);
            font-weight: var(--font-weight-semibold);
            outline: none;
        }

        .hDpoqp:focus {
            box-shadow: 0 0 0 2px var(--color-secondary-lighter);
            border-radius: var(--border-radius-xxs);
        }

        /* sc-component-id: ad__sc-1sj3nln-0 */
        .focuCb {
            white-space: pre-line;
        }

        /* sc-component-id: ad__sc-1sj3nln-1 */
        .fMgwdS {
            word-break: break-word;
        }

        /* sc-component-id: ad__sc-1f2ug0x-0 */
        .lfYRqx {
            width: 50%;
        }

        @media (min-width: 45em) {
            .lfYRqx {
                padding-left: 0px;
                width: 100%;
                font-size: var(--font-size-xxs);
                color: var(--color-neutral-120);
            }
        }

        /* sc-component-id: ad__sc-1f2ug0x-1 */
        .cpGpXB {
            box-sizing: border-box;
            padding-left: 16px;
            width: 50%;
        }

        .cpGpXB::before {
            display: none;
        }

        @media (min-width: 45em) {
            .cpGpXB {
                padding-left: 0px;
                width: 100%;
            }
        }

        /* sc-component-id: ad__sc-1f2ug0x-2 */
        .eSYIff {
            padding-left: var(--spacing-inline-xxxs);
            outline: none;
            width: 50%;
        }

        @media (min-width: 45em) {
            .eSYIff {
                padding-left: 0px;
                width: 100%;
            }
        }

        /* sc-component-id: ad__sc-1f2ug0x-3 */
        .eQlxUw {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            margin-top: var(--spacing-2);
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
        }

        @media (min-width: 45em) {
            .eQlxUw {
                -webkit-flex-direction: column;
                -ms-flex-direction: column;
                flex-direction: column;
            }
        }

        /* sc-component-id: sc-global-3620647079 */
        .ReactModal__Body--open,
        .ReactModal__Html--open {
            overflow: hidden;
        }

        /* sc-component-id: ad__sc-15o28wz-0 */
        .kTeLyN {
            margin: 0 var(--spacing-inline-quarck);
            margin-bottom: var(--spacing-inline-quarck);
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
        }

        .kTeLyN a:nth-child(2) {
            margin-left: 5px;
        }

        @media (min-width: 1em) and (max-width:52.4375em) {
            .kTeLyN {
                display: block;
                -webkit-order: 1;
                -ms-flex-order: 1;
                order: 1;
                width: 100%;
                margin: var(--spacing-inline-nano) 0 0 0;
            }

            .kTeLyN a:nth-child(2) {
                margin-left: 0;
            }
        }

        /* sc-component-id: ad__sc-15o28wz-1 */
        .dYYOaL {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            margin-right: var(--spacing-inline-nano);
            -webkit-align-items: baseline;
            -webkit-box-align: baseline;
            -ms-flex-align: baseline;
            align-items: baseline;
        }

        /* sc-component-id: ad__sc-15o28wz-2 */
        .dsBvGq {
            margin-right: 4px;
            margin-left: -2px;
        }

        /* sc-component-id: ad__pw7c9f-0 */
        .gpTdno {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            margin-bottom: -16px;
        }

        /* sc-component-id: ad__sc-1aze3je-0 */
        .kNSqkm {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            margin-top: var(--spacing-2);
            margin-bottom: var(--spacing-2);
            height: 24px;
        }

        /* sc-component-id: ad__sc-1aze3je-1 */
        .bKbctQ {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
        }

        /* sc-component-id: ad__sc-1aze3je-2 */
        .bKCVhH {
            margin-right: 4px;
            margin-left: 4px;
        }

        /* sc-component-id: ad__sc-1oq8jzc-0 */
        .dWayMW {
            font-size: var(--font-size-xs);
        }

        @media (min-width: 52.5em) {
            .dWayMW {
                font-size: var(--font-size-xxxs);
            }
        }

        /* sc-component-id: ad__sc-16iz3i7-0 */
        .hjLLUR {
            font-size: var(--font-size-xs);
        }

        @media (min-width: 52.5em) {
            .hjLLUR {
                font-size: var(--font-size-xxxs);
            }
        }

        /* sc-component-id: ad__sc-16bj9n5-0 */
        .hOpmFZ {
            font-size: var(--font-size-xs);
        }

        @media (min-width: 52.5em) {
            .hOpmFZ {
                font-size: var(--font-size-xxxs);
            }
        }

        /* sc-component-id: ad__en9h1n-0 */
        .cmhHQz {
            position: relative;
            width: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
        }

        @media (min-width: 839px) {
            .cmhHQz {
                -webkit-flex-direction: row;
                -ms-flex-direction: row;
                flex-direction: row;
                -webkit-box-pack: justify;
                -webkit-justify-content: space-between;
                -ms-flex-pack: justify;
                justify-content: space-between;
                width: auto;
            }
        }

        /* sc-component-id: ad__en9h1n-1 */
        .ldGENT {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            padding-right: var(--spacing-1);
            padding-left: var(--spacing-1);
        }

        /* sc-component-id: ad__en9h1n-3 */
        .gazhQO {
            border: none;
            background-color: transparent;
            padding: 0;
            height: auto;
            min-width: 16px;
            margin-left: 4px;
            margin-right: 4px;
        }

        .gazhQO:hover {
            background-color: transparent;
        }

        .gazhQO:focus {
            box-shadow: 0 0 0 var(--border-width-thick) var(--button-primary-color-outline);
        }

        /* sc-component-id: sc-global-1546285970 */
        .search-wrap-box {
            position: relative;
        }

        .combobox-wrapper span {
            box-shadow: 0 0 0 var(--border-width-hairline) var(--color-neutral-dark);
            -webkit-transition: all 0.2s ease;
            transition: all 0.2s ease;
            border-radius: var(--border-radius-sm);
        }

        .combobox-wrapper span:hover {
            outline: none;
            box-shadow: 0 0 0 var(--border-width-thin) var(--color-neutral-darker);
        }

        .combobox-wrapper span:focus-within {
            outline: none;
            box-shadow: 0 0 0 var(--border-width-thin) var(--color-secondary-medium);
        }

        .combobox-wrapper input {
            height: var(--spacing-stack-md);
            outline: none;
            font-size: 15px;
            font-family: var(--font-family);
            font-weight: var(--font-weight-regular);
            padding: var(--spacing-stack-xxxs) var(--spacing-stack-nano) var(--spacing-stack-xxxs) var(--spacing-stack-xxxs);
            margin-right: 40px;
            color: var(--color-neutral-darkest);
            border-radius: var(--border-radius-sm);
        }

        .combobox-wrapper input::-webkit-input-placeholder {
            color: var(--color-neutral-dark);
        }

        .combobox-wrapper input::-moz-placeholder {
            color: var(--color-neutral-dark);
        }

        .combobox-wrapper input:-ms-input-placeholder {
            color: var(--color-neutral-dark);
        }

        .combobox-wrapper input::placeholder {
            color: var(--color-neutral-dark);
        }

        .left-icon {
            position: absolute;
            cursor: pointer;
            border: none;
            outline: none;
            border-radius: var(--border-radius-lg);
            left: var(--spacing-inline-xxxs);
            height: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
        }

        .left-icon svg {
            z-index: var(--z-index-300-sticky);
        }

        .search-button-submit {
            position: absolute;
            cursor: pointer;
            border: none;
            outline: none;
            border-radius: var(--border-radius-lg);
            top: 4px;
            height: 40px;
            width: 40px;
            padding: 8px;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-transition: var(--transition-duration-fast);
            transition: var(--transition-duration-fast);
            z-index: var(--z-index-1-default);
            right: 6px;
            background: transparent;
        }

        .search-button-submit:hover {
            background: var(--color-neutral-dark);
        }

        .search-button-submit:hover svg {
            color: var(--color-neutral-darkest);
        }

        .search-button-submit:focus,
        .search-button-submit:active {
            background: var(--color-secondary-medium);
        }

        .search-button-submit:focus svg,
        .search-button-submit:active svg {
            color: white !important;
        }

        .search-button-submit>svg {
            width: 24px;
            height: 24px;
            display: inline-block;
            vertical-align: sub;
            color: var(--color-neutral-darker);
            width: 24px;
            height: 24px;
        }

        .listbox {
            box-shadow: 0px 2px 12px 0px #00000024;
            width: 375px !important;
            margin: 18px 0 0 0;
            border-radius: var(--border-radius-sm);
        }

        .result {
            width: 100%;
        }

        .result:first-of-type {
            border-top-left-radius: var(--border-radius-sm);
            border-top-right-radius: var(--border-radius-sm);
        }

        .result:first-of-type .listing-suggestion-item:focus {
            outline: none;
            border-top-left-radius: var(--border-radius-sm);
            border-top-right-radius: var(--border-radius-sm);
        }

        .result:last-of-type {
            border-bottom-left-radius: var(--border-radius-sm);
            border-bottom-right-radius: var(--border-radius-sm);
        }

        .result:last-of-type .listing-suggestion-item:focus {
            outline: none;
            border-bottom-left-radius: var(--border-radius-sm);
            border-bottom-right-radius: var(--border-radius-sm);
        }

        .listing-suggestion-item {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            width: 100%;
            padding: 12px 18px;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: start;
            -webkit-justify-content: flex-start;
            -ms-flex-pack: start;
            justify-content: flex-start;
        }

        .listing-suggestion-item:hover,
        .listing-suggestion-item:visited,
        .listing-suggestion-item:link,
        .listing-suggestion-item:active {
            -webkit-text-decoration: none !important;
            text-decoration: none !important;
        }

        .listing-suggestion-item:hover {
            background: var(--color-neutral-light);
        }

        .listing-suggestion-item:focus {
            -webkit-text-decoration: none !important;
            text-decoration: none !important;
            outline: none;
            background: var(--color-neutral-light);
        }

        .listing-suggestion-item__icon {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            padding-right: 17px;
            color: #d2d2d2;
        }

        .listing-suggestion-item__icon>img {
            max-width: 20px;
            opacity: 0.4;
        }

        .listing-suggestion-item__icon.close {
            padding: 0;
        }

        .listing-suggestion-item__text {
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
        }

        .history-text {
            color: var(--color-neutral-darkest);
            line-height: 20px;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
        }

        .suggestion-query {
            position: left;
            color: var(--color-neutral-darkest);
        }

        .suggestion-category {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-wrap: nowrap;
            -ms-flex-wrap: nowrap;
            flex-wrap: nowrap;
            padding-top: 4px;
        }

        .suggestion-category__prefix {
            color: #999;
            padding-right: 4px;
        }

        .suggestion-category__name {
            position: left;
            color: #6e0ad6;
            font-weight: 600;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
        }

        /* sc-component-id: sc-iQtOjA */
        .dDlaSX {
            position: relative;
        }

        /* sc-component-id: sc-fHxwqH */
        .cRTeXi .has-action-element {
            padding-right: 73px;
        }

        /* sc-component-id: ad__sc-1rbejcw-0 */
        .kxFGLZ {
            height: 50px;
            position: fixed;
            top: -60px;
            left: 0;
            width: 100vw;
            text-align: center;
            z-index: 10;
            -webkit-transition: all ease 0.3s;
            transition: all ease 0.3s;
        }

        .kxFGLZ.pinned {
            -webkit-transform: translateY(60px);
            -ms-transform: translateY(60px);
            transform: translateY(60px);
        }

        /* sc-component-id: sc-iiUIRa */
        .hnwyzW {
            max-width: 1140px;
            margin: auto;
        }

        /* sc-component-id: sc-hgRTRy */
        .jmFVhT {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            margin-top: var(--spacing-7);
            margin-bottom: var(--spacing-3);
        }

        @media all and (max-width: 1075px) {
            .jmFVhT {
                margin: var(--spacing-3) 0;
                -webkit-flex-direction: column;
                -ms-flex-direction: column;
                flex-direction: column;
            }
        }

        /* sc-component-id: sc-iIHSe */
        .dUaBHR {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-pack: justify;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            margin-top: var(--spacing-4);
            margin-bottom: var(--spacing-5);
        }

        @media all and (max-width: 1075px) {
            .dUaBHR {
                text-align: center;
                row-gap: var(--spacing-2);
            }
        }

        /* sc-component-id: sc-gldTML */
        .dnCYjr {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex: 1 1 0%;
            -ms-flex: 1 1 0%;
            flex: 1 1 0%;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: start;
            -webkit-justify-content: flex-start;
            -ms-flex-pack: start;
            justify-content: flex-start;
            -webkit-column-gap: var(--spacing-4);
            column-gap: var(--spacing-4);
        }

        @media all and (max-width: 1075px) {
            .dnCYjr {
                -webkit-flex-direction: column;
                -ms-flex-direction: column;
                flex-direction: column;
                row-gap: var(--spacing-2);
            }
        }

        /* sc-component-id: sc-feryYK */
        .iJlLnv {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-box-pack: end;
            -webkit-justify-content: flex-end;
            -ms-flex-pack: end;
            justify-content: flex-end;
            -webkit-column-gap: var(--spacing-4);
            column-gap: var(--spacing-4);
        }

        @media all and (max-width: 1075px) {
            .iJlLnv {
                -webkit-box-pack: center;
                -webkit-justify-content: center;
                -ms-flex-pack: center;
                justify-content: center;
                margin-top: 24px;
                -webkit-column-gap: var(--spacing-1);
                column-gap: 8px;
            }
        }

        .iJlLnv {
            display: flex;
            flex-direction: row;
            -webkit-box-pack: end;
            justify-content: flex-end;
            column-gap: var(--spacing-4);
        }

        /* sc-component-id: sc-cJOK */
        .gNKPOC {
            display: block;
        }

        /* sc-component-id: sc-ccSCjj */
        .deOajc {
            display: block;
        }

        /* sc-component-id: sc-jKmXuR */
        .fKHYVG {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            height: 17px;
            width: 40px;
            margin-left: -200px;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
        }

        /* sc-component-id: sc-bYwvMP */
        .kuPRsh {
            padding: var(--spacing-1);
            border-radius: 100%;
            -webkit-transition: all ease 0.3s;
            transition: all ease 0.3s;
        }

        .kuPRsh:hover svg,
        .kuPRsh:active svg {
            color: var(--color-neutral-70);
        }

        .kuPRsh:hover,
        .kuPRsh:active {
            background-color: rgb(58, 89, 152);
        }

        /* sc-component-id: sc-hUMlYv */
        .bttLbO {
            padding: var(--spacing-1);
            border-radius: 100%;
            -webkit-transition: all ease 0.3s;
            transition: all ease 0.3s;
        }

        .bttLbO:hover svg,
        .bttLbO:active svg {
            color: var(--color-neutral-70);
        }

        .bttLbO:hover,
        .bttLbO:active {
            background-color: rgb(255, 0, 0);
        }

        /* sc-component-id: sc-ESoVU */
        .eSaKqR {
            padding: var(--spacing-1);
            border-radius: 100%;
            -webkit-transition: all ease 0.3s;
            transition: all ease 0.3s;
        }

        .eSaKqR:hover svg,
        .eSaKqR:active svg {
            color: var(--color-neutral-70);
        }

        .eSaKqR:hover,
        .eSaKqR:active {
            background-color: rgb(0, 132, 191);
        }

        /* sc-component-id: sc-kkbgRg */
        .YPcue {
            padding: var(--spacing-1);
            border-radius: 100%;
            -webkit-transition: all ease 0.3s;
            transition: all ease 0.3s;
        }

        .YPcue:hover svg,
        .YPcue:active svg {
            color: var(--color-neutral-70);
        }

        .YPcue:hover,
        .YPcue:active {
            background-color: rgb(225, 48, 108);
        }

        /* sc-component-id: sc-hRmvpr */
        .iVEeUd {
            padding: var(--spacing-1);
            border-radius: 100%;
            -webkit-transition: all ease 0.3s;
            transition: all ease 0.3s;
        }

        .iVEeUd:hover svg,
        .iVEeUd:active svg {
            color: var(--color-neutral-70);
        }

        .iVEeUd:hover,
        .iVEeUd:active {
            background-color: rgb(29, 161, 242);
        }

        /* sc-component-id: sc-cZBZkQ */
        .gdTffh {
            -webkit-clip: rect(1px, 1px, 1px, 1px);
            clip: rect(1px, 1px, 1px, 1px);
            height: 1px;
            overflow: hidden;
            position: absolute;
            white-space: nowrap;
            width: 1px;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
        }

        /* sc-component-id: ad__c9d34d-0 */
        .hPDVvz {
            max-width: 100%;
            max-height: 35px;
        }

        /* sc-component-id: ad__hb5mou-0 */
        .jRULlV {
            background-color: #f9f9f9;
            padding: 0px;
            padding-top: 0;
            overflow: hidden;
            margin: -24px;
        }

        /* sc-component-id: ad__sc-18p038x-2 */
        .djeeke {
            display: block;
        }

        @media (min-width: 116.82em) {
            .djeeke {
                display: block;
                vertical-align: top;
            }
        }

        /* sc-component-id: ad__sc-18p038x-3 */
        @media (min-width: 116.82em) {
            .GYHge {
                display: -webkit-box;
                display: -webkit-flex;
                display: -ms-flexbox;
                display: flex;
                -webkit-box-pack: center;
                -webkit-justify-content: center;
                -ms-flex-pack: center;
                justify-content: center;
            }
        }

        /* sc-component-id: ad__sc-18p038x-4 */
        .brSEGL {
            display: none;
        }

        @media (min-width: 116.82em) {
            .brSEGL {
                display: block;
                vertical-align: top;
                min-width: 300px;
            }
        }

        /* sc-component-id: ad__sc-10rz2dk-0 */
        .hbnuUo {
            font-size: var(--font-size-md);
        }

        /* sc-component-id: ad__sc-10rz2dk-1 */
        .biydSK {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            margin-top: 18px;
            color: var(--color-neutral-130);
        }

        /* sc-component-id: ad__sc-10rz2dk-2 */
        .fxAfax {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            margin-left: 12px;
        }

        /* sc-component-id: ad__sc-346qe7-0 */
        .dZYxLS {
            width: 100%;
            display: grid;
            grid-template-columns: 2;
        }

        /* sc-component-id: ad__sc-346qe7-1 */
        .fEOdsZ {
            padding: 0 14px;
            width: 100%;
            margin-top: 8px;
            max-height: 48px;
        }

        .fEOdsZ svg {
            width: 24px;
            height: 24px;
            margin-left: 0;
            margin-right: 8px;
        }

        @media screen and (min-width: 640px) {
            .fEOdsZ {
                margin: 0;
            }
        }

        /* sc-component-id: ad__sc-346qe7-2 */
        .hWtUxe {
            color: var(--color-primary-100);
            font-weight: 600;
            line-height: var(--font-lineheight-supertight);
        }

        /* sc-component-id: ad__sc-3dvoaf-0 */
        .fYFVsJ {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            gap: 8px;
        }

        @media screen and (min-width: 640px) {
            .fYFVsJ {
                gap: 16px;
                width: 100%;
                display: grid;
                grid-template-columns: repeat(3, 1fr);
            }
        }

        /* sc-component-id: ad__sc-3dvoaf-1 */
        .bObnXG {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            color: var(--color-neutral-130);
            font-size: var(--font-size-xs);
            line-height: var(--font-lineheight-superdistant);
            word-break: break-word;
            font-family: var(--font-family);
        }

        @media screen and (min-width: 640px) {
            .bObnXG {
                -webkit-flex-direction: column;
                -ms-flex-direction: column;
                flex-direction: column;
            }
        }

        /* sc-component-id: ad__sc-3dvoaf-2 */
        .eDQOKf {
            font-weight: var(--font-weight-light);
        }

        /* sc-component-id: ad__sc-3dvoaf-3 */
        .fLZtzz {
            font-weight: var(--font-weight-bold);
        }

        /* sc-component-id: ad__sskx8g-0 */
        .gZALTo {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
        }

        /* sc-component-id: ad__sskx8g-1 */
        .fDwPLR {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-align-items: flex-start;
            -webkit-box-align: flex-start;
            -ms-flex-align: flex-start;
            align-items: flex-start;
        }

        /* sc-component-id: ad__sskx8g-2 */
        .hYUUEb {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-align-items: baseline;
            -webkit-box-align: baseline;
            -ms-flex-align: baseline;
            align-items: baseline;
        }

        /* sc-component-id: ad__sskx8g-3 */
        .inLRcV {
            font-size: var(--font-size-xl);
            margin-right: var(--spacing-1);
            font-weight: var(--font-weight-bold);
        }

        @media screen and (min-width: 640px) {
            .inLRcV {
                font-size: var(--font-size-xxl);
                font-weight: var(--font-weight-semibold);
            }
        }

        /* sc-component-id: ad__n916xm-0 */
        .ksnvTC {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
        }

        /* sc-component-id: ad__n916xm-1 */
        .dtnAeD {
            width: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
        }

        @media screen and (min-width: 640px) {
            .dtnAeD {
                -webkit-flex-direction: row-reverse;
                -ms-flex-direction: row-reverse;
                flex-direction: row-reverse;
                -webkit-box-pack: end;
                -webkit-justify-content: flex-end;
                -ms-flex-pack: end;
                justify-content: flex-end;
                -webkit-align-items: center;
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center;
                gap: 0;
            }
        }

        /* sc-component-id: ad__n916xm-3 */
        .vviKI {
            font-size: var(--font-size-xxl);
            margin-right: var(--spacing-1);
        }

        /* sc-component-id: ad__sc-2iplj6-0 */
        @media screen and (min-width: 640px) {
            .bWKAzL {
                display: grid;
                grid-template-columns: 1fr 230px;
            }
        }

        /* sc-component-id: ad__sc-2iplj6-1 */
        .ijmwZK {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            gap: 8px;
            width: 100%;
        }

        @media screen and (min-width: 640px) {
            .ijmwZK {
                -webkit-flex-direction: row;
                -ms-flex-direction: row;
                flex-direction: row;
                gap: 48px;
            }
        }

        /* sc-component-id: ad__sc-2iplj6-2 */
        .hPteUV {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
        }

        @media screen and (min-width: 640px) {
            .hPteUV {
                -webkit-flex-direction: column-reverse;
                -ms-flex-direction: column-reverse;
                flex-direction: column-reverse;
                -webkit-box-pack: end;
                -webkit-justify-content: end;
                -ms-flex-pack: end;
                justify-content: end;
            }
        }

        /* sc-component-id: ad__sc-2iplj6-3 */
        @media screen and (min-width: 640px) {
            .xIkHt {
                font-size: var(--font-size-sm);
            }
        }

        /* sc-component-id: ad__sc-2iplj6-4 */
        .GSDrY {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            gap: 8px;
        }

        @media screen and (min-width: 640px) {
            .GSDrY {
                -webkit-flex-direction: column;
                -ms-flex-direction: column;
                flex-direction: column;
                -webkit-align-items: flex-start;
                -webkit-box-align: flex-start;
                -ms-flex-align: flex-start;
                align-items: flex-start;
                gap: 0;
            }
        }

        /* sc-component-id: ad__sc-2iplj6-5 */
        .jPpOmb {
            color: var(--color-neutral-120);
            -webkit-text-decoration: line-through;
            text-decoration: line-through;
            font-size: var(--font-size-xxxs);
        }

        @media screen and (min-width: 640px) {
            .jPpOmb {
                font-size: var(--font-size-xs);
            }
        }

        /* sc-component-id: ad__sc-1yh67o8-0 */
        .itMgov {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            padding: var(--spacing-2) var(--spacing-3);
            box-sizing: border-box;
            border: var(--border-width-hairline) solid #E5E5E5;
            border-radius: var(--border-radius-sm);
        }

        /* sc-component-id: ad__sc-1yh67o8-1 */
        .iTFpfD {
            margin: var(--spacing-1);
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            gap: var(--spacing-1-5);
        }

        @media screen and (min-width: 640px) {
            .iTFpfD {
                -webkit-flex-direction: row;
                -ms-flex-direction: row;
                flex-direction: row;
            }
        }

        /* sc-component-id: ad__sc-1yh67o8-2 */
        .dUSUNf {
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            text-align: center;
        }

        @media screen and (min-width: 640px) {
            .dUSUNf {
                text-align: left;
            }
        }

        /* sc-component-id: ad__sc-1yh67o8-3 */
        .dRwohx {
            font-weight: var(--font-weight-regular);
            text-align: center;
            font-size: var(--font-size-xxs);
            color: var(--color-neutral-120);
        }

        /* sc-component-id: ad__sc-1x4pdhw-0 */
        .kwtiVV {
            font-size: var(--font-size-md);
        }

        /* sc-component-id: ad__sc-1x4pdhw-1 */
        .deKSko {
            display: grid;
            grid-template-columns: 1fr 1fr;
            row-gap: var(--spacing-3);
            margin-left: var(--spacing-1);
        }

        @media screen and (min-width: 640px) {
            .deKSko {
                grid-template-columns: 1fr 1fr 1fr;
                margin: 0;
            }
        }

        /* sc-component-id: ad__sc-1x4pdhw-2 */
        .cbkVdr {
            max-width: 152px;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            gap: var(--spacing-1-5);
            margin-right: var(--spacing-1-5);
        }

        /* sc-component-id: ad__sc-1x4pdhw-3 */
        .WuffR {
            font-weight: var(--font-weight-regular);
            font-size: var(--font-size-xs);
            color: var(--color-neutral-130);
        }

        /* sc-component-id: ad__sc-14o8i5t-0 */
        .jQovyr {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            background-color: var(--color-neutral-lighter);
            border-radius: var(--border-radius-sm);
            padding: var(--spacing-2);
            gap: var(--spacing-2);
            overflow: hidden;
            -webkit-align-items: flex-start;
            -webkit-box-align: flex-start;
            -ms-flex-align: flex-start;
            align-items: flex-start;
        }

        /* sc-component-id: ad__j3yxk4-0 */
        .eEAacy {
            padding: 0 4px;
        }

        @media (min-width: 52.5em) {
            .eEAacy {
                font-size: var(--font-size-xxxs);
                line-height: var(--font-lineheight-supertight);
            }
        }

        /* sc-component-id: sc-1pyqnf3-0 */
        .iGVCNZ {
            padding: 4px 8px;
            background-color: #24A148;
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            border-radius: 4px 0;
        }

        .besrdH {
            padding: 4px 8px;
            background-color: #24A148;
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            border-top-left-radius: 4px;
        }

        @media (min-width: 52.5em) {
            .besrdH {
                border-top-left-radius: 8px;
            }
        }

        /* sc-component-id: sc-1pyqnf3-1 */
        .deEyaB {
            display: inline-block;
            margin-right: 8px;
            height: 16px;
        }

        /* sc-component-id: sc-1pyqnf3-2 */
        .eaBsBz {
            white-space: nowrap;
            word-break: normal;
        }

        /* sc-component-id: VehicleReportLabelContainer__VehicleReportLabelWrapper-sra2we-0 */
        .eCmoFo {
            display: inline-block;
            margin-left: auto;
        }

        /* sc-component-id: ad__lkx530-0 */
        .fEhNSb {
            text-align: center;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            margin-left: calc(var(--spacing-2) * -1);
            margin-right: calc(var(--spacing-2) * -1);
        }

        @media (min-width: 45em) {
            .fEhNSb {
                margin-left: calc(var(--spacing-3) * -1);
                margin-right: calc(var(--spacing-3) * -1);
            }
        }

        @media (min-width: 52.5em) {
            .fEhNSb {
                margin-left: 0;
                margin-right: 0;
            }
        }

        /* sc-component-id: ad__lkx530-1 */
        .iPguLk {
            min-width: 100%;
            max-height: 280px;
            background-color: var(--color-neutral-100);
            position: relative;
            font-size: 0;
            vertical-align: middle;
        }

        /* sc-component-id: ad__lkx530-2 */
        .AkodD {
            white-space: nowrap;
            overflow: hidden;
            overflow-x: scroll;
            -webkit-transform: translateZ(0);
            -webkit-transform: translateZ(0);
            -ms-transform: translateZ(0);
            transform: translateZ(0);
            -webkit-overflow-scrolling: touch;
            -webkit-scroll-snap-points-x: repeat(100%);
            -ms-scroll-snap-points-x: repeat(100%);
            -webkit-scroll-snap-points-x: repeat(100%);
            -moz-scroll-snap-points-x: repeat(100%);
            -ms-scroll-snap-points-x: repeat(100%);
            scroll-snap-points-x: repeat(100%);
            -webkit-scroll-snap-type: x mandatory;
            -ms-scroll-snap-type: x mandatory;
            -webkit-scroll-snap-type: x mandatory;
            -moz-scroll-snap-type: x mandatory;
            -ms-scroll-snap-type: x mandatory;
            scroll-snap-type: x mandatory;
            -ms-overflow-style: none;
            -webkit-transition: all 100ms ease-out;
            transition: all 100ms ease-out;
            -webkit-scroll-snap-destination: 100% 100%;
            -ms-scroll-snap-destination: 100% 100%;
            -webkit-scroll-snap-destination: 100% 100%;
            -moz-scroll-snap-destination: 100% 100%;
            -ms-scroll-snap-destination: 100% 100%;
            scroll-snap-destination: 100% 100%;
            -webkit-scroll-behaviour: smooth;
            -moz-scroll-behaviour: smooth;
            -ms-scroll-behaviour: smooth;
            scroll-behaviour: smooth;
            min-height: 280px;
        }

        .AkodD::-webkit-scrollbar {
            display: none;
            width: 0 !important;
        }

        /* sc-component-id: ad__lkx530-4 */
        .iZsDPD {
            display: inline-block;
            vertical-align: middle;
            text-align: center;
            width: 100%;
            max-height: 280px;
            -webkit-scroll-snap-destination: 50% 50%;
            -ms-scroll-snap-destination: 50% 50%;
            -webkit-scroll-snap-destination: 50% 50%;
            -moz-scroll-snap-destination: 50% 50%;
            -ms-scroll-snap-destination: 50% 50%;
            scroll-snap-destination: 50% 50%;
            -webkit-scroll-snap-align: center none;
            -moz-scroll-snap-align: center none;
            -ms-scroll-snap-align: center none;
            scroll-snap-align: center none;
        }

        .iZsDPD img,
        .iZsDPD .image {
            max-width: 100%;
            max-height: 280px;
            margin: 0 auto;
        }

        .iZsDPD #no-photo-placeholder {
            width: 48px;
            height: 48px;
        }

        /* sc-component-id: ad__lkx530-5 */
        .lnINmz {
            right: auto;
            top: auto;
            left: 50%;
            bottom: 16px;
            -webkit-transform: translateX(-50%);
            -ms-transform: translateX(-50%);
            transform: translateX(-50%);
            border-radius: 4px;
            background-color: var—(color-neutral-130);
            padding: 5px 10px;
            position: absolute;
            z-index: 0;
            opacity: 0.3;
        }

        .lnINmz * {
            opacity: 0.3;
        }

        /* sc-component-id: ad__lkx530-6 */
        .iNpWBP {
            position: absolute;
            padding: 50px 15px;
            top: 50%;
            -webkit-transform: translateY(-50%);
            -ms-transform: translateY(-50%);
            transform: translateY(-50%);
            padding: 0;
            left: 0;
        }

        .iNpWBP svg {
            -webkit-filter: drop-shadow(0 1px 0px #b4b4b4);
            filter: drop-shadow(0 1px 0px #b4b4b4);
        }

        .gSjrEi {
            position: absolute;
            padding: 50px 15px;
            top: 50%;
            -webkit-transform: translateY(-50%);
            -ms-transform: translateY(-50%);
            transform: translateY(-50%);
            padding: 0;
            right: 0;
        }

        .gSjrEi svg {
            -webkit-filter: drop-shadow(0 1px 0px #b4b4b4);
            filter: drop-shadow(0 1px 0px #b4b4b4);
        }

        /* sc-component-id: ad__sc-1nnoc6t-1 */
        .hGbNNN {
            position: absolute;
            bottom: 0px;
            z-index: 2;
            right: 0px;
        }

        /* sc-component-id: ad__sc-28oze1-0 */
        .fOGggn {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            position: relative;
        }

        /* sc-component-id: ad__sc-28oze1-1 */
        .kiJqwC {
            text-align: center;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            margin-left: calc(var(--spacing-2) * -1);
            margin-right: calc(var(--spacing-2) * -1);
        }

        @media (min-width: 45em) {
            .kiJqwC {
                margin-left: calc(var(--spacing-3) * -1);
                margin-right: calc(var(--spacing-3) * -1);
            }
        }

        @media (min-width: 52.5em) {
            .kiJqwC {
                margin-left: 0;
                margin-right: 0;
            }
        }

        /* sc-component-id: ad__sc-28oze1-2 */
        .hpprOV {
            min-width: 100%;
            max-height: 402px;
            background-color: var(--color-neutral-100);
            position: relative;
            font-size: 0;
            vertical-align: middle;
            border-radius: 8px;
            overflow: hidden;
        }

        /* sc-component-id: ad__sc-28oze1-3 */
        .hlDnNa {
            white-space: nowrap;
            overflow: hidden;
            -webkit-transform: translateZ(0);
            -webkit-transform: translateZ(0);
            -ms-transform: translateZ(0);
            transform: translateZ(0);
            -webkit-transition: all 100ms ease-out;
            transition: all 100ms ease-out;
            -webkit-scroll-behavior: smooth;
            -moz-scroll-behavior: smooth;
            -ms-scroll-behavior: smooth;
            scroll-behavior: smooth;
            min-height: 402px;
            border-radius: 8px;
        }

        /* sc-component-id: ad__sc-28oze1-5 */
        .iyYINE {
            display: inline-block;
            vertical-align: middle;
            text-align: center;
            overflow: hidden;
            width: 100%;
            max-height: 402px;
            background-color: var(--color-neutral-100);
        }

        .iyYINE .image {
            width: 100%;
            max-height: 402px;
            object-fit: contain;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            position: absolute;
            bottom: 50%;
            right: 50%;
            -webkit-transform: translate(50%, 50%);
            -ms-transform: translate(50%, 50%);
            transform: translate(50%, 50%);
        }

        .iyYINE .imageIE {
            width: auto !important;
        }

        .iyYINE #no-photo-placeholder {
            width: 48px;
            height: 48px;
            top: 50%;
            bottom: 50%;
            left: 50%;
            right: 50%;
            position: absolute;
            -webkit-transform: translate(-50%, -50%);
            -ms-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%);
        }

        /* sc-component-id: ad__sc-28oze1-7 */
        .fKCszy {
            position: absolute;
            top: 50%;
            -webkit-transform: translateY(-50%);
            -ms-transform: translateY(-50%);
            transform: translateY(-50%);
            left: 16px;
        }

        .fUTtuG {
            position: absolute;
            top: 50%;
            -webkit-transform: translateY(-50%);
            -ms-transform: translateY(-50%);
            transform: translateY(-50%);
            right: 16px;
        }

        /* sc-component-id: ad__sc-28oze1-8 */
        .byItdH {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            cursor: pointer;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            box-shadow: 0 2px 4px -1px rgba(0, 0, 0, 0.2), 0 1px 10px 0 rgba(0, 0, 0, 0.12), 0 4px 5px 0 rgba(0, 0, 0, 0.14);
            background-color: var(--color-neutral-70);
        }

        .byItdH:hover {
            background-color: var(--color-neutral-100);
        }

        /* sc-component-id: ad__sc-28oze1-9 */
        .kPuCIR {
            position: relative;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        /* sc-component-id: ad__sc-28oze1-10 */
        .bfPQHL {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            margin-left: auto;
            margin-right: auto;
            list-style: none;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            margin: 0;
            padding: 0;
            margin-left: 8px;
            height: 402px;
            overflow: hidden;
            -webkit-transition: all 450ms ease-out;
            transition: all 450ms ease-out;
            -webkit-scroll-behavior: smooth;
            -moz-scroll-behavior: smooth;
            -ms-scroll-behavior: smooth;
            scroll-behavior: smooth;
        }

        /* sc-component-id: ad__sc-28oze1-11 */
        .cQXRoo {
            position: relative;
            line-height: 0;
            padding: 0 0 8px;
        }

        .cQXRoo:last-child {
            padding-bottom: 0;
        }

        /* sc-component-id: ad__sc-28oze1-12 */
        .lmUZJN {
            height: 56px;
            width: 56px;
            border-radius: 4px;
            overflow: hidden;
            position: relative;
            will-change: opacity;
            cursor: pointer;
            -webkit-transition: all 0.2s ease-in-out;
            transition: all 0.2s ease-in-out;
            opacity: 1;
        }

        .kCiVOw {
            height: 56px;
            width: 56px;
            border-radius: 4px;
            overflow: hidden;
            position: relative;
            will-change: opacity;
            cursor: pointer;
            -webkit-transition: all 0.2s ease-in-out;
            transition: all 0.2s ease-in-out;
            opacity: 0.64;
        }

        /* sc-component-id: ad__sc-28oze1-13 */
        .ktcdiJ {
            position: absolute;
            left: 50%;
            top: 50%;
            -webkit-transform: translate(-50%, -50%);
            -ms-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%);
            border-radius: 4px;
            height: 100%;
            width: 100%;
            object-fit: cover;
            z-index: 2;
        }

        /* sc-component-id: ad__sc-28oze1-14 */
        .hWeNGQ {
            position: absolute;
            left: 50%;
            -webkit-transform: translateX(-50%);
            -ms-transform: translateX(-50%);
            transform: translateX(-50%);
            padding: 0;
            width: 100%;
            text-align: center;
            top: 0;
        }

        .cSPhVH {
            position: absolute;
            left: 50%;
            -webkit-transform: translateX(-50%);
            -ms-transform: translateX(-50%);
            transform: translateX(-50%);
            padding: 0;
            width: 100%;
            text-align: center;
            bottom: 0;
        }

        /* sc-component-id: ad__sc-28oze1-15 */
        .gFvSWv {
            background-color: var(--color-neutral-70);
            cursor: pointer;
            line-height: 0;
        }

        /* sc-component-id: ad__sc-28oze1-16 */
        .biLqYe {
            background-image: url(https://placekitten.com/g/400/300);
            background-repeat: no-repeat;
            background-size: cover;
            background-position: 50%;
            -webkit-filter: blur(32px);
            filter: blur(32px);
            position: fixed;
            height: 120%;
            width: 120%;
            -webkit-transform: translate(-32px, -32px);
            -ms-transform: translate(-32px, -32px);
            transform: translate(-32px, -32px);
        }

        /* sc-component-id: ad__sc-1ro88on-1 */
        .PQyCd {
            position: absolute;
            bottom: 0px;
            z-index: 2;
            right: 64px;
        }

        /* sc-component-id: sc-keyframes-iLDseQ */
        @-webkit-keyframes iLDseQ {
            from {
                -webkit-transform: translateY(0%);
                -ms-transform: translateY(0%);
                transform: translateY(0%);
            }

            to {
                -webkit-transform: translateY(100%);
                -ms-transform: translateY(100%);
                transform: translateY(100%);
            }
        }

        @keyframes iLDseQ {
            from {
                -webkit-transform: translateY(0%);
                -ms-transform: translateY(0%);
                transform: translateY(0%);
            }

            to {
                -webkit-transform: translateY(100%);
                -ms-transform: translateY(100%);
                transform: translateY(100%);
            }
        }

        .dtNsyG {
            flex-direction: row;
            flex: 1 1 0%;
            min-height: 6px;
            max-height: 6px;
            position: relative;
            display: flex;
            -webkit-box-pack: center;
            justify-content: center;
            -webkit-box-align: center;
            align-items: center;
            height: 7px;
            border-radius: 5px 5px 0px 0px;
            background-color: rgb(16, 206, 100);
            z-index: 1;
            margin-bottom: -5px;
        }

        .iPLBto {
            background-color: rgb(249, 249, 249);
            border: 1px solid rgb(216, 216, 216);
            border-radius: 4px;
            padding: 16px 0px;
            display: flex;
            flex-direction: column;
            -webkit-box-pack: center;
            justify-content: center;
            -webkit-box-align: center;
            align-items: center;
        }

        .zdamc {
            display: flex;
            flex-direction: column;
            margin-bottom: 10px;
            width: 100%;
        }

        .bTGRVC {
            margin-bottom: 4px;
            display: flex;
            -webkit-box-pack: center;
            justify-content: center;
        }

        .djuouJ {
            font-size: 12px;
            font-weight: 500;
            color: rgb(153, 153, 153);
            display: flex;
            -webkit-box-pack: center;
            justify-content: center;
        }

        .zdamc {
            display: flex;
            flex-direction: column;
            margin-bottom: 10px;
            width: 100%;
        }

        .dxYbgB {
            position: relative;
            display: flex;
            -webkit-box-align: center;
            align-items: center;
            flex-direction: row;
        }

        eIyThw {
            font-size: 14px;
            color: rgb(74, 74, 74);
        }

        cQYZgc {
            margin-left: 8px;
            position: relative;
        }

        .lehJrf {
            box-sizing: border-box;
        }

        .ihkrEK {
            margin-left: 8px;
            position: relative;
        }

        .lehJrf {
            box-sizing: border-box;
        }

        .iGGLrM {
            margin-left: 8px;
            position: relative;
        }

        .lehJrf {
            box-sizing: border-box;
        }

        .iGGLrM {
            margin-left: 8px;
            position: relative;
        }

        .dxYbgB {
            position: relative;
            display: flex;
            -webkit-box-align: center;
            align-items: center;
            flex-direction: row;
        }

        .lehJrf {
            box-sizing: border-box;
        }

        .dozYtX {
            margin-bottom: 8px;
            display: flex;
        }

        .lehJrf {
            box-sizing: border-box;
        }

        .iKTsQ {
            position: relative;
            display: flex;
            -webkit-box-align: center;
            align-items: center;
        }

        .lehJrf {
            box-sizing: border-box;
        }

        .inSmub {
            font-size: 12px;
            font-weight: 500;
            color: rgb(153, 153, 153);
        }

        .fJeHbn {
            color: rgb(74, 74, 74);
            line-height: 24px;
            font-size: 14px;
            font-weight: 400;
            font-family: "Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;
            margin: 5px;
        }

        .iKTsQ {
            position: relative;
            display: flex;
            -webkit-box-align: center;
            align-items: center;
        }

        .ivRuca {
            display: flex;
            -webkit-box-pack: center;
            justify-content: center;
            margin-bottom: 8px;
        }

        .hgIHch {
            position: relative;
            display: flex;
            -webkit-box-align: center;
            align-items: center;
            flex-direction: row;
        }

        .gdnQCF {
            display: inline-flex;
            margin-right: 8px;
        }

        .lgiMsT {
            display: flex;
            flex-direction: column;
        }

        .yNjKg {
            display: inline-flex;
            -webkit-box-pack: center;
            justify-content: center;
            -webkit-box-align: center;
            align-items: center;
            cursor: pointer;
            outline: none;
            text-decoration: none;
            font-size: var(--font-size-xxxs);
            line-height: var(--font-lineheight-medium);
            color: var(--link-color-main-base);
            font-family: var(--font-family);
            font-weight: var(--font-weight-semibold);

        }

        .engNnN {
            width: 100%;
            height: 40px;
            margin-top: 8px;
            margin-bottom: 8px;

            @media (min-width: 1em) and (max-width: 52.4375em) .cZVxfz {
                position: fixed;
                bottom: 0px;
                left: 0px;
                right: 0px;
                z-index: 4;
            }

            .jEORtG {
                position: relative;
                color: var(--color-neutral-light);
            }

            .hXhrXr {
                display: inline-block;
                position: absolute;
                border-radius: var(--border-radius-sm);
                filter: drop-shadow(var(--shadow-level-1));
                background-color: var(--color-secondary-medium);
                padding: var(--spacing-2);
                right: calc(100% + 17px);
                bottom: 50%;
                transform: translateY(50%);
            }

            .jOwvKY {
                position: absolute;
                right: -17px;
                bottom: 50%;
                transform: translateY(50%) rotate(-90deg);
                fill: var(--color-secondary-medium);
            }

            .LHLPk {
                width: 236px;
            }

            .gJQzdb {
                display: flex;
                -webkit-box-pack: justify;
                justify-content: space-between;
            }

            .itofcO {
                display: block;
                margin: 0px;
                padding: 0px;
                font-family: var(--font-family);
                word-break: break-word;
                font-weight: var(--font-weight-bold);
                line-height: var(--font-lineheight-distant);
                font-size: var(--font-size-xxs);
                font-style: normal;
                color: var(--color-neutral-lightest);
            }

            .ltzVT {
                display: flex;
                -webkit-box-pack: center;
                justify-content: center;
                margin-bottom: 4px;
                margin-top: 0px;
                width: 100%;
            }

            .bDqKgU {
                margin-top: 16px);
                -webkit-box-pack: center;
                justify-content: center;
                -webkit-box-align: center;
                align-items: center;
                background: #f9f9f9;
                border: 1px solid #d2d2d2;
                border-radius: 4px);
            }

            .bYPvYq {
                display: flex;
            }

            .biBiOH {
                max-width: 328px;
                max-height: 217px;
                padding: 12px;
                background: #f9f9f9;
            }

            .fDflfl {
                display: flex;
                flex-wrap: wrap;
                -webkit-box-pack: center;
                justify-content: center;
                place-items: center;
                -webkit-box-align: center;
                margin-bottom: var(--spacing-stack-xxxs);
            }

            .dFDcEs {
                display: block;
                margin: 0px;
                padding: 0px;
                font-family: var(--font-family);
                word-break: break-word;
                font-weight: var(--font-weight-regular);
                line-height: var(--font-lineheight-distant);
                font-size: var(--font-size-xxs);
                font-style: normal;
                color: var(--color-neutral-darkest);
            }

            .fDflfl {
                display: flex;
                flex-wrap: wrap;
                -webkit-box-pack: center;
                justify-content: center;
                place-items: center;
                -webkit-box-align: center;
                margin-bottom: var(--spacing-stack-xxxs);
            }

            .bYPvYq {
                display: flex;
            }

            .iEwbMe {
                display: flex;
                -webkit-box-flex: 1;
                flex-grow: 1;
                flex-shrink: 1;
                width: 82px;
                height: 128px;
                flex-direction: column;
                -webkit-box-pack: center;
                justify-content: center;
                -webkit-box-align: center;
                align-items: center;
                text-align: center;
                border-right-width: var(--border-width-hairline);
                border-right-style: solid;
                border-right-color: var(--color-neutral-medium);
            }

            .SuCud {
                display: flex;
                -webkit-box-flex: 1;
                flex-grow: 1;
                flex-shrink: 1;
                width: 82px;
                height: 128px;
                flex-direction: column;
                -webkit-box-pack: center;
                justify-content: center;
                -webkit-box-align: center;
                align-items: center;
                text-align: center;
            }

            .hZMfbR {
                display: block;
                margin: 0px;
                padding: 0px;
                font-style: normal;
                font-family: var(--font-family);
                word-break: break-word;
                font-weight: var(--font-weight-regular);
                line-height: var(--font-lineheight-medium);
                font-size: var(--font-size-xxxs);
                color: var(--color-neutral-darkest);
            }

            .dpjyOE {
                display: block;
                margin-right: 0px;
                margin-bottom: 0px;
                margin-left: 0px;
                padding: 0px;
                font-family: var(--font-family);
                word-break: break-word;
                font-weight: var(--font-weight-semibold);
                line-height: var(--font-lineheight-superdistant);
                font-size: var(--font-size-xs);
                font-style: normal;
                color: var(--color-neutral-darkest);
                margin-top: var(--font-size-xxxs);
            }

            .kRxRQF {
                display: flex;
                -webkit-box-pack: center;
                justify-content: center;
                background-color: transparent;
                gap: var(--spacing-1);
            }

            .bKeMgi:not(:active) {
                transition: all 0.1s cubic-bezier(0.645, 0.045, 0.355, 1) 0s;
            }

            .bKeMgi {
                display: inline-flex;
                -webkit-box-align: center;
                align-items: center;
                -webkit-box-pack: center;
                justify-content: center;
                height: auto;
                border-radius: 24px;
                align-self: flex-start;
                flex-basis: auto;
                white-space: nowrap;
                cursor: pointer;
                box-shadow: rgba(74, 74, 74, 0.2) 0px 3px 5px 0px;
                background-color: var(--color-primary-100);
                color: rgb(255, 255, 255);
                padding: 12px;
                -webkit-tap-highlight-color: transparent;
                user-select: none;
            }

            .Tqhcg {
                width: 12px;
            }

            .gqVxRn {
                margin-right: 8px;
            }

            .cVQkQJ {
                display: block;
                margin: 0px;
                padding: 0px;
                font-family: var(--font-family);
                word-break: break-word;
                font-weight: var(--font-weight-semibold);
                line-height: var(--font-lineheight-superdistant);
                font-size: var(--font-size-xs);
                font-style: normal;
            }

            *,
            *::before,
            *::after {
                -webkit-box-sizing: border-box;
                -moz-box-sizing: border-box;
                box-sizing: border-box;
                font-family: 'Nunito Sans', 'Helvetica Neue', Helvetica, Arial, sans-serif;
                font-display: swap;
                -webkit-font-smoothing: antialiased
            }

            ul[class],
            ol[class] {
                padding: 0
            }

            body,
            h1,
            h2,
            h3,
            h4,
            p,
            figure,
            blockquote,
            dl,
            dd {
                margin: 0
            }

            ul[role='list'],
            ol[role='list'] {
                list-style: none
            }

            html:focus-within {
                scroll-behavior: smooth
            }

            body {
                min-height: 100vh;
                text-rendering: optimizeSpeed;
                -webkit-font-smoothing: antialiased;
                -moz-osx-font-smoothing: grayscale;
                line-height: 1.5
            }

            a:not([class]) {
                text-decoration-skip-ink: auto
            }

            img,
            picture {
                max-width: 100%;
                display: block
            }

            input,
            button,
            textarea,
            select {
                font: inherit
            }

            button,
            [type='button'],
            [type='reset'],
            [type='submit'] {
                -webkit-appearance: button
            }

            button::-moz-focus-inner,
            [type='button']::-moz-focus-inner,
            [type='reset']::-moz-focus-inner,
            [type='submit']::-moz-focus-inner {
                border-style: none;
                padding: 0
            }

            button:-moz-focusring,
            [type='button']:-moz-focusring,
            [type='reset']:-moz-focusring,
            [type='submit']:-moz-focusring {
                outline: 1px dotted ButtonText
            }

            @media(prefers-reduced-motion:reduce) {
                html:focus-within {
                    scroll-behavior: auto
                }

                *,
                *::before,
                *::after {
                    animation-duration: .01ms !important;
                    animation-iteration-count: 1 !important;
                    transition-duration: .01ms !important;
                    scroll-behavior: auto !important
                }
            }

            @media (min-width: 1em) .gtdIFh {
                order: 8;
            }

            .cuKJrD {
                display: flex;
                flex-direction: column;
            }

            .davdrV {
                display: block;
                margin: 0px;
                padding: 0px;
                font-style: normal;
                font-family: var(--font-family);
                word-break: break-word;
                font-weight: var(--font-weight-bold);
                line-height: var(--font-lineheight-medium);
                font-size: var(--font-size-sm);
                color: var(--color-neutral-130);
            }

            .bUfxEj {
                margin-left: -16px;
                margin-right: -16px;
            }

            .czdJJb {
                position: relative;
                margin-bottom: 32px;
            }

            .czdJJb .carousel.carousel-slider {
                overflow: initial;
            }

            .carousel.carousel-slider {
                position: relative;
                margin: 0px;
                overflow: hidden;
            }

            .carousel {
                position: relative;
                width: 100%;
            }

            carousel .slider-wrapper {
                overflow: hidden;
                margin: auto;
                width: 100%;
                transition: height 0.15s ease-in 0s;
            }

            .carousel * {
                box-sizing: border-box;
            }

            .carousel .slider-wrapper.axis-horizontal .slider {
                display: flex;
            }

            .carousel .slider.animated {
                transition: all 0.35s ease-in-out 0s;
            }

            .carousel .slider {
                margin: 0px;
                padding: 0px;
                position: relative;
                list-style: none;
                width: 100%;
            }

            .carousel .slider-wrapper.axis-horizontal .slider .slide {
                flex-flow: column;
            }

            .czdJJb .carousel .slide {
                background-color: initial;
            }

            .carousel .slide {
                min-width: 100%;
                margin: 0px;
                position: relative;
                text-align: center;
                background: rgb(0, 0, 0);
            }

            .carousel * {
                box-sizing: border-box;
            }
    </style>


    <div id="root">
        <div id="adview" class="ad__qp0wh1-2 hGvSnA">
            <div class="ad__h3us20-2 kIjqbV">
                <div></div>
            </div>
            <div style="display:flex;flex-direction:column;justify-content:center;align-items:center;min-height:;background-color:#ffffff;border-color:#e5e5e5;border-bottom-width:1px;border-bottom-style:solid;overflow-x:hidden" data-testid="adv-placeholder-adview">
                <div id="adview-page-top-pub" data-testid="adview-page-top-pub"></div>
            </div>
            <div class="ad__qp0wh1-3 hWFzQQ">
                <header id="header" data-ds-component="DS-Header" class="show-search-input sc-hqyNC hnRrUU">
                    <nav aria-label="Menu principal" class="sc-jbKcbu iCRRMm">
                        <div class="sc-dNLxif dBxJFy">
                            <div class="sc-jqCOkK aVtv">
                                <div class="sc-fjdhpX eLXScg">
                                    <a data-ds-component="DS-Link" href="##header" class="skip-link ds-primary-link sc-EHOje fVwWyK">Ir para o menu principal</a>
                                    <a data-ds-component="DS-Link" href="##main" class="skip-link ds-primary-link sc-EHOje fVwWyK">Ir para o conteúdo da página</a>
                                    <a data-ds-component="DS-Link" href="##footer" class="skip-link ds-primary-link sc-EHOje fVwWyK">Ir para o rodapé</a>
                                </div>
                                <button data-ds-component="DS-Button" aria-controls="ds-overflow-menu" aria-expanded="false" class="header-mobile-button ds-primary-link sc-jzJRlG iQExKI">
                                    <span aria-hidden="true" class="sc-fYxtnH hJtDZo">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" color="currentColor" size="24">
                                            <path fill="currentColor" fill-rule="evenodd" d="M3 12.75a.75.75 0 110-1.5h18a.75.75 0 110 1.5H3zm0-6a.75.75 0 010-1.5h18a.75.75 0 110 1.5H3zm0 12a.75.75 0 110-1.5h18a.75.75 0 110 1.5H3z"></path>
                                        </svg>
                                    </span>
                                    <span class="sc-VigVT cueDsN">Menu</span>
                                </button>
                                <a data-ds-component="DS-Link" href="#" class="ds-primary-link  sc-EHOje fVwWyK">
                                    <span class="sc-VigVT cueDsN">Página inicial</span>
                                    <span aria-hidden="true" class="sc-bbmXgH GMjXn">
                                        <svg data-ds-component="DS-LogoOLX" viewBox="0 0 40 40" class="default sc-gqjmRU jGLnOs">
                                            <g fill="none" fill-rule="evenodd">
                                                <path class="o" d="M7.579 26.294c-2.282 0-3.855-1.89-3.855-4.683 0-2.82 1.573-4.709 3.855-4.709 2.28 0 3.855 1.889 3.855 4.682 0 2.82-1.574 4.71-3.855 4.71m0 3.538c4.222 0 7.578-3.512 7.578-8.248 0-4.682-3.173-8.22-7.578-8.22C3.357 13.363 0 16.874 0 21.61c0 4.763 3.173 8.221 7.579 8.221"></path>
                                                <path class="l" d="M18.278 23.553h7.237c.499 0 .787-.292.787-.798V20.44c0-.505-.288-.798-.787-.798h-4.851V9.798c0-.505-.288-.798-.787-.798h-2.386c-.498 0-.787.293-.787.798v12.159c0 1.038.551 1.596 1.574 1.596"></path>
                                                <path class="x" d="M28.112 29.593l4.353-5.082 4.222 5.082c.367.452.839.452 1.258.08l1.705-1.517c.42-.373.472-.851.079-1.277l-4.694-5.321 4.274-4.869c.367-.426.34-.878-.078-1.277l-1.6-1.463c-.42-.4-.892-.373-1.259.08l-3.907 4.602-3.986-4.603c-.367-.425-.84-.479-1.259-.08l-1.652 1.49c-.42.4-.446.825-.053 1.278l4.354 4.868-4.747 5.348c-.393.452-.34.905.079 1.277l1.652 1.464c.42.372.891.345 1.259-.08"></path>
                                            </g>
                                        </svg>
                                    </span>
                                </a>
                                <div class="sc-ktHwxA cahgYa">
                                    <div id="oraculo" class="search-wrap-box">
                                        <div data-ds-component="DS-Autocomplete" class="sc-iQtOjA dDlaSX">
                                            <div class="combobox-wrapper">
                                                <div role="combobox" aria-controls="autocomplete-list" aria-expanded="false" aria-owns="autocomplete-list" aria-haspopup="listbox" aria-busy="false" id="searchtext-combobox" data-testid="searchtext-combobox" class="">
                                                    <div data-ds-component="DS-TextInput" class="sc-fHxwqH cRTeXi sc-feJyhm fcYJXN">
                                                        <span class="sc-iELTvK cNrgBk">
                                                            <input type="text" id="searchtext-input" aria-busy="false" aria-label="Autocomplete" aria-invalid="false" aria-errormessage="" aria-disabled="false" data-testid="searchtext-input" label="" aria-autocomplete="list" placeholder="Buscar" autocomplete="off" value="" spellcheck="false" class="sc-cmTdod iyFOQA">
                                                        </span>
                                                        <div data-ds-component="DS-Flex" class="sc-kafWEX etIOjC"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <button class="search-button-submit">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" size="24" color="currentColor">
                                                <path fill="currentColor" fill-rule="evenodd" d="M16.84 15.78l4.69 4.69a.75.75 0 01-1.06 1.06l-4.69-4.69a8.25 8.25 0 111.06-1.06zm-1.51-.564a6.75 6.75 0 10-.113.113.759.759 0 01.112-.113z"></path>
                                            </svg>
                                            <span class="sc-VigVT cueDsN">Buscar</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class="loaded  sc-uJMKN fbEBEC">
                                <ul class="desapegar sc-gGBfsJ hHrLKr">
                                    <li class="hide-on-tablet sc-jnlKLf gZakDx">
                                        <a data-ds-component="DS-Link" href="https://planoprofissional.olx.com.br/" class="header-link ds-primary-link sc-EHOje cBRYOz">
                                            <span aria-hidden="true" class="sc-fYxtnH hJtDZo">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" color="currentColor" size="24">
                                                    <path fill="currentColor" fill-rule="evenodd" d="M7.25 6.25V5A2.75 2.75 0 0110 2.25h4A2.75 2.75 0 0116.75 5v1.25H20A2.75 2.75 0 0122.75 9v10A2.75 2.75 0 0120 21.75H4A2.75 2.75 0 011.25 19V9A2.75 2.75 0 014 6.25h3.25zm1.5 0h6.5V5c0-.69-.56-1.25-1.25-1.25h-4c-.69 0-1.25.56-1.25 1.25v1.25zM4 7.75c-.69 0-1.25.56-1.25 1.25v10c0 .69.56 1.25 1.25 1.25h16c.69 0 1.25-.56 1.25-1.25V9c0-.69-.56-1.25-1.25-1.25H4z"></path>
                                                </svg>
                                            </span>
                                            <span class="sc-hEsumM cQjubG">Plano Profissional</span>
                                        </a>
                                    </li>
                                    <li class="hide-on-tablet sc-jnlKLf gZakDx">
                                        <a data-ds-component="DS-Link" href="#" class="header-link ds-primary-link sc-EHOje cBRYOz">
                                            <span aria-hidden="true" class="sc-fYxtnH hJtDZo">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" color="currentColor" size="24">
                                                    <path fill="currentColor" fill-rule="evenodd" d="M3 2.25h7a.75.75 0 01.75.75v7a.75.75 0 01-.75.75H3a.75.75 0 01-.75-.75V3A.75.75 0 013 2.25zm.75 7h5.5v-5.5h-5.5v5.5zm10.25-7h7a.75.75 0 01.75.75v7a.75.75 0 01-.75.75h-7a.75.75 0 01-.75-.75V3a.75.75 0 01.75-.75zm.75 7h5.5v-5.5h-5.5v5.5zm-.75 4h7a.75.75 0 01.75.75v7a.75.75 0 01-.75.75h-7a.75.75 0 01-.75-.75v-7a.75.75 0 01.75-.75zm.75 7h5.5v-5.5h-5.5v5.5zM3 13.25h7a.75.75 0 01.75.75v7a.75.75 0 01-.75.75H3a.75.75 0 01-.75-.75v-7a.75.75 0 01.75-.75zm.75 7h5.5v-5.5h-5.5v5.5z"></path>
                                                </svg>
                                            </span>
                                            <span class="sc-hEsumM cQjubG">Meus Anúncios</span>
                                        </a>
                                    </li>
                                    <li class="sc-jnlKLf gZakDx">
                                        <a data-ds-component="DS-Link" href="#" class="header-link ds-primary-link sc-EHOje cBRYOz">
                                            <span aria-hidden="true" class="sc-fYxtnH hJtDZo">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" color="currentColor" size="24">
                                                    <path fill="currentColor" fill-rule="evenodd" d="M20.77 15.635a9.25 9.25 0 01-8.268 5.115 9.13 9.13 0 01-3.854-.842l-5.41 1.804a.75.75 0 01-.95-.95l1.804-5.41A9.128 9.128 0 013.25 11.5a9.249 9.249 0 015.112-8.27 9.128 9.128 0 014.138-.98l.541.001c4.698.26 8.449 4.01 8.709 8.749v.5a9.127 9.127 0 01-.98 4.135zM8.464 18.39a.75.75 0 01.575.042 7.632 7.632 0 003.462.819 7.751 7.751 0 006.93-4.288 7.63 7.63 0 00.82-3.46l.001-.46C20.034 7.106 16.893 3.965 13 3.75h-.502a7.634 7.634 0 00-3.463.82 7.75 7.75 0 00-4.285 6.932 7.63 7.63 0 00.82 3.46.75.75 0 01.042.575l-1.426 4.277 4.277-1.425z"></path>
                                                </svg>
                                            </span>
                                            <span class="show-on-tablet sc-hEsumM cQjubG">Chat</span>
                                        </a>
                                    </li>
                                    <li class="sc-jnlKLf gZakDx">
                                        <a data-ds-component="DS-Link" href="#" class="header-link ds-primary-link sc-EHOje cBRYOz">
                                            <span aria-hidden="true" class="sc-fYxtnH hJtDZo">
                                                <span class="sc-tilXH afwMA" data-counter="0">
                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" color="currentColor" size="24">
                                                        <path fill="currentColor" fill-rule="evenodd" d="M22 17.75H2c-1 0-1-1.5 0-1.5A2.25 2.25 0 004.25 14V9a7.75 7.75 0 0115.5 0v5A2.25 2.25 0 0022 16.25c1 0 1 1.5 0 1.5zM18.25 14V9a6.25 6.25 0 00-12.5 0v5c0 .844-.279 1.623-.75 2.25h14a3.733 3.733 0 01-.75-2.25zm-3.871 7.376a2.75 2.75 0 01-4.758 0 .75.75 0 01.649-1.126h3.46a.75.75 0 01.649 1.126z"></path>
                                                    </svg>
                                                </span>
                                            </span>
                                            <span class="show-on-tablet sc-hEsumM cQjubG">Notificações</span>
                                        </a>
                                    </li>
                                    <li class="sc-jnlKLf gZakDx">
                                        <div data-ds-component="DS-Skeleton" aria-busy="true" width="135px" height="40px" class="profile-skeleton sc-jTzLTM hEqzYu"></div>
                                    </li>
                                    <li class="sc-jnlKLf gZakDx">
                                        <a data-testid="button-wrapper" data-ds-component="DS-Button" class="link-ad-button ds-primary-link sc-gZMcBi ehxqTE" a="" href="#" target="_blank">
                                            <div class="sc-iwsKbI hMjsjM">
                                                <span data-testid="icon-button" class="sc-htoDjs hYiizr">
                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" aria-hidden="true" color="currentColor" size="24">
                                                        <path fill="currentColor" fill-rule="evenodd" d="M12.75 11.25H19a.75.75 0 110 1.5h-6.25V19a.75.75 0 11-1.5 0v-6.25H5a.75.75 0 110-1.5h6.25V5a.75.75 0 111.5 0v6.25z"></path>
                                                    </svg>
                                                </span>
                                                <!-- -->
                                                Desapegar
                                            </div>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="sc-cIShpX ghAWfW">
                            <div id="oraculo" class="search-wrap-box">
                                <div data-ds-component="DS-Autocomplete" class="sc-iQtOjA dDlaSX">
                                    <div class="combobox-wrapper">
                                        <div role="combobox" aria-controls="autocomplete-list" aria-expanded="false" aria-owns="autocomplete-list" aria-haspopup="listbox" aria-busy="false" id="searchtext-combobox" data-testid="searchtext-combobox" class="">
                                            <div data-ds-component="DS-TextInput" class="sc-fHxwqH cRTeXi sc-feJyhm fcYJXN">
                                                <span class="sc-iELTvK cNrgBk">
                                                    <input type="text" id="searchtext-input" aria-busy="false" aria-label="Autocomplete" aria-invalid="false" aria-errormessage="" aria-disabled="false" data-testid="searchtext-input" label="" aria-autocomplete="list" placeholder="Buscar" autocomplete="off" value="" spellcheck="false" class="sc-cmTdod iyFOQA">
                                                </span>
                                                <div data-ds-component="DS-Flex" class="sc-kafWEX etIOjC"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <button class="search-button-submit">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" size="24" color="currentColor">
                                        <path fill="currentColor" fill-rule="evenodd" d="M16.84 15.78l4.69 4.69a.75.75 0 01-1.06 1.06l-4.69-4.69a8.25 8.25 0 111.06-1.06zm-1.51-.564a6.75 6.75 0 10-.113.113.759.759 0 01.112-.113z"></path>
                                    </svg>
                                    <span class="sc-VigVT cueDsN">Buscar</span>
                                </button>
                            </div>
                        </div>
                    </nav>
                </header>
            </div>
            <div id="content" class="ad__sc-18p038x-3 GYHge">
                <div id="leftside" class="ad__sc-18p038x-4 brSEGL"></div>
                <div class="ad__sc-18p038x-2 djeeke">
                    <div class="sc-bdVaJa ad__h3us20-1 ad__h3us20-0 iMxITp">
                        <div class="ad__h3us20-2 kIjqbV">
                            <div class="sc-bwzfXH ad__h3us20-0 ikHgMx">
                                <div class="ad__duvuxf-0 ad__h3us20-0 ddnqvn">
                                    <div data-ds-component="DS-Flex" class="sc-kafWEX ad__sc-1aze3je-0 kNSqkm">
                                        <div role="presentation" class="ad__sc-1aze3je-1 bKbctQ">
                                            <a data-ds-component="DS-Link" href="#" class="sc-EHOje jNyXWf">
                                                <!-- -->
                                                Rio Grande do Sul
                                                <!-- -->
                                            </a>
                                        </div>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" aria-hidden="true" color="var(--color-neutral-130)" class="ad__sc-1aze3je-2 bKCVhH">
                                            <path fill="var(--color-neutral-130)" fill-rule="evenodd" d="M9.46966991,17.4696699 C9.1767767,17.7625631 9.1767767,18.2374369 9.46966991,18.5303301 C9.76256313,18.8232233 10.2374369,18.8232233 10.5303301,18.5303301 L16.5303301,12.5303301 C16.8232233,12.2374369 16.8232233,11.7625631 16.5303301,11.4696699 L10.5303301,5.46966991 C10.2374369,5.1767767 9.76256313,5.1767767 9.46966991,5.46966991 C9.1767767,5.76256313 9.1767767,6.23743687 9.46966991,6.53033009 L14.9393398,12 L9.46966991,17.4696699 Z"></path>
                                        </svg>
                                        <div role="presentation" class="ad__sc-1aze3je-1 bKbctQ">
                                            <a data-ds-component="DS-Link" href="https://www.olx.com.br/estado-rs/regioes-de-caxias-do-sul-e-passo-fundo" class="sc-EHOje jNyXWf">
                                                <!-- -->
                                                Caxias do Sul e região
                                                <!-- -->
                                            </a>
                                        </div>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" aria-hidden="true" color="var(--color-neutral-130)" class="ad__sc-1aze3je-2 bKCVhH">
                                            <path fill="var(--color-neutral-130)" fill-rule="evenodd" d="M9.46966991,17.4696699 C9.1767767,17.7625631 9.1767767,18.2374369 9.46966991,18.5303301 C9.76256313,18.8232233 10.2374369,18.8232233 10.5303301,18.5303301 L16.5303301,12.5303301 C16.8232233,12.2374369 16.8232233,11.7625631 16.5303301,11.4696699 L10.5303301,5.46966991 C10.2374369,5.1767767 9.76256313,5.1767767 9.46966991,5.46966991 C9.1767767,5.76256313 9.1767767,6.23743687 9.46966991,6.53033009 L14.9393398,12 L9.46966991,17.4696699 Z"></path>
                                        </svg>
                                        <div role="presentation" class="ad__sc-1aze3je-1 bKbctQ">
                                            <a data-ds-component="DS-Link" href="https://www.olx.com.br/eletrodomesticos/estado-rs/regioes-de-caxias-do-sul-e-passo-fundo" class="sc-EHOje jNyXWf">
                                                <!-- -->
                                                Eletrodomésticos
                                                <!-- -->
                                            </a>
                                        </div>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" aria-hidden="true" color="var(--color-neutral-130)" class="ad__sc-1aze3je-2 bKCVhH">
                                            <path fill="var(--color-neutral-130)" fill-rule="evenodd" d="M9.46966991,17.4696699 C9.1767767,17.7625631 9.1767767,18.2374369 9.46966991,18.5303301 C9.76256313,18.8232233 10.2374369,18.8232233 10.5303301,18.5303301 L16.5303301,12.5303301 C16.8232233,12.2374369 16.8232233,11.7625631 16.5303301,11.4696699 L10.5303301,5.46966991 C10.2374369,5.1767767 9.76256313,5.1767767 9.46966991,5.46966991 C9.1767767,5.76256313 9.1767767,6.23743687 9.46966991,6.53033009 L14.9393398,12 L9.46966991,17.4696699 Z"></path>
                                        </svg>
                                        <div role="presentation" class="ad__sc-1aze3je-1 bKbctQ">
                                            <a data-ds-component="DS-Link" href="https://www.olx.com.br/eletrodomesticos/estado-rs/regioes-de-caxias-do-sul-e-passo-fundo/regiao-de-carazinho" class="sc-EHOje jNyXWf">
                                                <!-- -->
                                                Região de Carazinho
                                                <!-- -->
                                            </a>
                                        </div>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" aria-hidden="true" color="var(--color-neutral-130)" class="ad__sc-1aze3je-2 bKCVhH">
                                            <path fill="var(--color-neutral-130)" fill-rule="evenodd" d="M9.46966991,17.4696699 C9.1767767,17.7625631 9.1767767,18.2374369 9.46966991,18.5303301 C9.76256313,18.8232233 10.2374369,18.8232233 10.5303301,18.5303301 L16.5303301,12.5303301 C16.8232233,12.2374369 16.8232233,11.7625631 16.5303301,11.4696699 L10.5303301,5.46966991 C10.2374369,5.1767767 9.76256313,5.1767767 9.46966991,5.46966991 C9.1767767,5.76256313 9.1767767,6.23743687 9.46966991,6.53033009 L14.9393398,12 L9.46966991,17.4696699 Z"></path>
                                        </svg>
                                        <div role="presentation" class="ad__sc-1aze3je-1 bKbctQ">
                                            <a data-ds-component="DS-Link" href="https://www.olx.com.br/eletrodomesticos/estado-rs/regioes-de-caxias-do-sul-e-passo-fundo/regiao-de-carazinho/carazinho" class="sc-EHOje jNyXWf">
                                                <!-- -->
                                                Carazinho
                                                <!-- -->
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="sc-bwzfXH ad__h3us20-0 ikHgMx">
                            <div class="ad__duvuxf-0 ad__h3us20-0 eCUDNu">
                                <div class="ad__h3us20-6 huheQg">
                                    <div from="lg" class="ad__h3us20-4 hqjcIS">
                                        <div>
                                        </div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 hwGosR">
                                    <div from="lg" class="ad__h3us20-4 hqjcIS">
                                        <div>
                                            <div class="ad__lkx530-0 fEhNSb">
                                              
                   <style>
                     .carousel {
    position: relative;
    width: 100%;
    max-width: 300px;
    margin: auto;
    overflow: hidden;
}

.carousel-inner {
    display: flex;
    transition: transform 0.5s ease;
}

.carousel-item {
    min-width: 100%;
}

.carousel img {
    width: 100%;
    display: block;
}

.carousel-control-prev, .carousel-control-next {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    font-size: 2em;
    color: black;
    text-decoration: none;
    cursor: pointer;
    user-select: none;
    padding: 10px;
}

.carousel-control-prev {
    left: 0;
}

.carousel-control-next {
    right: 0;
}

@media (max-width: 768px) {
    .carousel-control-prev, .carousel-control-next {
        display: none;
    }
}

                   </style>                           
<div class="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="<?php echo $dados['img1']; ?>" alt="Image 1">
        </div>
        <div class="carousel-item">
            <img src="<?php echo $dados['img2']; ?>" alt="Image 2">
        </div>
        <div class="carousel-item">
            <img src="<?php echo $dados['img3']; ?>" alt="Image 3">
        </div>
        <div class="carousel-item">
            <img src="<?php echo $dados['img4']; ?>" alt="Image 4">
        </div>
        <div class="carousel-item">
            <img src="<?php echo $dados['img5']; ?>" alt="Image 5">
        </div>
    </div>
    <a class="carousel-control-prev" onclick="prevSlide()">&#10094;</a>
    <a class="carousel-control-next" onclick="nextSlide()">&#10095;</a>
</div>
<script>
  
let currentSlide = 0;

function showSlide(index) {
    const slides = document.querySelectorAll('.carousel-item');
    if (index >= slides.length) {
        currentSlide = 0;
    } else if (index < 0) {
        currentSlide = slides.length - 1;
    } else {
        currentSlide = index;
    }
    const offset = -currentSlide * 100;
    document.querySelector('.carousel-inner').style.transform = `translateX(${offset}%)`;
}

function nextSlide() {
    showSlide(currentSlide + 1);
}

function prevSlide() {
    showSlide(currentSlide - 1);
}

// Swipe functionality
let touchStartX = 0;
let touchEndX = 0;

function handleGesture() {
    if (touchEndX < touchStartX) nextSlide();
    if (touchEndX > touchStartX) prevSlide();
}

document.querySelector('.carousel').addEventListener('touchstart', e => {
    touchStartX = e.changedTouches[0].screenX;
});

document.querySelector('.carousel').addEventListener('touchend', e => {
    touchEndX = e.changedTouches[0].screenX;
    handleGesture();
});

// Initialize the first slide
showSlide(currentSlide);


</script>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 gxgpLc">
                                    <div class="ad__h3us20-4 cxrGoW">
                                        <div class="ad__h3us20-5 jpLxJR"></div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 klUCcX">
                                    <div class="ad__h3us20-4 cxrGoW">
                                        <div class="ad__h3us20-5 gcNVGl"></div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 hvdBmx">
                                    <div class="ad__h3us20-4 cxrGoW">
                                        <div class="ad__h3us20-5 jSHLrx"></div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 evlSXY">
                                    <div class="ad__h3us20-4 cxrGoW">
                                        <div class="ad__h3us20-5 hRnZIE"></div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 kUaoWB">
                                    <div class="ad__h3us20-4 cxrGoW">
                                        <div class="ad__h3us20-5 eeMMQZ"></div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 giOfmL">
                                    <div class="ad__h3us20-4 cxrGoW">
                                        <div class="ad__h3us20-5 kLTIUD"></div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 kuWHPL">
                                    <div class="ad__h3us20-4 cxrGoW">
                                        <div class="ad__h3us20-5 iqOYHc"></div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 jjwizE">
                                    <div class="ad__h3us20-4 cxrGoW">
                                        <div class="ad__h3us20-5 iqOYHc"></div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 iVEnbi">
                                    <div class="ad__h3us20-4 cxrGoW">
                                        <div class="ad__h3us20-5 iqOYHc"></div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 fewjmS">
                                    <div class="ad__h3us20-4 cxrGoW">
                                        <div class="ad__h3us20-5 iqOYHc"></div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 doBeQf">
                                    <div class="ad__h3us20-4 cxrGoW">
                                        <div class="ad__h3us20-5 kLTIUD"></div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 bDzyZu">
                                    <div from="xs" to="lg" class="ad__h3us20-4 jVXVWC">
                                        <div class="ad__h3us20-5 ktDRob"></div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 hgcbvd">
                                    <div class="ad__h3us20-4 cxrGoW">
                                        <div>
                                            <div class="sc-GMQeP hywCld">
                                                <div class="sc-GMQeP hywCld">
                                                    <span data-ds-component="DS-Badge" role="status" class="info sc-kAzzGY hFDmrz" aria-label="Garantia da OLX">
                                                        <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" width="24" height="24" color="currentColor" size="24">
                                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M8.218 14.976a.999.999 0 01-.436 0A8.67 8.67 0 011 6.499V3.5A2.5 2.5 0 013.5 1h9A2.5 2.5 0 0115 3.5v3a8.669 8.669 0 01-6.782 8.476zM14 6.5v-3A1.5 1.5 0 0012.5 2h-9A1.5 1.5 0 002 3.5v3A7.669 7.669 0 008 14a7.67 7.67 0 006-7.5z" fill="currentColor"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M8.969 3.3a.571.571 0 01.434.682l-.107.488a2.818 2.818 0 01.613.307c.246.163.24.506.03.714-.224.221-.59.196-.87.05l-.02-.01a1.355 1.355 0 00-.623-.144c-.252 0-.477.07-.675.209a.643.643 0 00-.296.55c0 .113.042.219.126.318.087.098.2.189.336.27.136.081.286.166.448.253.166.084.33.183.493.296.165.11.316.234.453.37a1.657 1.657 0 01.462 1.168c0 .359-.1.686-.3.982a2.017 2.017 0 01-.803.69 2.4 2.4 0 01-.752.225l-.114.518a.571.571 0 11-1.116-.246l.077-.353c-.16-.043-.315-.1-.465-.171a3.123 3.123 0 01-.615-.389c-.23-.187-.208-.53.01-.73.235-.214.603-.178.864.005a1.655 1.655 0 001.01.32c.159 0 .314-.03.465-.091a.995.995 0 00.392-.292.71.71 0 00.162-.458.689.689 0 00-.131-.41 1.17 1.17 0 00-.331-.322 5.34 5.34 0 00-.453-.266 9.65 9.65 0 01-.493-.284 3.156 3.156 0 01-.453-.335 1.428 1.428 0 01-.335-.458 1.484 1.484 0 01-.126-.62c0-.345.094-.658.283-.937.189-.279.444-.495.767-.65.259-.126.54-.201.842-.226l.13-.587a.571.571 0 01.68-.435z" fill="currentColor"></path>
                                                        </svg>
                                                        Garantia da OLX
                                                    </span>
                                                    <span data-ds-component="DS-Badge" role="status" class="info sc-kAzzGY hFDmrz" aria-label="Pague online">
                                                        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" width="24" height="24" color="currentColor" size="24">
                                                            <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4H6zM3 6h18M16 10a4 4 0 11-8 0" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                        </svg>
                                                        Pague online
                                                    </span>
                                                    <span data-ds-component="DS-Badge" role="status" class="info sc-kAzzGY hFDmrz" aria-label="Entrega fácil"><svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" width="24" height="24" color="currentColor" size="24">
                                                            <g clip-path="url(#Delivery_svg__clip0)">
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M.5 2.667a.5.5 0 01.5-.5h6.89a.5.5 0 01.5.5v1.929h3.687c.539 0 1.007.368 1.134.891l.411 1.698 1.791.923c.388.2.632.6.632 1.037v2.57c0 .644-.522 1.167-1.167 1.167h-1.574a2.012 2.012 0 11-4.018 0H7.392v-7.74a.505.505 0 01-.002-.047V3.167H1a.5.5 0 01-.5-.5zm9.114 9.215a2.01 2.01 0 013.362 0h1.902a.167.167 0 00.167-.167v-2.57a.167.167 0 00-.09-.148l-2.197-1.133-.519-2.141a.167.167 0 00-.162-.127H8.393v6.286h1.221zm-8.188-6.18a.5.5 0 01.5-.5h3.6a.5.5 0 110 1h-3.6a.5.5 0 01-.5-.5zm1.68 2.536a.5.5 0 000 1h2.332a.5.5 0 000-1H3.105zm1.177 3.036a.5.5 0 100 1h1a.5.5 0 000-1h-1zM11.295 14a1.012 1.012 0 100-2.024 1.012 1.012 0 000 2.024z" fill="currentColor"></path>
                                                            </g>
                                                            <defs>
                                                                <clipPath id="Delivery_svg__clip0">
                                                                    <path d="M0 0h16v16H0V0z" fill="#fff"></path>
                                                                </clipPath>
                                                            </defs>
                                                        </svg>Entrega fácil</span>
                                                    <span data-ds-component="DS-Badge" role="status" class="info sc-kAzzGY hFDmrz" aria-label="Parcelamento sem juros"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" color="currentColor" size="24">
                                                            <path fill="currentColor" fill-rule="evenodd" d="M22.25 9.25V6c0-.69-.56-1.25-1.25-1.25H3c-.69 0-1.25.56-1.25 1.25v3.25h20.5zm0 1.5H1.75V18c0 .69.56 1.25 1.25 1.25h18c.69 0 1.25-.56 1.25-1.25v-7.25zM3 3.25h18A2.75 2.75 0 0123.75 6v12A2.75 2.75 0 0121 20.75H3A2.75 2.75 0 01.25 18V6A2.75 2.75 0 013 3.25z"></path>
                                                        </svg>Parcelamento sem juros</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 kEkuZJ">
                                    <div class="ad__h3us20-4 cxrGoW">
                                        <div>
                                            <div data-ds-component="DS-Flex" data-testid="ad-price-wrapper" class="sc-kafWEX ad__sc-1ukaq78-0 kbqZof">
                                                <div class="ad__en9h1n-0 cmhHQz">
                                                    <div data-ds-component="DS-Flex" class="sc-kafWEX ad__sc-1wimjbb-3 rDAfb">
                                                        <div data-ds-component="DS-Flex" class="sc-kafWEX ad__sc-1wimjbb-4 lcAaLl">
                                                            <div data-ds-component="DS-Flex" class="sc-kafWEX jDogfN">
                                                                <span data-ds-component="DS-Text" class="ad__sc-1wimjbb-1 hoHpcC sc-hSdWYo dDGSHH" color="--color-neutral-130" display="block">R$ <?php
                                    $valor = $dados['valor'];
                                    echo  number_format($valor, 2 , ",", ".")
                                    ?></span>
                                                            </div>
                                                            <div class="ad__h3us20-3 lhJrCT">
                                                                <div data-ds-component="DS-Flex" class="sc-kafWEX iTyeOU">

                                                                    <div data-ds-component="DS-Flex" class="sc-kafWEX iTyeOU">
                                                                        <span id="parcelamento" data-valor="550,00" data-ds-component="DS-Text" color="--color-neutral-130" display="block" class="sc-hSdWYo gcOoiX"></span>
                                                                    </div>

                                                                    <div data-ds-component="DS-Flex" role="presentation" class="sc-kafWEX iTyeOU"></div>
                                                                </div>
                                                            </div>
                                                            <div class="ad__h3us20-3 lhJrCT">
                                                                <div class="ad__sc-1wimjbb-0 bsMpRS">
                                                                    <div data-ds-component="DS-Flex" class="sc-kafWEX sc-eLExRp hWTjz">
                                                                        <div data-ds-component="DS-Flex" direction="column" class="sc-kafWEX sc-cbkKFq jtNbfo">
                                                                            <div data-ds-component="DS-Flex" class="sc-kafWEX sc-krvtoX dOHiXa">
                                                                                <div data-ds-component="DS-Flex" class="sc-kafWEX sc-fYiAbW gsysFh"><svg width="25" height="25" viewBox="0 0 32 33" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                        <path d="M31.5 16.5C31.5 25.0604 24.5604 32 16 32C7.43959 32 0.5 25.0604 0.5 16.5C0.5 7.93959 7.43959 1 16 1C24.5604 1 31.5 7.93959 31.5 16.5Z" fill="white" stroke="#D2D2D2"></path>
                                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M11.7194 12.251C12.3471 12.251 12.9374 12.4955 13.3813 12.9391L15.7897 15.3481C15.9632 15.5215 16.2464 15.5222 16.4204 15.3478L18.82 12.9479C19.2639 12.5043 19.8542 12.2598 20.482 12.2598H20.771L17.723 9.21192C16.7738 8.26269 15.2349 8.26269 14.2857 9.21192L11.2466 12.251H11.7194ZM20.4822 20.7402C19.8543 20.7402 19.2641 20.4957 18.8202 20.052L16.4205 17.6524C16.252 17.4834 15.9584 17.4839 15.79 17.6524L13.3814 20.0608C12.9375 20.5045 12.3472 20.7488 11.7195 20.7488H11.2466L14.2858 23.7882C15.2351 24.7373 16.774 24.7373 17.7231 23.7882L20.7712 20.7402H20.4822ZM21.4455 12.9403L23.2873 14.7822C24.2365 15.7313 24.2365 17.2703 23.2873 18.2195L21.4455 20.0613C21.4048 20.0451 21.3611 20.035 21.3146 20.035H20.4773C20.0442 20.035 19.6205 19.8595 19.3145 19.5532L16.9149 17.1538C16.4799 16.7184 15.7212 16.7185 15.2858 17.1535L12.8774 19.5621C12.5713 19.8681 12.1476 20.0437 11.7146 20.0437H10.6849C10.641 20.0437 10.5998 20.0541 10.5611 20.0687L8.71192 18.2195C7.76269 17.2703 7.76269 15.7313 8.71192 14.7822L10.5612 12.9329C10.5999 12.9475 10.641 12.958 10.6849 12.958H11.7146C12.1476 12.958 12.5713 13.1335 12.8774 13.4396L15.2861 15.8483C15.5105 16.0726 15.8053 16.185 16.1004 16.185C16.3952 16.185 16.6903 16.0726 16.9147 15.8481L19.3145 13.4484C19.6205 13.1422 20.0442 12.9666 20.4773 12.9666H21.3146C21.3609 12.9666 21.4048 12.9566 21.4455 12.9403Z" fill="#32BCAD"></path>
                                                                                    </svg></div>
                                                                                <div data-ds-component="DS-Flex" class="sc-kafWEX sc-fYiAbW gsysFh"><svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" width="24" height="24" size="24" color="currentColor">
                                                                                        <path d="M16 32c8.837 0 16-7.163 16-16S24.837 0 16 0 0 7.163 0 16s7.163 16 16 16z" fill="#0054A4"></path>
                                                                                        <mask id="Visa_svg__a" maskUnits="userSpaceOnUse" x="0" y="0" width="32" height="32">
                                                                                            <path d="M16 32c8.837 0 16-7.163 16-16S24.837 0 16 0 0 7.163 0 16s7.163 16 16 16z" fill="#fff"></path>
                                                                                        </mask>
                                                                                        <g mask="url(#Visa_svg__a)" fill-rule="evenodd" clip-rule="evenodd">
                                                                                            <path d="M12.203 19.427l1.18-7.3h1.884l-1.179 7.3h-1.885zM20.925 12.306A4.67 4.67 0 0019.238 12c-1.864 0-3.176.99-3.187 2.41-.012 1.049.936 1.634 1.651 1.982.735.358.981.587.978.906-.005.49-.586.713-1.128.713-.754 0-1.155-.11-1.775-.383l-.243-.116-.263 1.634c.439.204 1.254.38 2.1.39 1.98 0 3.267-.98 3.282-2.494.007-.832-.495-1.463-1.583-1.984-.659-.338-1.063-.562-1.058-.905 0-.303.341-.628 1.08-.628a3.315 3.315 0 011.41.28l.17.084.255-1.583zM23.435 16.84c.157-.42.751-2.041.751-2.041-.01.019.156-.423.25-.697l.128.63s.362 1.742.436 2.107h-1.565zm2.326-4.706h-1.457c-.452 0-.79.13-.988.606l-2.8 6.69h1.98s.323-.9.397-1.098l2.414.004c.057.255.23 1.094.23 1.094h1.75l-1.526-7.296zM10.622 12.133L8.777 17.11 8.58 16.1c-.344-1.166-1.414-2.43-2.611-3.063l1.687 6.385 1.995-.001 2.968-7.287h-1.997z" fill="#fff"></path>
                                                                                            <path d="M7.065 12.128h-3.04L4 12.28c2.365.604 3.93 2.064 4.58 3.818l-.66-3.354c-.115-.462-.446-.6-.855-.616z" fill="#F39C12"></path>
                                                                                        </g>
                                                                                    </svg></div>
                                                                                <div data-ds-component="DS-Flex" class="sc-kafWEX sc-fYiAbW gsysFh"><svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" width="24" height="24" size="24" color="currentColor">
                                                                                        <path d="M16 32c8.837 0 16-7.163 16-16S24.837 0 16 0 0 7.163 0 16s7.163 16 16 16z" fill="#34495E"></path>
                                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M19.414 16.163a6.417 6.417 0 11-12.833 0 6.417 6.417 0 0112.833 0z" fill="#E74C3C"></path>
                                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M27.036 16.163a6.417 6.417 0 11-12.834 0 6.417 6.417 0 0112.834 0z" fill="#F1C40F"></path>
                                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M14.202 16.163a6.4 6.4 0 002.106 4.753 6.4 6.4 0 002.106-4.753 6.4 6.4 0 00-2.106-4.754 6.4 6.4 0 00-2.106 4.754z" fill="#F39C12"></path>
                                                                                    </svg></div>
                                                                                <div data-ds-component="DS-Flex" class="sc-kafWEX sc-fYiAbW gsysFh"><svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" width="24" height="24" size="24" color="currentColor">
                                                                                        <path d="M16 32c8.837 0 16-7.163 16-16S24.837 0 16 0 0 7.163 0 16s7.163 16 16 16z" fill="#0F0F12"></path>
                                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M16.232 6c5.642 0 10.215 4.574 10.215 10.215 0 5.642-4.573 10.216-10.215 10.216-5.642 0-10.215-4.574-10.215-10.216C6.017 10.574 10.59 6 16.232 6z" fill="#0F0F12"></path>
                                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M13.19 15.43l-3.136 1.35a1.796 1.796 0 013.136-1.351zm-1.347-1.953a3.14 3.14 0 013.052 2.402l-1.266.554v-.003l-1.294.569-3.106 1.358a3.14 3.14 0 012.613-4.879zM14.036 18.863c-1.124 1.066-2.61 1.171-3.917.378l.738-1.123c.744.445 1.49.373 2.24-.216l.94.96zM15.315 18.085l-.008-5.936h1.124v5.776c0 .056.007.104.08.133l.978.38-.44 1.146-1.147-.485c-.434-.183-.587-.45-.587-1.014z" fill="#FFFFFE"></path>
                                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M19.55 17.986a1.788 1.788 0 01-.135-2.714l-.726-1.178a3.155 3.155 0 00.175 5.082l.685-1.19z" fill="#2191C3"></path>
                                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M20.042 14.885a1.792 1.792 0 012.283 1.055l1.392-.117a3.16 3.16 0 00-4.256-2.18l.581 1.242z" fill="#FAEC32"></path>
                                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M22.438 16.658a1.792 1.792 0 01-2.226 1.65l-.546 1.265a3.158 3.158 0 004.138-2.872l-1.366-.043z" fill="#D0362B"></path>
                                                                                    </svg></div>
                                                                                <div data-ds-component="DS-Flex" class="sc-kafWEX sc-fYiAbW gsysFh"><svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" width="24" height="24" size="24" color="currentColor">
                                                                                        <path d="M16 32c8.837 0 16-7.163 16-16S24.837 0 16 0 0 7.163 0 16s7.163 16 16 16z" fill="#B10E0C"></path>
                                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M21.999 17.12c-.353.347-1.342.446-1.241-.382.084-.688.83-.834 1.639-.735-.06.376-.13.854-.398 1.118zm-1.114-2.683c-.033.19-.085.362-.127.543.404-.101 1.661-.413 1.782.128.04.18-.029.37-.08.511-1.136-.108-2.063.082-2.307.894-.163.545.019 1.08.366 1.23.67.288 1.485-.042 1.767-.495a2.09 2.09 0 00-.048.51h.589c.006-.565.088-1.023.175-1.532.074-.434.213-.863.19-1.246-.05-.876-1.497-.566-2.307-.543zm5.903 2.954c-.46.01-.69-.276-.7-.75-.018-.831.345-1.754 1.082-1.837.343-.038.592.042.844.128-.231.933-.148 2.436-1.226 2.46zM28.316 13a15.365 15.365 0 01-.239 1.485c-1.678-.533-2.708.706-2.69 2.236.005.296.055.589.24.798.317.36 1.227.447 1.686.144.09-.059.18-.166.239-.24.044-.055.115-.201.127-.16-.024.163-.06.313-.063.496h.62c.12-1.722.49-3.193.764-4.759h-.684zm-17.52 4.136c-.365.389-1.265.383-1.336-.272-.03-.285.075-.583.128-.878.052-.298.09-.584.143-.846.36-.442 1.42-.495 1.527.24.094.637-.158 1.434-.461 1.756zm.542-2.698c-.58-.218-1.285.042-1.591.29 0 .011-.008.013-.017.014l.017-.014v-.002c.005-.107.042-.181.047-.288h-.589c-.245 1.638-.536 3.23-.843 4.807h.684c.1-.614.165-1.262.303-1.837.156.605 1.176.49 1.607.256.888-.482 1.573-2.777.382-3.226zm3.246 1.15h-1.607a.95.95 0 01.907-.799c.493-.019.846.182.7.799zm-.653-1.215c-.494.038-.912.181-1.209.495-.364.385-.66 1.237-.573 2.012.124 1.107 1.496 1.067 2.594.799.019-.194.065-.36.095-.543-.452.17-1.237.407-1.702.112-.351-.223-.353-.788-.239-1.278.738-.024 1.505-.019 2.244 0 .047-.348.18-.727.063-1.07-.155-.453-.709-.57-1.273-.527zm-6.015.066c-.018.003-.017.025-.016.048a47.269 47.269 0 01-.573 3.273h.685c.164-1.139.352-2.254.588-3.321h-.684zm17.854.014c-.604-.303-1.108.206-1.305.511.056-.157.06-.366.112-.527h-.605a49.488 49.488 0 01-.589 3.322h.7c.005-.44.091-.766.16-1.198.146-.922.36-1.933 1.432-1.629.035-.156.05-.333.095-.479zm-7.685 2.524c-.063-.163-.08-.433-.064-.639.036-.46.203-1.023.462-1.277.357-.35 1.06-.293 1.623-.096.017-.19.055-.36.08-.543-.922-.15-1.797-.057-2.26.431-.454.478-.752 1.577-.541 2.268.246.809 1.35.853 2.243.543.04-.163.06-.344.096-.511-.489.255-1.422.387-1.64-.176zm-.382-2.54c-.607-.246-1.084.17-1.305.559.05-.173.071-.376.112-.559h-.605c-.148 1.15-.366 2.23-.573 3.322h.684c.096-.648.138-1.52.35-2.14.17-.495.616-.917 1.258-.687.009-.183.06-.322.08-.495zm-11.027-1.34c-.098.636-.208 1.26-.319 1.884-.708.008-1.432.035-2.116-.016.13-.61.222-1.257.35-1.868h-.764c-.273 1.556-.522 3.138-.827 4.663h.78c.122-.783.236-1.573.397-2.316.665-.016 1.462-.045 2.1.016-.13.773-.29 1.518-.413 2.3h.78c.25-1.58.514-3.146.827-4.663h-.795zm1.94.702c.137-.095.313-.524.112-.703-.063-.057-.17-.073-.318-.048-.138.023-.217.07-.27.144-.087.118-.166.474-.032.607.13.128.422.06.509 0z" fill="#FFFFFE"></path>
                                                                                    </svg></div>
                                                                                <div data-ds-component="DS-Flex" class="sc-kafWEX sc-fYiAbW gsysFh"><svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" width="24" height="24" size="24" color="currentColor">
                                                                                        <path d="M16 32c8.837 0 16-7.163 16-16S24.837 0 16 0 0 7.163 0 16s7.163 16 16 16z" fill="#3473DB"></path>
                                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M6.878 15.975c-.057.143.023.26.177.26h.723c.155 0 .235-.117.178-.26l-.432-1.098c-.057-.144-.15-.144-.207 0l-.439 1.098z" fill="#fff"></path>
                                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M22.673 15.292c0-.154.073-.177.161-.05l.087.123a.448.448 0 01.008.465l-.102.156c-.085.129-.154.108-.154-.046v-.648zm3.71 3.19a.569.569 0 01-.432-.238l-.796-1.26c-.082-.13-.218-.131-.3 0l-.804 1.26a.571.571 0 01-.432.237H17.761a.282.282 0 01-.281-.28v-5.193c0-.155.126-.281.28-.281h4.07c.155 0 .282.126.282.28v.843c0 .154-.127.28-.281.28h-2.526a.282.282 0 00-.281.281v.28c0 .155.126.281.28.281h2.246c.155 0 .28.127.28.281v.702c0 .154-.125.28-.28.28h-2.245a.282.282 0 00-.281.281v.421c0 .155.126.281.28.281h2.527c.154 0 .28.126.28.28v.712c0 .154.071.176.157.048l1.65-2.459a.458.458 0 00.001-.467l-1.566-2.371c-.085-.129-.028-.234.126-.234h1.263c.155 0 .348.107.43.238l.709 1.136c.081.13.216.131.3.001l.728-1.139a.573.573 0 01.432-.236h1.223c.154 0 .21.105.124.233l-1.57 2.337a.455.455 0 000 .467l1.653 2.484c.085.128.029.233-.125.233h-1.264zm-9.464-.281c0 .154-.127.28-.281.28h-1.123a.282.282 0 01-.28-.28v-2.707c0-.154-.067-.173-.148-.041l-1.112 1.807a1.623 1.623 0 01-.164.239c-.009 0-.086-.106-.171-.234l-1.198-1.81c-.085-.128-.155-.107-.155.047v2.699c0 .154-.126.28-.28.28h-.983a.282.282 0 01-.28-.28v-5.193c0-.155.125-.281.28-.281h1.156a.56.56 0 01.428.239l1.072 1.74c.081.13.214.13.295 0l1.072-1.74a.56.56 0 01.428-.24h1.163c.154 0 .28.127.28.282V18.2zm-7.704.28a.457.457 0 01-.388-.259l-.194-.464a.457.457 0 00-.388-.26H6.588a.456.456 0 00-.388.26l-.193.464a.457.457 0 01-.39.26H4.519c-.154 0-.231-.117-.171-.26l2.212-5.237a.46.46 0 01.39-.258h.968a.46.46 0 01.39.258l2.22 5.238c.06.142-.017.258-.171.258h-1.14zm19.568-.224l-.313-.466-1.337-1.996a.455.455 0 010-.466l1.254-1.877.31-.467.576-.866c.085-.13.029-.234-.126-.234H25.83a.464.464 0 00-.355.206 44.43 44.43 0 01-.273.444l-.015.026c-.082.13-.214.13-.294-.003l-.011-.018-.268-.448a.466.466 0 00-.358-.207H14.96c-.13 0-.29.095-.358.212-.068.117-.19.32-.27.452l-.357.587c-.08.132-.212.131-.292 0l-.359-.593c-.08-.132-.2-.334-.268-.45a.465.465 0 00-.359-.208H10.182a.282.282 0 00-.281.28v2.25c0 .154-.048.164-.107.021l-.733-1.774a23.34 23.34 0 01-.206-.518.436.436 0 00-.378-.26H6.39a.457.457 0 00-.389.26l-.217.518-2.212 5.243-.22.517-.272.643c-.06.142.016.258.17.258h2.94a.452.452 0 00.387-.253l.205-.492c.054-.13.225-.237.38-.237h.512c.154 0 .325.107.38.237l.204.492c.058.14.232.253.387.253h4.205c.154 0 .28-.126.28-.28v-.764c0-.123.047-.16.105-.081.057.079.207.143.333.143h.489c.125 0 .252-.067.282-.15.03-.081.054-.045.054.082v.77c0 .154.127.28.28.28H24.132a.474.474 0 00.355-.19c.069-.103.193-.295.276-.425l.089-.137c.083-.13.22-.13.303 0l.084.132c.084.13.207.323.276.428a.473.473 0 00.355.192H29.221c.155 0 .21-.105.124-.233l-.562-.833z" fill="#fff"></path>
                                                                                    </svg>
                                                                                </div>
                                                                                <div data-ds-component="DS-Flex" class="sc-kafWEX sc-fYiAbW gsysFh">

                                                                                </div>
                                                                            </div>
                                                                            <div data-ds-component="DS-Flex" direction="column" class="sc-kafWEX sc-fOKMvo jhThrT">
                                                                                <a data-ds-component="DS-Link" type="primary" class="sc-EHOje fVwWyK" onclick="vermodal()">Ver mais formas de pagamento</a>
                                                                            </div>
                                                                            <reach-portal>
                                                                                <div id="modalContainer" data-testid="bottom-sheet" data-rsbs-root="true" data-rsbs-state="open" data-rsbs-is-blocking="true" data-rsbs-is-dismissable="true" data-rsbs-has-header="true" data-rsbs-has-footer="false" class="sc-iujRgT gRMyKA" style="--rsbs-content-opacity: 1; --rsbs-backdrop-opacity: 1; --rsbs-antigap-scale-y: 0; --rsbs-overlay-translate-y: 0px; --rsbs-overlay-rounded: 16px; --rsbs-overlay-h: 327px; opacity: 1;">
                                                                                    <div data-rsbs-backdrop="true"></div>
                                                                                    <div aria-modal="true" role="dialog" data-rsbs-overlay="true" tabindex="-1">
                                                                                        <div data-rsbs-header="true">
                                                                                            <div class="sc-bMVAic cZBzyZ"><button type="button" data-testid="button-close" class="sc-bsbRJL gETGbd"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" color="#4A4A4A" class="sc-iQNlJl fYRuoc" size="24">
                                                                                                        <path fill="#4A4A4A" fill-rule="evenodd" d="M13.06 12l5.47 5.47a.75.75 0 01-1.06 1.06L12 13.06l-5.47 5.47a.75.75 0 01-1.06-1.06L10.94 12 5.47 6.53a.75.75 0 011.06-1.06L12 10.94l5.47-5.47a.75.75 0 011.06 1.06L13.06 12z"></path>
                                                                                                    </svg></button></div>
                                                                                        </div>
                                                                                        <div data-rsbs-scroll="true">
                                                                                            <div data-rsbs-content="true">
                                                                                                <div class="sc-bAeIUo cWeFKg">
                                                                                                    <div class="sc-kfGgVZ iLwJlJ"><span data-ds-component="DS-Text" class="sc-esjQYD ikJPMC sc-ifAKCX hUnWqk" color="--color-neutral-130" display="block">Formas de pagamento</span>
                                                                                                        <div class="sc-iQKALj VTnwo"></div>
                                                                                                    </div><span data-ds-component="DS-Text" class="sc-kIPQKe jgMiIX sc-ifAKCX cbbXMA" color="--color-neutral-130" display="block">Cartões de crédito&nbsp;<span data-ds-component="DS-Text" class="sc-eXEjpC eAsDxl sc-ifAKCX cbbXMA" color="--color-neutral-130" display="block">em até 12x sem juros</span></span>
                                                                                                    <div class="sc-bwCtUz gpyBbE">
                                                                                                        <div class="sc-hrWEMg fdYuev"><svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" width="32" height="32" size="32" color="currentColor">
                                                                                                                <path d="M16 32c8.837 0 16-7.163 16-16S24.837 0 16 0 0 7.163 0 16s7.163 16 16 16z" fill="#0054A4"></path>
                                                                                                                <mask id="Visa_svg__a" maskUnits="userSpaceOnUse" x="0" y="0" width="32" height="32">
                                                                                                                    <path d="M16 32c8.837 0 16-7.163 16-16S24.837 0 16 0 0 7.163 0 16s7.163 16 16 16z" fill="#fff"></path>
                                                                                                                </mask>
                                                                                                                <g mask="url(#Visa_svg__a)" fill-rule="evenodd" clip-rule="evenodd">
                                                                                                                    <path d="M12.203 19.427l1.18-7.3h1.884l-1.179 7.3h-1.885zM20.925 12.306A4.67 4.67 0 0019.238 12c-1.864 0-3.176.99-3.187 2.41-.012 1.049.936 1.634 1.651 1.982.735.358.981.587.978.906-.005.49-.586.713-1.128.713-.754 0-1.155-.11-1.775-.383l-.243-.116-.263 1.634c.439.204 1.254.38 2.1.39 1.98 0 3.267-.98 3.282-2.494.007-.832-.495-1.463-1.583-1.984-.659-.338-1.063-.562-1.058-.905 0-.303.341-.628 1.08-.628a3.315 3.315 0 011.41.28l.17.084.255-1.583zM23.435 16.84c.157-.42.751-2.041.751-2.041-.01.019.156-.423.25-.697l.128.63s.362 1.742.436 2.107h-1.565zm2.326-4.706h-1.457c-.452 0-.79.13-.988.606l-2.8 6.69h1.98s.323-.9.397-1.098l2.414.004c.057.255.23 1.094.23 1.094h1.75l-1.526-7.296zM10.622 12.133L8.777 17.11 8.58 16.1c-.344-1.166-1.414-2.43-2.611-3.063l1.687 6.385 1.995-.001 2.968-7.287h-1.997z" fill="#fff"></path>
                                                                                                                    <path d="M7.065 12.128h-3.04L4 12.28c2.365.604 3.93 2.064 4.58 3.818l-.66-3.354c-.115-.462-.446-.6-.855-.616z" fill="#F39C12"></path>
                                                                                                                </g>
                                                                                                            </svg></div>
                                                                                                        <div class="sc-hrWEMg fdYuev"><svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" width="32" height="32" size="32" color="currentColor">
                                                                                                                <path d="M16 32c8.837 0 16-7.163 16-16S24.837 0 16 0 0 7.163 0 16s7.163 16 16 16z" fill="#34495E"></path>
                                                                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M19.414 16.163a6.417 6.417 0 11-12.833 0 6.417 6.417 0 0112.833 0z" fill="#E74C3C"></path>
                                                                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M27.036 16.163a6.417 6.417 0 11-12.834 0 6.417 6.417 0 0112.834 0z" fill="#F1C40F"></path>
                                                                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M14.202 16.163a6.4 6.4 0 002.106 4.753 6.4 6.4 0 002.106-4.753 6.4 6.4 0 00-2.106-4.754 6.4 6.4 0 00-2.106 4.754z" fill="#F39C12"></path>
                                                                                                            </svg></div>
                                                                                                        <div class="sc-hrWEMg fdYuev"><svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" width="32" height="32" size="32" color="currentColor">
                                                                                                                <path d="M16 32c8.837 0 16-7.163 16-16S24.837 0 16 0 0 7.163 0 16s7.163 16 16 16z" fill="#0F0F12"></path>
                                                                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M16.232 6c5.642 0 10.215 4.574 10.215 10.215 0 5.642-4.573 10.216-10.215 10.216-5.642 0-10.215-4.574-10.215-10.216C6.017 10.574 10.59 6 16.232 6z" fill="#0F0F12"></path>
                                                                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M13.19 15.43l-3.136 1.35a1.796 1.796 0 013.136-1.351zm-1.347-1.953a3.14 3.14 0 013.052 2.402l-1.266.554v-.003l-1.294.569-3.106 1.358a3.14 3.14 0 012.613-4.879zM14.036 18.863c-1.124 1.066-2.61 1.171-3.917.378l.738-1.123c.744.445 1.49.373 2.24-.216l.94.96zM15.315 18.085l-.008-5.936h1.124v5.776c0 .056.007.104.08.133l.978.38-.44 1.146-1.147-.485c-.434-.183-.587-.45-.587-1.014z" fill="#FFFFFE"></path>
                                                                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M19.55 17.986a1.788 1.788 0 01-.135-2.714l-.726-1.178a3.155 3.155 0 00.175 5.082l.685-1.19z" fill="#2191C3"></path>
                                                                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M20.042 14.885a1.792 1.792 0 012.283 1.055l1.392-.117a3.16 3.16 0 00-4.256-2.18l.581 1.242z" fill="#FAEC32"></path>
                                                                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M22.438 16.658a1.792 1.792 0 01-2.226 1.65l-.546 1.265a3.158 3.158 0 004.138-2.872l-1.366-.043z" fill="#D0362B"></path>
                                                                                                            </svg></div>
                                                                                                        <div class="sc-hrWEMg fdYuev"><svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" width="32" height="32" size="32" color="currentColor">
                                                                                                                <path d="M16 32c8.837 0 16-7.163 16-16S24.837 0 16 0 0 7.163 0 16s7.163 16 16 16z" fill="#B10E0C"></path>
                                                                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M21.999 17.12c-.353.347-1.342.446-1.241-.382.084-.688.83-.834 1.639-.735-.06.376-.13.854-.398 1.118zm-1.114-2.683c-.033.19-.085.362-.127.543.404-.101 1.661-.413 1.782.128.04.18-.029.37-.08.511-1.136-.108-2.063.082-2.307.894-.163.545.019 1.08.366 1.23.67.288 1.485-.042 1.767-.495a2.09 2.09 0 00-.048.51h.589c.006-.565.088-1.023.175-1.532.074-.434.213-.863.19-1.246-.05-.876-1.497-.566-2.307-.543zm5.903 2.954c-.46.01-.69-.276-.7-.75-.018-.831.345-1.754 1.082-1.837.343-.038.592.042.844.128-.231.933-.148 2.436-1.226 2.46zM28.316 13a15.365 15.365 0 01-.239 1.485c-1.678-.533-2.708.706-2.69 2.236.005.296.055.589.24.798.317.36 1.227.447 1.686.144.09-.059.18-.166.239-.24.044-.055.115-.201.127-.16-.024.163-.06.313-.063.496h.62c.12-1.722.49-3.193.764-4.759h-.684zm-17.52 4.136c-.365.389-1.265.383-1.336-.272-.03-.285.075-.583.128-.878.052-.298.09-.584.143-.846.36-.442 1.42-.495 1.527.24.094.637-.158 1.434-.461 1.756zm.542-2.698c-.58-.218-1.285.042-1.591.29 0 .011-.008.013-.017.014l.017-.014v-.002c.005-.107.042-.181.047-.288h-.589c-.245 1.638-.536 3.23-.843 4.807h.684c.1-.614.165-1.262.303-1.837.156.605 1.176.49 1.607.256.888-.482 1.573-2.777.382-3.226zm3.246 1.15h-1.607a.95.95 0 01.907-.799c.493-.019.846.182.7.799zm-.653-1.215c-.494.038-.912.181-1.209.495-.364.385-.66 1.237-.573 2.012.124 1.107 1.496 1.067 2.594.799.019-.194.065-.36.095-.543-.452.17-1.237.407-1.702.112-.351-.223-.353-.788-.239-1.278.738-.024 1.505-.019 2.244 0 .047-.348.18-.727.063-1.07-.155-.453-.709-.57-1.273-.527zm-6.015.066c-.018.003-.017.025-.016.048a47.269 47.269 0 01-.573 3.273h.685c.164-1.139.352-2.254.588-3.321h-.684zm17.854.014c-.604-.303-1.108.206-1.305.511.056-.157.06-.366.112-.527h-.605a49.488 49.488 0 01-.589 3.322h.7c.005-.44.091-.766.16-1.198.146-.922.36-1.933 1.432-1.629.035-.156.05-.333.095-.479zm-7.685 2.524c-.063-.163-.08-.433-.064-.639.036-.46.203-1.023.462-1.277.357-.35 1.06-.293 1.623-.096.017-.19.055-.36.08-.543-.922-.15-1.797-.057-2.26.431-.454.478-.752 1.577-.541 2.268.246.809 1.35.853 2.243.543.04-.163.06-.344.096-.511-.489.255-1.422.387-1.64-.176zm-.382-2.54c-.607-.246-1.084.17-1.305.559.05-.173.071-.376.112-.559h-.605c-.148 1.15-.366 2.23-.573 3.322h.684c.096-.648.138-1.52.35-2.14.17-.495.616-.917 1.258-.687.009-.183.06-.322.08-.495zm-11.027-1.34c-.098.636-.208 1.26-.319 1.884-.708.008-1.432.035-2.116-.016.13-.61.222-1.257.35-1.868h-.764c-.273 1.556-.522 3.138-.827 4.663h.78c.122-.783.236-1.573.397-2.316.665-.016 1.462-.045 2.1.016-.13.773-.29 1.518-.413 2.3h.78c.25-1.58.514-3.146.827-4.663h-.795zm1.94.702c.137-.095.313-.524.112-.703-.063-.057-.17-.073-.318-.048-.138.023-.217.07-.27.144-.087.118-.166.474-.032.607.13.128.422.06.509 0z" fill="#FFFFFE"></path>
                                                                                                            </svg></div>
                                                                                                        <div class="sc-hrWEMg fdYuev"><svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" width="32" height="32" size="32" color="currentColor">
                                                                                                                <path d="M16 32c8.837 0 16-7.163 16-16S24.837 0 16 0 0 7.163 0 16s7.163 16 16 16z" fill="#3473DB"></path>
                                                                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M6.878 15.975c-.057.143.023.26.177.26h.723c.155 0 .235-.117.178-.26l-.432-1.098c-.057-.144-.15-.144-.207 0l-.439 1.098z" fill="#fff"></path>
                                                                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M22.673 15.292c0-.154.073-.177.161-.05l.087.123a.448.448 0 01.008.465l-.102.156c-.085.129-.154.108-.154-.046v-.648zm3.71 3.19a.569.569 0 01-.432-.238l-.796-1.26c-.082-.13-.218-.131-.3 0l-.804 1.26a.571.571 0 01-.432.237H17.761a.282.282 0 01-.281-.28v-5.193c0-.155.126-.281.28-.281h4.07c.155 0 .282.126.282.28v.843c0 .154-.127.28-.281.28h-2.526a.282.282 0 00-.281.281v.28c0 .155.126.281.28.281h2.246c.155 0 .28.127.28.281v.702c0 .154-.125.28-.28.28h-2.245a.282.282 0 00-.281.281v.421c0 .155.126.281.28.281h2.527c.154 0 .28.126.28.28v.712c0 .154.071.176.157.048l1.65-2.459a.458.458 0 00.001-.467l-1.566-2.371c-.085-.129-.028-.234.126-.234h1.263c.155 0 .348.107.43.238l.709 1.136c.081.13.216.131.3.001l.728-1.139a.573.573 0 01.432-.236h1.223c.154 0 .21.105.124.233l-1.57 2.337a.455.455 0 000 .467l1.653 2.484c.085.128.029.233-.125.233h-1.264zm-9.464-.281c0 .154-.127.28-.281.28h-1.123a.282.282 0 01-.28-.28v-2.707c0-.154-.067-.173-.148-.041l-1.112 1.807a1.623 1.623 0 01-.164.239c-.009 0-.086-.106-.171-.234l-1.198-1.81c-.085-.128-.155-.107-.155.047v2.699c0 .154-.126.28-.28.28h-.983a.282.282 0 01-.28-.28v-5.193c0-.155.125-.281.28-.281h1.156a.56.56 0 01.428.239l1.072 1.74c.081.13.214.13.295 0l1.072-1.74a.56.56 0 01.428-.24h1.163c.154 0 .28.127.28.282V18.2zm-7.704.28a.457.457 0 01-.388-.259l-.194-.464a.457.457 0 00-.388-.26H6.588a.456.456 0 00-.388.26l-.193.464a.457.457 0 01-.39.26H4.519c-.154 0-.231-.117-.171-.26l2.212-5.237a.46.46 0 01.39-.258h.968a.46.46 0 01.39.258l2.22 5.238c.06.142-.017.258-.171.258h-1.14zm19.568-.224l-.313-.466-1.337-1.996a.455.455 0 010-.466l1.254-1.877.31-.467.576-.866c.085-.13.029-.234-.126-.234H25.83a.464.464 0 00-.355.206 44.43 44.43 0 01-.273.444l-.015.026c-.082.13-.214.13-.294-.003l-.011-.018-.268-.448a.466.466 0 00-.358-.207H14.96c-.13 0-.29.095-.358.212-.068.117-.19.32-.27.452l-.357.587c-.08.132-.212.131-.292 0l-.359-.593c-.08-.132-.2-.334-.268-.45a.465.465 0 00-.359-.208H10.182a.282.282 0 00-.281.28v2.25c0 .154-.048.164-.107.021l-.733-1.774a23.34 23.34 0 01-.206-.518.436.436 0 00-.378-.26H6.39a.457.457 0 00-.389.26l-.217.518-2.212 5.243-.22.517-.272.643c-.06.142.016.258.17.258h2.94a.452.452 0 00.387-.253l.205-.492c.054-.13.225-.237.38-.237h.512c.154 0 .325.107.38.237l.204.492c.058.14.232.253.387.253h4.205c.154 0 .28-.126.28-.28v-.764c0-.123.047-.16.105-.081.057.079.207.143.333.143h.489c.125 0 .252-.067.282-.15.03-.081.054-.045.054.082v.77c0 .154.127.28.28.28H24.132a.474.474 0 00.355-.19c.069-.103.193-.295.276-.425l.089-.137c.083-.13.22-.13.303 0l.084.132c.084.13.207.323.276.428a.473.473 0 00.355.192H29.221c.155 0 .21-.105.124-.233l-.562-.833z" fill="#fff"></path>
                                                                                                            </svg></div>
                                                                                                    </div>
                                                                                                    <div class="sc-iQKALj VTnwo"></div>
                                                                                                    <div class="sc-ibxdXY iqneGe"><span data-ds-component="DS-Text" class="sc-RefOD kzCQXs sc-ifAKCX cbbXMA" color="--color-neutral-130" display="block">Mais formas de pagamento</span>
                                                                                                        <div class="sc-eTuwsz fmOdyH">
                                                                                                            <div class="sc-gwVKww cvFIYh"><svg width="96" height="33" viewBox="0 0 96 33" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                                                    <path d="M36.8548 30.4537C36.5379 30.4537 36.2812 30.1967 36.2812 29.8802V12.1684C36.2812 8.42984 39.3224 5.38867 43.061 5.38867L48.5616 5.39682C52.2875 5.40415 55.3189 8.44125 55.3189 12.1672V16.7664C55.3189 20.5049 52.2777 23.5461 48.5392 23.5461H39.9049C39.588 23.5461 39.3314 23.2895 39.3314 22.9726C39.3314 22.6556 39.588 22.399 39.9049 22.399H48.5392C51.6447 22.399 54.1715 19.8723 54.1715 16.7664V12.1672C54.1715 9.07262 51.6541 6.55039 48.5596 6.54388L43.0597 6.53573C39.955 6.53573 37.4283 9.06244 37.4283 12.1684V29.8802C37.4283 30.1967 37.1717 30.4537 36.8548 30.4537Z" fill="#98989C"></path>
                                                                                                                    <path d="M61.2144 23.6324C60.8975 23.6324 60.6409 23.3754 60.6409 23.0589V8.50927C60.6409 7.42128 59.7557 6.53614 58.6677 6.53614H56.2819C55.965 6.53614 55.708 6.27911 55.708 5.96261C55.708 5.6457 55.965 5.38867 56.2819 5.38867H58.6677C60.3883 5.38867 61.7879 6.78869 61.7879 8.50927V23.0589C61.7879 23.3754 61.5313 23.6324 61.2144 23.6324Z" fill="#98989C"></path>
                                                                                                                    <path d="M60.7168 3.75918L59.6349 2.6773C59.3665 2.40886 59.3665 1.97342 59.6349 1.70498L60.716 0.623506C60.9848 0.354664 61.4207 0.354664 61.6895 0.623506L62.771 1.70498C63.0394 1.97342 63.0394 2.40886 62.771 2.6773L61.6891 3.75918C61.4207 4.02762 60.9852 4.02762 60.7168 3.75918Z" fill="#4BB8A9"></path>
                                                                                                                    <path d="M68.1399 23.4311H65.7737C65.4568 23.4311 65.2002 23.174 65.2002 22.8575C65.2002 22.5406 65.4568 22.2836 65.7737 22.2836H68.1399C69.2125 22.2836 70.221 21.8661 70.9795 21.1076L76.5135 15.6762C76.9685 15.2212 77.5734 14.9707 78.217 14.9707C78.8606 14.9707 79.4655 15.2212 79.9205 15.6762L85.4346 21.0873C86.1931 21.8461 87.2012 22.2637 88.2742 22.2637H90.1976C90.5145 22.2637 90.7715 22.5203 90.7715 22.8372C90.7715 23.1541 90.5145 23.4107 90.1976 23.4107H88.2742C86.8949 23.4107 85.5984 22.8738 84.6232 21.8987L79.1095 16.4876C78.8708 16.2493 78.5539 16.1178 78.217 16.1178C77.8798 16.1178 77.5633 16.2493 77.325 16.4876L71.7905 21.9186C70.8153 22.8938 69.5188 23.4311 68.1399 23.4311Z" fill="#98989C"></path>
                                                                                                                    <path d="M68.1399 5.38867H65.7737C65.4568 5.38867 65.2002 5.6457 65.2002 5.9622C65.2002 6.27911 65.4568 6.53614 65.7737 6.53614H68.1399C69.2125 6.53614 70.221 6.95366 70.9795 7.71212L76.5135 13.1435C76.9685 13.5985 77.5734 13.849 78.217 13.849C78.8606 13.849 79.4655 13.5985 79.9205 13.1435L85.4346 7.73248C86.1931 6.97402 87.2012 6.5561 88.2742 6.5561H90.1976C90.5145 6.5561 90.7715 6.29948 90.7715 5.98257C90.7715 5.66566 90.5145 5.40904 90.1976 5.40904H88.2742C86.8949 5.40904 85.5984 5.94591 84.6232 6.92107L79.1095 12.3321C78.8708 12.5704 78.5539 12.702 78.217 12.702C77.8798 12.702 77.5633 12.5704 77.325 12.3321L71.7905 6.90111C70.8153 5.92595 69.5188 5.38867 68.1399 5.38867Z" fill="#98989C"></path>
                                                                                                                    <path d="M6.66717 25.3093C7.85455 25.3093 8.97147 24.847 9.8114 24.0075L14.3512 19.4677C14.6697 19.1484 15.2253 19.1492 15.5438 19.4677L20.1003 24.0242C20.9398 24.8637 22.0567 25.326 23.2441 25.326H24.1386L18.3891 31.0756C16.5935 32.8711 13.6823 32.8711 11.8864 31.0756L6.12012 25.3093H6.66717Z" fill="#4BB8A9"></path>
                                                                                                                    <path d="M23.2447 9.29152C22.0573 9.29152 20.9404 9.75384 20.1005 10.5934L15.5444 15.1502C15.2161 15.4785 14.6804 15.4798 14.3513 15.1498L9.81156 10.6097C8.97204 9.77054 7.85512 9.30822 6.66774 9.30822H6.12109L11.8869 3.54197C13.6829 1.74643 16.5941 1.74643 18.3897 3.54197L24.1392 9.29152H23.2447Z" fill="#4BB8A9"></path>
                                                                                                                    <path d="M1.34665 14.1619L4.78131 10.7272H6.6628C7.48195 10.7272 8.28359 11.0596 8.86241 11.6388L13.4022 16.1786C13.8266 16.6031 14.3851 16.8157 14.9427 16.8157C15.5008 16.8157 16.0588 16.6031 16.4833 16.179L21.0401 11.6221C21.619 11.0429 22.4206 10.7109 23.2398 10.7109H25.4691L28.9201 14.1619C30.7156 15.9574 30.7156 18.8691 28.9201 20.6646L25.4691 24.1156H23.2398C22.4206 24.1156 21.619 23.7836 21.0401 23.2043L16.4837 18.6479C15.6604 17.8251 14.2246 17.8247 13.4022 18.6483L8.86241 23.1876C8.28359 23.7669 7.48195 24.0993 6.6628 24.0993L4.7809 24.0989L1.34665 20.6646C-0.448884 18.8691 -0.448884 15.9574 1.34665 14.1619Z" fill="#4BB8A9"></path>
                                                                                                                </svg><span data-ds-component="DS-Text" class="sc-hXRMBi gTlfhj sc-ifAKCX iOyFmS" color="--color-neutral-130" display="block">Aprovação imediata.</span></div>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </reach-portal>
                                                                            <script>
                                                                                // Get a reference to the SVG element
                                                                                const svgCloseButton = document.querySelector('[data-testid="button-close"]');

                                                                                // Function to close the modal
                                                                                function closeModal() {
                                                                                    const modalOverlay = document.querySelector('reach-portal');
                                                                                    modalOverlay.style.display = 'none';
                                                                                }

                                                                                // Attach the click event listener to the SVG element
                                                                                svgCloseButton.addEventListener('click', closeModal);
                                                                            </script>
                                                                            <script>
                                                                                function vermodal() {
                                                                                    var modal = document.getElementById('modalContainer');
                                                                                    modal.style.display = 'block';
                                                                                }
                                                                            </script>
                                                                            <style>
                                                                                @keyframes modalFadeIn {
                                                                                    from {
                                                                                        opacity: 0;
                                                                                        transform: translateY(50px);
                                                                                    }

                                                                                    to {
                                                                                        opacity: 1;
                                                                                        transform: translateY(0);
                                                                                    }
                                                                                }

                                                                                .sc-iujRgT.gRMyKA {
                                                                                    animation: modalFadeIn 0.3s ease-in-out;
                                                                                }

                                                                                #modalContainer {
                                                                                    display: none;
                                                                                }

                                                                                [data-rsbs-is-dismissable="true"] [data-rsbs-backdrop],
                                                                                [data-rsbs-is-dismissable="false"][data-rsbs-state="opening"] [data-rsbs-backdrop],
                                                                                [data-rsbs-is-dismissable="false"][data-rsbs-state="closing"] [data-rsbs-backdrop] {
                                                                                    opacity: var(--rsbs-backdrop-opacity, 1);
                                                                                }

                                                                                [data-rsbs-backdrop] {
                                                                                    top: -60px;
                                                                                    bottom: -60px;
                                                                                    background-color: var(--rsbs-backdrop-bg, rgba(0, 0, 0, 0.6));
                                                                                    will-change: opacity;
                                                                                    cursor: pointer;
                                                                                    opacity: 1;
                                                                                }

                                                                                [data-rsbs-overlay],
                                                                                [data-rsbs-backdrop],
                                                                                [data-rsbs-root]::after {
                                                                                    z-index: 999;
                                                                                    overscroll-behavior: none;
                                                                                    touch-action: none;
                                                                                    position: fixed;
                                                                                    right: 0px;
                                                                                    bottom: 0px;
                                                                                    left: 0px;
                                                                                    user-select: none;
                                                                                    -webkit-tap-highlight-color: transparent;
                                                                                }

                                                                                .gRMyKA [data-rsbs-overlay] {
                                                                                    max-height: calc(100% - 16px);
                                                                                    height: auto !important;
                                                                                }

                                                                                [data-rsbs-overlay],
                                                                                [data-rsbs-backdrop],
                                                                                [data-rsbs-root]::after {
                                                                                    z-index: 999;
                                                                                    overscroll-behavior: none;
                                                                                    touch-action: none;
                                                                                    position: fixed;
                                                                                    right: 0px;
                                                                                    bottom: 0px;
                                                                                    left: 0px;
                                                                                    user-select: none;
                                                                                    -webkit-tap-highlight-color: transparent;
                                                                                }

                                                                                [data-rsbs-overlay],
                                                                                [data-rsbs-root]::after {
                                                                                    max-width: var(--rsbs-max-w, auto);
                                                                                    margin-left: var(--rsbs-ml, env(safe-area-inset-left));
                                                                                    margin-right: var(--rsbs-mr, env(safe-area-inset-right));
                                                                                }

                                                                                [data-rsbs-overlay] {
                                                                                    border-top-left-radius: var(--rsbs-overlay-rounded, 16px);
                                                                                    border-top-right-radius: var(--rsbs-overlay-rounded, 16px);
                                                                                    display: flex;
                                                                                    background: var(--rsbs-bg, #fff);
                                                                                    flex-direction: column;
                                                                                    height: var(--rsbs-overlay-h, 0px);
                                                                                    transform: translate3d(0, var(--rsbs-overlay-translate-y, 0px), 0);
                                                                                    will-change: height;
                                                                                }

                                                                                .gRMyKA [data-rsbs-header] {
                                                                                    padding-bottom: 0px;
                                                                                    box-shadow: none !important;
                                                                                }

                                                                                [data-rsbs-header] {
                                                                                    text-align: center;
                                                                                    user-select: none;
                                                                                    box-shadow: 0 1px 0 rgba(46, 59, 66, calc(var(--rsbs-content-opacity, 1) * 0.125));
                                                                                    z-index: 1;
                                                                                    padding-top: calc(20px + env(safe-area-inset-top));
                                                                                    padding-bottom: 8px;
                                                                                }

                                                                                [data-rsbs-footer],
                                                                                [data-rsbs-header] {
                                                                                    flex-shrink: 0;
                                                                                    cursor: ns-resize;
                                                                                    padding: 16px;
                                                                                }

                                                                                .gRMyKA [data-rsbs-header]::before {
                                                                                    background-color: transparent !important;
                                                                                }

                                                                                @media (-webkit-min-device-pixel-ratio: 2),
                                                                                (min-resolution: 2dppx) [data-rsbs-header]::before {
                                                                                    transform: translateX(-50%) scaleY(0.75);
                                                                                }

                                                                                [data-rsbs-header]::before {
                                                                                    position: absolute;
                                                                                    content: "";
                                                                                    display: block;
                                                                                    width: 36px;
                                                                                    height: 4px;
                                                                                    top: calc(8px + env(safe-area-inset-top));
                                                                                    left: 50%;
                                                                                    transform: translateX(-50%);
                                                                                    border-radius: 2px;
                                                                                    background-color: var(--rsbs-handle-bg, hsla(0, 0%, 0%, 0.14));
                                                                                }

                                                                                [data-rsbs-is-dismissable="true"] [data-rsbs-header]>*,
                                                                                [data-rsbs-is-dismissable="true"] [data-rsbs-scroll]>*,
                                                                                [data-rsbs-is-dismissable="true"] [data-rsbs-footer]>*,
                                                                                [data-rsbs-is-dismissable="false"][data-rsbs-state="opening"] [data-rsbs-header]>*,
                                                                                [data-rsbs-is-dismissable="false"][data-rsbs-state="closing"] [data-rsbs-header]>*,
                                                                                [data-rsbs-is-dismissable="false"][data-rsbs-state="opening"] [data-rsbs-scroll]>*,
                                                                                [data-rsbs-is-dismissable="false"][data-rsbs-state="closing"] [data-rsbs-scroll]>*,
                                                                                [data-rsbs-is-dismissable="false"][data-rsbs-state="opening"] [data-rsbs-footer]>*,
                                                                                [data-rsbs-is-dismissable="false"][data-rsbs-state="closing"] [data-rsbs-footer]>* {
                                                                                    opacity: var(--rsbs-content-opacity, 1);
                                                                                }

                                                                                .cZBzyZ {
                                                                                    display: flex;
                                                                                    -webkit-box-pack: end;
                                                                                    justify-content: flex-end;
                                                                                }

                                                                                .gETGbd {
                                                                                    padding: 0px;
                                                                                    background-color: transparent;
                                                                                    border: none;
                                                                                }

                                                                                .fYRuoc {
                                                                                    cursor: pointer;
                                                                                }

                                                                                .gETGbd {
                                                                                    padding: 0px;
                                                                                    background-color: transparent;
                                                                                    border: none;
                                                                                }

                                                                                [data-rsbs-footer],
                                                                                [data-rsbs-header] {
                                                                                    flex-shrink: 0;
                                                                                    cursor: ns-resize;
                                                                                    padding: 16px;
                                                                                }

                                                                                [data-rsbs-scroll] {
                                                                                    flex-shrink: 1;
                                                                                    -webkit-box-flex: 1;
                                                                                    flex-grow: 1;
                                                                                    -webkit-tap-highlight-color: revert;
                                                                                    user-select: auto;
                                                                                    overflow: auto;
                                                                                    overscroll-behavior: contain;
                                                                                }

                                                                                [data-rsbs-has-footer="false"] [data-rsbs-content] {
                                                                                    padding-bottom: env(safe-area-inset-bottom);
                                                                                }

                                                                                [data-rsbs-content] {
                                                                                    overflow: hidden;
                                                                                }

                                                                                .cWeFKg {
                                                                                    padding: 16px;
                                                                                }

                                                                                .iLwJlJ {
                                                                                    margin-bottom: 16px;
                                                                                }

                                                                                .hUnWqk {
                                                                                    display: block;
                                                                                    margin: 0px;
                                                                                    padding: 0px;
                                                                                    font-style: normal;
                                                                                    font-family: var(--font-family);
                                                                                    word-break: break-word;
                                                                                    font-weight: var(--font-weight-bold);
                                                                                    line-height: var(--font-lineheight-medium);
                                                                                    font-size: var(--font-size-sm);
                                                                                    color: var(--color-neutral-130);
                                                                                }

                                                                                .VTnwo {
                                                                                    border-bottom: 1px solid rgb(229, 229, 229);
                                                                                    margin: 8px 0px;
                                                                                }

                                                                                .iLwJlJ {
                                                                                    margin-bottom: 16px;
                                                                                }

                                                                                .eAsDxl {
                                                                                    color: rgb(16, 206, 100);
                                                                                }

                                                                                .gpyBbE {
                                                                                    display: flex;
                                                                                    margin-bottom: 16px;
                                                                                    margin-top: 16px;
                                                                                }

                                                                                .fdYuev {
                                                                                    margin-right: 8px;
                                                                                }

                                                                                .VTnwo {
                                                                                    border-bottom: 1px solid rgb(229, 229, 229);
                                                                                    margin: 8px 0px;
                                                                                }

                                                                                .iqneGe {
                                                                                    margin-top: 16px;
                                                                                }

                                                                                .fmOdyH {
                                                                                    margin-top: 16px;
                                                                                }

                                                                                .cvFIYh {
                                                                                    display: flex;
                                                                                    -webkit-box-align: center;
                                                                                    align-items: center;
                                                                                    margin-top: 16px;
                                                                                }

                                                                                .gTlfhj {
                                                                                    color: rgb(153, 153, 153);
                                                                                    margin-left: 21px;
                                                                                }

                                                                                .iOyFmS {
                                                                                    display: block;
                                                                                    margin: 0px;
                                                                                    padding: 0px;
                                                                                    font-style: normal;
                                                                                    font-family: var(--font-family);
                                                                                    word-break: break-word;
                                                                                    font-weight: var(--font-weight-regular);
                                                                                    line-height: var(--font-lineheight-medium);
                                                                                    font-size: var(--font-size-xxxs);
                                                                                    color: var(--color-neutral-130);
                                                                                }

                                                                                .cvFIYh {
                                                                                    display: flex;
                                                                                    -webkit-box-align: center;
                                                                                    align-items: center;
                                                                                    margin-top: 16px;
                                                                                }

                                                                                [data-rsbs-root]::after {
                                                                                    content: "";
                                                                                    pointer-events: none;
                                                                                    background: var(--rsbs-bg, #fff);
                                                                                    height: 1px;
                                                                                    transform-origin: center bottom;
                                                                                    transform: scale3d(1, var(--rsbs-antigap-scale-y, 0), 1);
                                                                                    will-change: transform;
                                                                                }
                                                                            </style>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="ad__h3us20-2 dAHSDM"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 hEqqlT">
                                    <div class="ad__h3us20-4 cxrGoW">
                                        <div>
                                            <div class="ad__h3us20-5 iTegyV"></div>
                                            <div class="ad__sc-15o28wz-0 kTeLyN">
                                                <div role="presentation" class="ad__sc-15o28wz-1 dYYOaL">
                                                    <a data-ds-component="DS-Link" rel="nofollow" href="https://emprestimos.olx.com.br/?aff=moveis_olx&amp;title=Geladeira&amp;image=/36/361381426742768.jpg&amp;price=R%24%201.150&amp;utm_source=olx&amp;utm_medium=olx&amp;utm_campaign=olx&amp;utm_content=moveis" target="_blank" class="sc-EHOje evIBiW">
                                                        <span class="ad__sc-15o28wz-2 dsBvGq">
                                                            <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
                                                                <path fill="#fff" d="M0 0h24v24H0z"></path>
                                                                <path d="M7.85 19.803a1.086 1.086 0 01.913-.457h6.391c.507 0 3.296-2.798 3.652-3.196a24.197 24.197 0 002.283-3.652 1.826 1.826 0 00-1.826-.456c-.808.187-1.283.767-1.826 1.826l-2.09 1.086" stroke="#9129b1" stroke-linejoin="round"></path>
                                                                <path d="M10.59 16.607h3.651c1.826 0 1.826-2.283 0-2.283h-2.41c-.383 0-1.096-.913-1.698-.913H7.85a3.195 3.195 0 00-1.826.913L4.198 16.15M3.282 15.236L1 17.518l5.478 5.478 2.282-2.282-5.478-5.478zM3.285 17.52l.913.913" stroke="#9129b1" stroke-linejoin="round"></path>
                                                                <path d="M18.747 12.238a3.8 3.8 0 00.06-.653c0-2.392-1.498-4.565-4.11-6.39M12.415 5.194c-2.61 1.826-4.108 3.99-4.108 6.391-.011.653.186 1.292.561 1.826" stroke="#9129b1" stroke-miterlimit="10"></path>
                                                                <path d="M14.698 5.194c-.119.183-.836.274-1.141.274a2.241 2.241 0 01-1.142-.274s-1.324-2.451-1.269-2.547c.48-.859 1.475-.694 2.41-.457a6.3 6.3 0 002.119.265c.023.347-.977 2.74-.977 2.74zM11.959 11.129v.456a.913.913 0 00.913.913h.913a.913.913 0 00.913-.913v-.255a.913.913 0 00-.626-.868l-1.488-.493a.913.913 0 01-.625-.867v-.256a.913.913 0 01.913-.913h.913a.913.913 0 01.913.913v.457M13.328 7.933V7.02M13.328 12.498v.913" stroke="#9129b1" stroke-miterlimit="10"></path>
                                                            </svg>
                                                        </span>
                                                        Simular empréstimo
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 eDFJpn">
                                    <div from="lg" class="ad__h3us20-4 hqjcIS">
                                        <div>
                                            <div class="ad__h3us20-5 iCUpEv"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 lcBaat">
                                    <div class="ad__h3us20-4 cxrGoW">
                                        <div>
                                            <h1 data-ds-component="DS-Text" class="ad__sc-45jt43-0 htAiPK sc-hSdWYo bYQcLm" color="--color-neutral-130" display="block"><?php echo $dados['nome']; ?> </h1>
                                        </div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 CPTuX">
                                    <div from="lg" class="ad__h3us20-4 hqjcIS">
                                        <div>
                                            <span data-ds-component="DS-Text" color="--color-neutral-120" class="ad__sc-1oq8jzc-0 dWayMW sc-hSdWYo jFeRvR" display="block">Publicado em
                                                <!-- -->
                                                <!-- -->
                                                <?php
$publicado = $dados['publicado']; 
$date = new DateTime($publicado);
$formattedDate = $date->format('d/m/y \à\s H:i');
echo $formattedDate;
?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 gCLDqU">
                                    <div from="lg" class="ad__h3us20-4 hqjcIS">
                                        <div>
                                            <div data-ds-component="DS-Flex" class="sc-kafWEX sc-fZwumE lhTahy"><span data-ds-component="DS-Text" color="--color-neutral-130" display="block" class="sc-hSdWYo dTeYkN">Este anúncio oferece:</span>
                                                <div data-ds-component="DS-Flex" class="sc-kafWEX sc-fQejPQ cONchc">
                                                    <div class="sc-jXQZqI gRdTZD"><svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" width="24" height="24" style="color:var(--color-neutral-darkest)" color="currentColor" size="24">
                                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M8.218 14.976a.999.999 0 01-.436 0A8.67 8.67 0 011 6.499V3.5A2.5 2.5 0 013.5 1h9A2.5 2.5 0 0115 3.5v3a8.669 8.669 0 01-6.782 8.476zM14 6.5v-3A1.5 1.5 0 0012.5 2h-9A1.5 1.5 0 002 3.5v3A7.669 7.669 0 008 14a7.67 7.67 0 006-7.5z" fill="currentColor"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M8.969 3.3a.571.571 0 01.434.682l-.107.488a2.818 2.818 0 01.613.307c.246.163.24.506.03.714-.224.221-.59.196-.87.05l-.02-.01a1.355 1.355 0 00-.623-.144c-.252 0-.477.07-.675.209a.643.643 0 00-.296.55c0 .113.042.219.126.318.087.098.2.189.336.27.136.081.286.166.448.253.166.084.33.183.493.296.165.11.316.234.453.37a1.657 1.657 0 01.462 1.168c0 .359-.1.686-.3.982a2.017 2.017 0 01-.803.69 2.4 2.4 0 01-.752.225l-.114.518a.571.571 0 11-1.116-.246l.077-.353c-.16-.043-.315-.1-.465-.171a3.123 3.123 0 01-.615-.389c-.23-.187-.208-.53.01-.73.235-.214.603-.178.864.005a1.655 1.655 0 001.01.32c.159 0 .314-.03.465-.091a.995.995 0 00.392-.292.71.71 0 00.162-.458.689.689 0 00-.131-.41 1.17 1.17 0 00-.331-.322 5.34 5.34 0 00-.453-.266 9.65 9.65 0 01-.493-.284 3.156 3.156 0 01-.453-.335 1.428 1.428 0 01-.335-.458 1.484 1.484 0 01-.126-.62c0-.345.094-.658.283-.937.189-.279.444-.495.767-.65.259-.126.54-.201.842-.226l.13-.587a.571.571 0 01.68-.435z" fill="currentColor"></path>
                                                        </svg></div>
                                                    <div data-ds-component="DS-Flex" class="sc-kafWEX sc-clNaTc fkwSEH">
                                                        <p data-ds-component="DS-Text" class="sc-iGPElx kRndgy sc-hSdWYo bducQJ" color="--color-neutral-130" display="block"><span data-ds-component="DS-Text" display="inline" class="sc-kasBVs dOfbLu sc-hSdWYo dVkImY" color="--color-neutral-130">Garantia da OLX. </span>Pague online e receba o que comprou ou a OLX devolve seu dinheiro</p>
                                                        <button data-testid="button-wrapper" data-ds-component="DS-Button" class="sc-etwtAo kOrzBT sc-gZMcBi giLqBp" id="openModalBtn">
                                                            <div class="sc-iwsKbI hMjsjM">Saiba mais sobre a garantia da OLX</div>
                                                        </button>
                                                        <div id="modal" class="modal">
                                                            <div class="modal-content">
                                                                <span id="closeModalBtn">×</span>
                                                                <span data-ds-component="DS-Text" class="sc-iBEsjs gVrvSe sc-hSdWYo bYQcLm" color="--color-neutral-130" display="block">Garantia da OLX</span>
                                                                <span data-ds-component="DS-Text" class="sc-hzNEM dNTrAm sc-hSdWYo iDAOTJ" color="--color-neutral-130" display="block">Receba o que comprou ou a OLX devolve seu dinheiro</span>
                                                                <div data-ds-component="DS-Flex" class="sc-kafWEX sc-fcdeBU oCUry">
                                                                    <p data-ds-component="DS-Text" class="sc-gmeYpB QUAjb sc-hSdWYo htqcWR" color="--color-neutral-130" display="block">Ao realizar o pagamento pela OLX, clicando no botão Comprar, nós protegemos o seu dinheiro até que você confirme que recebeu o produto conforme esperado. Situações de cobertura:</p>
                                                                    <ul class="sc-kxynE iVorxG">
                                                                        <li class="sc-cooIXK fWOsuW">Produto não recebido</li>
                                                                        <li class="sc-cooIXK fWOsuW">Produto defeituoso*</li>
                                                                        <li class="sc-cooIXK fWOsuW">Produto diferente do anunciado</li>
                                                                    </ul>
                                                                    <p data-ds-component="DS-Text" class="sc-gmeYpB QUAjb sc-hSdWYo htqcWR" color="--color-neutral-130" display="block">Não recebeu o que esperava? Acesse “Preciso de ajuda” em “Detalhes da Compra” e nós resolveremos pra você.</p>
                                                                    <p data-ds-component="DS-Text" class="sc-kZmsYB UJxrT sc-hSdWYo iCBjkC" color="--color-neutral-130" display="block">*Exceto nos casos de anúncios que explicitam essa condição</p>
                                                                </div>
                                                                <div data-ds-component="DS-Flex" class="sc-kafWEX sc-RcBXQ iaDrkT"><button data-testid="button-wrapper" data-ds-component="DS-Button" class="sc-iSDuPN bmTnMU sc-gZMcBi iCyRCL">
                                                                        <div class="sc-iwsKbI hMjsjM"> <!-- -->Voltar para o anúncio</div>
                                                                    </button></div>
                                                            </div>
                                                        </div>
                                                        <style>
                                                            /* The Modal (background) */
                                                            .modal {
                                                                display: none;
                                                                align-items: center;
                                                                justify-content: center;
                                                                animation: modalSlideUp 0.3s ease-out;
                                                                position: fixed;
                                                                z-index: 9999;
                                                                bottom: 0;
                                                                /* Coloque o modal na parte inferior da tela */
                                                                left: 0;
                                                                /* Alinhe o modal à esquerda da tela */
                                                                right: 0;
                                                                /* Alinhe o modal à direita da tela */
                                                                margin: 0 auto;
                                                                /* Centralize o modal horizontalmente */
                                                                overflow: auto;
                                                                background-color: rgba(0, 0, 0, 0.5);
                                                            }

                                                            @keyframes modalSlideUp {
                                                                from {
                                                                    transform: translateY(100%);
                                                                }

                                                                to {
                                                                    transform: translateY(0);
                                                                }
                                                            }

                                                            .modal-content {
                                                                max-width: 500px;
                                                                background-color: #fff;
                                                                padding: 20px;
                                                                border-top-left-radius: 16px;
                                                                border-top-right-radius: 16px;
                                                                box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
                                                                max-height: 80vh;
                                                                overflow-y: auto;
                                                                margin-top: calc(500% - 150px);
                                                                /* Ajuste o valor conforme necessário para a posição desejada */
                                                            }

                                                            #closeModalBtn {
                                                                color: #aaa;
                                                                float: right;
                                                                font-size: 28px;
                                                                font-weight: bold;
                                                                cursor: pointer;
                                                            }

                                                            #closeModalBtn:hover,
                                                            #closeModalBtn:focus {
                                                                color: black;
                                                                text-decoration: none;
                                                                cursor: pointer;
                                                            }
                                                        </style>
                                                        <script>
                                                            // Get references to the modal elements
                                                            const modal = document.getElementById('modal');
                                                            const openModalBtn = document.getElementById('openModalBtn');
                                                            const closeModalBtn = document.getElementById('closeModalBtn');

                                                            // Function to open the modal
                                                            function openModal() {
                                                                modal.style.display = 'block';
                                                            }

                                                            // Function to close the modal
                                                            function closeModal() {
                                                                modal.style.display = 'none';
                                                            }

                                                            // Event listeners for the buttons
                                                            openModalBtn.addEventListener('click', openModal);
                                                            closeModalBtn.addEventListener('click', closeModal);
                                                        </script>
                                                    </div>
                                                </div>
                                                <div data-ds-component="DS-Flex" class="sc-kafWEX sc-fQejPQ cONchc">
                                                    <div class="sc-jXQZqI gRdTZD"><svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" width="24" height="24" style="color:var(--color-neutral-darkest)" color="currentColor" size="24">
                                                            <g clip-path="url(#Delivery_svg__clip0)">
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M.5 2.667a.5.5 0 01.5-.5h6.89a.5.5 0 01.5.5v1.929h3.687c.539 0 1.007.368 1.134.891l.411 1.698 1.791.923c.388.2.632.6.632 1.037v2.57c0 .644-.522 1.167-1.167 1.167h-1.574a2.012 2.012 0 11-4.018 0H7.392v-7.74a.505.505 0 01-.002-.047V3.167H1a.5.5 0 01-.5-.5zm9.114 9.215a2.01 2.01 0 013.362 0h1.902a.167.167 0 00.167-.167v-2.57a.167.167 0 00-.09-.148l-2.197-1.133-.519-2.141a.167.167 0 00-.162-.127H8.393v6.286h1.221zm-8.188-6.18a.5.5 0 01.5-.5h3.6a.5.5 0 110 1h-3.6a.5.5 0 01-.5-.5zm1.68 2.536a.5.5 0 000 1h2.332a.5.5 0 000-1H3.105zm1.177 3.036a.5.5 0 100 1h1a.5.5 0 000-1h-1zM11.295 14a1.012 1.012 0 100-2.024 1.012 1.012 0 000 2.024z" fill="currentColor"></path>
                                                            </g>
                                                            <defs>
                                                                <clipPath id="Delivery_svg__clip0">
                                                                    <path d="M0 0h16v16H0V0z" fill="#fff"></path>
                                                                </clipPath>
                                                            </defs>
                                                        </svg></div>
                                                    <div data-ds-component="DS-Flex" class="sc-kafWEX sc-clNaTc fkwSEH">
                                                        <p data-ds-component="DS-Text" class="sc-iGPElx kRndgy sc-hSdWYo bducQJ" color="--color-neutral-130" display="block"><span data-ds-component="DS-Text" display="inline" class="sc-kasBVs dOfbLu sc-hSdWYo dVkImY" color="--color-neutral-130">Entrega fácil. </span>Receba ou retire seu produto onde quiser com segurança.</p>
                                                        <button data-testid="button-wrapper" data-ds-component="DS-Button" class="sc-etwtAo kOrzBT sc-gZMcBi giLqBp saibafrete" id="openModalBtnfrete">
                                                            <div class="sc-iwsKbI hMjsjM">Saiba mais sobre a entrega</div>
                                                        </button>

                                                        <div id="modalfrete" class="modal">
                                                            <!-- Modal content -->
                                                            <div class="modalfrete-content">
                                                                <span id="closeModalBtnfrete">×</span>
                                                                <!-- Add your content here for the "Saiba mais sobre a entrega" modal -->
                                                                <span data-ds-component="DS-Text" class="sc-gtfDJT fsMHPV sc-hSdWYo bYQcLm" color="--color-neutral-130" display="block">Entrega fácil</span>
                                                                <div class="sc-hzDEsm dPqlXg"><svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path d="M16 30C23.732 30 30 23.732 30 16C30 8.26801 23.732 2 16 2C8.26801 2 2 8.26801 2 16C2 23.732 8.26801 30 16 30Z" fill="#F0E6FF"></path>
                                                                        <path d="M30.2649 19.3581C30.2899 18.8243 30.2649 16.4465 28.5067 16.4465C28.3818 16.2281 27.8824 15.1363 27.4329 14.2143C27.0334 13.3408 26.1344 12.7827 25.1605 12.7827H21.4397V21.7117H30.0651C30.0651 21.7117 30.7393 21.275 30.7393 20.7654C30.7393 20.2801 30.8642 19.5037 30.2649 19.3581Z" fill="white"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M21.1897 12.7827C21.1897 12.6446 21.3016 12.5327 21.4397 12.5327H25.1605C26.2269 12.5327 27.2163 13.1428 27.659 14.1074C27.8574 14.5144 28.0653 14.9541 28.246 15.3361C28.2704 15.3876 28.2942 15.4381 28.3175 15.4873C28.4648 15.7985 28.5852 16.0513 28.6608 16.2021C29.0899 16.2337 29.4319 16.3974 29.6967 16.6431C29.9868 16.9124 30.172 17.2682 30.2914 17.6223C30.4884 18.2066 30.5211 18.8319 30.5191 19.1872C30.6322 19.2455 30.7239 19.3266 30.7948 19.4252C30.8985 19.5693 30.9485 19.7373 30.9737 19.8949C30.9991 20.0532 31.0019 20.2176 30.9995 20.3654C30.9983 20.4392 30.9961 20.5028 30.994 20.5619C30.9916 20.633 30.9893 20.6975 30.9893 20.7654C30.9893 21.1234 30.7591 21.4217 30.5812 21.6042C30.4867 21.7011 30.3931 21.7793 30.3234 21.8332C30.2884 21.8603 30.2589 21.8817 30.2377 21.8966C30.2271 21.904 30.2185 21.9099 30.2123 21.9141L30.2047 21.9191L30.2024 21.9206L30.2016 21.9212L30.2011 21.9214C30.2011 21.9215 30.201 21.9215 30.0651 21.7117L30.2011 21.9214C30.1607 21.9477 30.1133 21.9617 30.0651 21.9617H21.4397C21.3016 21.9617 21.1897 21.8498 21.1897 21.7117V12.7827ZM29.9859 21.4617C29.9955 21.4546 30.0061 21.4466 30.0175 21.4378C30.0742 21.3938 30.1492 21.331 30.2232 21.2551C30.3825 21.0918 30.4893 20.917 30.4893 20.7654C30.4893 20.6966 30.4921 20.6117 30.4948 20.5284C30.4968 20.4683 30.4987 20.409 30.4995 20.3572C30.5018 20.2183 30.4984 20.0886 30.48 19.9739C30.4615 19.8586 30.4304 19.7748 30.3889 19.7172C30.3518 19.6656 30.2986 19.6236 30.2059 19.6011C30.0895 19.5728 30.0096 19.466 30.0152 19.3465C30.0271 19.0909 30.0257 18.3995 29.8176 17.782C29.714 17.4749 29.5649 17.2029 29.3566 17.0096C29.154 16.8216 28.8836 16.6965 28.5067 16.6965C28.417 16.6965 28.3342 16.6485 28.2897 16.5706C28.221 16.4505 28.0591 16.1101 27.8656 15.7012C27.8422 15.6518 27.8183 15.6012 27.7939 15.5497C27.6127 15.1665 27.4056 14.7287 27.2082 14.3238L27.2055 14.3183C26.8484 13.5375 26.0408 13.0327 25.1605 13.0327H21.6897V21.4617H29.9859Z" fill="#4A4A4A"></path>
                                                                        <path d="M28.5187 16.4465C30.2768 16.4465 30.2486 18.7711 30.2236 19.3049H21.3984L21.4517 12.7827H25.1725C26.1464 12.7827 27.0453 13.3408 27.4449 14.2143C27.8944 15.1363 28.3938 16.2281 28.5187 16.4465Z" fill="#6E0AD6"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M21.2017 12.7807C21.2028 12.6434 21.3144 12.5327 21.4517 12.5327H25.1725C26.2389 12.5327 27.2283 13.1428 27.6709 14.1074C27.8693 14.5144 28.0773 14.9541 28.258 15.3361C28.2823 15.3877 28.3062 15.4381 28.3295 15.4873C28.4767 15.7984 28.5971 16.0512 28.6727 16.202C29.0999 16.2329 29.439 16.3927 29.7002 16.6347C29.9864 16.8999 30.1651 17.2504 30.2777 17.5986C30.5018 18.2913 30.4861 19.0435 30.4733 19.3166C30.4671 19.45 30.3572 19.5549 30.2236 19.5549H21.3984C21.3318 19.5549 21.2679 19.5283 21.2209 19.481C21.174 19.4336 21.1479 19.3695 21.1484 19.3029L21.2017 12.7807ZM21.6996 13.0327L21.6505 19.0549H29.9796C29.9803 18.7267 29.9524 18.2176 29.802 17.7525C29.705 17.4528 29.5626 17.1888 29.3604 17.0014C29.1638 16.8193 28.8972 16.6965 28.5187 16.6965C28.429 16.6965 28.3462 16.6485 28.3016 16.5706C28.233 16.4505 28.0711 16.1101 27.8776 15.7012C27.8542 15.6518 27.8303 15.6012 27.8059 15.5497C27.6246 15.1665 27.4175 14.7287 27.2202 14.3238L27.2175 14.3183L27.2175 14.3183C26.8604 13.5375 26.0528 13.0327 25.1725 13.0327H21.6996Z" fill="#4A4A4A"></path>
                                                                        <path d="M26.4829 16.4939L25.7172 14.844C25.6693 14.7227 25.5497 14.6499 25.4061 14.6499H23.6833V17.0035H26.1479C26.4111 17.0035 26.6025 16.7366 26.4829 16.4939Z" fill="white"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M23.4333 14.6499C23.4333 14.5118 23.5453 14.3999 23.6833 14.3999H25.4061C25.632 14.3999 25.8531 14.5172 25.9466 14.7445L26.7085 16.3863C26.9179 16.8162 26.5702 17.2535 26.1479 17.2535H23.6833C23.5453 17.2535 23.4333 17.1415 23.4333 17.0035V14.6499ZM23.9333 14.8999V16.7535H26.1479C26.1929 16.7535 26.2307 16.7309 26.252 16.6994C26.2716 16.6705 26.2754 16.6386 26.2586 16.6045L26.256 16.5992L26.2561 16.5992L25.4904 14.9492C25.4884 14.9448 25.4864 14.9403 25.4846 14.9357C25.4812 14.9271 25.4757 14.9201 25.4659 14.914C25.4552 14.9074 25.4358 14.8999 25.4061 14.8999H23.9333Z" fill="#4A4A4A"></path>
                                                                        <path d="M7.03442 8.5H19.3288C20.7095 8.5 21.8288 9.61929 21.8288 11V20.1797H11.4143H7.03442V8.5Z" fill="white"></path>
                                                                        <path d="M7.61853 20.1797H21.8289V21.737H9.17583C8.31576 21.737 7.61853 21.0398 7.61853 20.1797Lnan nanL7.61853 20.1797Z" fill="white"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M6.78442 20.2578C6.78442 20.1197 6.89635 20.0078 7.03442 20.0078L21.8288 20.0078C21.9668 20.0078 22.0788 20.1197 22.0788 20.2578C22.0788 20.3959 21.9668 20.5078 21.8288 20.5078L7.03442 20.5078C6.89635 20.5078 6.78442 20.3959 6.78442 20.2578Z" fill="#4A4A4A"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M6.78442 8.5C6.78442 8.36193 6.89635 8.25 7.03442 8.25H19.9406C21.1354 8.25 22.0788 9.22184 22.0788 10.4294V21.737C22.0788 21.8751 21.9668 21.987 21.8288 21.987H9.02507C8.52675 21.987 8.14032 21.8271 7.88876 21.4976C7.69074 21.2383 7.59834 20.9017 7.57161 20.5271H7.03442C6.89635 20.5271 6.78442 20.4151 6.78442 20.2771V17.4875C6.78442 17.3494 6.89635 17.2375 7.03442 17.2375C7.1725 17.2375 7.28442 17.3494 7.28442 17.4875V20.0271H7.81307C7.95114 20.0271 8.06307 20.139 8.06307 20.2771C8.06307 20.7066 8.14242 21.006 8.28615 21.1942C8.41951 21.3688 8.63908 21.487 9.02507 21.487H21.5788V10.4294C21.5788 9.48774 20.8491 8.75 19.9406 8.75H7.28442V12.2855C7.28442 12.4236 7.1725 12.5355 7.03442 12.5355C6.89635 12.5355 6.78442 12.4236 6.78442 12.2855V8.5Z" fill="#4A4A4A"></path>
                                                                        <path d="M13.3367 21.9438C13.3367 23.092 12.4141 23.9999 11.2806 23.9999C10.1471 23.9999 9.22449 23.0653 9.22449 21.9438C9.22449 20.8223 10.1471 19.8877 11.2806 19.8877C12.4405 19.8877 13.3367 20.7956 13.3367 21.9438Z" fill="white"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M11.2806 20.1377C10.2861 20.1377 9.47449 20.9594 9.47449 21.9438C9.47449 22.9282 10.2861 23.7499 11.2806 23.7499C12.2772 23.7499 13.0867 22.9528 13.0867 21.9438C13.0867 20.9327 12.3015 20.1377 11.2806 20.1377ZM8.97449 21.9438C8.97449 20.6852 10.0081 19.6377 11.2806 19.6377C12.5795 19.6377 13.5867 20.6585 13.5867 21.9438C13.5867 23.2313 12.551 24.2499 11.2806 24.2499C10.0081 24.2499 8.97449 23.2025 8.97449 21.9438Z" fill="#4A4A4A"></path>
                                                                        <path d="M12.3877 21.9441C12.3877 22.5623 11.891 23.0512 11.2806 23.0512C10.6703 23.0512 10.1735 22.548 10.1735 21.9441C10.1735 21.3402 10.6703 20.8369 11.2806 20.8369C11.9051 20.8369 12.3877 21.3258 12.3877 21.9441Z" fill="#6E0AD6"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M11.2806 21.0869C10.8093 21.0869 10.4235 21.4773 10.4235 21.9441C10.4235 22.4108 10.8093 22.8012 11.2806 22.8012C11.7541 22.8012 12.1377 22.4231 12.1377 21.9441C12.1377 21.4629 11.7661 21.0869 11.2806 21.0869ZM9.92346 21.9441C9.92346 21.203 10.5312 20.5869 11.2806 20.5869C12.0441 20.5869 12.6377 21.1886 12.6377 21.9441C12.6377 22.7016 12.0279 23.3012 11.2806 23.3012C10.5312 23.3012 9.92346 22.6851 9.92346 21.9441Z" fill="#4A4A4A"></path>
                                                                        <path d="M27.2551 21.9438C27.2551 23.092 26.3324 23.9999 25.1989 23.9999C24.0654 23.9999 23.1428 23.0653 23.1428 21.9438C23.1428 20.8223 24.0654 19.8877 25.1989 19.8877C26.3588 19.8877 27.2551 20.7956 27.2551 21.9438Z" fill="white"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M25.1989 20.1377C24.2045 20.1377 23.3928 20.9594 23.3928 21.9438C23.3928 22.9282 24.2045 23.7499 25.1989 23.7499C26.1955 23.7499 27.0051 22.9528 27.0051 21.9438C27.0051 20.9327 26.2198 20.1377 25.1989 20.1377ZM22.8928 21.9438C22.8928 20.6852 23.9264 19.6377 25.1989 19.6377C26.4978 19.6377 27.5051 20.6585 27.5051 21.9438C27.5051 23.2313 26.4694 24.2499 25.1989 24.2499C23.9264 24.2499 22.8928 23.2025 22.8928 21.9438Z" fill="#4A4A4A"></path>
                                                                        <path d="M26.3062 21.9441C26.3062 22.5623 25.8094 23.0512 25.1991 23.0512C24.5887 23.0512 24.0919 22.548 24.0919 21.9441C24.0919 21.3402 24.5887 20.8369 25.1991 20.8369C25.8236 20.8369 26.3062 21.3258 26.3062 21.9441Z" fill="#6E0AD6"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M25.1991 21.0869C24.7277 21.0869 24.3419 21.4773 24.3419 21.9441C24.3419 22.4108 24.7277 22.8012 25.1991 22.8012C25.6725 22.8012 26.0562 22.4231 26.0562 21.9441C26.0562 21.4629 25.6846 21.0869 25.1991 21.0869ZM23.8419 21.9441C23.8419 21.203 24.4497 20.5869 25.1991 20.5869C25.9626 20.5869 26.5562 21.1886 26.5562 21.9441C26.5562 22.7016 25.9463 23.3012 25.1991 23.3012C24.4497 23.3012 23.8419 22.6851 23.8419 21.9441Z" fill="#4A4A4A"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M2.99902 16.3423C2.99902 16.2042 3.11095 16.0923 3.24902 16.0923H11.6479C11.786 16.0923 11.8979 16.2042 11.8979 16.3423C11.8979 16.4804 11.786 16.5923 11.6479 16.5923H3.24902C3.11095 16.5923 2.99902 16.4804 2.99902 16.3423Z" fill="#4A4A4A"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M7.03442 13.311C7.1725 13.311 7.28442 13.423 7.28442 13.561V16.189C7.28442 16.327 7.1725 16.439 7.03442 16.439C6.89635 16.439 6.78442 16.327 6.78442 16.189V13.561C6.78442 13.423 6.89635 13.311 7.03442 13.311Z" fill="#4A4A4A"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M5.31982 12.3203C5.31982 12.1822 5.43175 12.0703 5.56982 12.0703H16.7443C16.8824 12.0703 16.9943 12.1822 16.9943 12.3203C16.9943 12.4584 16.8824 12.5703 16.7443 12.5703H5.56982C5.43175 12.5703 5.31982 12.4584 5.31982 12.3203Z" fill="#4A4A4A"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M5.31982 8.5C5.31982 8.36193 5.43175 8.25 5.56982 8.25H19.5199C19.658 8.25 19.7699 8.36193 19.7699 8.5C19.7699 8.63807 19.658 8.75 19.5199 8.75H5.56982C5.43175 8.75 5.31982 8.63807 5.31982 8.5Z" fill="#4A4A4A"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M3.27429 8.55957C3.27429 8.4215 3.38622 8.30957 3.52429 8.30957H4.02707C4.16515 8.30957 4.27707 8.4215 4.27707 8.55957C4.27707 8.69764 4.16515 8.80957 4.02707 8.80957H3.52429C3.38622 8.80957 3.27429 8.69764 3.27429 8.55957Z" fill="#4A4A4A"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M1.20459 8.55957C1.20459 8.4215 1.31652 8.30957 1.45459 8.30957H1.9813C2.11937 8.30957 2.2313 8.4215 2.2313 8.55957C2.2313 8.69764 2.11937 8.80957 1.9813 8.80957H1.45459C1.31652 8.80957 1.20459 8.69764 1.20459 8.55957Z" fill="#4A4A4A"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0.75 16.3423C0.75 16.2042 0.861929 16.0923 1 16.0923H1.52671C1.66478 16.0923 1.77671 16.2042 1.77671 16.3423C1.77671 16.4804 1.66478 16.5923 1.52671 16.5923H1C0.861929 16.5923 0.75 16.4804 0.75 16.3423Z" fill="#4A4A4A"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M3.27429 12.3203C3.27429 12.1822 3.38622 12.0703 3.52429 12.0703H4.02707C4.16515 12.0703 4.27707 12.1822 4.27707 12.3203C4.27707 12.4584 4.16515 12.5703 4.02707 12.5703H3.52429C3.38622 12.5703 3.27429 12.4584 3.27429 12.3203Z" fill="#4A4A4A"></path>
                                                                    </svg>
                                                                    <p data-ds-component="DS-Text" class="sc-hgHYgh hbTyoW sc-hSdWYo htqcWR" color="--color-neutral-130" display="block"><span data-ds-component="DS-Text" class="sc-eInJlc hbIzfU sc-hSdWYo bSkWab" color="--color-neutral-130" display="block">Quero receber o produto</span>Compre de qualquer lugar do Brasil e receba onde quiser. Clique no botão “Comprar” e escolha a opção “Quero receber pela OLX”.</p>
                                                                </div>
                                                                <div class="sc-hzDEsm dPqlXg"><svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path d="M16 30C23.732 30 30 23.732 30 16C30 8.26801 23.732 2 16 2C8.26801 2 2 8.26801 2 16C2 23.732 8.26801 30 16 30Z" fill="#F0E6FF"></path>
                                                                        <g clip-path="url(#clip0_189_21647)">
                                                                            <path d="M7.55603 2.99193V17.1895H26.8245V3.49641C26.8245 2.81176 26.2951 2.27124 25.6246 2.27124H8.26183C7.87364 2.27124 7.55603 2.59555 7.55603 2.99193Z" fill="white" stroke="#4A4A4A" stroke-width="0.5" stroke-miterlimit="10"></path>
                                                                            <path d="M12.441 14.3416L14.3407 15.4265H24.1107L26.6346 14.3416L24.1107 17.3252L21.6682 17.8677L15.8334 17.3252L12.441 14.3416Z" fill="#E5E5E5"></path>
                                                                            <path d="M20.1544 5.52614H14.7822C14.5247 5.52614 14.3407 5.34328 14.3407 5.08728V2.27124H20.3016V5.34328C20.3384 5.453 20.2648 5.52614 20.1544 5.52614Z" fill="#6E0AD6" stroke="#4A4A4A" stroke-miterlimit="10"></path>
                                                                            <path d="M28.327 12.9656C27.0493 13.2541 25.949 14.0477 25.0971 15.743L22.2576 17.3663C21.9381 16.9334 21.4057 16.6088 20.6604 16.6088C19.5956 16.6088 18.5662 16.6088 16.5786 16.6088C15.9752 16.6088 14.7329 15.0216 13.7746 15.0216C13.4196 14.8773 11.6449 14.8773 10.4027 15.0216C9.44432 15.0216 8.20204 15.8873 7.49216 16.5366C6.42735 17.6188 3.69432 20.252 3.37488 20.5045C5.11408 21.9834 8.66346 25.4462 9.44432 26.1676C10.5091 25.0855 10.9351 24.0755 11.7869 24.0755C12.6743 24.0755 20.4829 24.0755 21.3702 24.0755C22.1511 24.0755 26.5169 20.0355 27.0848 19.3862C27.4901 18.9193 29.2331 16.633 30.3394 14.8839C30.686 14.3359 30.6238 13.9345 30.4881 13.5277C30.0976 12.9505 29.6758 12.6409 28.327 12.9656Z" fill="white"></path>
                                                                            <path d="M28.327 12.9656C27.0493 13.2541 25.949 14.0477 25.0971 15.743L22.2576 17.3663C21.9381 16.9334 21.4057 16.6088 20.6604 16.6088C19.5956 16.6088 18.5662 16.6088 16.5786 16.6088C15.9752 16.6088 14.7329 15.0216 13.7746 15.0216C13.4196 14.8773 11.6449 14.8773 10.4027 15.0216C9.44432 15.0216 8.20204 15.8873 7.49216 16.5366C6.42735 17.6188 3.69432 20.252 3.37488 20.5045C5.11408 21.9834 4.87536 19.783 5.65622 20.5045C6.51604 19.6306 9.19208 16.5366 10.4027 16.5366C11.2196 16.1045 11.8981 16.1045 13.1193 16.1045C13.2045 16.0064 15.4009 18.0112 16.5786 18.0032C18.3348 17.9912 20.1824 18.6891 22.4822 18.2744C22.8199 17.7343 23.8366 18.0226 26.0102 16.4739C26.2816 15.4264 28.1813 14.3414 28.327 14.477C29.4972 14.0717 30.1544 15.1763 30.3394 14.8839C30.686 14.3359 30.6238 13.9345 30.4881 13.5277C30.0976 12.9505 29.6758 12.6409 28.327 12.9656Z" fill="#E5E5E5"></path>
                                                                            <path d="M14.9104 20.324C14.9104 20.324 19.631 20.324 20.6604 20.324C23.2869 20.324 23.2869 16.6087 20.6604 16.6087C19.5956 16.6087 18.5662 16.6087 16.5786 16.6087C15.9752 16.6087 14.8039 15.0216 13.8456 15.0216C13.4196 15.0216 11.219 15.0216 10.1897 15.0216C9.16037 15.0216 8.20204 15.8873 7.52765 16.5366C6.46284 17.6187 3.72981 20.2519 3.41037 20.5044C5.11407 21.9833 8.66346 25.4462 9.44432 26.1676C10.5091 25.0855 10.9351 24.0755 11.7869 24.0755H20.6249C21.3348 24.0755 22.0091 23.8951 22.648 23.5705C24.6712 22.4162 26.6233 19.9273 27.0848 19.4223C27.4752 18.9533 29.2144 16.7169 30.3147 14.9494C30.9181 14.0116 30.2082 12.7851 29.1079 12.8573C28.8594 12.8934 28.5755 12.9294 28.2915 13.0016C27.0138 13.2901 25.9135 14.0837 25.0616 15.7791L22.2221 17.1858" stroke="#4A4A4A" stroke-width="0.5" stroke-miterlimit="10"></path>
                                                                            <path d="M8.9475 29.0895L10.8642 27.1417C11.3256 26.6728 11.3256 25.9513 10.8642 25.4824L4.61725 19.0978C4.15583 18.6289 3.44595 18.6289 2.98453 19.0978L1.06787 21.0456C0.606447 21.5146 0.606447 22.236 1.06787 22.7049L7.35027 29.0895C7.7762 29.5585 8.52157 29.5585 8.9475 29.0895Z" fill="#6E0AD6" stroke="#4A4A4A" stroke-miterlimit="10"></path>
                                                                            <path d="M3.16199 21.3701L4.54625 22.7769" stroke="white" stroke-miterlimit="10" stroke-linecap="round"></path>
                                                                            <path d="M9.16052 12.8574H10.1898" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                            <path d="M11.0416 12.8574H12.1064" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                            <path d="M12.9584 12.8574H14.0232" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                        </g>
                                                                        <defs>
                                                                            <clipPath id="clip0_189_21647">
                                                                                <rect width="30.6667" height="27.6667" fill="white" transform="translate(0.499878 2)"></rect>
                                                                            </clipPath>
                                                                        </defs>
                                                                    </svg>
                                                                    <p data-ds-component="DS-Text" class="sc-hgHYgh hbTyoW sc-hSdWYo htqcWR" color="--color-neutral-130" display="block"><span data-ds-component="DS-Text" class="sc-eInJlc hbIzfU sc-hSdWYo bSkWab" color="--color-neutral-130" display="block">Quero retirar com o vendedor</span>Clique no botão Comprar e escolha a opção “Quero retirar com o vendedor”. Para essa opção, você deve combinar com o vendedor os detalhes de retirada do produto pelo chat.</p>
                                                                </div>
                                                                <div class="sc-hzDEsm dPqlXg"><svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path d="M16 30C23.732 30 30 23.732 30 16C30 8.26801 23.732 2 16 2C8.26801 2 2 8.26801 2 16C2 23.732 8.26801 30 16 30Z" fill="#F0E6FF"></path>
                                                                        <g clip-path="url(#clip0_189_21647)">
                                                                            <path d="M7.55603 2.99193V17.1895H26.8245V3.49641C26.8245 2.81176 26.2951 2.27124 25.6246 2.27124H8.26183C7.87364 2.27124 7.55603 2.59555 7.55603 2.99193Z" fill="white" stroke="#4A4A4A" stroke-width="0.5" stroke-miterlimit="10"></path>
                                                                            <path d="M12.441 14.3416L14.3407 15.4265H24.1107L26.6346 14.3416L24.1107 17.3252L21.6682 17.8677L15.8334 17.3252L12.441 14.3416Z" fill="#E5E5E5"></path>
                                                                            <path d="M20.1544 5.52614H14.7822C14.5247 5.52614 14.3407 5.34328 14.3407 5.08728V2.27124H20.3016V5.34328C20.3384 5.453 20.2648 5.52614 20.1544 5.52614Z" fill="#6E0AD6" stroke="#4A4A4A" stroke-miterlimit="10"></path>
                                                                            <path d="M28.327 12.9656C27.0493 13.2541 25.949 14.0477 25.0971 15.743L22.2576 17.3663C21.9381 16.9334 21.4057 16.6088 20.6604 16.6088C19.5956 16.6088 18.5662 16.6088 16.5786 16.6088C15.9752 16.6088 14.7329 15.0216 13.7746 15.0216C13.4196 14.8773 11.6449 14.8773 10.4027 15.0216C9.44432 15.0216 8.20204 15.8873 7.49216 16.5366C6.42735 17.6188 3.69432 20.252 3.37488 20.5045C5.11408 21.9834 8.66346 25.4462 9.44432 26.1676C10.5091 25.0855 10.9351 24.0755 11.7869 24.0755C12.6743 24.0755 20.4829 24.0755 21.3702 24.0755C22.1511 24.0755 26.5169 20.0355 27.0848 19.3862C27.4901 18.9193 29.2331 16.633 30.3394 14.8839C30.686 14.3359 30.6238 13.9345 30.4881 13.5277C30.0976 12.9505 29.6758 12.6409 28.327 12.9656Z" fill="white"></path>
                                                                            <path d="M28.327 12.9656C27.0493 13.2541 25.949 14.0477 25.0971 15.743L22.2576 17.3663C21.9381 16.9334 21.4057 16.6088 20.6604 16.6088C19.5956 16.6088 18.5662 16.6088 16.5786 16.6088C15.9752 16.6088 14.7329 15.0216 13.7746 15.0216C13.4196 14.8773 11.6449 14.8773 10.4027 15.0216C9.44432 15.0216 8.20204 15.8873 7.49216 16.5366C6.42735 17.6188 3.69432 20.252 3.37488 20.5045C5.11408 21.9834 4.87536 19.783 5.65622 20.5045C6.51604 19.6306 9.19208 16.5366 10.4027 16.5366C11.2196 16.1045 11.8981 16.1045 13.1193 16.1045C13.2045 16.0064 15.4009 18.0112 16.5786 18.0032C18.3348 17.9912 20.1824 18.6891 22.4822 18.2744C22.8199 17.7343 23.8366 18.0226 26.0102 16.4739C26.2816 15.4264 28.1813 14.3414 28.327 14.477C29.4972 14.0717 30.1544 15.1763 30.3394 14.8839C30.686 14.3359 30.6238 13.9345 30.4881 13.5277C30.0976 12.9505 29.6758 12.6409 28.327 12.9656Z" fill="#E5E5E5"></path>
                                                                            <path d="M14.9104 20.324C14.9104 20.324 19.631 20.324 20.6604 20.324C23.2869 20.324 23.2869 16.6087 20.6604 16.6087C19.5956 16.6087 18.5662 16.6087 16.5786 16.6087C15.9752 16.6087 14.8039 15.0216 13.8456 15.0216C13.4196 15.0216 11.219 15.0216 10.1897 15.0216C9.16037 15.0216 8.20204 15.8873 7.52765 16.5366C6.46284 17.6187 3.72981 20.2519 3.41037 20.5044C5.11407 21.9833 8.66346 25.4462 9.44432 26.1676C10.5091 25.0855 10.9351 24.0755 11.7869 24.0755H20.6249C21.3348 24.0755 22.0091 23.8951 22.648 23.5705C24.6712 22.4162 26.6233 19.9273 27.0848 19.4223C27.4752 18.9533 29.2144 16.7169 30.3147 14.9494C30.9181 14.0116 30.2082 12.7851 29.1079 12.8573C28.8594 12.8934 28.5755 12.9294 28.2915 13.0016C27.0138 13.2901 25.9135 14.0837 25.0616 15.7791L22.2221 17.1858" stroke="#4A4A4A" stroke-width="0.5" stroke-miterlimit="10"></path>
                                                                            <path d="M8.9475 29.0895L10.8642 27.1417C11.3256 26.6728 11.3256 25.9513 10.8642 25.4824L4.61725 19.0978C4.15583 18.6289 3.44595 18.6289 2.98453 19.0978L1.06787 21.0456C0.606447 21.5146 0.606447 22.236 1.06787 22.7049L7.35027 29.0895C7.7762 29.5585 8.52157 29.5585 8.9475 29.0895Z" fill="#6E0AD6" stroke="#4A4A4A" stroke-miterlimit="10"></path>
                                                                            <path d="M3.16199 21.3701L4.54625 22.7769" stroke="white" stroke-miterlimit="10" stroke-linecap="round"></path>
                                                                            <path d="M9.16052 12.8574H10.1898" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                            <path d="M11.0416 12.8574H12.1064" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                            <path d="M12.9584 12.8574H14.0232" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                        </g>
                                                                        <defs>
                                                                            <clipPath id="clip0_189_21647">
                                                                                <rect width="30.6667" height="27.6667" fill="white" transform="translate(0.499878 2)"></rect>
                                                                            </clipPath>
                                                                        </defs>
                                                                    </svg>
                                                                    <p data-ds-component="DS-Text" class="sc-hgHYgh hbTyoW sc-hSdWYo htqcWR" color="--color-neutral-130" display="block"><span data-ds-component="DS-Text" class="sc-eInJlc hbIzfU sc-hSdWYo bSkWab" color="--color-neutral-130" display="block">Quero retirar no armário da CliqueRetire </span>Clique no botão Comprar e escolha a opção "Quero retirar no armário da CliqueRetire". Escolha em qual armário quer retirar e te avisamos em "Detalhes da compra" quando e como retirar sua compra.</p>
                                                                </div>
                                                                <div data-ds-component="DS-Flex" class="sc-kafWEX sc-fOICqy dKiDao"><button data-testid="button-wrapper" data-ds-component="DS-Button" class="sc-gZMcBi iCyRCL">
                                                                        <div class="sc-iwsKbI hMjsjM"> <!-- -->Voltar para o anúncio</div>
                                                                    </button></div>
                                                            </div>
                                                        </div>
                                                        <script>
                                                            document.addEventListener("DOMContentLoaded", function() {
                                                                // Function to open the "Saiba mais sobre a entrega" modal
                                                                function openModal() {
                                                                    var modal = document.getElementById("modalfrete");
                                                                    modal.style.display = "block";
                                                                }

                                                                // Function to close the modal
                                                                function closeModal() {
                                                                    var modal = document.getElementById("modalfrete");
                                                                    modal.style.display = "none";
                                                                }

                                                                // Add event listener to the "Saiba mais sobre a entrega" button to open the modal
                                                                var openModalBtnfrete = document.getElementById("openModalBtnfrete");
                                                                openModalBtnfrete.addEventListener("click", openModal);

                                                                // Add event listener to the close button to close the modal
                                                                var closeModalBtnfrete = document.getElementById("closeModalBtnfrete");
                                                                closeModalBtnfrete.addEventListener("click", closeModal);
                                                            });
                                                        </script>
                                                        <style>
                                                            /* The Modal (background) */
                                                            .modalfrete {
                                                                display: none;
                                                                z-index: 9999;
                                                                position: fixed;
                                                                bottom: 0;
                                                                left: 0;
                                                                right: 0;
                                                                margin: 0 auto;
                                                                background-color: rgba(0, 0, 0, 0.5);
                                                            }

                                                            .modalfrete-content {
                                                                max-width: 500px;
                                                                background-color: #fff;
                                                                padding: 20px;
                                                                border-top-left-radius: 16px;
                                                                border-top-right-radius: 16px;
                                                                box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
                                                                max-height: 100vh;
                                                                overflow-y: auto;
                                                                margin-top: calc(500% - 150px);
                                                                /* Ajuste o valor conforme necessário para a posição desejada */
                                                            }

                                                            /* Close Button */
                                                            #closeModalBtnfrete {
                                                                color: #aaa;
                                                                float: right;
                                                                font-size: 28px;
                                                                font-weight: bold;
                                                                cursor: pointer;
                                                            }

                                                            #closeModalBtn:hover,
                                                            #closeModalBtn:focus {
                                                                color: black;
                                                                text-decoration: none;
                                                                cursor: pointer;
                                                            }
                                                        </style>


                                                    </div>
                                                </div>
                                                <div id="modal" data-ds-component="DS-Modal" class="sc-dEoRIm fmaqoh" data-testid="modal-overlay" aria-hidden="true">
                                                    <div role="dialog" aria-modal="true" aria-labelledby="ds-modal-content-126608" data-testid="modal" class="sc-jtggT kYnGEA">
                                                        <div class="sc-jKVCRD domptC"><button data-ds-component="DS-Button" data-testid="closeButton" type="button" class="sc-ebFjAB lluhit"><span class="sc-VigVT cueDsN">Fechar janela de diálogo</span><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M13.0607 12L18.5303 17.4697C18.8232 17.7626 18.8232 18.2374 18.5303 18.5303C18.2374 18.8232 17.7626 18.8232 17.4697 18.5303L12 13.0607L6.53033 18.5303C6.23744 18.8232 5.76256 18.8232 5.46967 18.5303C5.17678 18.2374 5.17678 17.7626 5.46967 17.4697L10.9393 12L5.46967 6.53033C5.17678 6.23744 5.17678 5.76256 5.46967 5.46967C5.76256 5.17678 6.23744 5.17678 6.53033 5.46967L12 10.9393L17.4697 5.46967C17.7626 5.17678 18.2374 5.17678 18.5303 5.46967C18.8232 5.76256 18.8232 6.23744 18.5303 6.53033L13.0607 12Z" fill="#4A4A4A"></path>
                                                                </svg></button></div>
                                                        <div id="ds-modal-content-126608" class="sc-kaNhvL cWMImq">
                                                            <div data-ds-component="DS-Flex" class="sc-kafWEX sc-jeCdPy kTSYUO"><span data-ds-component="DS-Text" class="sc-gtfDJT fsMHPV sc-hSdWYo bYQcLm" color="--color-neutral-130" display="block">Entrega fácil</span>
                                                                <div class="sc-hzDEsm dPqlXg"><svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path d="M16 30C23.732 30 30 23.732 30 16C30 8.26801 23.732 2 16 2C8.26801 2 2 8.26801 2 16C2 23.732 8.26801 30 16 30Z" fill="#F0E6FF"></path>
                                                                        <path d="M30.2649 19.3581C30.2899 18.8243 30.2649 16.4465 28.5067 16.4465C28.3818 16.2281 27.8824 15.1363 27.4329 14.2143C27.0334 13.3408 26.1344 12.7827 25.1605 12.7827H21.4397V21.7117H30.0651C30.0651 21.7117 30.7393 21.275 30.7393 20.7654C30.7393 20.2801 30.8642 19.5037 30.2649 19.3581Z" fill="white"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M21.1897 12.7827C21.1897 12.6446 21.3016 12.5327 21.4397 12.5327H25.1605C26.2269 12.5327 27.2163 13.1428 27.659 14.1074C27.8574 14.5144 28.0653 14.9541 28.246 15.3361C28.2704 15.3876 28.2942 15.4381 28.3175 15.4873C28.4648 15.7985 28.5852 16.0513 28.6608 16.2021C29.0899 16.2337 29.4319 16.3974 29.6967 16.6431C29.9868 16.9124 30.172 17.2682 30.2914 17.6223C30.4884 18.2066 30.5211 18.8319 30.5191 19.1872C30.6322 19.2455 30.7239 19.3266 30.7948 19.4252C30.8985 19.5693 30.9485 19.7373 30.9737 19.8949C30.9991 20.0532 31.0019 20.2176 30.9995 20.3654C30.9983 20.4392 30.9961 20.5028 30.994 20.5619C30.9916 20.633 30.9893 20.6975 30.9893 20.7654C30.9893 21.1234 30.7591 21.4217 30.5812 21.6042C30.4867 21.7011 30.3931 21.7793 30.3234 21.8332C30.2884 21.8603 30.2589 21.8817 30.2377 21.8966C30.2271 21.904 30.2185 21.9099 30.2123 21.9141L30.2047 21.9191L30.2024 21.9206L30.2016 21.9212L30.2011 21.9214C30.2011 21.9215 30.201 21.9215 30.0651 21.7117L30.2011 21.9214C30.1607 21.9477 30.1133 21.9617 30.0651 21.9617H21.4397C21.3016 21.9617 21.1897 21.8498 21.1897 21.7117V12.7827ZM29.9859 21.4617C29.9955 21.4546 30.0061 21.4466 30.0175 21.4378C30.0742 21.3938 30.1492 21.331 30.2232 21.2551C30.3825 21.0918 30.4893 20.917 30.4893 20.7654C30.4893 20.6966 30.4921 20.6117 30.4948 20.5284C30.4968 20.4683 30.4987 20.409 30.4995 20.3572C30.5018 20.2183 30.4984 20.0886 30.48 19.9739C30.4615 19.8586 30.4304 19.7748 30.3889 19.7172C30.3518 19.6656 30.2986 19.6236 30.2059 19.6011C30.0895 19.5728 30.0096 19.466 30.0152 19.3465C30.0271 19.0909 30.0257 18.3995 29.8176 17.782C29.714 17.4749 29.5649 17.2029 29.3566 17.0096C29.154 16.8216 28.8836 16.6965 28.5067 16.6965C28.417 16.6965 28.3342 16.6485 28.2897 16.5706C28.221 16.4505 28.0591 16.1101 27.8656 15.7012C27.8422 15.6518 27.8183 15.6012 27.7939 15.5497C27.6127 15.1665 27.4056 14.7287 27.2082 14.3238L27.2055 14.3183C26.8484 13.5375 26.0408 13.0327 25.1605 13.0327H21.6897V21.4617H29.9859Z" fill="#4A4A4A"></path>
                                                                        <path d="M28.5187 16.4465C30.2768 16.4465 30.2486 18.7711 30.2236 19.3049H21.3984L21.4517 12.7827H25.1725C26.1464 12.7827 27.0453 13.3408 27.4449 14.2143C27.8944 15.1363 28.3938 16.2281 28.5187 16.4465Z" fill="#6E0AD6"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M21.2017 12.7807C21.2028 12.6434 21.3144 12.5327 21.4517 12.5327H25.1725C26.2389 12.5327 27.2283 13.1428 27.6709 14.1074C27.8693 14.5144 28.0773 14.9541 28.258 15.3361C28.2823 15.3877 28.3062 15.4381 28.3295 15.4873C28.4767 15.7984 28.5971 16.0512 28.6727 16.202C29.0999 16.2329 29.439 16.3927 29.7002 16.6347C29.9864 16.8999 30.1651 17.2504 30.2777 17.5986C30.5018 18.2913 30.4861 19.0435 30.4733 19.3166C30.4671 19.45 30.3572 19.5549 30.2236 19.5549H21.3984C21.3318 19.5549 21.2679 19.5283 21.2209 19.481C21.174 19.4336 21.1479 19.3695 21.1484 19.3029L21.2017 12.7807ZM21.6996 13.0327L21.6505 19.0549H29.9796C29.9803 18.7267 29.9524 18.2176 29.802 17.7525C29.705 17.4528 29.5626 17.1888 29.3604 17.0014C29.1638 16.8193 28.8972 16.6965 28.5187 16.6965C28.429 16.6965 28.3462 16.6485 28.3016 16.5706C28.233 16.4505 28.0711 16.1101 27.8776 15.7012C27.8542 15.6518 27.8303 15.6012 27.8059 15.5497C27.6246 15.1665 27.4175 14.7287 27.2202 14.3238L27.2175 14.3183L27.2175 14.3183C26.8604 13.5375 26.0528 13.0327 25.1725 13.0327H21.6996Z" fill="#4A4A4A"></path>
                                                                        <path d="M26.4829 16.4939L25.7172 14.844C25.6693 14.7227 25.5497 14.6499 25.4061 14.6499H23.6833V17.0035H26.1479C26.4111 17.0035 26.6025 16.7366 26.4829 16.4939Z" fill="white"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M23.4333 14.6499C23.4333 14.5118 23.5453 14.3999 23.6833 14.3999H25.4061C25.632 14.3999 25.8531 14.5172 25.9466 14.7445L26.7085 16.3863C26.9179 16.8162 26.5702 17.2535 26.1479 17.2535H23.6833C23.5453 17.2535 23.4333 17.1415 23.4333 17.0035V14.6499ZM23.9333 14.8999V16.7535H26.1479C26.1929 16.7535 26.2307 16.7309 26.252 16.6994C26.2716 16.6705 26.2754 16.6386 26.2586 16.6045L26.256 16.5992L26.2561 16.5992L25.4904 14.9492C25.4884 14.9448 25.4864 14.9403 25.4846 14.9357C25.4812 14.9271 25.4757 14.9201 25.4659 14.914C25.4552 14.9074 25.4358 14.8999 25.4061 14.8999H23.9333Z" fill="#4A4A4A"></path>
                                                                        <path d="M7.03442 8.5H19.3288C20.7095 8.5 21.8288 9.61929 21.8288 11V20.1797H11.4143H7.03442V8.5Z" fill="white"></path>
                                                                        <path d="M7.61853 20.1797H21.8289V21.737H9.17583C8.31576 21.737 7.61853 21.0398 7.61853 20.1797Lnan nanL7.61853 20.1797Z" fill="white"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M6.78442 20.2578C6.78442 20.1197 6.89635 20.0078 7.03442 20.0078L21.8288 20.0078C21.9668 20.0078 22.0788 20.1197 22.0788 20.2578C22.0788 20.3959 21.9668 20.5078 21.8288 20.5078L7.03442 20.5078C6.89635 20.5078 6.78442 20.3959 6.78442 20.2578Z" fill="#4A4A4A"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M6.78442 8.5C6.78442 8.36193 6.89635 8.25 7.03442 8.25H19.9406C21.1354 8.25 22.0788 9.22184 22.0788 10.4294V21.737C22.0788 21.8751 21.9668 21.987 21.8288 21.987H9.02507C8.52675 21.987 8.14032 21.8271 7.88876 21.4976C7.69074 21.2383 7.59834 20.9017 7.57161 20.5271H7.03442C6.89635 20.5271 6.78442 20.4151 6.78442 20.2771V17.4875C6.78442 17.3494 6.89635 17.2375 7.03442 17.2375C7.1725 17.2375 7.28442 17.3494 7.28442 17.4875V20.0271H7.81307C7.95114 20.0271 8.06307 20.139 8.06307 20.2771C8.06307 20.7066 8.14242 21.006 8.28615 21.1942C8.41951 21.3688 8.63908 21.487 9.02507 21.487H21.5788V10.4294C21.5788 9.48774 20.8491 8.75 19.9406 8.75H7.28442V12.2855C7.28442 12.4236 7.1725 12.5355 7.03442 12.5355C6.89635 12.5355 6.78442 12.4236 6.78442 12.2855V8.5Z" fill="#4A4A4A"></path>
                                                                        <path d="M13.3367 21.9438C13.3367 23.092 12.4141 23.9999 11.2806 23.9999C10.1471 23.9999 9.22449 23.0653 9.22449 21.9438C9.22449 20.8223 10.1471 19.8877 11.2806 19.8877C12.4405 19.8877 13.3367 20.7956 13.3367 21.9438Z" fill="white"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M11.2806 20.1377C10.2861 20.1377 9.47449 20.9594 9.47449 21.9438C9.47449 22.9282 10.2861 23.7499 11.2806 23.7499C12.2772 23.7499 13.0867 22.9528 13.0867 21.9438C13.0867 20.9327 12.3015 20.1377 11.2806 20.1377ZM8.97449 21.9438C8.97449 20.6852 10.0081 19.6377 11.2806 19.6377C12.5795 19.6377 13.5867 20.6585 13.5867 21.9438C13.5867 23.2313 12.551 24.2499 11.2806 24.2499C10.0081 24.2499 8.97449 23.2025 8.97449 21.9438Z" fill="#4A4A4A"></path>
                                                                        <path d="M12.3877 21.9441C12.3877 22.5623 11.891 23.0512 11.2806 23.0512C10.6703 23.0512 10.1735 22.548 10.1735 21.9441C10.1735 21.3402 10.6703 20.8369 11.2806 20.8369C11.9051 20.8369 12.3877 21.3258 12.3877 21.9441Z" fill="#6E0AD6"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M11.2806 21.0869C10.8093 21.0869 10.4235 21.4773 10.4235 21.9441C10.4235 22.4108 10.8093 22.8012 11.2806 22.8012C11.7541 22.8012 12.1377 22.4231 12.1377 21.9441C12.1377 21.4629 11.7661 21.0869 11.2806 21.0869ZM9.92346 21.9441C9.92346 21.203 10.5312 20.5869 11.2806 20.5869C12.0441 20.5869 12.6377 21.1886 12.6377 21.9441C12.6377 22.7016 12.0279 23.3012 11.2806 23.3012C10.5312 23.3012 9.92346 22.6851 9.92346 21.9441Z" fill="#4A4A4A"></path>
                                                                        <path d="M27.2551 21.9438C27.2551 23.092 26.3324 23.9999 25.1989 23.9999C24.0654 23.9999 23.1428 23.0653 23.1428 21.9438C23.1428 20.8223 24.0654 19.8877 25.1989 19.8877C26.3588 19.8877 27.2551 20.7956 27.2551 21.9438Z" fill="white"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M25.1989 20.1377C24.2045 20.1377 23.3928 20.9594 23.3928 21.9438C23.3928 22.9282 24.2045 23.7499 25.1989 23.7499C26.1955 23.7499 27.0051 22.9528 27.0051 21.9438C27.0051 20.9327 26.2198 20.1377 25.1989 20.1377ZM22.8928 21.9438C22.8928 20.6852 23.9264 19.6377 25.1989 19.6377C26.4978 19.6377 27.5051 20.6585 27.5051 21.9438C27.5051 23.2313 26.4694 24.2499 25.1989 24.2499C23.9264 24.2499 22.8928 23.2025 22.8928 21.9438Z" fill="#4A4A4A"></path>
                                                                        <path d="M26.3062 21.9441C26.3062 22.5623 25.8094 23.0512 25.1991 23.0512C24.5887 23.0512 24.0919 22.548 24.0919 21.9441C24.0919 21.3402 24.5887 20.8369 25.1991 20.8369C25.8236 20.8369 26.3062 21.3258 26.3062 21.9441Z" fill="#6E0AD6"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M25.1991 21.0869C24.7277 21.0869 24.3419 21.4773 24.3419 21.9441C24.3419 22.4108 24.7277 22.8012 25.1991 22.8012C25.6725 22.8012 26.0562 22.4231 26.0562 21.9441C26.0562 21.4629 25.6846 21.0869 25.1991 21.0869ZM23.8419 21.9441C23.8419 21.203 24.4497 20.5869 25.1991 20.5869C25.9626 20.5869 26.5562 21.1886 26.5562 21.9441C26.5562 22.7016 25.9463 23.3012 25.1991 23.3012C24.4497 23.3012 23.8419 22.6851 23.8419 21.9441Z" fill="#4A4A4A"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M2.99902 16.3423C2.99902 16.2042 3.11095 16.0923 3.24902 16.0923H11.6479C11.786 16.0923 11.8979 16.2042 11.8979 16.3423C11.8979 16.4804 11.786 16.5923 11.6479 16.5923H3.24902C3.11095 16.5923 2.99902 16.4804 2.99902 16.3423Z" fill="#4A4A4A"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M7.03442 13.311C7.1725 13.311 7.28442 13.423 7.28442 13.561V16.189C7.28442 16.327 7.1725 16.439 7.03442 16.439C6.89635 16.439 6.78442 16.327 6.78442 16.189V13.561C6.78442 13.423 6.89635 13.311 7.03442 13.311Z" fill="#4A4A4A"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M5.31982 12.3203C5.31982 12.1822 5.43175 12.0703 5.56982 12.0703H16.7443C16.8824 12.0703 16.9943 12.1822 16.9943 12.3203C16.9943 12.4584 16.8824 12.5703 16.7443 12.5703H5.56982C5.43175 12.5703 5.31982 12.4584 5.31982 12.3203Z" fill="#4A4A4A"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M5.31982 8.5C5.31982 8.36193 5.43175 8.25 5.56982 8.25H19.5199C19.658 8.25 19.7699 8.36193 19.7699 8.5C19.7699 8.63807 19.658 8.75 19.5199 8.75H5.56982C5.43175 8.75 5.31982 8.63807 5.31982 8.5Z" fill="#4A4A4A"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M3.27429 8.55957C3.27429 8.4215 3.38622 8.30957 3.52429 8.30957H4.02707C4.16515 8.30957 4.27707 8.4215 4.27707 8.55957C4.27707 8.69764 4.16515 8.80957 4.02707 8.80957H3.52429C3.38622 8.80957 3.27429 8.69764 3.27429 8.55957Z" fill="#4A4A4A"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M1.20459 8.55957C1.20459 8.4215 1.31652 8.30957 1.45459 8.30957H1.9813C2.11937 8.30957 2.2313 8.4215 2.2313 8.55957C2.2313 8.69764 2.11937 8.80957 1.9813 8.80957H1.45459C1.31652 8.80957 1.20459 8.69764 1.20459 8.55957Z" fill="#4A4A4A"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0.75 16.3423C0.75 16.2042 0.861929 16.0923 1 16.0923H1.52671C1.66478 16.0923 1.77671 16.2042 1.77671 16.3423C1.77671 16.4804 1.66478 16.5923 1.52671 16.5923H1C0.861929 16.5923 0.75 16.4804 0.75 16.3423Z" fill="#4A4A4A"></path>
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M3.27429 12.3203C3.27429 12.1822 3.38622 12.0703 3.52429 12.0703H4.02707C4.16515 12.0703 4.27707 12.1822 4.27707 12.3203C4.27707 12.4584 4.16515 12.5703 4.02707 12.5703H3.52429C3.38622 12.5703 3.27429 12.4584 3.27429 12.3203Z" fill="#4A4A4A"></path>
                                                                    </svg>
                                                                    <p data-ds-component="DS-Text" class="sc-hgHYgh hbTyoW sc-hSdWYo htqcWR" color="--color-neutral-130" display="block"><span data-ds-component="DS-Text" class="sc-eInJlc hbIzfU sc-hSdWYo bSkWab" color="--color-neutral-130" display="block">Quero receber o produto</span>Compre de qualquer lugar do Brasil e receba onde quiser. Clique no botão “Comprar” e escolha a opção “Quero receber pela OLX”.</p>
                                                                </div>
                                                                <div class="sc-hzDEsm dPqlXg"><svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path d="M16 30C23.732 30 30 23.732 30 16C30 8.26801 23.732 2 16 2C8.26801 2 2 8.26801 2 16C2 23.732 8.26801 30 16 30Z" fill="#F0E6FF"></path>
                                                                        <g clip-path="url(#clip0_189_21647)">
                                                                            <path d="M7.55603 2.99193V17.1895H26.8245V3.49641C26.8245 2.81176 26.2951 2.27124 25.6246 2.27124H8.26183C7.87364 2.27124 7.55603 2.59555 7.55603 2.99193Z" fill="white" stroke="#4A4A4A" stroke-width="0.5" stroke-miterlimit="10"></path>
                                                                            <path d="M12.441 14.3416L14.3407 15.4265H24.1107L26.6346 14.3416L24.1107 17.3252L21.6682 17.8677L15.8334 17.3252L12.441 14.3416Z" fill="#E5E5E5"></path>
                                                                            <path d="M20.1544 5.52614H14.7822C14.5247 5.52614 14.3407 5.34328 14.3407 5.08728V2.27124H20.3016V5.34328C20.3384 5.453 20.2648 5.52614 20.1544 5.52614Z" fill="#6E0AD6" stroke="#4A4A4A" stroke-miterlimit="10"></path>
                                                                            <path d="M28.327 12.9656C27.0493 13.2541 25.949 14.0477 25.0971 15.743L22.2576 17.3663C21.9381 16.9334 21.4057 16.6088 20.6604 16.6088C19.5956 16.6088 18.5662 16.6088 16.5786 16.6088C15.9752 16.6088 14.7329 15.0216 13.7746 15.0216C13.4196 14.8773 11.6449 14.8773 10.4027 15.0216C9.44432 15.0216 8.20204 15.8873 7.49216 16.5366C6.42735 17.6188 3.69432 20.252 3.37488 20.5045C5.11408 21.9834 8.66346 25.4462 9.44432 26.1676C10.5091 25.0855 10.9351 24.0755 11.7869 24.0755C12.6743 24.0755 20.4829 24.0755 21.3702 24.0755C22.1511 24.0755 26.5169 20.0355 27.0848 19.3862C27.4901 18.9193 29.2331 16.633 30.3394 14.8839C30.686 14.3359 30.6238 13.9345 30.4881 13.5277C30.0976 12.9505 29.6758 12.6409 28.327 12.9656Z" fill="white"></path>
                                                                            <path d="M28.327 12.9656C27.0493 13.2541 25.949 14.0477 25.0971 15.743L22.2576 17.3663C21.9381 16.9334 21.4057 16.6088 20.6604 16.6088C19.5956 16.6088 18.5662 16.6088 16.5786 16.6088C15.9752 16.6088 14.7329 15.0216 13.7746 15.0216C13.4196 14.8773 11.6449 14.8773 10.4027 15.0216C9.44432 15.0216 8.20204 15.8873 7.49216 16.5366C6.42735 17.6188 3.69432 20.252 3.37488 20.5045C5.11408 21.9834 4.87536 19.783 5.65622 20.5045C6.51604 19.6306 9.19208 16.5366 10.4027 16.5366C11.2196 16.1045 11.8981 16.1045 13.1193 16.1045C13.2045 16.0064 15.4009 18.0112 16.5786 18.0032C18.3348 17.9912 20.1824 18.6891 22.4822 18.2744C22.8199 17.7343 23.8366 18.0226 26.0102 16.4739C26.2816 15.4264 28.1813 14.3414 28.327 14.477C29.4972 14.0717 30.1544 15.1763 30.3394 14.8839C30.686 14.3359 30.6238 13.9345 30.4881 13.5277C30.0976 12.9505 29.6758 12.6409 28.327 12.9656Z" fill="#E5E5E5"></path>
                                                                            <path d="M14.9104 20.324C14.9104 20.324 19.631 20.324 20.6604 20.324C23.2869 20.324 23.2869 16.6087 20.6604 16.6087C19.5956 16.6087 18.5662 16.6087 16.5786 16.6087C15.9752 16.6087 14.8039 15.0216 13.8456 15.0216C13.4196 15.0216 11.219 15.0216 10.1897 15.0216C9.16037 15.0216 8.20204 15.8873 7.52765 16.5366C6.46284 17.6187 3.72981 20.2519 3.41037 20.5044C5.11407 21.9833 8.66346 25.4462 9.44432 26.1676C10.5091 25.0855 10.9351 24.0755 11.7869 24.0755H20.6249C21.3348 24.0755 22.0091 23.8951 22.648 23.5705C24.6712 22.4162 26.6233 19.9273 27.0848 19.4223C27.4752 18.9533 29.2144 16.7169 30.3147 14.9494C30.9181 14.0116 30.2082 12.7851 29.1079 12.8573C28.8594 12.8934 28.5755 12.9294 28.2915 13.0016C27.0138 13.2901 25.9135 14.0837 25.0616 15.7791L22.2221 17.1858" stroke="#4A4A4A" stroke-width="0.5" stroke-miterlimit="10"></path>
                                                                            <path d="M8.9475 29.0895L10.8642 27.1417C11.3256 26.6728 11.3256 25.9513 10.8642 25.4824L4.61725 19.0978C4.15583 18.6289 3.44595 18.6289 2.98453 19.0978L1.06787 21.0456C0.606447 21.5146 0.606447 22.236 1.06787 22.7049L7.35027 29.0895C7.7762 29.5585 8.52157 29.5585 8.9475 29.0895Z" fill="#6E0AD6" stroke="#4A4A4A" stroke-miterlimit="10"></path>
                                                                            <path d="M3.16199 21.3701L4.54625 22.7769" stroke="white" stroke-miterlimit="10" stroke-linecap="round"></path>
                                                                            <path d="M9.16052 12.8574H10.1898" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                            <path d="M11.0416 12.8574H12.1064" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                            <path d="M12.9584 12.8574H14.0232" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                        </g>
                                                                        <defs>
                                                                            <clipPath id="clip0_189_21647">
                                                                                <rect width="30.6667" height="27.6667" fill="white" transform="translate(0.499878 2)"></rect>
                                                                            </clipPath>
                                                                        </defs>
                                                                    </svg>
                                                                    <p data-ds-component="DS-Text" class="sc-hgHYgh hbTyoW sc-hSdWYo htqcWR" color="--color-neutral-130" display="block"><span data-ds-component="DS-Text" class="sc-eInJlc hbIzfU sc-hSdWYo bSkWab" color="--color-neutral-130" display="block">Quero retirar com o vendedor</span>Clique no botão Comprar e escolha a opção “Quero retirar com o vendedor”. Para essa opção, você deve combinar com o vendedor os detalhes de retirada do produto pelo chat.</p>
                                                                </div>
                                                                <div class="sc-hzDEsm dPqlXg"><svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path d="M16 30C23.732 30 30 23.732 30 16C30 8.26801 23.732 2 16 2C8.26801 2 2 8.26801 2 16C2 23.732 8.26801 30 16 30Z" fill="#F0E6FF"></path>
                                                                        <g clip-path="url(#clip0_189_21647)">
                                                                            <path d="M7.55603 2.99193V17.1895H26.8245V3.49641C26.8245 2.81176 26.2951 2.27124 25.6246 2.27124H8.26183C7.87364 2.27124 7.55603 2.59555 7.55603 2.99193Z" fill="white" stroke="#4A4A4A" stroke-width="0.5" stroke-miterlimit="10"></path>
                                                                            <path d="M12.441 14.3416L14.3407 15.4265H24.1107L26.6346 14.3416L24.1107 17.3252L21.6682 17.8677L15.8334 17.3252L12.441 14.3416Z" fill="#E5E5E5"></path>
                                                                            <path d="M20.1544 5.52614H14.7822C14.5247 5.52614 14.3407 5.34328 14.3407 5.08728V2.27124H20.3016V5.34328C20.3384 5.453 20.2648 5.52614 20.1544 5.52614Z" fill="#6E0AD6" stroke="#4A4A4A" stroke-miterlimit="10"></path>
                                                                            <path d="M28.327 12.9656C27.0493 13.2541 25.949 14.0477 25.0971 15.743L22.2576 17.3663C21.9381 16.9334 21.4057 16.6088 20.6604 16.6088C19.5956 16.6088 18.5662 16.6088 16.5786 16.6088C15.9752 16.6088 14.7329 15.0216 13.7746 15.0216C13.4196 14.8773 11.6449 14.8773 10.4027 15.0216C9.44432 15.0216 8.20204 15.8873 7.49216 16.5366C6.42735 17.6188 3.69432 20.252 3.37488 20.5045C5.11408 21.9834 8.66346 25.4462 9.44432 26.1676C10.5091 25.0855 10.9351 24.0755 11.7869 24.0755C12.6743 24.0755 20.4829 24.0755 21.3702 24.0755C22.1511 24.0755 26.5169 20.0355 27.0848 19.3862C27.4901 18.9193 29.2331 16.633 30.3394 14.8839C30.686 14.3359 30.6238 13.9345 30.4881 13.5277C30.0976 12.9505 29.6758 12.6409 28.327 12.9656Z" fill="white"></path>
                                                                            <path d="M28.327 12.9656C27.0493 13.2541 25.949 14.0477 25.0971 15.743L22.2576 17.3663C21.9381 16.9334 21.4057 16.6088 20.6604 16.6088C19.5956 16.6088 18.5662 16.6088 16.5786 16.6088C15.9752 16.6088 14.7329 15.0216 13.7746 15.0216C13.4196 14.8773 11.6449 14.8773 10.4027 15.0216C9.44432 15.0216 8.20204 15.8873 7.49216 16.5366C6.42735 17.6188 3.69432 20.252 3.37488 20.5045C5.11408 21.9834 4.87536 19.783 5.65622 20.5045C6.51604 19.6306 9.19208 16.5366 10.4027 16.5366C11.2196 16.1045 11.8981 16.1045 13.1193 16.1045C13.2045 16.0064 15.4009 18.0112 16.5786 18.0032C18.3348 17.9912 20.1824 18.6891 22.4822 18.2744C22.8199 17.7343 23.8366 18.0226 26.0102 16.4739C26.2816 15.4264 28.1813 14.3414 28.327 14.477C29.4972 14.0717 30.1544 15.1763 30.3394 14.8839C30.686 14.3359 30.6238 13.9345 30.4881 13.5277C30.0976 12.9505 29.6758 12.6409 28.327 12.9656Z" fill="#E5E5E5"></path>
                                                                            <path d="M14.9104 20.324C14.9104 20.324 19.631 20.324 20.6604 20.324C23.2869 20.324 23.2869 16.6087 20.6604 16.6087C19.5956 16.6087 18.5662 16.6087 16.5786 16.6087C15.9752 16.6087 14.8039 15.0216 13.8456 15.0216C13.4196 15.0216 11.219 15.0216 10.1897 15.0216C9.16037 15.0216 8.20204 15.8873 7.52765 16.5366C6.46284 17.6187 3.72981 20.2519 3.41037 20.5044C5.11407 21.9833 8.66346 25.4462 9.44432 26.1676C10.5091 25.0855 10.9351 24.0755 11.7869 24.0755H20.6249C21.3348 24.0755 22.0091 23.8951 22.648 23.5705C24.6712 22.4162 26.6233 19.9273 27.0848 19.4223C27.4752 18.9533 29.2144 16.7169 30.3147 14.9494C30.9181 14.0116 30.2082 12.7851 29.1079 12.8573C28.8594 12.8934 28.5755 12.9294 28.2915 13.0016C27.0138 13.2901 25.9135 14.0837 25.0616 15.7791L22.2221 17.1858" stroke="#4A4A4A" stroke-width="0.5" stroke-miterlimit="10"></path>
                                                                            <path d="M8.9475 29.0895L10.8642 27.1417C11.3256 26.6728 11.3256 25.9513 10.8642 25.4824L4.61725 19.0978C4.15583 18.6289 3.44595 18.6289 2.98453 19.0978L1.06787 21.0456C0.606447 21.5146 0.606447 22.236 1.06787 22.7049L7.35027 29.0895C7.7762 29.5585 8.52157 29.5585 8.9475 29.0895Z" fill="#6E0AD6" stroke="#4A4A4A" stroke-miterlimit="10"></path>
                                                                            <path d="M3.16199 21.3701L4.54625 22.7769" stroke="white" stroke-miterlimit="10" stroke-linecap="round"></path>
                                                                            <path d="M9.16052 12.8574H10.1898" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                            <path d="M11.0416 12.8574H12.1064" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                            <path d="M12.9584 12.8574H14.0232" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                        </g>
                                                                        <defs>
                                                                            <clipPath id="clip0_189_21647">
                                                                                <rect width="30.6667" height="27.6667" fill="white" transform="translate(0.499878 2)"></rect>
                                                                            </clipPath>
                                                                        </defs>
                                                                    </svg>
                                                                    <p data-ds-component="DS-Text" class="sc-hgHYgh hbTyoW sc-hSdWYo htqcWR" color="--color-neutral-130" display="block"><span data-ds-component="DS-Text" class="sc-eInJlc hbIzfU sc-hSdWYo bSkWab" color="--color-neutral-130" display="block">Quero retirar no armário da CliqueRetire </span>Clique no botão Comprar e escolha a opção "Quero retirar no armário da CliqueRetire". Escolha em qual armário quer retirar e te avisamos em "Detalhes da compra" quando e como retirar sua compra.</p>
                                                                </div>
                                                            </div>
                                                            <p data-ds-component="DS-Text" class="sc-hgHYgh hbTyoW sc-hSdWYo htqcWR" color="--color-neutral-130" display="block">Em todas as opções acima você está protegido pela garantia da OLX. O vendedor só receberá o pagamento após sua confirmação de recebimento ou retirada do produto.</p>
                                                            <p data-ds-component="DS-Text" class="sc-hgHYgh hbTyoW sc-hSdWYo htqcWR" color="--color-neutral-130" display="block">Fique atento: no caso de realizar o pagamento em mãos e em dinheiro, ou utilizando qualquer meio online que não seja a plataforma da OLX, essa garantia perde o efeito e sua transação não estará assegurada pela OLX.</p>
                                                            <div data-ds-component="DS-Flex" class="sc-kafWEX sc-fOICqy dKiDao"><button data-testid="button-wrapper" data-ds-component="DS-Button" class="sc-gZMcBi iCyRCL">
                                                                    <div class="sc-iwsKbI hMjsjM"> <!-- -->Voltar para o anúncio</div>
                                                                </button></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div id="modal" data-ds-component="DS-Modal" class="sc-dEoRIm fmaqoh" data-testid="modal-overlay" aria-hidden="true">
                                                    <div role="dialog" aria-modal="true" aria-labelledby="ds-modal-content-126609" data-testid="modal" class="sc-jtggT fRcoaK">
                                                        <div class="sc-jKVCRD domptC"><button data-ds-component="DS-Button" data-testid="closeButton" type="button" class="sc-ebFjAB lluhit"><span class="sc-VigVT cueDsN">Fechar janela de diálogo</span><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M13.0607 12L18.5303 17.4697C18.8232 17.7626 18.8232 18.2374 18.5303 18.5303C18.2374 18.8232 17.7626 18.8232 17.4697 18.5303L12 13.0607L6.53033 18.5303C6.23744 18.8232 5.76256 18.8232 5.46967 18.5303C5.17678 18.2374 5.17678 17.7626 5.46967 17.4697L10.9393 12L5.46967 6.53033C5.17678 6.23744 5.17678 5.76256 5.46967 5.46967C5.76256 5.17678 6.23744 5.17678 6.53033 5.46967L12 10.9393L17.4697 5.46967C17.7626 5.17678 18.2374 5.17678 18.5303 5.46967C18.8232 5.76256 18.8232 6.23744 18.5303 6.53033L13.0607 12Z" fill="#4A4A4A"></path>
                                                                </svg></button></div>
                                                        <div id="ds-modal-content-126609" class="sc-kaNhvL cWMImq">
                                                            <div data-ds-component="DS-Flex" class="sc-kafWEX sc-chbbiW dYkYVy"><span data-ds-component="DS-Text" class="sc-iBEsjs gVrvSe sc-hSdWYo bYQcLm" color="--color-neutral-130" display="block">Garantia da OLX</span><span data-ds-component="DS-Text" class="sc-hzNEM dNTrAm sc-hSdWYo iDAOTJ" color="--color-neutral-130" display="block">Receba o que comprou ou a OLX devolve seu dinheiro</span>
                                                                <div data-ds-component="DS-Flex" class="sc-kafWEX sc-fcdeBU oCUry">
                                                                    <p data-ds-component="DS-Text" class="sc-gmeYpB QUAjb sc-hSdWYo htqcWR" color="--color-neutral-130" display="block">Ao realizar o pagamento pela OLX, clicando no botão Comprar, nós protegemos o seu dinheiro até que você confirme que recebeu o produto conforme esperado. Situações de cobertura:</p>
                                                                    <ul class="sc-kxynE iVorxG">
                                                                        <li class="sc-cooIXK fWOsuW">Produto não recebido</li>
                                                                        <li class="sc-cooIXK fWOsuW">Produto defeituoso*</li>
                                                                        <li class="sc-cooIXK fWOsuW">Produto diferente do anunciado</li>
                                                                    </ul>
                                                                    <p data-ds-component="DS-Text" class="sc-gmeYpB QUAjb sc-hSdWYo htqcWR" color="--color-neutral-130" display="block">Não recebeu o que esperava? Acesse “Preciso de ajuda” em “Detalhes da Compra” e nós resolveremos pra você.</p>
                                                                    <p data-ds-component="DS-Text" class="sc-kZmsYB UJxrT sc-hSdWYo iCBjkC" color="--color-neutral-130" display="block">*Exceto nos casos de anúncios que explicitam essa condição</p>
                                                                </div>
                                                            </div>
                                                            <div data-ds-component="DS-Flex" class="sc-kafWEX sc-RcBXQ iaDrkT"><button data-testid="button-wrapper" data-ds-component="DS-Button" class="sc-iSDuPN bmTnMU sc-gZMcBi iCyRCL">
                                                                    <div class="sc-iwsKbI hMjsjM"> <!-- -->Voltar para o anúncio</div>
                                                                </button></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 gHIvfR">
                                    <div from="lg" class="ad__h3us20-4 hqjcIS">
                                        <div>
                                            <div class="ad__h3us20-5 dpgDGU"></div>
                                            <div data-ds-component="DS-Flex" class="sc-kafWEX ad__en9h1n-1 ldGENT">
                                                <button data-testid="button-wrapper" data-ds-component="DS-Button" class="ad__en9h1n-3 gazhQO sc-gZMcBi iCyRCL">

                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 fqKcol">
                                    <div class="ad__h3us20-4 cxrGoW">
                                        <div>
                                            <div class="ad__sc-1o2mpyl-0 dQQnbA"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 glVqTX">
                                    <div class="ad__h3us20-4 cxrGoW">
                                        <div>
                                            <div class="ad__sc-1o2mpyl-0 dQQnbA"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 dGhjVe">
                                    <div class="ad__h3us20-4 cxrGoW">
                                        <div>
                                            <div class="ad__sc-1o2mpyl-0 dQQnbA"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 dZssbj">
                                    <div from="lg" class="ad__h3us20-4 hqjcIS">
                                        <div>
                                            <div class="ad__sc-1o2mpyl-0 dQQnbA"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 jkAK">
                                    <div class="ad__h3us20-4 cxrGoW">
                                        <div>
                                            <div class="ad__h3us20-4 cxrGoW">
                                                <div>
                                                    <div class="ad__h3us20-5 hebXKQ"></div>
                                                    <div data-ds-component="DS-Flex" class="sc-kafWEX ad__sc-5fdfr5-0 kIJyLN">
                                                        <h2 data-ds-component="DS-Text" color="--color-neutral-130" display="block" class="sc-hSdWYo davdrV">Calcule o frete</h2>
                                                        <div role="presentation" class="ad__sc-5fdfr5-1 dRVOMM"><a data-ds-component="DS-Link" href="https://buscacepinter.correios.com.br/app/endereco/index.php" target="_blank" data-testid="zipcode-check" class="ad__sc-5fdfr5-2 eIrngG sc-EHOje cBRYOz">Não sei meu CEP</a></div>
                                                    </div>
                                                    <div data-ds-component="DS-Flex" class="sc-kafWEX jDogfN">
                                                        <div data-testid="zipcodeinput-widget" class="ad__sc-5fdfr5-5 jpvXFy">
                                                            <form class="ad__sc-5fdfr5-8 emZFka">
                                                                <div data-ds-component="DS-TextInput" class="ad__sc-5fdfr5-3 ekrleZ sc-feJyhm fcYJXN">
                                                                    <span class="sc-iELTvK cNrgBk">
                                                                        <input type="text" aria-busy="false" aria-label="Campo de cep" aria-invalid="false" aria-errormessage="" aria-disabled="false" placeholder="Digite o CEP para calcular o frete" tabindex="0" value="" class="sc-cmTdod iyFOQA" id="campoCep">
                                                                    </span>
                                                                    <div data-ds-component="DS-Flex" data-testid="deliverySimulationResults" class="sc-gzVnrw nGgKe" id="resultadoFrete" style="display: none;">
                                                                        <div class="ad__sc-181grey-8 liCkqS">
                                                                            <div data-ds-component="DS-Flex" class="sc-gzVnrw ad__sc-181grey-5 dTLPje"></div>
                                                                            <div data-ds-component="DS-Container" class="ad__sc-181grey-4 kOjjhB sc-dqBHgY dvoZyR sc-gzVnrw kLyojW" type="outlined"><span data-ds-component="DS-Text" color="--color-neutral-130" display="block" class="sc-ifAKCX jViSDP" id="enderecoCep">Centro, Passo Fundo, RS</span></div>
                                                                        </div>
                                                                        <div data-ds-component="DS-Flex" class="sc-gzVnrw UujBt">
                                                                            <div data-ds-component="DS-Flex" class="sc-gzVnrw ad__sc-181grey-0 bPKpas"></div><svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" color="var(--color-neutral-130)" style="margin-left: -20px;">
                                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M10.2971 16.346L7.68871 13.7375C6.76419 14.2245 3.6968 16.1663 3.36585 20.6341C8.01702 20.2959 9.88267 17.1721 10.2971 16.346ZM6.1132 13.1055L3.26831 12.5366C2.7805 12.439 2.48782 12.0488 2.39026 11.6585C2.39026 11.1707 2.58538 10.7805 3.07319 10.4878L8.82928 7.36584C9.19217 7.18439 9.72379 7.17167 10.0319 7.48459C10.5447 6.7835 11.1208 6.10359 11.756 5.51219C15.5609 2 21.1219 2 21.317 2H22V2.68293C22 2.87805 21.9024 8.43902 18.4878 12.2439C17.925 12.8484 17.282 13.3994 16.617 13.8932C16.9257 14.2669 16.9123 14.7119 16.7317 15.0732L13.6097 20.8293C13.317 21.3171 12.9268 21.5122 12.5365 21.5122H12.3414C11.8536 21.4146 11.5609 21.122 11.4634 20.6342L10.9332 17.9831C9.66182 19.8157 6.9915 22 2.68293 22H2V21.3171C2.07693 17.0088 4.27725 14.3992 6.1132 13.1055ZM12.0644 16.4889C12.8563 16.1386 14.1374 15.5277 15.462 14.6855L12.7317 19.6585L12.0644 16.4889ZM9.21953 8.63413L9.24052 8.65512C8.3976 9.99965 7.79499 11.2856 7.46348 12.0436L4.24392 11.3658L9.21953 8.63413ZM8.6341 12.8293L11.1707 15.3659C12.3414 14.878 15.4634 13.4146 17.5121 11.2683C19.9512 8.63415 20.5365 4.82927 20.6341 3.36585C19.1707 3.46341 15.3658 4.04878 12.7317 6.4878C10.5853 8.43902 9.1219 11.6585 8.6341 12.8293ZM17.2195 6.78049C16.7317 6.29268 16.0488 6 15.3658 6C14.6829 6 14 6.29268 13.5122 6.78049C13.0244 7.26829 12.7317 7.95122 12.7317 8.63415C12.7317 9.31707 13.0244 10 13.5122 10.4878C14 10.9756 14.6829 11.2683 15.3658 11.2683C16.0488 11.2683 16.7317 10.9756 17.2195 10.4878C18.2927 9.41463 18.2927 7.7561 17.2195 6.78049ZM16.439 9.70732C15.8536 10.2927 14.878 10.2927 14.2927 9.70732C13.7073 9.12195 13.7073 8.14634 14.2927 7.56098C14.5853 7.26829 14.9756 7.07317 15.3658 7.07317C15.7561 7.07317 16.1463 7.26829 16.439 7.56098C17.0244 8.14634 17.0244 9.12195 16.439 9.70732Z" fill="var(--color-neutral-130)"></path>
                                                                            </svg>
                                                                            <div class="ad__h3us20-2 dAHSDM">
                                                                                <div data-ds-component="DS-Flex" class="sc-gzVnrw ad__sc-181grey-3 gIpWoT"><span data-ds-component="DS-Text" color="--color-neutral-130" display="block" class="sc-ifAKCX lgjPoE">Receba&nbsp;<span data-ds-component="DS-Text" display="inline" color="--color-neutral-130" class="sc-ifAKCX bFYwwx">em até&nbsp;<span data-ds-component="DS-Text" display="inline" color="--color-neutral-130" class="sc-ifAKCX koBdgQ">7&nbsp;dias úteis</span></span>&nbsp;com&nbsp;<span data-ds-component="DS-Text" display="inline" color="--color-neutral-130" class="sc-ifAKCX koBdgQ">Padrão</span>&nbsp;por&nbsp;<span data-ds-component="DS-Text" color="--color-neutral-120" display="inline" class="ad__sc-181grey-10 gMYlic sc-ifAKCX fBEkJf" style="text-decoration: line-through;">R$ 24,59</span><span data-ds-component="DS-Text" display="inline" class="ad__sc-181grey-11 fSnvRW sc-ifAKCX bsLHBR" color="--color-neutral-130">R$ 14,90</span></span>
                                                                                    <span data-testid="deliverySimulationResults-see-more-btn" role="button" tabindex="0" class="ad__sc-181grey-7 iymMhV"></span>
                                                                                </div>
                                                                            </div>


                                                                            <div class="ad__h3us20-3 ad__sc-181grey-6 ixznNN">
                                                                                <div data-ds-component="DS-Flex" class="sc-gzVnrw kuXcRK">
                                                                                    <div data-ds-component="DS-Flex" class="sc-gzVnrw ad__sc-181grey-3 gIpWoT"><span data-ds-component="DS-Text" color="--color-neutral-130" display="block" class="sc-ifAKCX ebbvmy">Expressa</span><span data-ds-component="DS-Text" color="--color-neutral-120" display="block" class="sc-ifAKCX ilrSX">Receba em até 1 dia útil</span></div>
                                                                                    <div data-ds-component="DS-Flex" class="sc-gzVnrw ad__sc-181grey-3 iQnFPq" style="gap: var(--spacing-0-5);"><span data-ds-component="DS-Text" color="--color-neutral-120" display="inline" class="ad__sc-181grey-10 gMYlic sc-ifAKCX fBEkJf" style="text-decoration: line-through;">R$ <?php echo $frete_alto; ?></span><span data-ds-component="DS-Text" class="ad__sc-181grey-11 fSnvRW sc-ifAKCX iOyFmS" color="--color-neutral-130" display="block">R$ <?php echo $frete; ?></span></div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="ad__h3us20-3 lhJrCT">
                                                                            <div data-ds-component="DS-Flex" class="sc-gzVnrw jNsmCS"><span data-testid="deliverySimulationResults-see-more-btn" role="button" tabindex="0" class="ad__sc-181grey-7 iymMhV"></span></div>
                                                                        </div>
                                                                    </div>
                                                                    <script>
                                                                        const campoCep = document.getElementById("campoCep");
                                                                        const resultadoFrete = document.getElementById("resultadoFrete");
                                                                        const enderecoCep = document.getElementById("enderecoCep");

                                                                        campoCep.addEventListener("input", () => {
                                                                            const cepValue = campoCep.value.replace(/\D/g, ""); // Remove caracteres não numéricos

                                                                            // Verifica se o CEP tem 8 números antes de fazer a requisição
                                                                            if (cepValue.length === 8) {
                                                                                const viaCepUrl = `https://viacep.com.br/ws/${cepValue}/json/`;

                                                                                fetch(viaCepUrl)
                                                                                    .then(response => response.json())
                                                                                    .then(data => {
                                                                                        if (!data.erro) {
                                                                                            const endereco = `${data.bairro}, ${data.localidade}, ${data.uf}`;
                                                                                            enderecoCep.innerText = endereco;
                                                                                        } else {
                                                                                            enderecoCep.innerText = "Endereço não encontrado";
                                                                                        }
                                                                                    })
                                                                                    .catch(error => {
                                                                                        enderecoCep.innerText = "Erro ao buscar o endereço";
                                                                                    });

                                                                                resultadoFrete.style.display = "block"; // Mostra a janela oculta
                                                                            } else {
                                                                                resultadoFrete.style.display = "none"; // Esconde a janela se o CEP não tiver 8 números
                                                                                enderecoCep.innerText = "Digite um CEP válido";
                                                                            }
                                                                        });
                                                                    </script>
                                                                    <style>
                                                                        .nGgKe {
                                                                            display: flex;
                                                                            flex-direction: column;
                                                                        }

                                                                        .liCkqS {
                                                                            margin-top: var(--spacing-1);
                                                                        }

                                                                        .dTLPje {
                                                                            display: flex;
                                                                            border-radius: 2px;
                                                                            background-color: var(--color-neutral-90);
                                                                            height: 32px;
                                                                            width: 32px;
                                                                            transform: rotate(45deg) translate(20px, -10px);
                                                                            margin-bottom: -24px;
                                                                        }

                                                                        .kOjjhB {
                                                                            background-color: var(--color-neutral-90);
                                                                            border: none;
                                                                            padding: var(--spacing-2);
                                                                            position: relative;
                                                                        }

                                                                        .dvoZyR {
                                                                            background-color: #f6f6f6;
                                                                            border-radius: var(--border-radius-sm);
                                                                            padding: var(--spacing-2);
                                                                            overflow: hidden;
                                                                            border: var(--border-width-hairline) solid var(--container-border-color-outlined);
                                                                        }

                                                                        .kLyojW {
                                                                            display: flex;
                                                                        }

                                                                        .jViSDP {
                                                                            display: block;
                                                                            margin: 0px;
                                                                            padding: 0px;
                                                                            font-family: var(--font-family);
                                                                            word-break: break-word;
                                                                            font-weight: var(--font-weight-semibold);
                                                                            line-height: var(--font-lineheight-distant);
                                                                            font-size: var(--font-size-xxs);
                                                                            font-style: normal;
                                                                            color: var(--color-neutral-130);
                                                                        }

                                                                        .UujBt {
                                                                            display: flex;
                                                                            -webkit-box-align: center;
                                                                            align-items: center;
                                                                            margin-top: var(--spacing-2);
                                                                        }

                                                                        .bPKpas {
                                                                            display: flex;
                                                                            border-radius: 50%;
                                                                            background-color: var(--color-neutral-90);
                                                                            padding: 10px;
                                                                        }

                                                                        .igTPsH {
                                                                            color: var(--color-neutral-130);
                                                                            height: 20px;
                                                                            width: 20px;
                                                                        }

                                                                        .dAHSDM {
                                                                            display: none;
                                                                        }

                                                                        .gIpWoT {
                                                                            display: flex;
                                                                            flex-direction: column;
                                                                            margin-left: var(--spacing-1);
                                                                        }

                                                                        .lgjPoE {
                                                                            display: block;
                                                                            margin: 0px;
                                                                            padding: 0px;
                                                                            font-family: var(--font-family);
                                                                            word-break: break-word;
                                                                            font-weight: var(--font-weight-regular);
                                                                            line-height: var(--font-lineheight-distant);
                                                                            font-size: var(--font-size-xxs);
                                                                            font-style: normal;
                                                                            color: var(--color-neutral-130);
                                                                        }

                                                                        .bFYwwx {
                                                                            display: inline;
                                                                            margin: 0px;
                                                                            padding: 0px;
                                                                            font-family: var(--font-family);
                                                                            word-break: break-word;
                                                                            font-weight: var(--font-weight-regular);
                                                                            line-height: var(--font-lineheight-distant);
                                                                            font-size: var(--font-size-xxs);
                                                                            font-style: normal;
                                                                            color: var(--color-neutral-130);
                                                                        }

                                                                        .koBdgQ {
                                                                            display: inline;
                                                                            margin: 0px;
                                                                            padding: 0px;
                                                                            font-family: var(--font-family);
                                                                            word-break: break-word;
                                                                            font-weight: var(--font-weight-semibold);
                                                                            line-height: var(--font-lineheight-distant);
                                                                            font-size: var(--font-size-xxs);
                                                                            font-style: normal;
                                                                            color: var(--color-neutral-130);
                                                                        }

                                                                        .fBEkJf {
                                                                            display: inline;
                                                                            margin-right: 15px;
                                                                            padding: 0px;
                                                                            font-style: normal;
                                                                            font-family: var(--font-family);
                                                                            word-break: break-word;
                                                                            font-weight: var(--font-weight-regular);
                                                                            line-height: var(--font-lineheight-medium);
                                                                            font-size: var(--font-size-xxxs);
                                                                            color: var(--color-neutral-120);
                                                                        }

                                                                        .fSnvRW {
                                                                            font-weight: var(--font-weight-bold);
                                                                            color: var(--color-feedback-success-100);
                                                                        }

                                                                        .bsLHBR {
                                                                            display: inline;
                                                                            margin-top: 0px;
                                                                            margin-right: 0px;
                                                                            margin-bottom: 0px;
                                                                            padding: 0px;
                                                                            font-style: normal;
                                                                            font-family: var(--font-family);
                                                                            word-break: break-word;
                                                                            font-weight: var(--font-weight-regular);
                                                                            line-height: var(--font-lineheight-medium);
                                                                            font-size: var(--font-size-xxxs);
                                                                            color: var(--color-neutral-130);
                                                                            margin-left: var(--spacing-0-5);
                                                                        }

                                                                        .jNsmCS {
                                                                            display: flex;
                                                                            margin-top: var(--spacing-2);
                                                                        }

                                                                        .iymMhV {
                                                                            cursor: pointer;
                                                                            color: var(--color-secondary-medium);
                                                                            font-weight: var(--font-weight-semibold);
                                                                            font-size: var(--font-size-xxs);
                                                                            outline: none;
                                                                        }
                                                                    </style>
                                                                    <div data-ds-component="DS-Flex" class="sc-kafWEX etIOjC"></div>
                                                                </div>
                                                                <div data-ds-component="DS-Flex" class="sc-kafWEX ad__sc-5fdfr5-4 dKHbZG">
                                                                    <div class="ad__h3us20-3 ad__sc-5fdfr5-6 iylYKg"></div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                        <div data-ds-component="DS-Flex" class="sc-kafWEX ad__sc-5fdfr5-7 kvIMt">
                                                            <div data-ds-component="DS-Flex" class="sc-kafWEX owzzZ"></div><button data-testid="submitDeliverySimulation" data-ds-component="DS-Button" class="sc-gZMcBi fXudwZ">
                                                                <div class="sc-iwsKbI hMjsjM"> <!-- -->Calcular</div>
                                                            </button>
                                                        </div>
                                                    </div>
                                                    <div class="ad__h3us20-5 jSHLrx"></div>
                                                    <div class="ad__h3us20-3 lhJrCT">
                                                        <div class="ad__sc-1o2mpyl-0 dQQnbA"></div>
                                                        <div class="ad__h3us20-5 iCUpEv"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 dyxZfV">
                                    <div class="ad__h3us20-4 cxrGoW">
                                        <div>
                                            <div data-ds-component="DS-Flex" data-section="description" class="sc-kafWEX iUYDes">
                                                <div class="ad__h3us20-3 lhJrCT">
                                                    <h2 data-ds-component="DS-Text" color="--color-neutral-130" display="block" class="sc-hSdWYo davdrV">Descrição</h2>
                                                    <div class="ad__h3us20-5 kLTIUD"></div>
                                                </div>
                                                <div class="ad__sc-1sj3nln-0 focuCb">
                                                    <div data-ds-component="DS-Flex" class="sc-kafWEX iUYDes">
                                                        <p class="ad__sc-1kv8vxj-0 dLCxtV">
                                                        </p>
                                                        <p class="ad__sc-1kv8vxj-0 jWWQbF" style="position: relative;"><span data-ds-component="DS-Text" class="ad__sc-1sj3nln-1 fMgwdS sc-hSdWYo htqcWR" color="--color-neutral-130" display="block"><?php echo $dados['descricao']; ?> </span></p>
                                                        <div class="erd_scroll_detection_container erd_scroll_detection_container_animation_active" style="visibility: hidden; display: inline; width: 0px; height: 0px; z-index: -1; overflow: hidden; margin: 0px; padding: 0px;">
                                                            <div dir="ltr" class="erd_scroll_detection_container" style="position: absolute; flex: 0 0 auto; overflow: hidden; z-index: -1; visibility: hidden; width: 100%; height: 100%; left: 0px; top: 0px;">
                                                                <div class="erd_scroll_detection_container" style="position: absolute; flex: 0 0 auto; overflow: hidden; z-index: -1; visibility: hidden; inset: -1px 0px 0px -1px;">
                                                                    <div style="position: absolute; flex: 0 0 auto; overflow: scroll; z-index: -1; visibility: hidden; width: 100%; height: 100%;">
                                                                        <div style="position: absolute; left: 0px; top: 0px; width: 369px; height: 179px;"></div>
                                                                    </div>
                                                                    <div style="position: absolute; flex: 0 0 auto; overflow: scroll; z-index: -1; visibility: hidden; width: 100%; height: 100%;">
                                                                        <div style="position: absolute; width: 200%; height: 200%;"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <p></p>
                                                        <div class="erd_scroll_detection_container erd_scroll_detection_container_animation_active" style="visibility: hidden; display: inline; width: 0px; height: 0px; z-index: -1; overflow: hidden; margin: 0px; padding: 0px;">
                                                            <div dir="ltr" class="erd_scroll_detection_container" style="position: absolute; flex: 0 0 auto; overflow: hidden; z-index: -1; visibility: hidden; width: 100%; height: 100%; left: 0px; top: 0px;">
                                                                <div class="erd_scroll_detection_container" style="position: absolute; flex: 0 0 auto; overflow: hidden; z-index: -1; visibility: hidden; inset: -1px 0px 0px -1px;">
                                                                    <div style="position: absolute; flex: 0 0 auto; overflow: scroll; z-index: -1; visibility: hidden; width: 100%; height: 100%;">
                                                                        <div style="position: absolute; left: 0px; top: 0px; width: 379px; height: 83px;"></div>
                                                                    </div>
                                                                    <div style="position: absolute; flex: 0 0 auto; overflow: scroll; z-index: -1; visibility: hidden; width: 100%; height: 100%;">
                                                                        <div style="position: absolute; width: 200%; height: 200%;"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <p></p>
                                                        <p></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 endrEq">
                                    <div class="ad__h3us20-4 cxrGoW">
                                        <div>
                                            <div data-ds-component="DS-Flex" class="sc-kafWEX cuKJrD">
                                                <h2 data-ds-component="DS-Text" color="--color-neutral-130" display="block" class="sc-hSdWYo eRxGni">Detalhes</h2>
                                                <div class="ad__h3us20-5 TLwJC"></div>
                                                <div data-testid="ad-properties" class="sc-bwzfXH ad__h3us20-0 ikHgMx">
                                                    <div class="ad__duvuxf-0 ad__h3us20-0 kUfvdA">
                                                        <div data-ds-component="DS-Flex" class="sc-kafWEX ad__sc-1f2ug0x-3 eQlxUw">
                                                            <span data-ds-component="DS-Text" class="ad__sc-1f2ug0x-0 lfYRqx sc-hSdWYo htqcWR" color="--color-neutral-130" display="block">Categoria</span>
                                                            <div role="presentation" class="ad__sc-1f2ug0x-2 eSYIff">
                                                                <a data-ds-component="DS-Link" href="#" class="sc-EHOje lePqYm"><?php echo $dados['categorias']; ?> </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="ad__duvuxf-0 ad__h3us20-0 kUfvdA">
                                                        <div data-ds-component="DS-Flex" class="sc-kafWEX ad__sc-1f2ug0x-3 eQlxUw">
                                                            <span data-ds-component="DS-Text" class="ad__sc-1f2ug0x-0 lfYRqx sc-hSdWYo htqcWR" color="--color-neutral-130" display="block">Tipo</span>
                                                            <div role="presentation" class="ad__sc-1f2ug0x-2 eSYIff">
                                                                <a data-ds-component="DS-Link" href="#" class="sc-EHOje lePqYm"><?php echo $dados['tipo']; ?> </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 jszGRZ">
                                    <div class="ad__h3us20-4 cxrGoW">
                                        <div>
                                            <div class="ad__h3us20-2 kWBGUW">
                                                <div data-ds-component="DS-Flex" class="sc-kafWEX cuKJrD">
                                                    <h2 data-ds-component="DS-Text" color="--color-neutral-130" display="block" class="sc-hSdWYo eRxGni">Localização</h2>
                                                    <div class="ad__h3us20-5 TLwJC"></div>
                                                    <div data-testid="ad-properties" class="sc-bwzfXH ad__h3us20-0 ikHgMx">
                                                        <div class="ad__duvuxf-0 ad__h3us20-0 kUfvdA">
                                                            <div data-ds-component="DS-Flex" class="sc-kafWEX ad__sc-1f2ug0x-3 eQlxUw">
                                                                <span data-ds-component="DS-Text" class="ad__sc-1f2ug0x-0 lfYRqx sc-hSdWYo htqcWR" color="--color-neutral-130" display="block">CEP</span>
                                                                <span data-ds-component="DS-Text" class="ad__sc-1f2ug0x-1 cpGpXB sc-hSdWYo gwYTWo" color="--color-neutral-130" display="block"><?php
function formatarCep($cep) {
    // Remove caracteres não numéricos
    $cep = preg_replace('/[^0-9]/', '', $cep);

    // Verifica se o CEP tem 8 dígitos
    if (strlen($cep) == 8) {
        // Formata o CEP no formato xxxxx-xxx
        return substr($cep, 0, 5) . '-' . substr($cep, 5, 3);
    }

    // Retorna o CEP original se não tiver 8 dígitos
    return $cep;
}

echo formatarCep($dados['cep']);
?>
</span>
                                                            </div>
                                                        </div>
                                                        <div class="ad__duvuxf-0 ad__h3us20-0 kUfvdA">
                                                            <div data-ds-component="DS-Flex" class="sc-kafWEX ad__sc-1f2ug0x-3 eQlxUw">
                                                                <span data-ds-component="DS-Text" class="ad__sc-1f2ug0x-0 lfYRqx sc-hSdWYo htqcWR" color="--color-neutral-130" display="block">Município</span>
                                                                <span data-ds-component="DS-Text" class="ad__sc-1f2ug0x-1 cpGpXB sc-hSdWYo gwYTWo" color="--color-neutral-130" display="block"><?php echo $dados['municipio']; ?></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="ad__h3us20-5 LaOtk"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="ad__h3us20-6 jZrnoS">

                                </div>
                                <div class="ad__h3us20-6 hQCBiM">
                                    <div from="xs" to="lg" class="ad__h3us20-4 jVXVWC">
                                        <div>
                                            <div data-ds-component="DS-Flex" class="sc-kafWEX iTyeOU">
                                                <span data-ds-component="DS-Text" color="--color-neutral-120" class="ad__sc-1oq8jzc-0 dWayMW sc-hSdWYo jFeRvR" display="block">Publicado em
                                                    <!-- -->
                                                    <!-- -->
                                                    24/07 às 10:11</span>
                                                <span data-ds-component="DS-Text" class="ad__j3yxk4-0 eEAacy sc-hSdWYo htqcWR" color="--color-neutral-130" display="block">-</span>
                                                <span data-ds-component="DS-Text" color="--color-neutral-120" class="ad__sc-16iz3i7-0 hjLLUR sc-hSdWYo jFeRvR" display="block">cód.
                                                    <!-- -->
                                                    <!-- -->
                                                    1213957664</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 bgBcvm">
                                    <div from="xs" to="lg" class="ad__h3us20-4 jVXVWC">
                                        <div></div>
                                    </div>
                                </div>
                                <div class="ad__h3us20-6 igPCMP">
                                    <div from="xs" to="lg" class="ad__h3us20-4 jVXVWC">
                                        <div>
                                            <div data-ds-component="DS-Flex" class="sc-kafWEX cETbit">
                                                <div data-ds-component="DS-Flex" class="sc-kafWEX iTyeOU">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="ad__h3us20-6 fnmykv">
                                <div from="xs" to="lg" class="ad__h3us20-4 jVXVWC">
                                    <div>
                                        <div data-ds-component="DS-Flex" class="sc-kafWEX ad__pw7c9f-0 gpTdno">
                                            <button data-testid="button-wrapper" data-ds-component="DS-Button" class="sc-gZMcBi dhMNpJ">
                                                <div class="sc-iwsKbI hMjsjM">
                                                    <span data-testid="icon-button" class="sc-htoDjs hYiizr">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                                                            <path fill="currentColor" fill-rule="evenodd" d="M20.1410488,11.9192144 C21.0111169,11.0495546 21.5,9.86964349 21.5,8.63933177 C21.5,7.40903732 21.0111291,6.22912113 20.1406731,5.35907349 C19.2709033,4.48889534 18.0909972,4 16.8606682,4 C15.6303392,4 14.4504331,4.48889534 13.5804144,5.35932248 L13.0603975,5.8793394 C12.4746111,6.46512582 11.5248636,6.46512581 10.9390772,5.87933938 L10.418938,5.35920023 C8.60737139,3.54763364 5.67024159,3.54763366 3.85867497,5.35920027 C2.04710836,7.17076689 2.04710834,10.1078967 3.85867491,11.9194633 L11.9997374,20.0605258 L20.1410488,11.9192144 Z M11.9997374,4.81867921 L12.5197543,4.29866229 C13.6726655,3.14627475 15.2333397,2.5 16.8606682,2.5 C18.488944,2.5 20.0504876,3.14702727 21.2015822,4.29866229 C22.3529727,5.44951237 23,7.01105603 23,8.63933177 C23,10.2676075 22.3529727,11.8291512 21.20146,12.9801235 L12.5205248,21.6610586 C12.2329018,21.9486816 11.7665729,21.9486816 11.4789499,21.6610586 L2.79801474,12.9801235 C0.400661729,10.5827704 0.400661758,6.69589314 2.7980148,4.2985401 C5.19536785,1.90118705 9.0822451,1.90118702 11.4795982,4.29854004 L11.9997374,4.81867921 Z"></path>
                                                        </svg>
                                                    </span>
                                                    <!-- -->
                                                    Favoritar
                                                </div>
                                            </button>
                                            <button data-testid="button-wrapper" data-ds-component="DS-Button" class="sc-gZMcBi dhMNpJ">
                                                <div class="sc-iwsKbI hMjsjM">
                                                    <span data-testid="icon-button" class="sc-htoDjs hYiizr">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                                                            <path fill="currentColor" fill-rule="evenodd" d="M14.4487856,17.792098 L8.79655427,14.4984113 C8.10985964,15.2665201 7.11139121,15.75 6,15.75 C3.92893219,15.75 2.25,14.0710678 2.25,12 C2.25,9.92893219 3.92893219,8.25 6,8.25 C7.11123296,8.25 8.10957529,8.73334223 8.79626091,9.50126062 L14.4472762,6.20345402 C14.3193604,5.82570606 14.25,5.42095303 14.25,5 C14.25,2.92893219 15.9289322,1.25 18,1.25 C20.0710678,1.25 21.75,2.92893219 21.75,5 C21.75,7.07106781 20.0710678,8.75 18,8.75 C16.888767,8.75 15.8904247,8.26665777 15.2037391,7.49873938 L9.55272378,10.796546 C9.68063957,11.1742939 9.75,11.579047 9.75,12 C9.75,12.420798 9.68069065,12.8254079 9.5528651,13.2030366 L15.206874,16.4977592 C15.8934614,15.7318733 16.8904569,15.25 18,15.25 C20.0710678,15.25 21.75,16.9289322 21.75,19 C21.75,21.0710678 20.0710678,22.75 18,22.75 C15.9289322,22.75 14.25,21.0710678 14.25,19 C14.25,18.5773943 14.3199061,18.171116 14.4487856,17.792098 L14.4487856,17.792098 Z M16.0036371,17.9611939 C15.8416028,18.2719534 15.75,18.6252792 15.75,19 C15.75,20.2426407 16.7573593,21.25 18,21.25 C19.2426407,21.25 20.25,20.2426407 20.25,19 C20.25,17.7573593 19.2426407,16.75 18,16.75 C17.2116871,16.75 16.5180619,17.1554063 16.1162398,17.7691037 C16.1027697,17.8025844 16.0867141,17.8355039 16.0680062,17.8676083 C16.0486211,17.9008745 16.0270706,17.9320946 16.0036371,17.9611939 L16.0036371,17.9611939 Z M7.9698325,10.9118261 C7.96020899,10.8976469 7.95100105,10.883043 7.94223473,10.8680214 C7.93354073,10.8531236 7.9254182,10.8380498 7.91786046,10.8228254 C7.52194832,10.1791761 6.81109388,9.75 6,9.75 C4.75735931,9.75 3.75,10.7573593 3.75,12 C3.75,13.2426407 4.75735931,14.25 6,14.25 C6.81109577,14.25 7.52195164,13.8208219 7.91786323,13.1771701 C7.92535031,13.1620881 7.93339167,13.1471537 7.94199384,13.1323917 C7.95083294,13.1172231 7.96012229,13.1024799 7.96983508,13.0881693 C8.14836396,12.76568 8.25,12.3947092 8.25,12 C8.25,11.6052889 8.14836297,11.2343164 7.9698325,10.9118261 L7.9698325,10.9118261 Z M16.0301675,6.08817393 C16.039791,6.1023531 16.048999,6.11695695 16.0577653,6.13197863 C16.0664593,6.14687639 16.0745818,6.16195018 16.0821395,6.17717458 C16.4780517,6.82082391 17.1889061,7.25 18,7.25 C19.2426407,7.25 20.25,6.24264069 20.25,5 C20.25,3.75735931 19.2426407,2.75 18,2.75 C16.7573593,2.75 15.75,3.75735931 15.75,5 C15.75,5.3947111 15.851637,5.7656836 16.0301675,6.08817393 L16.0301675,6.08817393 Z"></path>
                                                        </svg>
                                                    </span>
                                                    <!-- -->
                                                    Compartilhar
                                                </div>
                                            </button>
                                            <div class="ad__h3us20-2 kIjqbV">
                                                <button data-testid="button-wrapper" data-ds-component="DS-Button" class="sc-gZMcBi dhMNpJ">
                                                    <div class="sc-iwsKbI hMjsjM">
                                                        <span data-testid="icon-button" class="sc-htoDjs hYiizr">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                                                                <path fill="currentColor" fill-rule="evenodd" d="M3.25,22 L3.25,3 C3.25,2.80108763 3.32901763,2.6103222 3.46966991,2.46966991 C3.66560259,2.27373723 4.03217632,2.02935475 4.59645699,1.80364248 C5.46888118,1.45467281 6.59458162,1.25 8,1.25 C9.37492256,1.25 10.3182224,1.51951424 12.278543,2.30364248 C14.0682224,3.01951424 14.8749226,3.25 16,3.25 C17.2195816,3.25 18.1563812,3.07967281 18.846457,2.80364248 C19.0716351,2.71357122 19.2482226,2.62063048 19.3808499,2.53221228 C19.4447494,2.48961259 19.4729572,2.46638262 19.4696699,2.46966991 C19.9421436,1.99719627 20.75,2.33182136 20.75,3 L20.75,15 C20.75,15.1989124 20.6709824,15.3896778 20.5303301,15.5303301 C20.3343974,15.7262628 19.9678237,15.9706452 19.403543,16.1963575 C18.5311188,16.5453272 17.4054184,16.75 16,16.75 C14.6250774,16.75 13.6817776,16.4804858 11.721457,15.6963575 C9.93177759,14.9804858 9.12507744,14.75 8,14.75 C6.78041838,14.75 5.84361882,14.9203272 5.15354301,15.1963575 C4.9956786,15.2595033 4.86169611,15.3240594 4.75,15.3874787 L4.75,22 C4.75,22.4142136 4.41421356,22.75 4,22.75 C3.58578644,22.75 3.25,22.4142136 3.25,22 Z M8,13.25 C9.37492256,13.25 10.3182224,13.5195142 12.278543,14.3036425 C14.0682224,15.0195142 14.8749226,15.25 16,15.25 C17.2195816,15.25 18.1563812,15.0796728 18.846457,14.8036425 C19.0043214,14.7404967 19.1383039,14.6759406 19.25,14.6125213 L19.25,4.25530826 C18.4002888,4.56826382 17.3243301,4.75 16,4.75 C14.6250774,4.75 13.6817776,4.48048576 11.721457,3.69635752 C9.93177759,2.98048576 9.12507744,2.75 8,2.75 C6.78041838,2.75 5.84361882,2.92032719 5.15354301,3.19635752 C4.9956786,3.25950328 4.86169611,3.32405938 4.75,3.38747875 L4.75,13.7446917 C5.59971119,13.4317362 6.6756699,13.25 8,13.25 Z"></path>
                                                            </svg>
                                                        </span>
                                                        <!-- -->
                                                        Denunciar
                                                    </div>
                                                </button>
                                            </div>
                                        </div>
                                        <div class="ad__h3us20-5 LaOtk"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="ad__h3us20-6 grbrHJ">
                                <div from="xs" to="lg" class="ad__h3us20-4 jVXVWC">
                                    <div>
                                        <div class="wrapper_advertisement" data-testid="AdDetailAdvertising"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="ad__duvuxf-0 ad__h3us20-0 hwQusK">

                            <div class="ad__h3us20-6 kGPQGP">

                            </div>
                            <style>
                                .gdksDt {
                                    display: flex;
                                    -webkit-box-flex: 1;
                                    flex-grow: 1;
                                    flex-shrink: 1;
                                    width: 82px;
                                    height: 128px;
                                    flex-direction: column;
                                    -webkit-box-pack: center;
                                    justify-content: center;
                                    -webkit-box-align: center;
                                    align-items: center;
                                    text-align: center;
                                    border-left-width: var(--border-width-hairline);
                                    border-left-style: solid;
                                    border-left-color: var(--color-neutral-medium);
                                }

                                .dpjyOE {
                                    display: block;
                                    margin-right: 0px;
                                    margin-bottom: 0px;
                                    margin-left: 0px;
                                    padding: 0px;
                                    font-family: var(--font-family);
                                    word-break: break-word;
                                    font-weight: var(--font-weight-semibold);
                                    line-height: var(--font-lineheight-superdistant);
                                    font-size: var(--font-size-xs);
                                    font-style: normal;
                                    color: var(--color-neutral-darkest);
                                    margin-top: var(--font-size-xxxs);
                                }

                                .bDqKgU {
                                    margin-top: var(--spacing-stack-xxxs);
                                    -webkit-box-pack: center;
                                    justify-content: center;
                                    -webkit-box-align: center;
                                    align-items: center;
                                    background: var(--color-neutral-lighter);
                                    border: 1px solid var(--color-neutral-dark);
                                    border-radius: var(--spacing-stack-quarck);
                                }

                                .bYPvYq {
                                    display: flex;
                                }

                                .biBiOH {
                                    max-width: 328px;
                                    max-height: 217px;
                                    padding: 12px;
                                    background: var(--color-neutral-lighter);
                                }

                                .fDflfl {
                                    display: flex;
                                    flex-wrap: wrap;
                                    -webkit-box-pack: center;
                                    justify-content: center;
                                    place-items: center;
                                    -webkit-box-align: center;
                                    margin-bottom: var(--spacing-stack-xxxs);
                                }

                                .dFDcEs {
                                    display: block;
                                    margin: 0px;
                                    padding: 0px;
                                    font-family: var(--font-family);
                                    word-break: break-word;
                                    font-weight: var(--font-weight-regular);
                                    line-height: var(--font-lineheight-distant);
                                    font-size: var(--font-size-xxs);
                                    font-style: normal;
                                    color: var(--color-neutral-darkest);
                                }

                                .bYPvYq {
                                    display: flex;
                                }

                                .iEwbMe {
                                    display: flex;
                                    -webkit-box-flex: 1;
                                    flex-grow: 1;
                                    flex-shrink: 1;
                                    width: 82px;
                                    height: 128px;
                                    flex-direction: column;
                                    -webkit-box-pack: center;
                                    justify-content: center;
                                    -webkit-box-align: center;
                                    align-items: center;
                                    text-align: center;
                                    border-right-width: var(--border-width-hairline);
                                    border-right-style: solid;
                                    border-right-color: var(--color-neutral-medium);
                                }

                                .dpjyOE {
                                    display: block;
                                    margin-right: 0px;
                                    margin-bottom: 0px;
                                    margin-left: 0px;
                                    padding: 0px;
                                    font-family: var(--font-family);
                                    word-break: break-word;
                                    font-weight: var(--font-weight-semibold);
                                    line-height: var(--font-lineheight-superdistant);
                                    font-size: var(--font-size-xs);
                                    font-style: normal;
                                    color: var(--color-neutral-darkest);
                                    margin-top: var(--font-size-xxxs);
                                }

                                .hZMfbR {
                                    display: block;
                                    margin: 0px;
                                    padding: 0px;
                                    font-style: normal;
                                    font-family: var(--font-family);
                                    word-break: break-word;
                                    font-weight: var(--font-weight-regular);
                                    line-height: var(--font-lineheight-medium);
                                    font-size: var(--font-size-xxxs);
                                    color: var(--color-neutral-darkest);
                                }

                                .iEwbMe {
                                    display: flex;
                                    -webkit-box-flex: 1;
                                    flex-grow: 1;
                                    flex-shrink: 1;
                                    width: 82px;
                                    height: 128px;
                                    flex-direction: column;
                                    -webkit-box-pack: center;
                                    justify-content: center;
                                    -webkit-box-align: center;
                                    align-items: center;
                                    text-align: center;
                                    border-right-width: var(--border-width-hairline);
                                    border-right-style: solid;
                                    border-right-color: var(--color-neutral-medium);
                                }

                                .SuCud {
                                    display: flex;
                                    -webkit-box-flex: 1;
                                    flex-grow: 1;
                                    flex-shrink: 1;
                                    width: 82px;
                                    height: 128px;
                                    flex-direction: column;
                                    -webkit-box-pack: center;
                                    justify-content: center;
                                    -webkit-box-align: center;
                                    align-items: center;
                                    text-align: center;
                                }
                            </style>
                            <div class="ad__h3us20-6 gySvSN">
                                <div data-ds-component="DS-Flex" class="sc-bdvvtL Box__SellerHistoryContainer-sc-15z8czu-0 bYPvYq bDqKgU">
                                    <div class="Box__Container-sc-15z8czu-1 biBiOH">
                                        <div class="Box__FlexTitle-sc-15z8czu-3 fDflfl">
                                            <p color="--color-neutral-darkest" display="block" data-ds-component="DS-Text" class="sc-gsDKAQ dFDcEs">Histórico do vendedor</p>
                                        </div>
                                        <div data-ds-component="DS-Flex" class="sc-bdvvtL bYPvYq">
                                            <div class="Box__FlexItem-sc-15z8czu-2 iEwbMe"><svg width="65" height="64" viewBox="0 0 65 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M32.3334 58.3637C46.8936 58.3637 58.697 46.5603 58.697 32.0001C58.697 17.4399 46.8936 5.63647 32.3334 5.63647C17.7731 5.63647 5.96973 17.4399 5.96973 32.0001C5.96973 46.5603 17.7731 58.3637 32.3334 58.3637Z" fill="#F0E6FF"></path>
                                                    <path d="M26.4369 13.6538L16.4879 23.7107C16.051 24.1764 15.8367 24.8083 15.8944 25.4402L18.3922 52.2643C18.5076 53.4866 19.5792 54.3763 20.791 54.2682L30.9886 52.8119" fill="#6E0AD6"></path>
                                                    <path d="M26.4369 13.6538L16.4879 23.7107C16.051 24.1764 15.8367 24.8083 15.8944 25.4402L18.3922 52.2643C18.5076 53.4866 19.5792 54.3763 20.791 54.2682L30.9886 52.8119" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M20.552 25.806L27.0808 12.5187C27.6084 11.4378 28.8532 10.9139 29.9908 11.3047L43.9059 16.0609C44.5571 16.2854 45.0847 16.7843 45.3485 17.4245L56.4361 44.4897C56.9389 45.7203 56.3619 47.1339 55.1418 47.6411L44.9198 51.9066L34.6979 56.1722C33.4778 56.6794 32.0764 56.0974 31.5736 54.8668L20.486 27.8016C20.2222 27.153 20.2469 26.4296 20.552 25.806ZM30.6833 17.1585C32.1094 16.5598 33.7499 17.2416 34.3434 18.6884C34.9369 20.1352 34.2527 21.7899 32.8266 22.3803C31.4004 22.9789 29.76 22.2971 29.1664 20.8503C28.5729 19.4118 29.2489 17.7572 30.6833 17.1585Z" fill="white"></path>
                                                    <path d="M27.0808 12.5187L27.5296 12.7392L27.5302 12.738L27.0808 12.5187ZM20.552 25.806L20.1032 25.5855L20.1028 25.5863L20.552  25.806ZM29.9908 11.3047L29.8284 11.7776L29.8291 11.7779L29.9908 11.3047ZM43.9059 16.0609L44.0688 15.5882L44.0676  15.5878L43.9059 16.0609ZM45.3485 17.4245L45.8112 17.235L45.8108 17.2341L45.3485 17.4245ZM56.4361 44.4897L56.8989  44.3006L56.8987 44.3002L56.4361 44.4897ZM55.1418 47.6411L54.9499 47.1794L54.9493 47.1796L55.1418 47.6411ZM44.9198  51.9066L45.1124 52.3681L44.9198 51.9066ZM34.6979 56.1722L34.8898 56.6339L34.8904 56.6336L34.6979 56.1722ZM31.5736  54.8668L32.0364 54.6776L32.0362 54.6772L31.5736 54.8668ZM20.486 27.8016L20.0228 27.99L20.0233 27.9911L20.486  27.8016ZM34.3434 18.6884L34.806 18.4987V18.4987L34.3434 18.6884ZM30.6833 17.1585L30.8758 17.6199L30.8768 17.6195L30.6833  17.1585ZM32.8266 22.3803L32.6353 21.9183L32.633 21.9192L32.8266 22.3803ZM29.1664 20.8503L29.629 20.6605L29.6286 20.6596L29.1664 20.8503ZM26.6321 12.2982L20.1032 25.5855L21.0007 26.0265L27.5296 12.7392L26.6321 12.2982ZM30.1532 10.8319C28.7742 10.3581 27.2685 10.9943 26.6315 12.2994L27.5302 12.738C27.9483 11.8813 28.9322 11.4697 29.8284 11.7776L30.1532 10.8319ZM44.0676 15.5878L30.1525 10.8316L29.8291 11.7779L43.7442 16.534L44.0676 15.5878ZM45.8108 17.2341C45.4927 16.4621 44.8567 15.8598 44.0688 15.5882L43.7429 16.5336C44.2576 16.711 44.6767 17.1065 44.8862 17.615L45.8108 17.2341ZM56.8987 44.3002L45.8112  17.235L44.8858 17.6141L55.9734 44.6792L56.8987 44.3002ZM55.3338 48.1028C56.8124 47.4881 57.5038 45.781 56.8989  44.3006L55.9732 44.6788C56.374 45.6596 55.9114 46.7797 54.9499 47.1794L55.3338 48.1028ZM45.1124 52.3681L55.3344  48.1025L54.9493 47.1796L44.7273 51.4452L45.1124 52.3681ZM34.8904 56.6336L45.1124 52.3681L44.7273 51.4452L34.5053  55.7108L34.8904 56.6336ZM31.1107 55.0559C31.7182 56.5426 33.4131 57.2478 34.8898 56.6339L34.5059 55.7105C33.5426  56.111 32.4346 55.6521 32.0364 54.6776L31.1107 55.0559ZM20.0233 27.9911L31.1109 55.0563L32.0362 54.6772L20.9487  27.6121L20.0233 27.9911ZM20.1028 25.5863C19.735 26.3384 19.7057 27.2102 20.0228 27.99L20.9492 27.6132C20.7387 27.0958  20.7589 26.5209 21.0011 26.0257L20.1028 25.5863ZM34.806 18.4987C34.1082 16.7978 32.1748 15.9901 30.4897  16.6975L30.8768 17.6195C32.044 17.1295 33.3915 17.6855 33.8808 18.8782L34.806 18.4987ZM33.0178 22.8423C34.702  22.1451 35.5027 20.1969 34.806 18.4987L33.8808 18.8782C34.3712 20.0736 33.8034 21.4347 32.6353 21.9183L33.0178  22.8423ZM28.7039 21.0401C29.4016 22.741 31.335 23.5487 33.0201 22.8413L32.633 21.9192C31.4659 22.4092 30.1183  21.8533 29.629 20.6605L28.7039 21.0401ZM30.4907 16.6971C28.7997 17.4028 28.0067 19.3505 28.7042 21.041L29.6286  20.6596C29.1391 19.4732 29.698 18.1115 30.8758 17.6199L30.4907 16.6971Z" fill="#4A4A4A"></path>
                                                    <path d="M52.3725 46.7078C53.5926 46.2006 54.1696 44.7871 53.6668 43.5565L50.5712 36" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path d="M49.1796 33.2L49.7531 34.6" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path d="M34.3434 18.6886C33.7499 17.2418 32.1094 16.56 30.6833 17.1587C29.2489 17.7574 28.5729 19.412 29.1665 20.8505C29.76 22.2973 31.4005 22.9791 32.8266 22.3805C34.2527 21.7901 34.9369 20.1354 34.3434 18.6886Z" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path d="M31.3262 18.4059C28.375 13.4834 20.7909 6.56538 18.5569 9.56708C16.9247 11.7622 20.8898 15.0383 24.8385 17.0838" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M37.9298 36.8692L40.0347 35.9159C40.8966 35.5255 41.8969 35.8983 42.2735 36.7501C42.6502 37.602 42.2582 38.6053 41.3964 38.9956L37.6091 40.7109C37.1947 40.8986 37.0034 41.3883 37.1845 41.7978C37.3656 42.2074 37.8538 42.3893 38.2682 42.2016L40.2488 41.3046L40.8971 42.7708C41.0782 43.1803 41.5664 43.3623 41.9808 43.1746C42.3951 42.9869 42.5864 42.4972 42.4054 42.0877L41.7571 40.6215L42.0638 40.4826C43.7543 39.717 44.5289 37.7342 43.7901 36.0633C43.0513 34.3923 41.0745 33.6557 39.3839 34.4214L37.2789 35.3747C36.4171 35.765 35.4167 35.3923 35.0401 34.5404C34.6635 33.6885 35.0554 32.6852 35.9173 32.2949L39.6383 30.6097C40.0526 30.422 40.2439 29.9323 40.0629 29.5228C39.8818 29.1132 39.3935 28.9313 38.9792 29.1189L37.0648 29.9859L36.4311 28.5525C36.25 28.143 35.7617 27.961 35.3474 28.1487C34.933 28.3364 34.7417 28.8261 34.9228 29.2356L35.5602 30.6772L35.2535 30.8161C33.5629 31.5818 32.7884 33.5645 33.5272 35.2354C34.2706 36.8944 36.2475 37.6311 37.9298 36.8692Z" fill="#6E0AD6"></path>
                                                </svg>
                                                <p color="--color-neutral-darkest" display="block" data-ds-component="DS-Text" class="sc-gsDKAQ dpjyOE"><?php echo $dados['vedidos_anunciante']; ?></p>
                                                <p color="--color-neutral-darkest" display="block" data-ds-component="DS-Text" class="sc-gsDKAQ hZMfbR">Anuncios vendidos</p>
                                            </div>
                                            <div class="Box__FlexItem-sc-15z8czu-2 SuCud"><svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M10.9447 5.02519L58.3213 45.0326C60.2187 46.5929 60.5637 49.5888 59.0688 51.5861C58.3788 52.5223 57.4014 53.1464 56.309 53.3337L14.7395 59.9495C12.3821 60.324 10.1973 58.5764 9.85231 55.955C9.85231 55.955 9.85231 55.955 9.85231 55.8926L4.04522 9.33176C3.70025 6.77279 5.36763 4.40105 7.72496 4.02657C8.87488 3.90174 10.0248 4.21381 10.9447 5.02519Z" fill="#DEF9CC"></path>
                                                    <path d="M60.5298 38.716C60.5797 37.6484 60.5298 32.8928 57.0134 32.8928C56.7637 32.456 55.7648 30.2723 54.8658 28.4283C54.0667 26.6813 52.2688 25.5652 50.321 25.5652H42.8794V43.4231H60.1302C60.1302 43.4231 61.4787 42.5497 61.4787 41.5306C61.4787 40.5601 61.7284 39.0072 60.5298 38.716Z" fill="white" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path d="M57.0374 32.8928C60.5537 32.8928 60.4972 37.542 60.4472 38.6096H42.7969L42.9033 25.5652H50.3449C52.2927 25.5652 54.0907 26.6813 54.8898 28.4283C55.7888 30.2723 56.7876 32.456 57.0374 32.8928Z" fill="#8CE563" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path d="M52.9657 32.9879L51.4344 29.688C51.3387 29.4454 51.0994 29.2998 50.8123 29.2998H47.3667V34.0069H52.2958C52.8222 34.0069 53.205 33.4731 52.9657 32.9879Z" fill="white" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path d="M14.069 17H38.6576C41.4191 17 43.6576 19.2386 43.6576 22V40.3595H22.8288H14.069V17Z" fill="white"></path>
                                                    <path d="M15.2371 40.3594H43.6578V43.474H18.3517C16.6315 43.474 15.2371 42.0795 15.2371 40.3594Z" fill="white"></path>
                                                    <path d="M43.6576 40.5151L14.069 40.5151" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path d="M14.069 24.571V17H39.8814C41.9846 17 43.6576 18.7096 43.6576 20.8588V43.4741H18.0503C16.2816 43.4741 15.6263 42.3614 15.6263 40.5541H14.069V34.975" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path d="M26.6735 43.8876C26.6735 46.1841 24.8282 47.9999 22.5612 47.9999C20.2942 47.9999 18.449 46.1307 18.449 43.8876C18.449 41.6446 20.2942 39.7754 22.5612 39.7754C24.8809 39.7754 26.6735 41.5912 26.6735 43.8876Z" fill="white" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path d="M24.7755 43.8876C24.7755 45.1242 23.7819 46.1019 22.5612 46.1019C21.3405 46.1019 20.3469 45.0954 20.3469 43.8876C20.3469 42.6798 21.3405 41.6733 22.5612 41.6733C23.8103 41.6733 24.7755 42.6511 24.7755 43.8876Z" fill="#8CE563" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path d="M54.5101 43.8876C54.5101 46.1841 52.6649 47.9999 50.3979 47.9999C48.1309 47.9999 46.2856 46.1307 46.2856 43.8876C46.2856 41.6446 48.1309 39.7754 50.3979 39.7754C52.7176 39.7754 54.5101 41.5912 54.5101 43.8876Z" fill="white" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path d="M52.6124 43.8876C52.6124 45.1242 51.6188 46.1019 50.3981 46.1019C49.1774 46.1019 48.1838 45.0954 48.1838 43.8876C48.1838 42.6798 49.1774 41.6733 50.3981 41.6733C51.6472 41.6733 52.6124 42.6511 52.6124 43.8876Z" fill="#8CE563" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path d="M23.2957 32.6851H6.49792" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path d="M14.069 27.1223V32.3782" stroke="#4A4A4A" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path d="M33.4886 24.6411H11.1396" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path d="M39.0398 17H11.1396" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path d="M8.05415 17.1194H7.04858" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path d="M3.96272 17.1194H2.9093" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path d="M3.05342 32.6851H2" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path d="M8.05415 24.6411H7.04858" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg>
                                                <p color="--color-neutral-darkest" display="block" data-ds-component="DS-Text" class="sc-gsDKAQ dpjyOE">1 dia</p>
                                                <p color="--color-neutral-darkest" display="block" data-ds-component="DS-Text" class="sc-gsDKAQ hZMfbR">Tempo médio<br>de despacho</p>
                                            </div>
                                            <div class="Box__FlexItem-sc-15z8czu-2 gdksDt"><svg width="65" height="64" viewBox="0 0 65 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M49.722 59.9523L7.63441 53.0859C5.68891 52.762 4.39191 50.9482 4.71616 49.0049L11.5254 6.96457C11.8497 5.02126 13.6655 3.72572 15.611 4.0496L57.6986 10.916C59.6441 11.2399 60.9411 13.0536 60.6168 14.9969L53.8076 56.9725C53.5482 58.9158 51.6675 60.2761 49.722 59.9523Z" fill="#FFF3E6"></path>
                                                    <g clip-path="url(#clip0_17870_136343)">
                                                        <rect x="14.1665" y="7.5" width="36.3333" height="48.3333" rx="3.5" fill="white" stroke="#4A4A4A"></rect>
                                                        <rect x="38.3333" y="41.8" width="5.33333" height="1" rx="0.5" fill="#4A4A4A"></rect>
                                                        <rect x="19.6665" y="37.4666" width="5.66667" height="1" rx="0.5" fill="#4A4A4A"></rect>
                                                        <rect x="19.6665" y="33.1333" width="16" height="1" rx="0.5" fill="#4A4A4A"></rect>
                                                        <rect x="38.3333" y="33.1333" width="5.33333" height="1" rx="0.5" fill="#4A4A4A"></rect>
                                                        <rect x="27.6665" y="37.4666" width="16" height="1" rx="0.5" fill="#4A4A4A"></rect>
                                                        <rect x="19.6665" y="41.8" width="16" height="1" rx="0.5" fill="#4A4A4A"></rect>
                                                        <path d="M19.6665 48.6334C19.6665 47.6209 20.4873 46.8 21.4998 46.8H31.1665C32.179 46.8 32.9998 47.6209 32.9998 48.6334C32.9998 49.6459 32.179 50.4667 31.1665 50.4667H21.4998C20.4873 50.4667 19.6665 49.6459 19.6665 48.6334Z" fill="#F28000"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M28.3922 23.4511C28.3922 21.1317 26.512 19.2515 24.1926 19.2515C21.8732 19.2515 19.9929 21.1317 19.9929 23.4511C19.9929 25.7706 21.8732 27.6508 24.1926 27.6508C26.512 27.6508 28.3922 25.7706 28.3922 23.4511Z" stroke="#F28000" stroke-linecap="round" stroke-linejoin="round"></path>
                                                        <path d="M31.2078 23.2375L37.4418 17.7827" stroke="#F28000" stroke-linecap="round" stroke-linejoin="round"></path>
                                                        <path d="M37.6336 16.4343L29.2342 16.4343L24.1946 23.453L30.5048 23.5524" stroke="#F28000" stroke-linecap="round" stroke-linejoin="round"></path>
                                                        <path d="M30.8171 23.627L28.8599 14.6245" stroke="#F28000" stroke-linecap="round" stroke-linejoin="round"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M43.9303 23.4524C43.9303 21.1329 42.0501 19.2527 39.7306 19.2527C37.4112 19.2527 35.531 21.1329 35.531 23.4524C35.531 25.7718 37.4112 27.652 39.7306 27.652C42.0501 27.652 43.9303 25.7718 43.9303 23.4524Z" stroke="#F28000" stroke-linecap="round" stroke-linejoin="round"></path>
                                                        <path d="M39.7318 23.4514C35.8419 16.8684 39.5927 12.0939 35.1042 13.2908" stroke="#F28000" stroke-linecap="round" stroke-linejoin="round"></path>
                                                        <path d="M27.625 14.5945L30.318 14.5945" stroke="#F28000" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </g>
                                                    <path d="M48.6665 59C53.6371 59 57.6665 54.9706 57.6665 50C57.6665 45.0294 53.6371 41 48.6665 41C43.6959 41 39.6665 45.0294 39.6665 50C39.6665 54.9706 43.6959 59 48.6665 59Z" fill="#F28000" stroke="#4A4A4A" stroke-miterlimit="10"></path>
                                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M45.9507 47.2746C46.2447 46.9729 46.7214 46.9729 47.0154 47.2746L51.6995 52.0803C51.9935 52.382 51.9935 52.871 51.6995 53.1726C51.4055 53.4742 50.9288 53.4742 50.6349 53.1726L45.9507 48.3668C45.6567 48.0652 45.6567 47.5762 45.9507 47.2746Z" fill="white"></path>
                                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M46.1641 53.1729C45.8701 52.8713 45.8701 52.3823 46.1641 52.0806L50.8483 47.2749C51.1422 46.9732 51.6189 46.9732 51.9129 47.2749C52.2069 47.5765 52.2069 48.0655 51.9129 48.3672L47.2288 53.1729C46.9348 53.4746 46.4581 53.4746 46.1641 53.1729Z" fill="white"></path>
                                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M45.9507 47.2746C46.2447 46.9729 46.7214 46.9729 47.0154 47.2746L51.6995 52.0803C51.9935 52.382 51.9935 52.871 51.6995 53.1726C51.4055 53.4742 50.9288 53.4742 50.6349 53.1726L45.9507 48.3668C45.6567 48.0652 45.6567 47.5762 45.9507 47.2746Z" stroke="white" stroke-width="0.5" stroke-linecap="round"></path>
                                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M46.1641 53.1729C45.8701 52.8713 45.8701 52.3823 46.1641 52.0806L50.8483 47.2749C51.1422 46.9732 51.6189 46.9732 51.9129 47.2749C52.2069 47.5765 52.2069 48.0655 51.9129 48.3672L47.2288 53.1729C46.9348 53.4746 46.4581 53.4746 46.1641 53.1729Z" stroke="white" stroke-width="0.5" stroke-linecap="round"></path>
                                                    <defs>
                                                        <clipPath id="clip0_17870_136343">
                                                            <rect width="37.3333" height="49.3333" fill="white" transform="translate(13.6665 7)"></rect>
                                                        </clipPath>
                                                    </defs>
                                                </svg>
                                                <p color="--color-neutral-darkest" display="block" data-ds-component="DS-Text" class="sc-gsDKAQ dpjyOE">0</p>
                                                <p color="--color-neutral-darkest" display="block" data-ds-component="DS-Text" class="sc-gsDKAQ hZMfbR">Vendas canceladas</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <br>
                            </div>
                            <div class="ad__h3us20-6 eLypNc">
                                <div class="ad__h3us20-4 cxrGoW">
                                    <div class="ad__h3us20-5 kLTIUD"></div>
                                </div>
                            </div>
                            <style>
                                .gIXVTt {
                                    padding: var(--spacing-stack-xs) var(--spacing-inline-xxxs);
                                    display: flex;
                                    margin-right: var(--spacing-inline-xxxs);
                                    margin-left: var(--spacing-inline-xxxs);
                                    border-radius: var(--border-radius-sm);
                                    border: 1px solid var(--color-neutral-medium);
                                    background-color: var(--color-neutral-lighter);
                                }

                                .htqcWR {
                                    display: block;
                                    margin: 0px;
                                    padding: 0px;
                                    font-family: var(--font-family);
                                    word-break: break-word;
                                    font-weight: var(--font-weight-regular);
                                    line-height: var(--font-lineheight-superdistant);
                                    font-size: var(--font-size-xs);
                                    font-style: normal;
                                    color: var(--color-neutral-130);
                                }

                                .carousel .slider-wrapper.axis-horizontal .slider .slide {
                                    flex-flow: column;
                                }

                                .czdJJb .carousel .slide {
                                    background-color: initial;
                                }

                                .carousel .slide {
                                    min-width: 100%;
                                    margin: 0px;
                                    position: relative;
                                    text-align: center;
                                    background: rgb(0, 0, 0);
                                }

                                .bFNMKY {
                                    margin-top: var(--spacing-stack-xxs);
                                    margin-bottom: var(--spacing-stack-xxxs);
                                }

                                .jdxMYo {
                                    display: flex;
                                    flex-direction: column;
                                    background-color: var(--color-neutral-lighter);
                                    padding: 0;
                                }

                                .dvdvVb {
                                    display: flex;
                                    flex-direction: column;
                                }

                                .iPVWvr {
                                    display: flex;
                                    -webkit-box-flex: 0;
                                    flex-grow: 0;
                                    background-color: transparent;
                                    width: 100%;
                                }

                                .gcOoiX {
                                    display: block;
                                    margin: 0px;
                                    padding: 0px;
                                    font-family: var(--font-family);
                                    word-break: break-word;
                                    font-weight: var(--font-weight-semibold);
                                    line-height: var(--font-lineheight-distant);
                                    font-size: var(--font-size-xxs);
                                    font-style: normal;
                                    color: var(--color-neutral-130);
                                }

                                .iPVWvr {
                                    display: flex;
                                    -webkit-box-flex: 0;
                                    flex-grow: 0;
                                    background-color: transparent;
                                    width: 100%;
                                }

                                .dvdvVb {
                                    display: flex;
                                    flex-direction: column;
                                }

                                @media (max-width: 701px) .dwbQeO {
                                    width: 316px;
                                }

                                .dwbQeO {
                                    display: flex;
                                    -webkit-box-pack: start;
                                    place-content: center flex-start;
                                    flex-shrink: 1;
                                    box-sizing: border-box;
                                    flex-wrap: wrap;
                                    background-color: transparent;
                                }

                                .cAkiDV {
                                    display: flex;
                                    -webkit-box-pack: start;
                                    justify-content: flex-start;
                                    flex-basis: 150px;
                                    background-color: var(--color-neutral-lighter);
                                    margin-bottom: var(--spacing-stack-nano);
                                    margin-right: var(--spacing-inline-nano);
                                }

                                .fVwWyK {
                                    display: inline-flex;
                                    -webkit-box-pack: center;
                                    justify-content: center;
                                    -webkit-box-align: center;
                                    align-items: center;
                                    cursor: pointer;
                                    outline: none;
                                    text-decoration: none;
                                    font-size: var(--font-size-xxxs);
                                    line-height: var(--font-lineheight-medium);
                                    color: var(--link-color-main-base);
                                    font-family: var(--font-family);
                                    font-weight: var(--font-weight-semibold);
                                }

                                .jdxMYo {
                                    display: flex;
                                    flex-direction: column;
                                    background-color: var(--color-neutral-lighter);
                                    padding: 0 35px;
                                }

                                .bFNMKY {
                                    margin-top: var(--spacing-stack-xxs);
                                    margin-bottom: var(--spacing-stack-xxxs);
                                }

                                .lhJrCT {
                                    display: block;
                                }

                                .effUCd {
                                    margin: 0px;
                                    height: 1px;
                                    border: none;
                                    background-color: var(--divider-default-background-color);
                                }

                                .hnwyzW {
                                    max-width: 1140px;
                                    margin: auto;
                                }

                                @media (max-width: 1075px) .jmFVhT {
                                    margin: 24px,
                                    0;
                                    flex-direction: column;
                                }

                                @media (max-width: 1075px) .dnCYjr {
                                    flex-direction: column;
                                    row-gap: 16px;
                                }

                                .dnCYjr {
                                    display: flex;
                                    flex: 1 1 0%;
                                    -webkit-box-align: center;
                                    align-items: center;
                                    -webkit-box-pack: start;
                                    justify-content: flex-start;
                                    column-gap: var(--spacing-4);
                                }

                                .jnHZQQ {
                                    display: inline-flex;
                                    -webkit-box-pack: center;
                                    justify-content: center;
                                    -webkit-box-align: center;
                                    align-items: center;
                                    cursor: pointer;
                                    outline: none;
                                    text-decoration: none;
                                    font-size: 12px;
                                    line-height: 1.32;
                                    color: var(--link-color-grey-base);
                                    font-family: var(--font-family);
                                    font-weight: 600;
                                }

                                .lgjPoE {
                                    display: block;
                                    margin: 0px;
                                    padding: 0px;
                                    font-family: var(--font-family);
                                    word-break: break-word;
                                    font-weight: var(--font-weight-regular);
                                    line-height: var(--font-lineheight-distant);
                                    font-size: var(--font-size-xxs);
                                    font-style: normal;
                                    color: var(--color-neutral-130);
                                }

                                .jGCCic {
                                    display: flex;
                                    background-color: var(--color-neutral-80);
                                    margin-left: -1rem;
                                    margin-right: -1rem;
                                    padding-top: 32px;
                                    -webkit-box-pack: center;
                                    justify-content: center;
                                    align-content: stretch;
                                    flex-wrap: nowrap;
                                }

                                .container {
                                    display: flex;
                                    align-items: center;
                                }

                                .name {
                                    margin-right: 10px;
                                    /* Para adicionar algum espaço entre o texto e o ícone */
                                }

                                /* Opcional: alinhar o ícone na parte inferior do texto */
                                .icon {
                                    display: flex;
                                    align-items: flex-end;
                                }

                                .iymMhV {
                                    cursor: pointer;
                                    color: var(--color-secondary-medium);
                                    font-weight: var(--font-weight-semibold);
                                    font-size: var(--font-size-xxs);
                                    outline: none;
                                }

                                .gIpWoT {
                                    display: flex;
                                    flex-direction: column;
                                    margin-left: var(--spacing-1);
                                }

                                .dAHSDM {
                                    display: none;
                                }

                                .ixznNN {
                                    display: block;
                                    width: 100%;
                                }

                                .kuXcRK {
                                    display: flex;
                                    -webkit-box-pack: justify;
                                    justify-content: space-between;
                                }

                                .gIpWoT {
                                    display: flex;
                                    flex-direction: column;
                                    margin-left: var(--spacing-1);
                                }

                                .ebbvmy {
                                    display: block;
                                    margin: 0px;
                                    padding: 0px;
                                    font-style: normal;
                                    font-family: var(--font-family);
                                    word-break: break-word;
                                    font-weight: var(--font-weight-semibold);
                                    line-height: var(--font-lineheight-medium);
                                    font-size: var(--font-size-xxxs);
                                    color: var(--color-neutral-130);
                                }

                                .ilrSX {
                                    display: block;
                                    margin: 0px;
                                    padding: 0px;
                                    font-style: normal;
                                    font-family: var(--font-family);
                                    word-break: break-word;
                                    font-weight: var(--font-weight-regular);
                                    line-height: var(--font-lineheight-medium);
                                    font-size: var(--font-size-xxxs);
                                    color: var(--color-neutral-120);
                                }

                                .iQnFPq {
                                    display: flex;
                                    margin-left: var(--spacing-1);
                                }
                            </style>
                            <div class="ad__h3us20-6 uQFHC">
                                <div overflow="1" class="ad__hb5mou-0 jRULlV">
                                    <div class="ad__h3us20-3 lhJrCT">
                                        <div data-ds-component="DS-Flex" class="sc-kafWEX eEpVMR"><span data-ds-component="DS-Text" color="--color-neutral-130" display="block" class="sc-hSdWYo dReaFp">Baixe grátis o aplicativo!</span>
                                            <div data-ds-component="DS-Flex" class="sc-kafWEX iTyeOU"><a data-ds-component="DS-Link" href="https://itunes.apple.com/br/app/apple-store/id692808319?pt=839460&amp;ct=footer-mobile&amp;mt=8" target="_blank" class="sc-EHOje fVwWyK"><img src="files/baixar-na-app-store-botao-3.png" alt="App Store" class="ad__c9d34d-0 hPDVvz"></a><a data-ds-component="DS-Link" href="https://play.google.com/store/apps/details?id=com.schibsted.bomnegocio.androidApp&amp;hl=pt_BR&amp;utm_source=mobile&amp;utm_campaign=footer" target="_blank" class="sc-EHOje fVwWyK"><img src="files/google-play-badge.png" alt="Google Play" class="ad__c9d34d-0 hPDVvz"></a></div>
                                        </div>
                                        <div class="ad__hb5mou-1 bFNMKY">
                                            <div data-ds-component="DS-Flex" class="sc-kafWEX ad__chp44w-2 jdxMYo">
                                                <div class="ad__chp44w-5 dvdvVb">
                                                    <div data-ds-component="DS-Flex" class="sc-kafWEX ad__chp44w-3 iPVWvr"><span data-ds-component="DS-Text" color="--color-neutral-130" display="block" class="sc-hSdWYo gcOoiX">Pesquisas Populares</span></div>
                                                    <hr data-ds-component="DS-Divider" id="eledivider" class="sc-cMljjf iwsvIO">
                                                </div>
                                                <div data-ds-component="DS-Flex" class="sc-kafWEX cogkGm">
                                                    <div data-ds-component="DS-Flex" class="sc-kafWEX ad__chp44w-0 dwbQeO">
                                                        <div data-ds-component="DS-Flex" class="sc-kafWEX ad__chp44w-1 cAkiDV"><a data-ds-component="DS-Link" href="#" class="sc-EHOje fVwWyK"><span data-ds-component="DS-Text" class="ad__chp44w-4 ilAToR sc-hSdWYo cXLeHH" color="--color-neutral-130" display="block">Agro e indústria</span></a></div>
                                                        <div data-ds-component="DS-Flex" class="sc-kafWEX ad__chp44w-1 cAkiDV"><a data-ds-component="DS-Link" href="#" class="sc-EHOje fVwWyK"><span data-ds-component="DS-Text" class="ad__chp44w-4 ilAToR sc-hSdWYo cXLeHH" color="--color-neutral-130" display="block">Animais de estimação</span></a></div>
                                                        <div data-ds-component="DS-Flex" class="sc-kafWEX ad__chp44w-1 cAkiDV"><a data-ds-component="DS-Link" href="#" class="sc-EHOje fVwWyK"><span data-ds-component="DS-Text" class="ad__chp44w-4 ilAToR sc-hSdWYo cXLeHH" color="--color-neutral-130" display="block">Artigos infantis</span></a></div>
                                                        <div data-ds-component="DS-Flex" class="sc-kafWEX ad__chp44w-1 cAkiDV"><a data-ds-component="DS-Link" href="#" class="sc-EHOje fVwWyK"><span data-ds-component="DS-Text" class="ad__chp44w-4 ilAToR sc-hSdWYo cXLeHH" color="--color-neutral-130" display="block">Autos e peças</span></a></div>
                                                        <div data-ds-component="DS-Flex" class="sc-kafWEX ad__chp44w-1 cAkiDV"><a data-ds-component="DS-Link" href="#" class="sc-EHOje fVwWyK"><span data-ds-component="DS-Text" class="ad__chp44w-4 ilAToR sc-hSdWYo cXLeHH" color="--color-neutral-130" display="block">Comércio e escritório</span></a></div>
                                                        <div data-ds-component="DS-Flex" class="sc-kafWEX ad__chp44w-1 cAkiDV"><a data-ds-component="DS-Link" href="#" class="sc-EHOje fVwWyK"><span data-ds-component="DS-Text" class="ad__chp44w-4 ilAToR sc-hSdWYo cXLeHH" color="--color-neutral-130" display="block">Eletrônicos e celulares</span></a></div>
                                                        <div data-ds-component="DS-Flex" class="sc-kafWEX ad__chp44w-1 cAkiDV"><a data-ds-component="DS-Link" href="#" class="sc-EHOje fVwWyK"><span data-ds-component="DS-Text" class="ad__chp44w-4 ilAToR sc-hSdWYo cXLeHH" color="--color-neutral-130" display="block">Esportes e lazer</span></a></div>
                                                        <div data-ds-component="DS-Flex" class="sc-kafWEX ad__chp44w-1 cAkiDV"><a data-ds-component="DS-Link" href="#" class="sc-EHOje fVwWyK"><span data-ds-component="DS-Text" class="ad__chp44w-4 ilAToR sc-hSdWYo cXLeHH" color="--color-neutral-130" display="block">Imóveis</span></a></div>
                                                        <div data-ds-component="DS-Flex" class="sc-kafWEX ad__chp44w-1 cAkiDV"><a data-ds-component="DS-Link" href="#" class="sc-EHOje fVwWyK"><span data-ds-component="DS-Text" class="ad__chp44w-4 ilAToR sc-hSdWYo cXLeHH" color="--color-neutral-130" display="block">Moda e beleza</span></a></div>
                                                        <div data-ds-component="DS-Flex" class="sc-kafWEX ad__chp44w-1 cAkiDV"><a data-ds-component="DS-Link" href="#" class="sc-EHOje fVwWyK"><span data-ds-component="DS-Text" class="ad__chp44w-4 ilAToR sc-hSdWYo cXLeHH" color="--color-neutral-130" display="block">Música e hobbies</span></a></div>
                                                        <div data-ds-component="DS-Flex" class="sc-kafWEX ad__chp44w-1 cAkiDV"><a data-ds-component="DS-Link" href="#" class="sc-EHOje fVwWyK"><span data-ds-component="DS-Text" class="ad__chp44w-4 ilAToR sc-hSdWYo cXLeHH" color="--color-neutral-130" display="block">Para a sua casa</span></a></div>
                                                        <div data-ds-component="DS-Flex" class="sc-kafWEX ad__chp44w-1 cAkiDV"><a data-ds-component="DS-Link" href="#" class="sc-EHOje fVwWyK"><span data-ds-component="DS-Text" class="ad__chp44w-4 ilAToR sc-hSdWYo cXLeHH" color="--color-neutral-130" display="block">Serviços</span></a></div>
                                                        <div data-ds-component="DS-Flex" class="sc-kafWEX ad__chp44w-1 cAkiDV"><a data-ds-component="DS-Link" href="#" class="sc-EHOje fVwWyK"><span data-ds-component="DS-Text" class="ad__chp44w-4 ilAToR sc-hSdWYo cXLeHH" color="--color-neutral-130" display="block">Vagas de emprego</span></a></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <footer id="footer" data-ds-component="DS-Footer" class="sc-eLdqWK jrNxLO" style="margin: auto;">
                                        <hr data-ds-component="DS-Divider" class="sc-jAaTju effUCd">
                                        <div class="sc-iiUIRa hnwyzW">
                                            <div class="sc-hgRTRy jmFVhT">
                                                <nav aria-label="Links comuns" class="sc-gldTML dnCYjr"><a data-ds-component="DS-Link" href="https://ajuda.olx.com.br/s" class="sc-bZQynM jnHZQQ" style="text-decoration: none;" target="_blank">
                                                        <span data-ds-component="DS-Text" color="--color-neutral-130" display="block" class="sc-ifAKCX lgjPoE">Ajuda e contato</span>
                                                    </a><a data-ds-component="DS-Link" href="#" target="_blank" class="sc-ifAKCX lgjPoE" style="text-decoration: none; color: var(--color-neutral-130); display: block;">
                                                        Dicas de segurança
                                                    </a>
                                                    <a data-ds-component="DS-Link" href="#" target="_blank" class="sc-bZQynM jnHZQQ" style="text-decoration: none; color: var(--color-neutral-130); display: block;">
                                                        <span data-ds-component="DS-Text" class="sc-ifAKCX lgjPoE">Vender na OLX</span>
                                                    </a>
                                                    <a data-ds-component="DS-Link" href="#" target="_blank" class="sc-bZQynM jnHZQQ" style="text-decoration: none; color: var(--color-neutral-130); display: block;">
                                                        <span data-ds-component="DS-Text" class="sc-ifAKCX lgjPoE">Plano Profissional</span>
                                                    </a>
                                                    <a data-ds-component="DS-Link" href="#" target="_blank" class="sc-bZQynM jnHZQQ" style="text-decoration: none; color: var(--color-neutral-130); display: block;">
                                                        <span data-ds-component="DS-Text" class="sc-ifAKCX lgjPoE">Mapa do site</span>
                                                    </a>
                                                </nav>
                                                <nav aria-label="Mídias sociais" class="sc-feryYK iJlLnv"><a data-ds-component="DS-Link" href="https://www.facebook.com/olxbrasil" aria-label="Facebook" class="sc-elNKlv sc-bYwvMP kuPRsh sc-bZQynM jnHZQQ"><span aria-hidden="true" class="sc-jKmXuR fKHYVG"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" color="currentColor" size="24">
                                                                <path fill="currentColor" fill-rule="evenodd" d="M9.216 22.91V12.452H7V8.85h2.216V6.688C9.216 3.748 10.466 2 14.02 2h2.959v3.604h-1.85c-1.383 0-1.475.504-1.475 1.443L13.65 8.85H17l-.392 3.603h-2.959V22.91H9.216z"></path>
                                                            </svg></span></a><a data-ds-component="DS-Link" href="https://www.youtube.com/user/OLXBrasil" aria-label="YouTube" class="sc-elNKlv sc-hUMlYv bttLbO sc-bZQynM jnHZQQ"><span aria-hidden="true" class="sc-jKmXuR fKHYVG"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" color="currentColor" size="24">
                                                                <path fill="currentColor" fill-rule="evenodd" d="M21.182 15.604c0 3.123-3.133 3.123-3.133 3.123H6.132C3 18.727 3 15.604 3 15.604v-6.48C3 6 6.132 6 6.132 6H18.05c3.133 0 3.133 3.123 3.133 3.123v6.48zm-5.561-3.231L9.669 8.887v6.97l5.952-3.484z"></path>
                                                            </svg></span></a><a data-ds-component="DS-Link" href="https://www.linkedin.com/company/olx-brasil" aria-label="LinkedIn" class="sc-elNKlv sc-ESoVU eSaKqR sc-bZQynM jnHZQQ"><span aria-hidden="true" class="sc-jKmXuR fKHYVG"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" color="currentColor" size="24">
                                                                <path fill="currentColor" fill-rule="evenodd" d="M3.459 8.83h3.543v12.35H3.46V8.83zM5.14 7.285h-.025C3.832 7.285 3 6.341 3 5.145 3 3.926 3.856 3 5.165 3c1.307 0 2.111.923 2.137 2.142 0 1.196-.83 2.143-2.162 2.143zm16.042 13.897h-4.019v-6.393c0-1.672-.628-2.813-2.01-2.813-1.058 0-1.646.77-1.92 1.513-.102.265-.086.637-.086 1.01v6.683h-3.98s.05-11.323 0-12.352h3.98v1.938c.235-.847 1.507-2.057 3.537-2.057 2.52 0 4.498 1.778 4.498 5.602v6.869z"></path>
                                                            </svg></span></a><a data-ds-component="DS-Link" href="https://instagram.com/olxbr" aria-label="Instagram" class="sc-elNKlv sc-kkbgRg YPcue sc-bZQynM jnHZQQ"><span aria-hidden="true" class="sc-jKmXuR fKHYVG"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" color="currentColor" size="24">
                                                                <path fill="currentColor" fill-rule="evenodd" d="M12 2c2.716 0 3.056.012 4.123.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 011.772 1.153 4.902 4.902 0 011.153 1.772c.247.636.416 1.363.465 2.427.048 1.067.06 1.407.06 4.123s-.012 3.056-.06 4.123c-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.153 1.772 4.902 4.902 0 01-1.772 1.153c-.636.247-1.363.416-2.427.465-1.067.049-1.407.06-4.123.06s-3.056-.011-4.123-.06c-1.064-.049-1.791-.218-2.427-.465a4.902 4.902 0 01-1.772-1.153 4.902 4.902 0 01-1.153-1.772c-.247-.636-.416-1.363-.465-2.427C2.011 15.056 2 14.716 2 12s.011-3.056.06-4.123c.049-1.064.218-1.791.465-2.427a4.902 4.902 0 011.153-1.772A4.902 4.902 0 015.45 2.525c.636-.247 1.363-.416 2.427-.465C8.944 2.012 9.284 2 12 2zm0 1.802c-2.67 0-2.986.01-4.04.058-.976.045-1.505.208-1.858.344-.466.182-.8.399-1.15.748-.35.35-.566.684-.748 1.15-.137.353-.3.882-.344 1.857-.048 1.055-.058 1.37-.058 4.041 0 2.67.01 2.986.058 4.04.045.976.207 1.505.344 1.858.182.466.399.8.748 1.15.35.35.684.566 1.15.748.353.137.882.3 1.857.344 1.054.048 1.37.058 4.041.058 2.67 0 2.987-.01 4.04-.058.976-.045 1.505-.207 1.858-.344.466-.182.8-.399 1.15-.748.35-.35.566-.684.748-1.15.136-.353.3-.882.344-1.857.048-1.055.058-1.37.058-4.041 0-2.67-.01-2.986-.058-4.04-.045-.976-.208-1.505-.344-1.858a3.098 3.098 0 00-.748-1.15 3.099 3.099 0 00-1.15-.748c-.353-.136-.882-.3-1.857-.344-1.055-.048-1.37-.058-4.041-.058zm.02 3.079a5.139 5.139 0 110 10.278 5.139 5.139 0 010-10.278zm0 8.475a3.336 3.336 0 100-6.672 3.336 3.336 0 000 6.672zm6.488-8.713a1.19 1.19 0 11-2.381 0 1.19 1.19 0 012.38 0z"></path>
                                                            </svg></span></a><a data-ds-component="DS-Link" href="https://twitter.com/olx_Brasil" aria-label="Twitter" class="sc-elNKlv sc-hRmvpr iVEeUd sc-bZQynM jnHZQQ"><span aria-hidden="true" class="sc-jKmXuR fKHYVG"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" color="currentColor" size="24">
                                                                <path fill="currentColor" fill-rule="evenodd" d="M18.842 6.587a4.1 4.1 0 001.721-2.284 7.596 7.596 0 01-2.488 1.002A3.813 3.813 0 0015.217 4c-2.163 0-3.915 1.85-3.915 4.13 0 .324.032.64.1.941-3.255-.172-6.14-1.815-8.073-4.316a4.294 4.294 0 00-.53 2.078c0 1.432.691 2.697 1.742 3.439a3.777 3.777 0 01-1.775-.516v.05c0 2.002 1.35 3.672 3.144 4.05-.33.097-.675.146-1.034.146-.252 0-.498-.025-.736-.073.498 1.64 1.944 2.836 3.659 2.868A7.604 7.604 0 012 18.508a10.68 10.68 0 006.004 1.856c7.205 0 11.143-6.295 11.143-11.754 0-.18-.002-.358-.01-.534a8.187 8.187 0 001.954-2.139 7.507 7.507 0 01-2.249.65z"></path>
                                                            </svg></span></a></nav>
                                            </div>
                                            <hr data-ds-component="DS-Divider" class="sc-jAaTju effUCd">
                                            <div class="sc-iIHSe dUaBHR">
                                                <nav aria-label="Links Jurídicos" class="sc-cJOK gNKPOC"><span data-ds-component="DS-Text" color="--color-neutral-130" display="block" class="sc-ifAKCX lgjPoE"><a data-ds-component="DS-Link" href="https://portal.olx.com.br/" class="sc-bZQynM jnHZQQ">Sobre a OLX</a>,&nbsp;<a data-ds-component="DS-Link" href="https://www.olx.com.br/copyright.htm" class="sc-bZQynM jnHZQQ">Termos de uso</a>,&nbsp;<a data-ds-component="DS-Link" href="https://ajuda.olx.com.br/s/article/politica-de-privacidade" class="sc-bZQynM jnHZQQ">Política de privacidade</a>, e <a data-ds-component="DS-Link" href="#" class="sc-bZQynM jnHZQQ">Proteção à Propriedade Intelectual</a></span></nav>
                                                <address class="sc-ccSCjj deOajc"><span data-ds-component="DS-Text" color="--color-neutral-130" display="block" class="sc-ifAKCX lgjPoE">© Bom Negócio Atividades de Internet Ltda. Rua do Catete, 359, Flamengo - 22220-001 - Rio de Janeiro, RJ</span></address>
                                            </div>
                                        </div>
                                    </footer>
                                </div>
                            </div>

                            <div class="ad__h3us20-6 kdswBR">
                                <div class="ad__h3us20-4 cxrGoW">
                                    <div>
                                        <div class="ad__h3us20-3 lhJrCT">
                                            <h2 data-ds-component="DS-Text" data-testid="ad-seller" color="--color-neutral-130" display="block" class="sc-hSdWYo davdrV">Anunciante</h2>
                                            <div class="ad__h3us20-5 dpgDGU"></div>
                                        </div>
                                        <div data-section="miniprofile" class="ad__sc-1ut0abb-0 gxGXJC" height="237">
                                            <div id="miniprofile" class="ad__sc-1ut0abb-1 cscsTy" width="368">
                                                <div>
                                                    <div>
                                                        <div class="sc-gMcBNU sc-ldcLGC dtNsyG sc-aewfc lehJrf"></div>
                                                        <div class="sc-hfLElm iPLBto" color="#f9f9f9" bordercolor="#d8d8d8">
                                                            <div></div>
                                                            <div class="sc-eLpfTy zdamc sc-aewfc lehJrf">
                                                                <div style="position: relative; width: 100%; display: flex; flex-direction: column-reverse;">
                                                                    <div tabindex="0" style="outline: none; display: flex; justify-content: center;">
                                                                        <div class="container">
                                                                            <span class="name">
                                                                                <strong><?php echo $dados['nome_anunciante']; ?> </strong>
                                                                            </span>
                                                                            <div class="icon">
                                                                                <svg class="profile-verified-icon" xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" viewBox="0 0 13 13">
                                                                                    <path fill="#10CE64" fill-rule="evenodd" d="M6.5 13a6.5 6.5 0 100-13 6.5 6.5 0 000 13z" clip-rule="evenodd"></path>
                                                                                    <path fill="#fff" fill-rule="evenodd" stroke="#fff" d="M4.362 6.43a.213.213 0 00-.303 0 .216.216 0 000 .304L5.487 8.17c.084.084.22.084.303 0l3.143-3.16a.216.216 0 000-.304.213.213 0 00-.303 0L5.64 7.713 4.362 6.43z" clip-rule="evenodd"></path>
                                                                                </svg>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div style="width: 100%; display: none;">
                                                                        <div class="sc-kGYfcE eVivoj sc-aewfc lehJrf">
                                                                            <div class="sc-dgAbBl kREdWl sc-aewfc lehJrf"></div><span class="sc-hPZeXZ hjzcaS sc-iHhHRJ fJeHbn" color="dark" font-weight="400">Usuário real e verificado pela OLX</span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div></div>
<?php
// Supondo que a data esteja no formato 'Y-m-d' (ex: '2014-02-15')
$dataBanco = $dados['data_anunciante']; // Pegue a data do banco de dados

// Cria um objeto DateTime a partir da data do banco de dados
$data = new DateTime($dataBanco);

// Formata a data para exibir o mês e o ano
$mesAno = $data->format('F \d\e Y'); // Exemplo: 'February de 2014'

// Traduz o mês para o português
$meses = [
    'January' => 'janeiro',
    'February' => 'fevereiro',
    'March' => 'março',
    'April' => 'abril',
    'May' => 'maio',
    'June' => 'junho',
    'July' => 'julho',
    'August' => 'agosto',
    'September' => 'setembro',
    'October' => 'outubro',
    'November' => 'novembro',
    'December' => 'dezembro'
];

$mes = $data->format('F');
$mesPortugues = $meses[$mes];

echo '<div class="sc-bpKEQf bTGRVC sc-aewfc lehJrf"></div><span class="djuouJ" color="dark" font-weight="400">Na OLX desde ' . $mesPortugues . ' de ' . $data->format('Y') . '</span></div>';
?>

                                                            <div class="sc-fPCuyW dxYbgB sc-aewfc lehJrf"><span class="sc-dAWfgX eIyThw sc-iHhHRJ fJeHbn" color="dark" font-weight="400">Verificado com:</span>
                                                                <div title="Telefone verificado" class="sc-dpiBDp cQYZgc sc-aewfc lehJrf"><span style="width: 24px; height: 24px; position: relative; display: inline-block;"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                                                            <g fill="none" fill-rule="evenodd">
                                                                                <circle cx="12" cy="12" r="12" fill="#10CE64"></circle>
                                                                                <path fill="#FFF" d="M15.848 17.869c-1.598.381-3.196-.191-3.196-.191-1.598-1.145-2.632-2.481-3.196-3.435l-.094-.096-.094-.095c-.564-.954-1.598-2.48-2.068-4.485 0 0 .188-1.717 1.128-3.053 1.128-.859 1.692-.382 1.692-.382l1.504 2.195a.627.627 0 0 1-.188.859l-1.034.668s-.94.286.846 3.053c1.786 2.672 2.256 1.813 2.256 1.813l1.034-.668c.282-.19.658-.095.846.19l1.504 2.196c0-.096.188.667-.94 1.43z"></path>
                                                                            </g>
                                                                        </svg></span></div>
                                                                <div title="E-mail verificado" class="sc-csZoYU ihkrEK sc-aewfc lehJrf"><span style="width: 24px; height: 24px; position: relative; display: inline-block;"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                                                            <g fill="none" fill-rule="evenodd">
                                                                                <circle cx="12" cy="12" r="12" fill="#10CE64"></circle>
                                                                                <path fill="#FFF" fill-rule="nonzero" d="M6.9 7.2a.845.845 0 0 0-.333.07l5.09 4.791c.22.207.455.207.676 0l5.1-4.79A.845.845 0 0 0 17.1 7.2H6.9zm-.89.833c-.006.044-.01.09-.01.136v6.462c0 .537.401.969.9.969h10.2c.499 0 .9-.432.9-.97V8.17c0-.047-.004-.093-.01-.137l-5.067 4.76a1.342 1.342 0 0 1-1.856 0L6.01 8.033z"></path>
                                                                            </g>
                                                                        </svg></span></div>
                                                                <div title="Facebook não verificado" class="sc-ctwKVn iGGLrM sc-aewfc lehJrf"><span style="width: 24px; height: 24px; position: relative; display: inline-block;"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                                                            <g fill="none" fill-rule="evenodd">
                                                                                <circle cx="12" cy="12" r="12" fill="#E5E5E5"></circle>
                                                                                <path fill="#FFF" fill-rule="nonzero" d="M13.486 18v-5.466h1.778l.266-2.14h-2.044V9.032c0-.62.167-1.038 1.022-1.038H15.6V6.083A14.543 14.543 0 0 0 14.015 6c-1.571 0-2.642.994-2.642 2.82v1.574H9.6v2.14h1.773V18h2.113z"></path>
                                                                            </g>
                                                                        </svg></span></div>
                                                            </div>
                                                            <div class="sc-bECiaU dozYtX sc-aewfc lehJrf">
                                                                <div class="sc-sVRsr iKTsQ sc-aewfc lehJrf"><span class="inSmub" color="dark" font-weight="400">Último acesso há <?php echo $dados['ultimo_anunciante']; ?></span></div>
                                                            </div>
                                                            <div class="sc-hfsWMF ivRuca sc-aewfc lehJrf">
                                                                <div class="sc-juQqkt hgIHch sc-aewfc lehJrf"><svg width="16" height="16" viewBox="0 0 16 16" class="sc-bkCOcH gdnQCF">
                                                                        <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                                            <g id="layers" transform="translate(1.000000, 1.000000)" fill="#4A4A4A" fill-rule="nonzero">
                                                                                <path d="M6.7763932,-0.447213595 C6.91715695,-0.517595468 7.08284305,-0.517595468 7.2236068,-0.447213595 L14.2236068,3.0527864 C14.5921311,3.23704854 14.5921311,3.76295146 14.2236068,3.9472136 L7.2236068,7.4472136 C7.08284305,7.51759547 6.91715695,7.51759547 6.7763932,7.4472136 L-0.223606798,3.9472136 C-0.592131067,3.76295146 -0.592131067,3.23704854 -0.223606798,3.0527864 L6.7763932,-0.447213595 Z M7,0.559016994 L1.11803399,3.5 L7,6.44098301 L12.881966,3.5 L7,0.559016994 Z" id="Path"></path>
                                                                                <path d="M13.7763932,10.0527864 C14.0233825,9.92929178 14.323719,10.029404 14.4472136,10.2763932 C14.5707082,10.5233825 14.470596,10.823719 14.2236068,10.9472136 L7.2236068,14.4472136 C7.08284305,14.5175955 6.91715695,14.5175955 6.7763932,14.4472136 L-0.223606798,10.9472136 C-0.470596046,10.823719 -0.57070822,10.5233825 -0.447213595,10.2763932 C-0.323718971,10.029404 -0.023382451,9.92929178 0.223606798,10.0527864 L7,13.440983 L13.7763932,10.0527864 Z" id="Path"></path>
                                                                                <path d="M7,9.94098301 L13.7763932,6.5527864 C14.0233825,6.42929178 14.323719,6.52940395 14.4472136,6.7763932 C14.5707082,7.02338245 14.470596,7.32371897 14.2236068,7.4472136 L7.2236068,10.9472136 C7.08284305,11.0175955 6.91715695,11.0175955 6.7763932,10.9472136 L-0.223606798,7.4472136 C-0.470596046,7.32371897 -0.57070822,7.02338245 -0.447213595,6.7763932 C-0.323718971,6.52940395 -0.023382451,6.42929178 0.223606798,6.5527864 L7,9.94098301 Z" id="Path"></path>
                                                                            </g>
                                                                        </g>
                                                                    </svg>
                                                                    <div>
                                                                        <div role="presentation" class="sc-ekQYnd lgiMsT"><a data-ds-component="DS-Link" href="#" target="_blank" class="sc-bZQynM yNjKg">Ver todos os anúncios</a></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div id="mercurie-app" class="sc-aewfc lehJrf">
                                                                <div class="sc-jTzLTM iwtnNi styles__Content-sc-tdweo5-0 ghSyPD"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="ad__h3us20-6 dDFqHg">
                                <div class="ad__h3us20-4 cxrGoW">
                                    <div></div>
                                </div>
                            </div>
                            <div class="ad__h3us20-6 gbMdeQ">
                                <div from="lg" class="ad__h3us20-4 hqjcIS">
                                    <div>
                                        <div class="sc-gxMtzJ iGgTDm">
                                            <div class="sc-dfVpRl kAWE">
                                                <span data-ds-component="DS-Text" class="sc-gzOgki ehNPHd sc-hSdWYo gwYTWo" color="--color-neutral-130" display="block">Formas de pagamento</span>
                                            </div>
                                            <div class="sc-iyvyFf iYdLJP">
                                                <div class="sc-kPVwWT bLpKIE"><svg width="33" height="33" viewBox="0 0 32 33" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M31.5 16.5C31.5 25.0604 24.5604 32 16 32C7.43959 32 0.5 25.0604 0.5 16.5C0.5 7.93959 7.43959 1 16 1C24.5604 1 31.5 7.93959 31.5 16.5Z" fill="white" stroke="#D2D2D2"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M11.7194 12.251C12.3471 12.251 12.9374 12.4955 13.3813 12.9391L15.7897 15.3481C15.9632 15.5215 16.2464 15.5222 16.4204 15.3478L18.82 12.9479C19.2639 12.5043 19.8542 12.2598 20.482 12.2598H20.771L17.723 9.21192C16.7738 8.26269 15.2349 8.26269 14.2857 9.21192L11.2466 12.251H11.7194ZM20.4822 20.7402C19.8543 20.7402 19.2641 20.4957 18.8202 20.052L16.4205 17.6524C16.252 17.4834 15.9584 17.4839 15.79 17.6524L13.3814 20.0608C12.9375 20.5045 12.3472 20.7488 11.7195 20.7488H11.2466L14.2858 23.7882C15.2351 24.7373 16.774 24.7373 17.7231 23.7882L20.7712 20.7402H20.4822ZM21.4455 12.9403L23.2873 14.7822C24.2365 15.7313 24.2365 17.2703 23.2873 18.2195L21.4455 20.0613C21.4048 20.0451 21.3611 20.035 21.3146 20.035H20.4773C20.0442 20.035 19.6205 19.8595 19.3145 19.5532L16.9149 17.1538C16.4799 16.7184 15.7212 16.7185 15.2858 17.1535L12.8774 19.5621C12.5713 19.8681 12.1476 20.0437 11.7146 20.0437H10.6849C10.641 20.0437 10.5998 20.0541 10.5611 20.0687L8.71192 18.2195C7.76269 17.2703 7.76269 15.7313 8.71192 14.7822L10.5612 12.9329C10.5999 12.9475 10.641 12.958 10.6849 12.958H11.7146C12.1476 12.958 12.5713 13.1335 12.8774 13.4396L15.2861 15.8483C15.5105 16.0726 15.8053 16.185 16.1004 16.185C16.3952 16.185 16.6903 16.0726 16.9147 15.8481L19.3145 13.4484C19.6205 13.1422 20.0442 12.9666 20.4773 12.9666H21.3146C21.3609 12.9666 21.4048 12.9566 21.4455 12.9403Z" fill="#32BCAD"></path>
                                                    </svg></div>
                                                <div class="sc-kPVwWT bLpKIE"><svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" width="32" height="32" size="32" color="currentColor">
                                                        <path d="M16 32c8.837 0 16-7.163 16-16S24.837 0 16 0 0 7.163 0 16s7.163 16 16 16z" fill="#0054A4"></path>
                                                        <mask id="Visa_svg__a" maskUnits="userSpaceOnUse" x="0" y="0" width="32" height="32">
                                                            <path d="M16 32c8.837 0 16-7.163 16-16S24.837 0 16 0 0 7.163 0 16s7.163 16 16 16z" fill="#fff"></path>
                                                        </mask>
                                                        <g mask="url(#Visa_svg__a)" fill-rule="evenodd" clip-rule="evenodd">
                                                            <path d="M12.203 19.427l1.18-7.3h1.884l-1.179 7.3h-1.885zM20.925 12.306A4.67 4.67 0 0019.238 12c-1.864 0-3.176.99-3.187 2.41-.012 1.049.936 1.634 1.651 1.982.735.358.981.587.978.906-.005.49-.586.713-1.128.713-.754 0-1.155-.11-1.775-.383l-.243-.116-.263 1.634c.439.204 1.254.38 2.1.39 1.98 0 3.267-.98 3.282-2.494.007-.832-.495-1.463-1.583-1.984-.659-.338-1.063-.562-1.058-.905 0-.303.341-.628 1.08-.628a3.315 3.315 0 011.41.28l.17.084.255-1.583zM23.435 16.84c.157-.42.751-2.041.751-2.041-.01.019.156-.423.25-.697l.128.63s.362 1.742.436 2.107h-1.565zm2.326-4.706h-1.457c-.452 0-.79.13-.988.606l-2.8 6.69h1.98s.323-.9.397-1.098l2.414.004c.057.255.23 1.094.23 1.094h1.75l-1.526-7.296zM10.622 12.133L8.777 17.11 8.58 16.1c-.344-1.166-1.414-2.43-2.611-3.063l1.687 6.385 1.995-.001 2.968-7.287h-1.997z" fill="#fff"></path>
                                                            <path d="M7.065 12.128h-3.04L4 12.28c2.365.604 3.93 2.064 4.58 3.818l-.66-3.354c-.115-.462-.446-.6-.855-.616z" fill="#F39C12"></path>
                                                        </g>
                                                    </svg></div>
                                                <div class="sc-kPVwWT bLpKIE"><svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" width="32" height="32" size="32" color="currentColor">
                                                        <path d="M16 32c8.837 0 16-7.163 16-16S24.837 0 16 0 0 7.163 0 16s7.163 16 16 16z" fill="#34495E"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M19.414 16.163a6.417 6.417 0 11-12.833 0 6.417 6.417 0 0112.833 0z" fill="#E74C3C"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M27.036 16.163a6.417 6.417 0 11-12.834 0 6.417 6.417 0 0112.834 0z" fill="#F1C40F"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M14.202 16.163a6.4 6.4 0 002.106 4.753 6.4 6.4 0 002.106-4.753 6.4 6.4 0 00-2.106-4.754 6.4 6.4 0 00-2.106 4.754z" fill="#F39C12"></path>
                                                    </svg></div>
                                                <div class="sc-kPVwWT bLpKIE"><svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" width="32" height="32" size="32" color="currentColor">
                                                        <path d="M16 32c8.837 0 16-7.163 16-16S24.837 0 16 0 0 7.163 0 16s7.163 16 16 16z" fill="#0F0F12"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M16.232 6c5.642 0 10.215 4.574 10.215 10.215 0 5.642-4.573 10.216-10.215 10.216-5.642 0-10.215-4.574-10.215-10.216C6.017 10.574 10.59 6 16.232 6z" fill="#0F0F12"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M13.19 15.43l-3.136 1.35a1.796 1.796 0 013.136-1.351zm-1.347-1.953a3.14 3.14 0 013.052 2.402l-1.266.554v-.003l-1.294.569-3.106 1.358a3.14 3.14 0 012.613-4.879zM14.036 18.863c-1.124 1.066-2.61 1.171-3.917.378l.738-1.123c.744.445 1.49.373 2.24-.216l.94.96zM15.315 18.085l-.008-5.936h1.124v5.776c0 .056.007.104.08.133l.978.38-.44 1.146-1.147-.485c-.434-.183-.587-.45-.587-1.014z" fill="#FFFFFE"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M19.55 17.986a1.788 1.788 0 01-.135-2.714l-.726-1.178a3.155 3.155 0 00.175 5.082l.685-1.19z" fill="#2191C3"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M20.042 14.885a1.792 1.792 0 012.283 1.055l1.392-.117a3.16 3.16 0 00-4.256-2.18l.581 1.242z" fill="#FAEC32"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M22.438 16.658a1.792 1.792 0 01-2.226 1.65l-.546 1.265a3.158 3.158 0 004.138-2.872l-1.366-.043z" fill="#D0362B"></path>
                                                    </svg></div>
                                                <div class="sc-kPVwWT bLpKIE"><svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" width="32" height="32" size="32" color="currentColor">
                                                        <path d="M16 32c8.837 0 16-7.163 16-16S24.837 0 16 0 0 7.163 0 16s7.163 16 16 16z" fill="#B10E0C"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M21.999 17.12c-.353.347-1.342.446-1.241-.382.084-.688.83-.834 1.639-.735-.06.376-.13.854-.398 1.118zm-1.114-2.683c-.033.19-.085.362-.127.543.404-.101 1.661-.413 1.782.128.04.18-.029.37-.08.511-1.136-.108-2.063.082-2.307.894-.163.545.019 1.08.366 1.23.67.288 1.485-.042 1.767-.495a2.09 2.09 0 00-.048.51h.589c.006-.565.088-1.023.175-1.532.074-.434.213-.863.19-1.246-.05-.876-1.497-.566-2.307-.543zm5.903 2.954c-.46.01-.69-.276-.7-.75-.018-.831.345-1.754 1.082-1.837.343-.038.592.042.844.128-.231.933-.148 2.436-1.226 2.46zM28.316 13a15.365 15.365 0 01-.239 1.485c-1.678-.533-2.708.706-2.69 2.236.005.296.055.589.24.798.317.36 1.227.447 1.686.144.09-.059.18-.166.239-.24.044-.055.115-.201.127-.16-.024.163-.06.313-.063.496h.62c.12-1.722.49-3.193.764-4.759h-.684zm-17.52 4.136c-.365.389-1.265.383-1.336-.272-.03-.285.075-.583.128-.878.052-.298.09-.584.143-.846.36-.442 1.42-.495 1.527.24.094.637-.158 1.434-.461 1.756zm.542-2.698c-.58-.218-1.285.042-1.591.29 0 .011-.008.013-.017.014l.017-.014v-.002c.005-.107.042-.181.047-.288h-.589c-.245 1.638-.536 3.23-.843 4.807h.684c.1-.614.165-1.262.303-1.837.156.605 1.176.49 1.607.256.888-.482 1.573-2.777.382-3.226zm3.246 1.15h-1.607a.95.95 0 01.907-.799c.493-.019.846.182.7.799zm-.653-1.215c-.494.038-.912.181-1.209.495-.364.385-.66 1.237-.573 2.012.124 1.107 1.496 1.067 2.594.799.019-.194.065-.36.095-.543-.452.17-1.237.407-1.702.112-.351-.223-.353-.788-.239-1.278.738-.024 1.505-.019 2.244 0 .047-.348.18-.727.063-1.07-.155-.453-.709-.57-1.273-.527zm-6.015.066c-.018.003-.017.025-.016.048a47.269 47.269 0 01-.573 3.273h.685c.164-1.139.352-2.254.588-3.321h-.684zm17.854.014c-.604-.303-1.108.206-1.305.511.056-.157.06-.366.112-.527h-.605a49.488 49.488 0 01-.589 3.322h.7c.005-.44.091-.766.16-1.198.146-.922.36-1.933 1.432-1.629.035-.156.05-.333.095-.479zm-7.685 2.524c-.063-.163-.08-.433-.064-.639.036-.46.203-1.023.462-1.277.357-.35 1.06-.293 1.623-.096.017-.19.055-.36.08-.543-.922-.15-1.797-.057-2.26.431-.454.478-.752 1.577-.541 2.268.246.809 1.35.853 2.243.543.04-.163.06-.344.096-.511-.489.255-1.422.387-1.64-.176zm-.382-2.54c-.607-.246-1.084.17-1.305.559.05-.173.071-.376.112-.559h-.605c-.148 1.15-.366 2.23-.573 3.322h.684c.096-.648.138-1.52.35-2.14.17-.495.616-.917 1.258-.687.009-.183.06-.322.08-.495zm-11.027-1.34c-.098.636-.208 1.26-.319 1.884-.708.008-1.432.035-2.116-.016.13-.61.222-1.257.35-1.868h-.764c-.273 1.556-.522 3.138-.827 4.663h.78c.122-.783.236-1.573.397-2.316.665-.016 1.462-.045 2.1.016-.13.773-.29 1.518-.413 2.3h.78c.25-1.58.514-3.146.827-4.663h-.795zm1.94.702c.137-.095.313-.524.112-.703-.063-.057-.17-.073-.318-.048-.138.023-.217.07-.27.144-.087.118-.166.474-.032.607.13.128.422.06.509 0z" fill="#FFFFFE"></path>
                                                    </svg></div>
                                                <div class="sc-kPVwWT bLpKIE"><svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" width="32" height="32" size="32" color="currentColor">
                                                        <path d="M16 32c8.837 0 16-7.163 16-16S24.837 0 16 0 0 7.163 0 16s7.163 16 16 16z" fill="#3473DB"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M6.878 15.975c-.057.143.023.26.177.26h.723c.155 0 .235-.117.178-.26l-.432-1.098c-.057-.144-.15-.144-.207 0l-.439 1.098z" fill="#fff"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M22.673 15.292c0-.154.073-.177.161-.05l.087.123a.448.448 0 01.008.465l-.102.156c-.085.129-.154.108-.154-.046v-.648zm3.71 3.19a.569.569 0 01-.432-.238l-.796-1.26c-.082-.13-.218-.131-.3 0l-.804 1.26a.571.571 0 01-.432.237H17.761a.282.282 0 01-.281-.28v-5.193c0-.155.126-.281.28-.281h4.07c.155 0 .282.126.282.28v.843c0 .154-.127.28-.281.28h-2.526a.282.282 0 00-.281.281v.28c0 .155.126.281.28.281h2.246c.155 0 .28.127.28.281v.702c0 .154-.125.28-.28.28h-2.245a.282.282 0 00-.281.281v.421c0 .155.126.281.28.281h2.527c.154 0 .28.126.28.28v.712c0 .154.071.176.157.048l1.65-2.459a.458.458 0 00.001-.467l-1.566-2.371c-.085-.129-.028-.234.126-.234h1.263c.155 0 .348.107.43.238l.709 1.136c.081.13.216.131.3.001l.728-1.139a.573.573 0 01.432-.236h1.223c.154 0 .21.105.124.233l-1.57 2.337a.455.455 0 000 .467l1.653 2.484c.085.128.029.233-.125.233h-1.264zm-9.464-.281c0 .154-.127.28-.281.28h-1.123a.282.282 0 01-.28-.28v-2.707c0-.154-.067-.173-.148-.041l-1.112 1.807a1.623 1.623 0 01-.164.239c-.009 0-.086-.106-.171-.234l-1.198-1.81c-.085-.128-.155-.107-.155.047v2.699c0 .154-.126.28-.28.28h-.983a.282.282 0 01-.28-.28v-5.193c0-.155.125-.281.28-.281h1.156a.56.56 0 01.428.239l1.072 1.74c.081.13.214.13.295 0l1.072-1.74a.56.56 0 01.428-.24h1.163c.154 0 .28.127.28.282V18.2zm-7.704.28a.457.457 0 01-.388-.259l-.194-.464a.457.457 0 00-.388-.26H6.588a.456.456 0 00-.388.26l-.193.464a.457.457 0 01-.39.26H4.519c-.154 0-.231-.117-.171-.26l2.212-5.237a.46.46 0 01.39-.258h.968a.46.46 0 01.39.258l2.22 5.238c.06.142-.017.258-.171.258h-1.14zm19.568-.224l-.313-.466-1.337-1.996a.455.455 0 010-.466l1.254-1.877.31-.467.576-.866c.085-.13.029-.234-.126-.234H25.83a.464.464 0 00-.355.206 44.43 44.43 0 01-.273.444l-.015.026c-.082.13-.214.13-.294-.003l-.011-.018-.268-.448a.466.466 0 00-.358-.207H14.96c-.13 0-.29.095-.358.212-.068.117-.19.32-.27.452l-.357.587c-.08.132-.212.131-.292 0l-.359-.593c-.08-.132-.2-.334-.268-.45a.465.465 0 00-.359-.208H10.182a.282.282 0 00-.281.28v2.25c0 .154-.048.164-.107.021l-.733-1.774a23.34 23.34 0 01-.206-.518.436.436 0 00-.378-.26H6.39a.457.457 0 00-.389.26l-.217.518-2.212 5.243-.22.517-.272.643c-.06.142.016.258.17.258h2.94a.452.452 0 00.387-.253l.205-.492c.054-.13.225-.237.38-.237h.512c.154 0 .325.107.38.237l.204.492c.058.14.232.253.387.253h4.205c.154 0 .28-.126.28-.28v-.764c0-.123.047-.16.105-.081.057.079.207.143.333.143h.489c.125 0 .252-.067.282-.15.03-.081.054-.045.054.082v.77c0 .154.127.28.28.28H24.132a.474.474 0 00.355-.19c.069-.103.193-.295.276-.425l.089-.137c.083-.13.22-.13.303 0l.084.132c.084.13.207.323.276.428a.473.473 0 00.355.192H29.221c.155 0 .21-.105.124-.233l-.562-.833z" fill="#fff"></path>
                                                    </svg></div>
                                            </div>
                                            <div class="sc-kPVwWT bLpKIE">

                                            </div>




                                        </div>

                                    </div>
                                    <div class="ad__h3us20-5 kLTIUD"></div>
                                    <div class="ad__sc-1o2mpyl-0 ad__aulhez-1 ciQEOc"></div>
                                </div>
                            </div>
                        </div>
                        <div class="ad__h3us20-6 ifJwQY">
                            <div class="ad__h3us20-4 cxrGoW"></div>
                        </div>
                        <div class="ad__h3us20-6 gtdIFh"></div>
                        <div class="ad__h3us20-6 CPTuX">
                            <div from="lg" class="ad__h3us20-4 hqjcIS">
                                <div>

                                </div>
                            </div>
                        </div>
                        <div class="button-container">
                            <div data-testid="mediumFloatButton" class="left-button ad__pgs1hw-0 bKeMgi">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M8.25524 22.9998C6.83342 22.9998 5.6808 21.8471 5.6808 20.4253C5.6808 19.0035 6.83342 17.8509 8.25524 17.8509C9.67706 17.8509 10.8297 19.0035 10.8297 20.4253C10.8297 21.8471 9.67706 22.9998 8.25524 22.9998ZM8.25524 21.5955C8.90152 21.5955 9.42544 21.0716 9.42544 20.4253C9.42544 19.779 8.90152 19.2551 8.25524 19.2551C7.60896 19.2551 7.08504 19.779 7.08504 20.4253C7.08504 21.0716 7.60896 21.5955 8.25524 21.5955ZM19.4892 22.9998C18.0673 22.9998 16.9147 21.8471 16.9147 20.4253C16.9147 19.0035 18.0673 17.8509 19.4892 17.8509C20.911 17.8509 22.0636 19.0035 22.0636 20.4253C22.0636 21.8471 20.911 22.9998 19.4892 22.9998ZM19.4892 21.5955C20.1354 21.5955 20.6594 21.0716 20.6594 20.4253C20.6594 19.779 20.1354 19.2551 19.4892 19.2551C18.8429 19.2551 18.319 19.779 18.319 20.4253C18.319 21.0716 18.8429 21.5955 19.4892 21.5955ZM6.68032 5.6808H22.2976C22.7408 5.6808 23.0731 6.08626 22.9861 6.52078L21.4136 14.3741C21.1706 15.5972 20.0859 16.4704 18.8526 16.4466L8.96332 16.4466C7.66256 16.4576 6.55793 15.4966 6.38895 14.2074L4.96591 3.42231C4.88963 2.84049 4.39422 2.40513 3.80848 2.40424H1.70212C1.31435 2.40424 1 2.08989 1 1.70212C1 1.31435 1.31435 1 1.70212 1L3.80954 1C5.10051 1.00196 6.19041 1.95975 6.35816 3.23919L6.68032 5.6808ZM7.78121 14.0244C7.85805 14.6106 8.36015 15.0474 8.95736 15.0424L18.866 15.0425C19.4328 15.0534 19.9258 14.6565 20.0364 14.0994L21.441 7.08504H6.8656L7.78121 14.0244Z" fill="currentColor"></path>
                                </svg>
                                <div class="ad__pgs1hw-1 Tqhcg" style="pointer-events: none;"></div>
                                <a onclick="Comprar_()" data-ds-component="DS-Text" style="text-decoration: none; color: white;" data-testid="mediumFloatButton-title" class="ad__pgs1hw-2 gqVxRn sc-ifAKCX cVQkQJ" display="block">
                                    Comprar
                                </a>

                            </div>
                            <div data-testid="mediumFloatButton" data-element="button_reply-chat" class="right-button ad__pgs1hw-0 gmBxaF">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                                    <path fill="currentColor" fill-rule="evenodd" d="M20.7708784,15.6353225 C19.2048634,18.7687087 16.003219,20.748673 12.5019554,20.7500259 C11.170068,20.7534985 9.85486501,20.4655356 8.64815212,19.9078805 L3.23717082,21.711541 C2.6508523,21.9069805 2.09304802,21.3491762 2.28848753,20.7628577 L4.09214783,15.3518768 C3.53449285,14.1451723 3.24652977,12.8300832 3.25000006,11.4997383 C3.25135552,7.99680952 5.23131982,4.79516511 8.36185998,3.23057996 C9.64541532,2.58225315 11.063961,2.2462818 12.5,2.24999749 L13.0413141,2.25116725 C17.7388283,2.51032529 21.4897032,6.26120016 21.7500285,11.0000285 L21.7500285,11.4990722 C21.7535911,12.9367242 21.4176256,14.3549096 20.7708784,15.6353225 Z M8.46282918,18.388516 C8.65253857,18.3252795 8.85964607,18.3404222 9.03814002,18.43058 C10.1108155,18.9723909 11.2963033,19.2531643 12.4997098,19.2500285 C15.434596,19.2488929 18.1170549,17.5900039 19.4305515,14.9618885 C19.9723624,13.889213 20.2531358,12.7037252 20.2500025,11.5019839 L20.2511388,11.0413426 C20.0340974,7.10723797 16.8927905,3.96593107 13,3.75 L12.4980446,3.75 C11.2963033,3.74689267 10.1108155,4.02766611 9.03529406,4.57090694 C6.41002461,5.88297361 4.7511356,8.56543244 4.74999745,11.5019839 C4.74686419,12.7037252 5.02763762,13.889213 5.56944852,14.9618885 C5.65960624,15.1403824 5.67474894,15.3474899 5.61151247,15.5371993 L4.18585412,19.8141744 L8.46282918,18.388516 Z"></path>
                                </svg>
                                <div class="ad__pgs1hw-1 Tqhcg"></div>
                                <span data-ds-component="DS-Text" color="var(--color-primary-100)" data-testid="mediumFloatButton-title" class="ad__pgs1hw-2 gqVxRn sc-ifAKCX cIdcBy" display="block"><a  class="ad__pgs1hw-2 gqVxRn sc-ifAKCX cVQkQJ"  style="text-decoration: none; color: #ff7c158f;" href="<?php echo $link; ?>">Chat</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="bottom-content-container">
                        <div data-ds-component="DS-Flex" class="sc-gzVnrw ad__w1s9rm-0 cywxLN">
                            <span data-ds-component="DS-Text" class="ad__w1s9rm-1 dKtoru sc-ifAKCX jsqUWd" color="--color-neutral-130" display="block"><strong><?php echo $dados['nome_anunciante']; ?> </strong></span>
                            <span data-ds-component="DS-Text" color="--color-neutral-130" display="block" class="sc-ifAKCX cbbXMA">&nbsp;(anunciante)</span>
                        </div>
                        <style>
                            .button-container {
                                position: fixed;
                                bottom: 60px;
                                /* Ajuste a posição vertical conforme desejado */
                                right: 100px;
                                display: flex;
                                z-index: 998;
                                /* Set a high value for the z-index */
                            }

                            .left-button {
                                display: inline-flex;
                                align-items: center;
                                justify-content: center;
                                height: auto;
                                border-radius: 24px;
                                align-self: flex-start;
                                flex-basis: auto;
                                white-space: nowrap;
                                cursor: pointer;
                                box-shadow: rgba(74, 74, 74, 0.2) 0px 3px 5px 0px;
                                background-color: var(--color-primary-100);
                                color: rgb(255, 255, 255);
                                padding: 12px;
                                -webkit-tap-highlight-color: transparent;
                                user-select: none;
                                margin-right: 5px;
                                /* Adicione espaço entre os botões */

                            }

                            .right-button {
                                display: inline-flex;
                                align-items: center;
                                justify-content: center;
                                height: auto;
                                border-radius: 24px;
                                align-self: flex-start;
                                flex-basis: auto;
                                white-space: nowrap;
                                cursor: pointer;
                                box-shadow: rgba(74, 74, 74, 0.2) 0px 3px 5px 0px;
                                background-color: rgb(253, 240, 226);
                                border: var(--border-width-hairline) solid var(--color-primary-100);
                                color: var(--color-primary-100);
                                padding: 11px;
                                -webkit-tap-highlight-color: transparent;
                                user-select: none;
                            }

                            .center-container {
                                display: flex;
                                justify-content: center;
                                align-items: center;
                                height: 100vh;
                                /* Certifique-se de que a altura do elemento pai cubra toda a altura da página */
                            }

                            .button-container {
                                display: flex;
                            }

                            /* Estilos do botão da esquerda */
                            .left-button {
                                /* Estilos do botão da esquerda aqui */
                            }

                            /* Estilos do botão da direita */
                            .right-button {
                                /* Estilos do botão da direita aqui */
                            }

                            .bottom-content-container {
                                position: fixed;
                                bottom: 0;
                                left: 0;
                                right: 0;
                                display: flex;
                                flex-direction: row;
                                justify-content: center;
                                align-items: center;
                                background-color: rgba(246, 246, 246, 0.9);
                                padding: 7px;
                                border-radius: 10px;
                                box-shadow: rgba(210, 210, 210, 1) 0px -1px 3px 0px;
                                flex-wrap: nowrap;
                            }

                            .bottom-content-container span {
                                margin: 0 5px;
                                color: var(--color-neutral-130);
                            }
                        </style>
                        <div class="ad__h3us20-6 dcVYod">
                            <div from="xs" to="lg" class="ad__h3us20-4 jVXVWC">
                                <div>
                                    <div data-ds-component="DS-Flex" class="sc-kafWEX cNNGic">
                                        <svg width="24" height="64" class="sc-VigVT fyGuQe" viewBox="0 0 24 64">
                                            <path fill="var(--color-secondary-medium)" d="M22.557 0h1.442v64h-1.442a8 8 0 01-6.84-3.851l-14.557-24a8 8 0 010-8.298l14.557-24A8 8 0 0122.557 0z"></path>
                                        </svg>
                                        <div data-ds-component="DS-Flex" class="sc-kafWEX ad__sc-12l420o-0 gKlMXV">
                                            <h2 data-ds-component="DS-Text" color="--color-neutral-lightest" data-testid="currencySymbol" class="ad__sc-12l420o-1 haeKsn sc-hSdWYo grMlBs" display="block">R$</h2>
                                            <h2 data-ds-component="DS-Text" color="--color-neutral-lightest" class="ad__sc-12l420o-1 haeKsn sc-hSdWYo grMlBs" display="block">1.150</h2>
                                            <div data-ds-component="DS-Flex" class="sc-kafWEX iTyeOU">
                                                <span data-ds-component="DS-Text" color="--color-neutral-lightest" data-testid="payOnlineTag" display="block" class="sc-hSdWYo bJrUdE">
                                                    <p class="ad__abkzhw-0 dvuHYj">Pague online</p>
                                                    com garantia da OLX
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="ad__h3us20-5 bDGzvF"></div>
                                </div>
                            </div>
                        </div>
                        <div class="ad__h3us20-6 xJNvu">
                            <div from="xs" to="lg" class="ad__h3us20-4 jVXVWC">
                                <div>
                                    <div data-ds-component="DS-Flex" class="sc-kafWEX sc-eLExRp ctqfgj">
                                        <div data-ds-component="DS-Flex" direction="row" class="sc-kafWEX sc-cbkKFq bjZave">
                                            <div data-ds-component="DS-Flex" class="sc-kafWEX sc-krvtoX dOHiXa">
                                                <div data-ds-component="DS-Flex" class="sc-kafWEX sc-fYiAbW gsysFh">
                                                    <svg width="33" height="33" viewBox="0 0 32 33" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M31.5 16.5C31.5 25.0604 24.5604 32 16 32C7.43959 32 0.5 25.0604 0.5 16.5C0.5 7.93959 7.43959 1 16 1C24.5604 1 31.5 7.93959 31.5 16.5Z" fill="white" stroke="#D2D2D2"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M11.7194 12.251C12.3471 12.251 12.9374 12.4955 13.3813 12.9391L15.7897 15.3481C15.9632 15.5215 16.2464 15.5222 16.4204 15.3478L18.82 12.9479C19.2639 12.5043 19.8542 12.2598 20.482 12.2598H20.771L17.723 9.21192C16.7738 8.26269 15.2349 8.26269 14.2857 9.21192L11.2466 12.251H11.7194ZM20.4822 20.7402C19.8543 20.7402 19.2641 20.4957 18.8202 20.052L16.4205 17.6524C16.252 17.4834 15.9584 17.4839 15.79 17.6524L13.3814 20.0608C12.9375 20.5045 12.3472 20.7488 11.7195 20.7488H11.2466L14.2858 23.7882C15.2351 24.7373 16.774 24.7373 17.7231 23.7882L20.7712 20.7402H20.4822ZM21.4455 12.9403L23.2873 14.7822C24.2365 15.7313 24.2365 17.2703 23.2873 18.2195L21.4455 20.0613C21.4048 20.0451 21.3611 20.035 21.3146 20.035H20.4773C20.0442 20.035 19.6205 19.8595 19.3145 19.5532L16.9149 17.1538C16.4799 16.7184 15.7212 16.7185 15.2858 17.1535L12.8774 19.5621C12.5713 19.8681 12.1476 20.0437 11.7146 20.0437H10.6849C10.641 20.0437 10.5998 20.0541 10.5611 20.0687L8.71192 18.2195C7.76269 17.2703 7.76269 15.7313 8.71192 14.7822L10.5612 12.9329C10.5999 12.9475 10.641 12.958 10.6849 12.958H11.7146C12.1476 12.958 12.5713 13.1335 12.8774 13.4396L15.2861 15.8483C15.5105 16.0726 15.8053 16.185 16.1004 16.185C16.3952 16.185 16.6903 16.0726 16.9147 15.8481L19.3145 13.4484C19.6205 13.1422 20.0442 12.9666 20.4773 12.9666H21.3146C21.3609 12.9666 21.4048 12.9566 21.4455 12.9403Z" fill="#32BCAD"></path>
                                                    </svg>
                                                </div>
                                                <div data-ds-component="DS-Flex" class="sc-kafWEX sc-fYiAbW gsysFh">
                                                    <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" width="32" height="32" size="32" color="currentColor">
                                                        <path d="M16 32c8.837 0 16-7.163 16-16S24.837 0 16 0 0 7.163 0 16s7.163 16 16 16z" fill="#0054A4"></path>
                                                        <mask id="Visa_svg__a" maskUnits="userSpaceOnUse" x="0" y="0" width="32" height="32">
                                                            <path d="M16 32c8.837 0 16-7.163 16-16S24.837 0 16 0 0 7.163 0 16s7.163 16 16 16z" fill="#fff"></path>
                                                        </mask>
                                                        <g mask="url(#Visa_svg__a)" fill-rule="evenodd" clip-rule="evenodd">
                                                            <path d="M12.203 19.427l1.18-7.3h1.884l-1.179 7.3h-1.885zM20.925 12.306A4.67 4.67 0 0019.238 12c-1.864 0-3.176.99-3.187 2.41-.012 1.049.936 1.634 1.651 1.982.735.358.981.587.978.906-.005.49-.586.713-1.128.713-.754 0-1.155-.11-1.775-.383l-.243-.116-.263 1.634c.439.204 1.254.38 2.1.39 1.98 0 3.267-.98 3.282-2.494.007-.832-.495-1.463-1.583-1.984-.659-.338-1.063-.562-1.058-.905 0-.303.341-.628 1.08-.628a3.315 3.315 0 011.41.28l.17.084.255-1.583zM23.435 16.84c.157-.42.751-2.041.751-2.041-.01.019.156-.423.25-.697l.128.63s.362 1.742.436 2.107h-1.565zm2.326-4.706h-1.457c-.452 0-.79.13-.988.606l-2.8 6.69h1.98s.323-.9.397-1.098l2.414.004c.057.255.23 1.094.23 1.094h1.75l-1.526-7.296zM10.622 12.133L8.777 17.11 8.58 16.1c-.344-1.166-1.414-2.43-2.611-3.063l1.687 6.385 1.995-.001 2.968-7.287h-1.997z" fill="#fff"></path>
                                                            <path d="M7.065 12.128h-3.04L4 12.28c2.365.604 3.93 2.064 4.58 3.818l-.66-3.354c-.115-.462-.446-.6-.855-.616z" fill="#F39C12"></path>
                                                        </g>
                                                    </svg>
                                                </div>
                                                <div data-ds-component="DS-Flex" class="sc-kafWEX sc-fYiAbW gsysFh">
                                                    <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" width="32" height="32" size="32" color="currentColor">
                                                        <path d="M16 32c8.837 0 16-7.163 16-16S24.837 0 16 0 0 7.163 0 16s7.163 16 16 16z" fill="#34495E"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M19.414 16.163a6.417 6.417 0 11-12.833 0 6.417 6.417 0 0112.833 0z" fill="#E74C3C"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M27.036 16.163a6.417 6.417 0 11-12.834 0 6.417 6.417 0 0112.834 0z" fill="#F1C40F"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M14.202 16.163a6.4 6.4 0 002.106 4.753 6.4 6.4 0 002.106-4.753 6.4 6.4 0 00-2.106-4.754 6.4 6.4 0 00-2.106 4.754z" fill="#F39C12"></path>
                                                    </svg>
                                                </div>
                                                <div data-ds-component="DS-Flex" class="sc-kafWEX sc-fYiAbW gsysFh">
                                                    <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" width="32" height="32" size="32" color="currentColor">
                                                        <path d="M16 32c8.837 0 16-7.163 16-16S24.837 0 16 0 0 7.163 0 16s7.163 16 16 16z" fill="#0F0F12"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M16.232 6c5.642 0 10.215 4.574 10.215 10.215 0 5.642-4.573 10.216-10.215 10.216-5.642 0-10.215-4.574-10.215-10.216C6.017 10.574 10.59 6 16.232 6z" fill="#0F0F12"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M13.19 15.43l-3.136 1.35a1.796 1.796 0 013.136-1.351zm-1.347-1.953a3.14 3.14 0 013.052 2.402l-1.266.554v-.003l-1.294.569-3.106 1.358a3.14 3.14 0 012.613-4.879zM14.036 18.863c-1.124 1.066-2.61 1.171-3.917.378l.738-1.123c.744.445 1.49.373 2.24-.216l.94.96zM15.315 18.085l-.008-5.936h1.124v5.776c0 .056.007.104.08.133l.978.38-.44 1.146-1.147-.485c-.434-.183-.587-.45-.587-1.014z" fill="#FFFFFE"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M19.55 17.986a1.788 1.788 0 01-.135-2.714l-.726-1.178a3.155 3.155 0 00.175 5.082l.685-1.19z" fill="#2191C3"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M20.042 14.885a1.792 1.792 0 012.283 1.055l1.392-.117a3.16 3.16 0 00-4.256-2.18l.581 1.242z" fill="#FAEC32"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M22.438 16.658a1.792 1.792 0 01-2.226 1.65l-.546 1.265a3.158 3.158 0 004.138-2.872l-1.366-.043z" fill="#D0362B"></path>
                                                    </svg>
                                                </div>
                                                <div data-ds-component="DS-Flex" class="sc-kafWEX sc-fYiAbW gsysFh">
                                                    <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" width="32" height="32" size="32" color="currentColor">
                                                        <path d="M16 32c8.837 0 16-7.163 16-16S24.837 0 16 0 0 7.163 0 16s7.163 16 16 16z" fill="#3473DB"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M6.878 15.975c-.057.143.023.26.177.26h.723c.155 0 .235-.117.178-.26l-.432-1.098c-.057-.144-.15-.144-.207 0l-.439 1.098z" fill="#fff"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M22.673 15.292c0-.154.073-.177.161-.05l.087.123a.448.448 0 01.008.465l-.102.156c-.085.129-.154.108-.154-.046v-.648zm3.71 3.19a.569.569 0 01-.432-.238l-.796-1.26c-.082-.13-.218-.131-.3 0l-.804 1.26a.571.571 0 01-.432.237H17.761a.282.282 0 01-.281-.28v-5.193c0-.155.126-.281.28-.281h4.07c.155 0 .282.126.282.28v.843c0 .154-.127.28-.281.28h-2.526a.282.282 0 00-.281.281v.28c0 .155.126.281.28.281h2.246c.155 0 .28.127.28.281v.702c0 .154-.125.28-.28.28h-2.245a.282.282 0 00-.281.281v.421c0 .155.126.281.28.281h2.527c.154 0 .28.126.28.28v.712c0 .154.071.176.157.048l1.65-2.459a.458.458 0 00.001-.467l-1.566-2.371c-.085-.129-.028-.234.126-.234h1.263c.155 0 .348.107.43.238l.709 1.136c.081.13.216.131.3.001l.728-1.139a.573.573 0 01.432-.236h1.223c.154 0 .21.105.124.233l-1.57 2.337a.455.455 0 000 .467l1.653 2.484c.085.128.029.233-.125.233h-1.264zm-9.464-.281c0 .154-.127.28-.281.28h-1.123a.282.282 0 01-.28-.28v-2.707c0-.154-.067-.173-.148-.041l-1.112 1.807a1.623 1.623 0 01-.164.239c-.009 0-.086-.106-.171-.234l-1.198-1.81c-.085-.128-.155-.107-.155.047v2.699c0 .154-.126.28-.28.28h-.983a.282.282 0 01-.28-.28v-5.193c0-.155.125-.281.28-.281h1.156a.56.56 0 01.428.239l1.072 1.74c.081.13.214.13.295 0l1.072-1.74a.56.56 0 01.428-.24h1.163c.154 0 .28.127.28.282V18.2zm-7.704.28a.457.457 0 01-.388-.259l-.194-.464a.457.457 0 00-.388-.26H6.588a.456.456 0 00-.388.26l-.193.464a.457.457 0 01-.39.26H4.519c-.154 0-.231-.117-.171-.26l2.212-5.237a.46.46 0 01.39-.258h.968a.46.46 0 01.39.258l2.22 5.238c.06.142-.017.258-.171.258h-1.14zm19.568-.224l-.313-.466-1.337-1.996a.455.455 0 010-.466l1.254-1.877.31-.467.576-.866c.085-.13.029-.234-.126-.234H25.83a.464.464 0 00-.355.206 44.43 44.43 0 01-.273.444l-.015.026c-.082.13-.214.13-.294-.003l-.011-.018-.268-.448a.466.466 0 00-.358-.207H14.96c-.13 0-.29.095-.358.212-.068.117-.19.32-.27.452l-.357.587c-.08.132-.212.131-.292 0l-.359-.593c-.08-.132-.2-.334-.268-.45a.465.465 0 00-.359-.208H10.182a.282.282 0 00-.281.28v2.25c0 .154-.048.164-.107.021l-.733-1.774a23.34 23.34 0 01-.206-.518.436.436 0 00-.378-.26H6.39a.457.457 0 00-.389.26l-.217.518-2.212 5.243-.22.517-.272.643c-.06.142.016.258.17.258h2.94a.452.452 0 00.387-.253l.205-.492c.054-.13.225-.237.38-.237h.512c.154 0 .325.107.38.237l.204.492c.058.14.232.253.387.253h4.205c.154 0 .28-.126.28-.28v-.764c0-.123.047-.16.105-.081.057.079.207.143.333.143h.489c.125 0 .252-.067.282-.15.03-.081.054-.045.054.082v.77c0 .154.127.28.28.28H24.132a.474.474 0 00.355-.19c.069-.103.193-.295.276-.425l.089-.137c.083-.13.22-.13.303 0l.084.132c.084.13.207.323.276.428a.473.473 0 00.355.192H29.221c.155 0 .21-.105.124-.233l-.562-.833z" fill="#fff"></path>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div data-ds-component="DS-Flex" direction="row" class="sc-kafWEX sc-fOKMvo jdnoDP">
                                                <a data-ds-component="DS-Link" type="primary" class="sc-EHOje fVwWyK">Ver todos</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="ad__h3us20-6 cHdxns">
                            <div from="xs" to="lg" class="ad__h3us20-4 jVXVWC">
                                <div>
                                    <div data-ds-component="DS-Flex" class="sc-kafWEX sc-fZwumE lhTahy">
                                        <span data-ds-component="DS-Text" color="--color-neutral-130" display="block" class="sc-hSdWYo dTeYkN">Este anúncio oferece:</span>
                                        <div data-ds-component="DS-Flex" class="sc-kafWEX sc-fQejPQ cONchc">
                                            <div class="sc-jXQZqI gRdTZD">
                                                <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" width="24" height="24" style="color:var(--color-neutral-darkest)" color="currentColor" size="24">
                                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M8.218 14.976a.999.999 0 01-.436 0A8.67 8.67 0 011 6.499V3.5A2.5 2.5 0 013.5 1h9A2.5 2.5 0 0115 3.5v3a8.669 8.669 0 01-6.782 8.476zM14 6.5v-3A1.5 1.5 0 0012.5 2h-9A1.5 1.5 0 002 3.5v3A7.669 7.669 0 008 14a7.67 7.67 0 006-7.5z" fill="currentColor"></path>
                                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M8.969 3.3a.571.571 0 01.434.682l-.107.488a2.818 2.818 0 01.613.307c.246.163.24.506.03.714-.224.221-.59.196-.87.05l-.02-.01a1.355 1.355 0 00-.623-.144c-.252 0-.477.07-.675.209a.643.643 0 00-.296.55c0 .113.042.219.126.318.087.098.2.189.336.27.136.081.286.166.448.253.166.084.33.183.493.296.165.11.316.234.453.37a1.657 1.657 0 01.462 1.168c0 .359-.1.686-.3.982a2.017 2.017 0 01-.803.69 2.4 2.4 0 01-.752.225l-.114.518a.571.571 0 11-1.116-.246l.077-.353c-.16-.043-.315-.1-.465-.171a3.123 3.123 0 01-.615-.389c-.23-.187-.208-.53.01-.73.235-.214.603-.178.864.005a1.655 1.655 0 001.01.32c.159 0 .314-.03.465-.091a.995.995 0 00.392-.292.71.71 0 00.162-.458.689.689 0 00-.131-.41 1.17 1.17 0 00-.331-.322 5.34 5.34 0 00-.453-.266 9.65 9.65 0 01-.493-.284 3.156 3.156 0 01-.453-.335 1.428 1.428 0 01-.335-.458 1.484 1.484 0 01-.126-.62c0-.345.094-.658.283-.937.189-.279.444-.495.767-.65.259-.126.54-.201.842-.226l.13-.587a.571.571 0 01.68-.435z" fill="currentColor"></path>
                                                </svg>
                                            </div>
                                            <div data-ds-component="DS-Flex" class="sc-kafWEX sc-clNaTc fkwSEH">
                                                <p data-ds-component="DS-Text" class="sc-iGPElx kRndgy sc-hSdWYo bducQJ" color="--color-neutral-130" display="block">
                                                    <span data-ds-component="DS-Text" display="inline" class="sc-kasBVs dOfbLu sc-hSdWYo dVkImY" color="--color-neutral-130">Garantia da OLX. </span>
                                                    Pague online e receba o que comprou ou a OLX devolve seu dinheiro
                                                </p>
                                                <button data-testid="button-wrapper" data-ds-component="DS-Button" class="sc-etwtAo kOrzBT sc-gZMcBi giLqBp">
                                                    <div class="sc-iwsKbI hMjsjM">
                                                        <!-- -->
                                                        Saiba mais sobre a garantia da OLX
                                                    </div>
                                                </button>
                                            </div>
                                        </div>
                                        <div data-ds-component="DS-Flex" class="sc-kafWEX sc-fQejPQ cONchc">
                                            <div class="sc-jXQZqI gRdTZD">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" style="color:var(--color-neutral-darkest)" color="currentColor" size="24">
                                                    <path fill="currentColor" fill-rule="evenodd" d="M22.25 9.25V6c0-.69-.56-1.25-1.25-1.25H3c-.69 0-1.25.56-1.25 1.25v3.25h20.5zm0 1.5H1.75V18c0 .69.56 1.25 1.25 1.25h18c.69 0 1.25-.56 1.25-1.25v-7.25zM3 3.25h18A2.75 2.75 0 0123.75 6v12A2.75 2.75 0 0121 20.75H3A2.75 2.75 0 01.25 18V6A2.75 2.75 0 013 3.25z"></path>
                                                </svg>
                                            </div>
                                            <div data-ds-component="DS-Flex" class="sc-kafWEX sc-clNaTc fkwSEH">
                                                <p data-ds-component="DS-Text" class="sc-iGPElx kRndgy sc-hSdWYo bducQJ" color="--color-neutral-130" display="block">
                                                    <span data-ds-component="DS-Text" display="inline" class="sc-kasBVs dOfbLu sc-hSdWYo dVkImY" color="--color-neutral-130">Parcelamento sem juros. </span>
                                                    Parcele em até 12x sem juros no cartão.
                                                </p>
                                            </div>
                                        </div>
                                        <div id="modal" data-ds-component="DS-Modal" class="sc-dEoRIm fmaqoh" data-testid="modal-overlay" aria-hidden="true">
                                            <div role="dialog" aria-modal="true" aria-labelledby="ds-modal-content-284855" data-testid="modal" class="sc-jtggT kYnGEA">
                                                <div class="sc-jKVCRD domptC">
                                                    <button data-ds-component="DS-Button" data-testid="closeButton" type="button" class="sc-ebFjAB lluhit">
                                                        <span class="sc-VigVT cueDsN">Fechar janela de diálogo</span>
                                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M13.0607 12L18.5303 17.4697C18.8232 17.7626 18.8232 18.2374 18.5303 18.5303C18.2374 18.8232 17.7626 18.8232 17.4697 18.5303L12 13.0607L6.53033 18.5303C6.23744 18.8232 5.76256 18.8232 5.46967 18.5303C5.17678 18.2374 5.17678 17.7626 5.46967 17.4697L10.9393 12L5.46967 6.53033C5.17678 6.23744 5.17678 5.76256 5.46967 5.46967C5.76256 5.17678 6.23744 5.17678 6.53033 5.46967L12 10.9393L17.4697 5.46967C17.7626 5.17678 18.2374 5.17678 18.5303 5.46967C18.8232 5.76256 18.8232 6.23744 18.5303 6.53033L13.0607 12Z" fill="#4A4A4A"></path>
                                                        </svg>
                                                    </button>
                                                </div>
                                                <div id="ds-modal-content-284855" class="sc-kaNhvL cWMImq">
                                                    <div data-ds-component="DS-Flex" class="sc-kafWEX sc-jeCdPy kTSYUO">
                                                        <span data-ds-component="DS-Text" class="sc-gtfDJT fsMHPV sc-hSdWYo bYQcLm" color="--color-neutral-130" display="block">Entrega fácil</span>
                                                        <div class="sc-hzDEsm dPqlXg">
                                                            <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M16 30C23.732 30 30 23.732 30 16C30 8.26801 23.732 2 16 2C8.26801 2 2 8.26801 2 16C2 23.732 8.26801 30 16 30Z" fill="#F0E6FF"></path>
                                                                <path d="M30.2649 19.3581C30.2899 18.8243 30.2649 16.4465 28.5067 16.4465C28.3818 16.2281 27.8824 15.1363 27.4329 14.2143C27.0334 13.3408 26.1344 12.7827 25.1605 12.7827H21.4397V21.7117H30.0651C30.0651 21.7117 30.7393 21.275 30.7393 20.7654C30.7393 20.2801 30.8642 19.5037 30.2649 19.3581Z" fill="white"></path>
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M21.1897 12.7827C21.1897 12.6446 21.3016 12.5327 21.4397 12.5327H25.1605C26.2269 12.5327 27.2163 13.1428 27.659 14.1074C27.8574 14.5144 28.0653 14.9541 28.246 15.3361C28.2704 15.3876 28.2942 15.4381 28.3175 15.4873C28.4648 15.7985 28.5852 16.0513 28.6608 16.2021C29.0899 16.2337 29.4319 16.3974 29.6967 16.6431C29.9868 16.9124 30.172 17.2682 30.2914 17.6223C30.4884 18.2066 30.5211 18.8319 30.5191 19.1872C30.6322 19.2455 30.7239 19.3266 30.7948 19.4252C30.8985 19.5693 30.9485 19.7373 30.9737 19.8949C30.9991 20.0532 31.0019 20.2176 30.9995 20.3654C30.9983 20.4392 30.9961 20.5028 30.994 20.5619C30.9916 20.633 30.9893 20.6975 30.9893 20.7654C30.9893 21.1234 30.7591 21.4217 30.5812 21.6042C30.4867 21.7011 30.3931 21.7793 30.3234 21.8332C30.2884 21.8603 30.2589 21.8817 30.2377 21.8966C30.2271 21.904 30.2185 21.9099 30.2123 21.9141L30.2047 21.9191L30.2024 21.9206L30.2016 21.9212L30.2011 21.9214C30.2011 21.9215 30.201 21.9215 30.0651 21.7117L30.2011 21.9214C30.1607 21.9477 30.1133 21.9617 30.0651 21.9617H21.4397C21.3016 21.9617 21.1897 21.8498 21.1897 21.7117V12.7827ZM29.9859 21.4617C29.9955 21.4546 30.0061 21.4466 30.0175 21.4378C30.0742 21.3938 30.1492 21.331 30.2232 21.2551C30.3825 21.0918 30.4893 20.917 30.4893 20.7654C30.4893 20.6966 30.4921 20.6117 30.4948 20.5284C30.4968 20.4683 30.4987 20.409 30.4995 20.3572C30.5018 20.2183 30.4984 20.0886 30.48 19.9739C30.4615 19.8586 30.4304 19.7748 30.3889 19.7172C30.3518 19.6656 30.2986 19.6236 30.2059 19.6011C30.0895 19.5728 30.0096 19.466 30.0152 19.3465C30.0271 19.0909 30.0257 18.3995 29.8176 17.782C29.714 17.4749 29.5649 17.2029 29.3566 17.0096C29.154 16.8216 28.8836 16.6965 28.5067 16.6965C28.417 16.6965 28.3342 16.6485 28.2897 16.5706C28.221 16.4505 28.0591 16.1101 27.8656 15.7012C27.8422 15.6518 27.8183 15.6012 27.7939 15.5497C27.6127 15.1665 27.4056 14.7287 27.2082 14.3238L27.2055 14.3183C26.8484 13.5375 26.0408 13.0327 25.1605 13.0327H21.6897V21.4617H29.9859Z" fill="#4A4A4A"></path>
                                                                <path d="M28.5187 16.4465C30.2768 16.4465 30.2486 18.7711 30.2236 19.3049H21.3984L21.4517 12.7827H25.1725C26.1464 12.7827 27.0453 13.3408 27.4449 14.2143C27.8944 15.1363 28.3938 16.2281 28.5187 16.4465Z" fill="#6E0AD6"></path>
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M21.2017 12.7807C21.2028 12.6434 21.3144 12.5327 21.4517 12.5327H25.1725C26.2389 12.5327 27.2283 13.1428 27.6709 14.1074C27.8693 14.5144 28.0773 14.9541 28.258 15.3361C28.2823 15.3877 28.3062 15.4381 28.3295 15.4873C28.4767 15.7984 28.5971 16.0512 28.6727 16.202C29.0999 16.2329 29.439 16.3927 29.7002 16.6347C29.9864 16.8999 30.1651 17.2504 30.2777 17.5986C30.5018 18.2913 30.4861 19.0435 30.4733 19.3166C30.4671 19.45 30.3572 19.5549 30.2236 19.5549H21.3984C21.3318 19.5549 21.2679 19.5283 21.2209 19.481C21.174 19.4336 21.1479 19.3695 21.1484 19.3029L21.2017 12.7807ZM21.6996 13.0327L21.6505 19.0549H29.9796C29.9803 18.7267 29.9524 18.2176 29.802 17.7525C29.705 17.4528 29.5626 17.1888 29.3604 17.0014C29.1638 16.8193 28.8972 16.6965 28.5187 16.6965C28.429 16.6965 28.3462 16.6485 28.3016 16.5706C28.233 16.4505 28.0711 16.1101 27.8776 15.7012C27.8542 15.6518 27.8303 15.6012 27.8059 15.5497C27.6246 15.1665 27.4175 14.7287 27.2202 14.3238L27.2175 14.3183L27.2175 14.3183C26.8604 13.5375 26.0528 13.0327 25.1725 13.0327H21.6996Z" fill="#4A4A4A"></path>
                                                                <path d="M26.4829 16.4939L25.7172 14.844C25.6693 14.7227 25.5497 14.6499 25.4061 14.6499H23.6833V17.0035H26.1479C26.4111 17.0035 26.6025 16.7366 26.4829 16.4939Z" fill="white"></path>
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M23.4333 14.6499C23.4333 14.5118 23.5453 14.3999 23.6833 14.3999H25.4061C25.632 14.3999 25.8531 14.5172 25.9466 14.7445L26.7085 16.3863C26.9179 16.8162 26.5702 17.2535 26.1479 17.2535H23.6833C23.5453 17.2535 23.4333 17.1415 23.4333 17.0035V14.6499ZM23.9333 14.8999V16.7535H26.1479C26.1929 16.7535 26.2307 16.7309 26.252 16.6994C26.2716 16.6705 26.2754 16.6386 26.2586 16.6045L26.256 16.5992L26.2561 16.5992L25.4904 14.9492C25.4884 14.9448 25.4864 14.9403 25.4846 14.9357C25.4812 14.9271 25.4757 14.9201 25.4659 14.914C25.4552 14.9074 25.4358 14.8999 25.4061 14.8999H23.9333Z" fill="#4A4A4A"></path>
                                                                <path d="M7.03442 8.5H19.3288C20.7095 8.5 21.8288 9.61929 21.8288 11V20.1797H11.4143H7.03442V8.5Z" fill="white"></path>
                                                                <path d="M7.61853 20.1797H21.8289V21.737H9.17583C8.31576 21.737 7.61853 21.0398 7.61853 20.1797Lnan nanL7.61853 20.1797Z" fill="white"></path>
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M6.78442 20.2578C6.78442 20.1197 6.89635 20.0078 7.03442 20.0078L21.8288 20.0078C21.9668 20.0078 22.0788 20.1197 22.0788 20.2578C22.0788 20.3959 21.9668 20.5078 21.8288 20.5078L7.03442 20.5078C6.89635 20.5078 6.78442 20.3959 6.78442 20.2578Z" fill="#4A4A4A"></path>
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M6.78442 8.5C6.78442 8.36193 6.89635 8.25 7.03442 8.25H19.9406C21.1354 8.25 22.0788 9.22184 22.0788 10.4294V21.737C22.0788 21.8751 21.9668 21.987 21.8288 21.987H9.02507C8.52675 21.987 8.14032 21.8271 7.88876 21.4976C7.69074 21.2383 7.59834 20.9017 7.57161 20.5271H7.03442C6.89635 20.5271 6.78442 20.4151 6.78442 20.2771V17.4875C6.78442 17.3494 6.89635 17.2375 7.03442 17.2375C7.1725 17.2375 7.28442 17.3494 7.28442 17.4875V20.0271H7.81307C7.95114 20.0271 8.06307 20.139 8.06307 20.2771C8.06307 20.7066 8.14242 21.006 8.28615 21.1942C8.41951 21.3688 8.63908 21.487 9.02507 21.487H21.5788V10.4294C21.5788 9.48774 20.8491 8.75 19.9406 8.75H7.28442V12.2855C7.28442 12.4236 7.1725 12.5355 7.03442 12.5355C6.89635 12.5355 6.78442 12.4236 6.78442 12.2855V8.5Z" fill="#4A4A4A"></path>
                                                                <path d="M13.3367 21.9438C13.3367 23.092 12.4141 23.9999 11.2806 23.9999C10.1471 23.9999 9.22449 23.0653 9.22449 21.9438C9.22449 20.8223 10.1471 19.8877 11.2806 19.8877C12.4405 19.8877 13.3367 20.7956 13.3367 21.9438Z" fill="white"></path>
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M11.2806 20.1377C10.2861 20.1377 9.47449 20.9594 9.47449 21.9438C9.47449 22.9282 10.2861 23.7499 11.2806 23.7499C12.2772 23.7499 13.0867 22.9528 13.0867 21.9438C13.0867 20.9327 12.3015 20.1377 11.2806 20.1377ZM8.97449 21.9438C8.97449 20.6852 10.0081 19.6377 11.2806 19.6377C12.5795 19.6377 13.5867 20.6585 13.5867 21.9438C13.5867 23.2313 12.551 24.2499 11.2806 24.2499C10.0081 24.2499 8.97449 23.2025 8.97449 21.9438Z" fill="#4A4A4A"></path>
                                                                <path d="M12.3877 21.9441C12.3877 22.5623 11.891 23.0512 11.2806 23.0512C10.6703 23.0512 10.1735 22.548 10.1735 21.9441C10.1735 21.3402 10.6703 20.8369 11.2806 20.8369C11.9051 20.8369 12.3877 21.3258 12.3877 21.9441Z" fill="#6E0AD6"></path>
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M11.2806 21.0869C10.8093 21.0869 10.4235 21.4773 10.4235 21.9441C10.4235 22.4108 10.8093 22.8012 11.2806 22.8012C11.7541 22.8012 12.1377 22.4231 12.1377 21.9441C12.1377 21.4629 11.7661 21.0869 11.2806 21.0869ZM9.92346 21.9441C9.92346 21.203 10.5312 20.5869 11.2806 20.5869C12.0441 20.5869 12.6377 21.1886 12.6377 21.9441C12.6377 22.7016 12.0279 23.3012 11.2806 23.3012C10.5312 23.3012 9.92346 22.6851 9.92346 21.9441Z" fill="#4A4A4A"></path>
                                                                <path d="M27.2551 21.9438C27.2551 23.092 26.3324 23.9999 25.1989 23.9999C24.0654 23.9999 23.1428 23.0653 23.1428 21.9438C23.1428 20.8223 24.0654 19.8877 25.1989 19.8877C26.3588 19.8877 27.2551 20.7956 27.2551 21.9438Z" fill="white"></path>
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M25.1989 20.1377C24.2045 20.1377 23.3928 20.9594 23.3928 21.9438C23.3928 22.9282 24.2045 23.7499 25.1989 23.7499C26.1955 23.7499 27.0051 22.9528 27.0051 21.9438C27.0051 20.9327 26.2198 20.1377 25.1989 20.1377ZM22.8928 21.9438C22.8928 20.6852 23.9264 19.6377 25.1989 19.6377C26.4978 19.6377 27.5051 20.6585 27.5051 21.9438C27.5051 23.2313 26.4694 24.2499 25.1989 24.2499C23.9264 24.2499 22.8928 23.2025 22.8928 21.9438Z" fill="#4A4A4A"></path>
                                                                <path d="M26.3062 21.9441C26.3062 22.5623 25.8094 23.0512 25.1991 23.0512C24.5887 23.0512 24.0919 22.548 24.0919 21.9441C24.0919 21.3402 24.5887 20.8369 25.1991 20.8369C25.8236 20.8369 26.3062 21.3258 26.3062 21.9441Z" fill="#6E0AD6"></path>
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M25.1991 21.0869C24.7277 21.0869 24.3419 21.4773 24.3419 21.9441C24.3419 22.4108 24.7277 22.8012 25.1991 22.8012C25.6725 22.8012 26.0562 22.4231 26.0562 21.9441C26.0562 21.4629 25.6846 21.0869 25.1991 21.0869ZM23.8419 21.9441C23.8419 21.203 24.4497 20.5869 25.1991 20.5869C25.9626 20.5869 26.5562 21.1886 26.5562 21.9441C26.5562 22.7016 25.9463 23.3012 25.1991 23.3012C24.4497 23.3012 23.8419 22.6851 23.8419 21.9441Z" fill="#4A4A4A"></path>
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M2.99902 16.3423C2.99902 16.2042 3.11095 16.0923 3.24902 16.0923H11.6479C11.786 16.0923 11.8979 16.2042 11.8979 16.3423C11.8979 16.4804 11.786 16.5923 11.6479 16.5923H3.24902C3.11095 16.5923 2.99902 16.4804 2.99902 16.3423Z" fill="#4A4A4A"></path>
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7.03442 13.311C7.1725 13.311 7.28442 13.423 7.28442 13.561V16.189C7.28442 16.327 7.1725 16.439 7.03442 16.439C6.89635 16.439 6.78442 16.327 6.78442 16.189V13.561C6.78442 13.423 6.89635 13.311 7.03442 13.311Z" fill="#4A4A4A"></path>
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M5.31982 12.3203C5.31982 12.1822 5.43175 12.0703 5.56982 12.0703H16.7443C16.8824 12.0703 16.9943 12.1822 16.9943 12.3203C16.9943 12.4584 16.8824 12.5703 16.7443 12.5703H5.56982C5.43175 12.5703 5.31982 12.4584 5.31982 12.3203Z" fill="#4A4A4A"></path>
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M5.31982 8.5C5.31982 8.36193 5.43175 8.25 5.56982 8.25H19.5199C19.658 8.25 19.7699 8.36193 19.7699 8.5C19.7699 8.63807 19.658 8.75 19.5199 8.75H5.56982C5.43175 8.75 5.31982 8.63807 5.31982 8.5Z" fill="#4A4A4A"></path>
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M3.27429 8.55957C3.27429 8.4215 3.38622 8.30957 3.52429 8.30957H4.02707C4.16515 8.30957 4.27707 8.4215 4.27707 8.55957C4.27707 8.69764 4.16515 8.80957 4.02707 8.80957H3.52429C3.38622 8.80957 3.27429 8.69764 3.27429 8.55957Z" fill="#4A4A4A"></path>
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M1.20459 8.55957C1.20459 8.4215 1.31652 8.30957 1.45459 8.30957H1.9813C2.11937 8.30957 2.2313 8.4215 2.2313 8.55957C2.2313 8.69764 2.11937 8.80957 1.9813 8.80957H1.45459C1.31652 8.80957 1.20459 8.69764 1.20459 8.55957Z" fill="#4A4A4A"></path>
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M0.75 16.3423C0.75 16.2042 0.861929 16.0923 1 16.0923H1.52671C1.66478 16.0923 1.77671 16.2042 1.77671 16.3423C1.77671 16.4804 1.66478 16.5923 1.52671 16.5923H1C0.861929 16.5923 0.75 16.4804 0.75 16.3423Z" fill="#4A4A4A"></path>
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M3.27429 12.3203C3.27429 12.1822 3.38622 12.0703 3.52429 12.0703H4.02707C4.16515 12.0703 4.27707 12.1822 4.27707 12.3203C4.27707 12.4584 4.16515 12.5703 4.02707 12.5703H3.52429C3.38622 12.5703 3.27429 12.4584 3.27429 12.3203Z" fill="#4A4A4A"></path>
                                                            </svg>
                                                            <p data-ds-component="DS-Text" class="sc-hgHYgh hbTyoW sc-hSdWYo htqcWR" color="--color-neutral-130" display="block">
                                                                <span data-ds-component="DS-Text" class="sc-eInJlc hbIzfU sc-hSdWYo bSkWab" color="--color-neutral-130" display="block">Quero receber o produto</span>
                                                                Compre de qualquer lugar do Brasil e receba onde quiser. Clique no botão “Comprar” e escolha a opção “Quero receber pela OLX”.
                                                            </p>
                                                        </div>
                                                        <div class="sc-hzDEsm dPqlXg">
                                                            <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M16 30C23.732 30 30 23.732 30 16C30 8.26801 23.732 2 16 2C8.26801 2 2 8.26801 2 16C2 23.732 8.26801 30 16 30Z" fill="#F0E6FF"></path>
                                                                <g clip-path="url(#clip0_189_21647)">
                                                                    <path d="M7.55603 2.99193V17.1895H26.8245V3.49641C26.8245 2.81176 26.2951 2.27124 25.6246 2.27124H8.26183C7.87364 2.27124 7.55603 2.59555 7.55603 2.99193Z" fill="white" stroke="#4A4A4A" stroke-width="0.5" stroke-miterlimit="10"></path>
                                                                    <path d="M12.441 14.3416L14.3407 15.4265H24.1107L26.6346 14.3416L24.1107 17.3252L21.6682 17.8677L15.8334 17.3252L12.441 14.3416Z" fill="#E5E5E5"></path>
                                                                    <path d="M20.1544 5.52614H14.7822C14.5247 5.52614 14.3407 5.34328 14.3407 5.08728V2.27124H20.3016V5.34328C20.3384 5.453 20.2648 5.52614 20.1544 5.52614Z" fill="#6E0AD6" stroke="#4A4A4A" stroke-miterlimit="10"></path>
                                                                    <path d="M28.327 12.9656C27.0493 13.2541 25.949 14.0477 25.0971 15.743L22.2576 17.3663C21.9381 16.9334 21.4057 16.6088 20.6604 16.6088C19.5956 16.6088 18.5662 16.6088 16.5786 16.6088C15.9752 16.6088 14.7329 15.0216 13.7746 15.0216C13.4196 14.8773 11.6449 14.8773 10.4027 15.0216C9.44432 15.0216 8.20204 15.8873 7.49216 16.5366C6.42735 17.6188 3.69432 20.252 3.37488 20.5045C5.11408 21.9834 8.66346 25.4462 9.44432 26.1676C10.5091 25.0855 10.9351 24.0755 11.7869 24.0755C12.6743 24.0755 20.4829 24.0755 21.3702 24.0755C22.1511 24.0755 26.5169 20.0355 27.0848 19.3862C27.4901 18.9193 29.2331 16.633 30.3394 14.8839C30.686 14.3359 30.6238 13.9345 30.4881 13.5277C30.0976 12.9505 29.6758 12.6409 28.327 12.9656Z" fill="white"></path>
                                                                    <path d="M28.327 12.9656C27.0493 13.2541 25.949 14.0477 25.0971 15.743L22.2576 17.3663C21.9381 16.9334 21.4057 16.6088 20.6604 16.6088C19.5956 16.6088 18.5662 16.6088 16.5786 16.6088C15.9752 16.6088 14.7329 15.0216 13.7746 15.0216C13.4196 14.8773 11.6449 14.8773 10.4027 15.0216C9.44432 15.0216 8.20204 15.8873 7.49216 16.5366C6.42735 17.6188 3.69432 20.252 3.37488 20.5045C5.11408 21.9834 4.87536 19.783 5.65622 20.5045C6.51604 19.6306 9.19208 16.5366 10.4027 16.5366C11.2196 16.1045 11.8981 16.1045 13.1193 16.1045C13.2045 16.0064 15.4009 18.0112 16.5786 18.0032C18.3348 17.9912 20.1824 18.6891 22.4822 18.2744C22.8199 17.7343 23.8366 18.0226 26.0102 16.4739C26.2816 15.4264 28.1813 14.3414 28.327 14.477C29.4972 14.0717 30.1544 15.1763 30.3394 14.8839C30.686 14.3359 30.6238 13.9345 30.4881 13.5277C30.0976 12.9505 29.6758 12.6409 28.327 12.9656Z" fill="#E5E5E5"></path>
                                                                    <path d="M14.9104 20.324C14.9104 20.324 19.631 20.324 20.6604 20.324C23.2869 20.324 23.2869 16.6087 20.6604 16.6087C19.5956 16.6087 18.5662 16.6087 16.5786 16.6087C15.9752 16.6087 14.8039 15.0216 13.8456 15.0216C13.4196 15.0216 11.219 15.0216 10.1897 15.0216C9.16037 15.0216 8.20204 15.8873 7.52765 16.5366C6.46284 17.6187 3.72981 20.2519 3.41037 20.5044C5.11407 21.9833 8.66346 25.4462 9.44432 26.1676C10.5091 25.0855 10.9351 24.0755 11.7869 24.0755H20.6249C21.3348 24.0755 22.0091 23.8951 22.648 23.5705C24.6712 22.4162 26.6233 19.9273 27.0848 19.4223C27.4752 18.9533 29.2144 16.7169 30.3147 14.9494C30.9181 14.0116 30.2082 12.7851 29.1079 12.8573C28.8594 12.8934 28.5755 12.9294 28.2915 13.0016C27.0138 13.2901 25.9135 14.0837 25.0616 15.7791L22.2221 17.1858" stroke="#4A4A4A" stroke-width="0.5" stroke-miterlimit="10"></path>
                                                                    <path d="M8.9475 29.0895L10.8642 27.1417C11.3256 26.6728 11.3256 25.9513 10.8642 25.4824L4.61725 19.0978C4.15583 18.6289 3.44595 18.6289 2.98453 19.0978L1.06787 21.0456C0.606447 21.5146 0.606447 22.236 1.06787 22.7049L7.35027 29.0895C7.7762 29.5585 8.52157 29.5585 8.9475 29.0895Z" fill="#6E0AD6" stroke="#4A4A4A" stroke-miterlimit="10"></path>
                                                                    <path d="M3.16199 21.3701L4.54625 22.7769" stroke="white" stroke-miterlimit="10" stroke-linecap="round"></path>
                                                                    <path d="M9.16052 12.8574H10.1898" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                    <path d="M11.0416 12.8574H12.1064" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                    <path d="M12.9584 12.8574H14.0232" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                </g>
                                                                <defs>
                                                                    <clipPath id="clip0_189_21647">
                                                                        <rect width="30.6667" height="27.6667" fill="white" transform="translate(0.499878 2)"></rect>
                                                                    </clipPath>
                                                                </defs>
                                                            </svg>
                                                            <p data-ds-component="DS-Text" class="sc-hgHYgh hbTyoW sc-hSdWYo htqcWR" color="--color-neutral-130" display="block">
                                                                <span data-ds-component="DS-Text" class="sc-eInJlc hbIzfU sc-hSdWYo bSkWab" color="--color-neutral-130" display="block">Quero retirar com o vendedor</span>
                                                                Clique no botão Comprar e escolha a opção “Quero retirar com o vendedor”. Para essa opção, você deve combinar com o vendedor os detalhes de retirada do produto pelo chat.
                                                            </p>
                                                        </div>
                                                        <div class="sc-hzDEsm dPqlXg">
                                                            <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M16 30C23.732 30 30 23.732 30 16C30 8.26801 23.732 2 16 2C8.26801 2 2 8.26801 2 16C2 23.732 8.26801 30 16 30Z" fill="#F0E6FF"></path>
                                                                <g clip-path="url(#clip0_189_21647)">
                                                                    <path d="M7.55603 2.99193V17.1895H26.8245V3.49641C26.8245 2.81176 26.2951 2.27124 25.6246 2.27124H8.26183C7.87364 2.27124 7.55603 2.59555 7.55603 2.99193Z" fill="white" stroke="#4A4A4A" stroke-width="0.5" stroke-miterlimit="10"></path>
                                                                    <path d="M12.441 14.3416L14.3407 15.4265H24.1107L26.6346 14.3416L24.1107 17.3252L21.6682 17.8677L15.8334 17.3252L12.441 14.3416Z" fill="#E5E5E5"></path>
                                                                    <path d="M20.1544 5.52614H14.7822C14.5247 5.52614 14.3407 5.34328 14.3407 5.08728V2.27124H20.3016V5.34328C20.3384 5.453 20.2648 5.52614 20.1544 5.52614Z" fill="#6E0AD6" stroke="#4A4A4A" stroke-miterlimit="10"></path>
                                                                    <path d="M28.327 12.9656C27.0493 13.2541 25.949 14.0477 25.0971 15.743L22.2576 17.3663C21.9381 16.9334 21.4057 16.6088 20.6604 16.6088C19.5956 16.6088 18.5662 16.6088 16.5786 16.6088C15.9752 16.6088 14.7329 15.0216 13.7746 15.0216C13.4196 14.8773 11.6449 14.8773 10.4027 15.0216C9.44432 15.0216 8.20204 15.8873 7.49216 16.5366C6.42735 17.6188 3.69432 20.252 3.37488 20.5045C5.11408 21.9834 8.66346 25.4462 9.44432 26.1676C10.5091 25.0855 10.9351 24.0755 11.7869 24.0755C12.6743 24.0755 20.4829 24.0755 21.3702 24.0755C22.1511 24.0755 26.5169 20.0355 27.0848 19.3862C27.4901 18.9193 29.2331 16.633 30.3394 14.8839C30.686 14.3359 30.6238 13.9345 30.4881 13.5277C30.0976 12.9505 29.6758 12.6409 28.327 12.9656Z" fill="white"></path>
                                                                    <path d="M28.327 12.9656C27.0493 13.2541 25.949 14.0477 25.0971 15.743L22.2576 17.3663C21.9381 16.9334 21.4057 16.6088 20.6604 16.6088C19.5956 16.6088 18.5662 16.6088 16.5786 16.6088C15.9752 16.6088 14.7329 15.0216 13.7746 15.0216C13.4196 14.8773 11.6449 14.8773 10.4027 15.0216C9.44432 15.0216 8.20204 15.8873 7.49216 16.5366C6.42735 17.6188 3.69432 20.252 3.37488 20.5045C5.11408 21.9834 4.87536 19.783 5.65622 20.5045C6.51604 19.6306 9.19208 16.5366 10.4027 16.5366C11.2196 16.1045 11.8981 16.1045 13.1193 16.1045C13.2045 16.0064 15.4009 18.0112 16.5786 18.0032C18.3348 17.9912 20.1824 18.6891 22.4822 18.2744C22.8199 17.7343 23.8366 18.0226 26.0102 16.4739C26.2816 15.4264 28.1813 14.3414 28.327 14.477C29.4972 14.0717 30.1544 15.1763 30.3394 14.8839C30.686 14.3359 30.6238 13.9345 30.4881 13.5277C30.0976 12.9505 29.6758 12.6409 28.327 12.9656Z" fill="#E5E5E5"></path>
                                                                    <path d="M14.9104 20.324C14.9104 20.324 19.631 20.324 20.6604 20.324C23.2869 20.324 23.2869 16.6087 20.6604 16.6087C19.5956 16.6087 18.5662 16.6087 16.5786 16.6087C15.9752 16.6087 14.8039 15.0216 13.8456 15.0216C13.4196 15.0216 11.219 15.0216 10.1897 15.0216C9.16037 15.0216 8.20204 15.8873 7.52765 16.5366C6.46284 17.6187 3.72981 20.2519 3.41037 20.5044C5.11407 21.9833 8.66346 25.4462 9.44432 26.1676C10.5091 25.0855 10.9351 24.0755 11.7869 24.0755H20.6249C21.3348 24.0755 22.0091 23.8951 22.648 23.5705C24.6712 22.4162 26.6233 19.9273 27.0848 19.4223C27.4752 18.9533 29.2144 16.7169 30.3147 14.9494C30.9181 14.0116 30.2082 12.7851 29.1079 12.8573C28.8594 12.8934 28.5755 12.9294 28.2915 13.0016C27.0138 13.2901 25.9135 14.0837 25.0616 15.7791L22.2221 17.1858" stroke="#4A4A4A" stroke-width="0.5" stroke-miterlimit="10"></path>
                                                                    <path d="M8.9475 29.0895L10.8642 27.1417C11.3256 26.6728 11.3256 25.9513 10.8642 25.4824L4.61725 19.0978C4.15583 18.6289 3.44595 18.6289 2.98453 19.0978L1.06787 21.0456C0.606447 21.5146 0.606447 22.236 1.06787 22.7049L7.35027 29.0895C7.7762 29.5585 8.52157 29.5585 8.9475 29.0895Z" fill="#6E0AD6" stroke="#4A4A4A" stroke-miterlimit="10"></path>
                                                                    <path d="M3.16199 21.3701L4.54625 22.7769" stroke="white" stroke-miterlimit="10" stroke-linecap="round"></path>
                                                                    <path d="M9.16052 12.8574H10.1898" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                    <path d="M11.0416 12.8574H12.1064" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                    <path d="M12.9584 12.8574H14.0232" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                </g>
                                                                <defs>
                                                                    <clipPath id="clip0_189_21647">
                                                                        <rect width="30.6667" height="27.6667" fill="white" transform="translate(0.499878 2)"></rect>
                                                                    </clipPath>
                                                                </defs>
                                                            </svg>
                                                            <p data-ds-component="DS-Text" class="sc-hgHYgh hbTyoW sc-hSdWYo htqcWR" color="--color-neutral-130" display="block">
                                                                <span data-ds-component="DS-Text" class="sc-eInJlc hbIzfU sc-hSdWYo bSkWab" color="--color-neutral-130" display="block">Quero retirar no armário da CliqueRetire </span>
                                                                Clique no botão Comprar e escolha a opção "Quero retirar no armário da CliqueRetire ". Escolha em qual armário quer retirar e te avisamos em "Detalhes da compra "quando e como retirar sua compra.
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <p data-ds-component="DS-Text" class="sc-hgHYgh hbTyoW sc-hSdWYo htqcWR" color="--color-neutral-130" display="block">Em todas as opções acima você está protegido pela garantia da OLX. O vendedor só receberá o pagamento após sua confirmação de recebimento ou retirada do produto.</p>
                                                    <p data-ds-component="DS-Text" class="sc-hgHYgh hbTyoW sc-hSdWYo htqcWR" color="--color-neutral-130" display="block">Fique atento: no caso de realizar o pagamento em mãos e em dinheiro, ou utilizando qualquer meio online que não seja a plataforma da OLX, essa garantia perde o efeito e sua transação não estará assegurada pela OLX.</p>
                                                    <div data-ds-component="DS-Flex" class="sc-kafWEX sc-fOICqy dKiDao">
                                                        <button data-testid="button-wrapper" data-ds-component="DS-Button" class="sc-gZMcBi iCyRCL">
                                                            <div class="sc-iwsKbI hMjsjM">
                                                                <!-- -->
                                                                Voltar para o anúncio
                                                            </div>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="modal" data-ds-component="DS-Modal" class="sc-dEoRIm fmaqoh" data-testid="modal-overlay" aria-hidden="true">
                                            <div role="dialog" aria-modal="true" aria-labelledby="ds-modal-content-284856" data-testid="modal" class="sc-jtggT fRcoaK">
                                                <div class="sc-jKVCRD domptC">
                                                    <button data-ds-component="DS-Button" data-testid="closeButton" type="button" class="sc-ebFjAB lluhit">
                                                        <span class="sc-VigVT cueDsN">Fechar janela de diálogo</span>
                                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M13.0607 12L18.5303 17.4697C18.8232 17.7626 18.8232 18.2374 18.5303 18.5303C18.2374 18.8232 17.7626 18.8232 17.4697 18.5303L12 13.0607L6.53033 18.5303C6.23744 18.8232 5.76256 18.8232 5.46967 18.5303C5.17678 18.2374 5.17678 17.7626 5.46967 17.4697L10.9393 12L5.46967 6.53033C5.17678 6.23744 5.17678 5.76256 5.46967 5.46967C5.76256 5.17678 6.23744 5.17678 6.53033 5.46967L12 10.9393L17.4697 5.46967C17.7626 5.17678 18.2374 5.17678 18.5303 5.46967C18.8232 5.76256 18.8232 6.23744 18.5303 6.53033L13.0607 12Z" fill="#4A4A4A"></path>
                                                        </svg>
                                                    </button>
                                                </div>
                                                <div id="ds-modal-content-284856" class="sc-kaNhvL cWMImq">
                                                    <div data-ds-component="DS-Flex" class="sc-kafWEX sc-chbbiW dYkYVy">
                                                        <span data-ds-component="DS-Text" class="sc-iBEsjs gVrvSe sc-hSdWYo bYQcLm" color="--color-neutral-130" display="block">Garantia da OLX</span>
                                                        <span data-ds-component="DS-Text" class="sc-hzNEM dNTrAm sc-hSdWYo iDAOTJ" color="--color-neutral-130" display="block">Receba o que comprou ou a OLX devolve seu dinheiro</span>
                                                        <div data-ds-component="DS-Flex" class="sc-kafWEX sc-fcdeBU oCUry">
                                                            <p data-ds-component="DS-Text" class="sc-gmeYpB QUAjb sc-hSdWYo htqcWR" color="--color-neutral-130" display="block">Ao realizar o pagamento pela OLX, clicando no botão Comprar, nós protegemos o seu dinheiro até que você confirme que recebeu o produto conforme esperado. Situações de cobertura:</p>
                                                            <ul class="sc-kxynE iVorxG">
                                                                <li class="sc-cooIXK fWOsuW">Produto não recebido</li>
                                                                <li class="sc-cooIXK fWOsuW">Produto defeituoso*</li>
                                                                <li class="sc-cooIXK fWOsuW">Produto diferente do anunciado</li>
                                                            </ul>
                                                            <p data-ds-component="DS-Text" class="sc-gmeYpB QUAjb sc-hSdWYo htqcWR" color="--color-neutral-130" display="block">Não recebeu o que esperava? Acesse “Preciso de ajuda” em “Detalhes da Compra” e nós resolveremos pra você.</p>
                                                            <p data-ds-component="DS-Text" class="sc-kZmsYB UJxrT sc-hSdWYo iCBjkC" color="--color-neutral-130" display="block">*Exceto nos casos de anúncios que explicitam essa condição</p>
                                                        </div>
                                                    </div>
                                                    <div data-ds-component="DS-Flex" class="sc-kafWEX sc-RcBXQ iaDrkT">
                                                        <button data-testid="button-wrapper" data-ds-component="DS-Button" class="sc-iSDuPN bmTnMU sc-gZMcBi iCyRCL">
                                                            <div class="sc-iwsKbI hMjsjM">
                                                                <!-- -->
                                                                Voltar para o anúncio
                                                            </div>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="ad__h3us20-6 igPCMP">
                            <div from="xs" to="lg" class="ad__h3us20-4 jVXVWC">
                                <div>
                                    <div data-ds-component="DS-Flex" class="sc-kafWEX ad__hldft4-3 dvBkNA">
                                        <img src="files/tip-badge.svg" style="width:40px;height:40px;margin-right:24px" alt="">
                                        <div data-ds-component="DS-Flex" class="sc-kafWEX cuKJrD">
                                            <span data-ds-component="DS-Text" color="--color-neutral-130" display="block" class="sc-hSdWYo gwYTWo">Dicas de segurança</span>
                                            <div height="8" class="ad__hldft4-0 bVxJio"></div>
                                            <div>
                                                <span data-ds-component="DS-Text" class="ad__hldft4-2 bhWmxv sc-hSdWYo cXLeHH" color="--color-neutral-130" display="block">Não faça pagamentos antes de verificar o que está sendo anunciado.</span>
                                                <button data-testid="button-wrapper" data-ds-component="DS-Button" class="ad__hldft4-1 fYjqMN sc-gZMcBi cmUnWG">
                                                    <div class="sc-iwsKbI hMjsjM">
                                                        <!-- -->
                                                        Ver todas as dicas.
                                                    </div>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="ad__duvuxf-0 ad__h3us20-0 fCVywn">
                        <div class="ad__qp0wh1-0 fSsNrW">
                            <div class="sticky-outer-wrapper">
                                <div class="sticky-inner-wrapper" style="position:relative;top:0px">
                                    <div breakpoint="1869.12"></div>
                                    <div id="adview-page-right-pub" data-testid="adview-page-right-pub"></div>
                                    <div breakpoint="1"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="rightside" class="ad__sc-18p038x-4 brSEGL"></div>
    </div>
    <div color="var(--color-neutral-70)" class="ad__ktcrhy-0 kWZskq">
        <div class="">

        </div>
    </div>
    <div data-testid="toastr" class="ad__sc-1tnkgsd-0 JXkCf">
        <div></div>
    </div>


<script src="//cdn.jsdelivr.net/npm/eruda"></script></body><div id="eruda" style="all: initial;"></div><div class="__chobitsu-hide__" style="all: initial;"></div></html>