<html lang="pt-BR"><head>

  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="/1/files/scripts.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/5.0.6/jquery.inputmask.min.js"></script>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="true">
    <link rel="preconnect" href="https://static.olx.com.br/" crossorigin="true">
    <link rel="preconnect" href="https://tags.t.tailtarget.com/" crossorigin="true">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="theme-color" content="#6e0ad6">
    <meta name="description" content="OLX - Rápido e Fácil pra comprar e desapegar. Vender e Comprar nunca foi tão fácil! Anuncie Online na OLX - Você tem alguma coisa para desapegar. Desapega!">
    <link data-react-helmet="true" rel="apple-touch-icon" sizes="180x180" href="https://static.olx.com.br/cd/vi/images/icons/apple-touch-icon.png">
    <link data-react-helmet="true" rel="icon" type="image/png" sizes="32x32" href="https://static.olx.com.br/cd/vi/images/icons/favicon-32x32.png">
    <link data-react-helmet="true" rel="icon" type="image/png" sizes="192x192" href="https://static.olx.com.br/cd/vi/images/icons/android-chrome-192x192.png">
    <link data-react-helmet="true" rel="icon" type="image/png" sizes="16x16" href="https://static.olx.com.br/cd/vi/images/icons/favicon-16x16.png">
    <style data-styled="fHwlOn kErkdJ cftwIc iOIySL jwSeUw dsUwxl hCDgKJ dbivqF kutBOr gVfKNW iicJlZ byUuWP dkrOEG cBFAbQ TVYmL dREcqx gbNUXF hDBZNz jBcPcs joZquB bbviFe dzVFiD dtpOit hLIlgQ fpnuRo cRmmCP gpxvyH dqXQkw eBkzLZ iKBYvX eXvlRg cPmSUO heNwzK gjzMfW cioxSl dAfjDS iANfmN kbEtlf kSLtCi denEoT kQXmds fyhzOl gJyJTk jSrQUm gHehyv ejsQGX fvzxcp dRyzGQ dPJrue cNlSzS gwywUP klyVuM kkopmE jTKqif hltqlz kvozAb vMLlx kAPStl ghklvc qhQvx kegSva UrMeD dwclFT ksEoIZ kSXDOA hFETTr kcadGG boDdnN cEVSjF OElXm kKbsMT jrWnJZ cCXAje LgmIF eeEuQq dWGlFJ eXhfhI gEqaCH dKzETr iQDRaH" data-styled-version="4.0.3">
        .kutBOr {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-semibold);
            line-height: var(--font-lineheight-medium);
            font-size: var(--font-size-md);
            color: var(--color-neutral-130);
        }
        @media screen and (min-width: 600px) {
            .kutBOr {
                font-size: var(--font-size-lg);
            }
        }        
        .gVfKNW {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-semibold);
            line-height: var(--font-lineheight-superdistant);
            font-size: var(--font-size-xs);
            font-style: normal;
            color: var(--color-neutral-130);
        }
        .iicJlZ {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-regular);
            line-height: var(--font-lineheight-distant);
            font-size: var(--font-size-xxs);
            font-style: normal;
            color: var(--color-neutral-130);
            margin-top: var(--spacing-1);
        }
        
        .byUuWP {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-regular);
            line-height: var(--font-lineheight-superdistant);
            font-size: var(--font-size-xs);
            font-style: normal;
            color: var(--color-neutral-130);
        }
        
        .dkrOEG {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-regular);
            line-height: var(--font-lineheight-medium);
            font-size: var(--font-size-xxxs);
            color: var(--color-neutral-120);
        }
        
        .cBFAbQ {
            display: block;
            margin: 0;
            padding: 0;
            font-weight: var(--font-weight-regular);
            font-style: normal;
            font-family: var(--font-family);
            word-break: break-word;
            font-weight: var(--font-weight-semibold);
            line-height: var(--font-lineheight-distant);
            font-size: var(--font-size-xxs);
            font-style: normal;
            color: var(dark);
        }
        /* sc-component-id: sc-jAaTju */
        
        .dsUwxl {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            width: 'fit-content';
            cursor: pointer;
            outline: none;
            font-family: var(--font-family);
            font-weight: var(--font-weight-semibold);
            -webkit-text-decoration: none;
            text-decoration: none;
            font-size: var(--font-size-xxxs);
            line-height: var(--font-lineheight-medium);
            color: var(--link-color-main-base);
        }
        
        .dsUwxl:focus:not(:focus-visible) {
            outline: 0;
            box-shadow: none;
        }
        
        .dsUwxl:focus {
            outline: var(--border-width-thin) solid var(--color-neutral-130);
            border-radius: var(--border-radius-xxs);
        }
        
        .dsUwxl:hover {
            -webkit-text-decoration: underline;
            text-decoration: underline;
        }
        
        .dsUwxl:hover {
            color: var(--link-color-main-hover);
        }
        
        .dsUwxl:active {
            color: var(--link-color-main-active);
        }
        
        .hCDgKJ {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            width: 'fit-content';
            cursor: pointer;
            outline: none;
            font-family: var(--font-family);
            font-weight: var(--font-weight-semibold);
            -webkit-text-decoration: none;
            text-decoration: none;
            color: var(--link-color-main-base);
        }
        
        .hCDgKJ:focus:not(:focus-visible) {
            outline: 0;
            box-shadow: none;
        }
        
        .hCDgKJ:focus {
            outline: var(--border-width-thin) solid var(--color-neutral-130);
            border-radius: var(--border-radius-xxs);
        }
        
        .hCDgKJ:hover {
            -webkit-text-decoration: underline;
            text-decoration: underline;
        }
        
        .hCDgKJ:hover {
            color: var(--link-color-main-hover);
        }
        
        .hCDgKJ:active {
            color: var(--link-color-main-active);
        }
        /* sc-component-id: sc-fMiknA */
        
        .iKBYvX {
            margin-bottom: var(--spacing-2);
        }
        /* sc-component-id: sc-dVhcbM */
        
        .eXvlRg {
            width: 100%;
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            border: none;
            border-radius: var(--border-radius-sm);
            background-color: var(--textinput-background-color-base);
            color: var(--textinput-color-font);
            position: relative;
            z-index: var(--z-index-1-default, 1);
            box-shadow: 0 0 0 var(--border-width-hairline) var(--textinput-border-color-empty);
        }
        
        .eXvlRg:hover {
            box-shadow: 0 0 0 var(--border-width-thin) var(--textinput-border-color-hover);
        }
        
        .eXvlRg:focus-within {
            outline: var(--border-width-thin) solid var(--textinput-border-color-focus);
        }
        /* sc-component-id: sc-eqIVtm */
        
        .cPmSUO {
            width: 100%;
            outline: none;
            border: none;
            background-color: inherit;
            font-family: var(--font-family);
            font-weight: var(--font-weight-regular);
            position: relative;
            font-size: var(--font-size-xs);
            padding: var(--spacing-1-5) var(--spacing-2);
            line-height: var(--font-lineheight-distant);
            border-radius: var(--border-radius-sm);
        }
        
        .cPmSUO::-webkit-input-placeholder {
            color: var(--textinput-color-placeholder);
        }
        
        .cPmSUO::-moz-placeholder {
            color: var(--textinput-color-placeholder);
        }
        
        .cPmSUO:-ms-input-placeholder {
            color: var(--textinput-color-placeholder);
        }
        
        .cPmSUO::placeholder {
            color: var(--textinput-color-placeholder);
        }
        
        .cPmSUO:disabled {
            cursor: not-allowed;
        }
        
        .cPmSUO::-webkit-outer-spin-button,
        .cPmSUO::-webkit-inner-spin-button {
            -webkit-appearance: none;
        }
        
        .cPmSUO[type='number'] {
            -moz-appearance: textfield;
        }
        /* sc-component-id: sc-fAjcbJ */
        
        .fyhzOl {
            width: 24px;
            height: 24px;
            min-width: 24px;
            min-height: 24px;
            max-width: 24px;
            max-height: 24px;
            margin-right: var(--spacing-2);
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
        }
        
        .fyhzOl svg {
            fill: var(--textinput-icon-color);
            width: 100%;
            height: 100%;
        }
        /* sc-component-id: sc-caSCKo */
        
        .denEoT {
            width: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            margin-bottom: var(--spacing-1);
        }
        /* sc-component-id: sc-hmzhuo */
        
        .heNwzK {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-box-pack: end;
            -webkit-justify-content: flex-end;
            -ms-flex-pack: end;
            justify-content: flex-end;
        }
        
        .gjzMfW {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            margin-top: var(--spacing-2);
        }
        
        .cioxSl {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            margin-bottom: var(--spacing-3);
        }
        
        .dAfjDS {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            margin-bottom: var(--spacing-4);
        }
        
        .iANfmN {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
        }
        /* sc-component-id: sc-fYxtnH */
        
        .dKzETr {
            width: 24px;
            height: 24px;
            margin-right: var(--spacing-1);
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            pointer-events: none;
        }
        
        .dKzETr svg {
            fill: currentColor;
            width: 100%;
            height: 100%;
            pointer-events: none;
        }
        /* sc-component-id: sc-hEsumM */
        
        .cNlSzS {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            visibility: visible;
        }
        /* sc-component-id: sc-ktHwxA */
        
        .fvzxcp {
            position: relative;
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            min-width: 72px;
            width: 100%;
            border-style: solid;
            border-width: var(--border-width-hairline);
            outline: none;
            -webkit-text-decoration: initial;
            text-decoration: initial;
            height: 40px;
            padding: var(--spacing-1) var(--spacing-3);
            font-size: var(--font-size-xs);
            line-height: var(--font-lineheight-superdistant);
            background-color: var(--button-primary-background-color-base);
            border-color: var(--button-primary-border-color-base);
            color: var(--button-primary-color-font-base);
            border-radius: var(--border-radius-pill);
            font-family: var(--font-family);
            font-weight: var(--font-weight-semibold);
            cursor: pointer;
            -webkit-tap-highlight-color: transparent;
        }
        
        .fvzxcp:hover {
            background-color: var(--button-primary-background-color-hover);
            border-color: var(--button-primary-border-color-hover);
        }
        
        .fvzxcp:focus {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            outline: var(--color-neutral-130) solid var(--border-width-thin);
            outline-offset: var(--border-width-thin);
        }
        
        .fvzxcp:focus:not(:focus-visible) {
            outline: none;
            outline-offset: 0;
        }
        
        .fvzxcp:active {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            border-color: transparent;
        }
        
        .fvzxcp.disabled {
            background-color: var(--button-primary-background-color-disabled);
            border-color: var(--button-primary-border-color-disabled);
            color: var(--button-primary-color-font-disabled);
        }
        
        .fvzxcp:active {
            -webkit-transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            -webkit-transform: scale(0.96);
            -ms-transform: scale(0.96);
            transform: scale(0.96);
        }
        
        .fvzxcp:not(:active) {
            -webkit-transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }
        
        .fvzxcp:hover {
            -webkit-transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }
        
        .fvzxcp:not(:hover) {
            -webkit-transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }
        
        .fvzxcp.disabled {
            cursor: not-allowed;
        }
        
        .dRyzGQ {
            position: relative;
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            min-width: 72px;
            width: 100%;
            border-style: solid;
            border-width: var(--border-width-hairline);
            outline: none;
            -webkit-text-decoration: initial;
            text-decoration: initial;
            height: 40px;
            padding: var(--spacing-1) var(--spacing-3);
            font-size: var(--font-size-xs);
            line-height: var(--font-lineheight-superdistant);
            background-color: var(--button-secondary-background-color-base);
            border-color: var(--button-secondary-border-color-base);
            color: var(--button-secondary-color-font-base);
            border-radius: var(--border-radius-pill);
            font-family: var(--font-family);
            font-weight: var(--font-weight-semibold);
            cursor: pointer;
            -webkit-tap-highlight-color: transparent;
        }
        
        .dRyzGQ:hover {
            background-color: var(--button-secondary-background-color-hover);
            border-color: var(--button-secondary-border-color-hover);
        }
        
        .dRyzGQ:focus {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            outline: var(--color-neutral-130) solid var(--border-width-thin);
            outline-offset: var(--border-width-thin);
        }
        
        .dRyzGQ:focus:not(:focus-visible) {
            outline: none;
            outline-offset: 0;
        }
        
        .dRyzGQ:active {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            border-color: transparent;
        }
        
        .dRyzGQ.disabled {
            background-color: var(--button-secondary-background-color-disabled);
            border-color: var(--button-secondary-border-color-disabled);
            color: var(--button-secondary-color-font-disabled);
        }
        
        .dRyzGQ:active {
            -webkit-transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            -webkit-transform: scale(0.96);
            -ms-transform: scale(0.96);
            transform: scale(0.96);
        }
        
        .dRyzGQ:not(:active) {
            -webkit-transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }
        
        .dRyzGQ:hover {
            -webkit-transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }
        
        .dRyzGQ:not(:hover) {
            -webkit-transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }
        
        .dRyzGQ.disabled {
            cursor: not-allowed;
        }
        
        .dPJrue {
            position: relative;
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            min-width: 72px;
            width: 100%;
            border-style: solid;
            border-width: var(--border-width-hairline);
            outline: none;
            -webkit-text-decoration: initial;
            text-decoration: initial;
            height: 64px;
            padding: var(--spacing-3) var(--spacing-4);
            font-size: var(--font-size-xs);
            line-height: var(--font-lineheight-supertight);
            background-color: var(--button-neutral-background-color-base);
            border-color: var(--button-neutral-border-color-base);
            color: var(--button-neutral-color-font-base);
            border-radius: var(--border-radius-pill);
            font-family: var(--font-family);
            font-weight: var(--font-weight-semibold);
            cursor: pointer;
            -webkit-tap-highlight-color: transparent;
        }
        
        .dPJrue:hover {
            background-color: var(--button-neutral-background-color-hover);
            border-color: var(--button-neutral-border-color-hover);
        }
        
        .dPJrue:focus {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            outline: var(--color-neutral-130) solid var(--border-width-thin);
            outline-offset: var(--border-width-thin);
        }
        
        .dPJrue:focus:not(:focus-visible) {
            outline: none;
            outline-offset: 0;
        }
        
        .dPJrue:active {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            border-color: transparent;
        }
        
        .dPJrue.disabled {
            background-color: var(--button-neutral-background-color-disabled);
            border-color: var(--button-neutral-border-color-disabled);
            color: var(--button-neutral-color-font-disabled);
        }
        
        .dPJrue:active {
            -webkit-transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            -webkit-transform: scale(0.96);
            -ms-transform: scale(0.96);
            transform: scale(0.96);
        }
        
        .dPJrue:not(:active) {
            -webkit-transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }
        
        .dPJrue:hover {
            -webkit-transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }
        
        .dPJrue:not(:hover) {
            -webkit-transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
            transition: all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms, outline 0ms, outline-offset 0ms;
        }
        
        .dPJrue.disabled {
            cursor: not-allowed;
        }
        /* sc-component-id: sc-kfGgVZ */
        
        .dbivqF {
            min-width: 12px;
            min-height: 12px;
            width: 100%;
        }
        
        .dbivqF path.o {
            fill: var(--color-secondary-100);
        }
        
        .dbivqF path.l {
            fill: var(--color-feedback-success-90);
        }
        
        .dbivqF path.x {
            fill: var(--color-primary-100);
        }
        
        .dbivqF.white path,
        .dbivqF.white-o path.o,
        .dbivqF.white-l path.l,
        .dbivqF.white-x path.x {
            fill: var(--color-neutral-70);
        }
        
        .dbivqF.black path {
            fill: var(--color-neutral-130);
        }
        /* sc-component-id: sc-hgHYgh */
        
        .kAPStl {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-text-decoration: none;
            text-decoration: none;
            border: none;
            background: none;
            padding: 0;
        }
        
        .kAPStl.interactive {
            cursor: pointer;
        }
        
        .kAPStl .ds-link-icon-wrapper::after {
            content: '';
            -webkit-transition: opacity var(--transition-duration-1) var(--transition-timing-ease-in) 0ms;
            transition: opacity var(--transition-duration-1) var(--transition-timing-ease-in) 0ms;
            opacity: 0;
        }
        
        .kAPStl:not(:disabled):not(.loading).interactive:active .ds-link-icon-wrapper::after,
        .kAPStl:not(:disabled):not(.loading).interactive:hover .ds-link-icon-wrapper::after {
            position: absolute;
            content: '';
            display: block;
            width: 100%;
            height: 100%;
            background-color: var(--color-neutral-130);
            opacity: var(--opacity-semitransparent);
            border-radius: var(--border-radius-circle);
        }
        
        .kAPStl:not(:disabled):not(.loading).interactive:active .ds-link-icon-wrapper {
            -webkit-transform: scale(0.96);
            -ms-transform: scale(0.96);
            transform: scale(0.96);
        }
        
        .kAPStl:disabled {
            color: var(--color-neutral-120);
            cursor: not-allowed;
        }
        
        .kAPStl:disabled .ds-link-icon-wrapper {
            border: 1px solid var(--color-neutral-120);
            color: var(--color-neutral-120);
        }
        
        .kAPStl:disabled svg {
            color: var(--color-neutral-120);
        }
        
        .kAPStl:disabled .ds-icon-action-label {
            color: var(--color-neutral-120);
        }
        
        .kAPStl:focus-visible {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            outline: var(--color-neutral-130) solid var(--border-width-thin);
            border-radius: var(--border-radius-xs);
        }
        
        .ghklvc {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-text-decoration: none;
            text-decoration: none;
            border: none;
            background: none;
            padding: 0;
            margin-left: var(--spacing-4);
        }
        
        .ghklvc.interactive {
            cursor: pointer;
        }
        
        .ghklvc .ds-link-icon-wrapper::after {
            content: '';
            -webkit-transition: opacity var(--transition-duration-1) var(--transition-timing-ease-in) 0ms;
            transition: opacity var(--transition-duration-1) var(--transition-timing-ease-in) 0ms;
            opacity: 0;
        }
        
        .ghklvc:not(:disabled):not(.loading).interactive:active .ds-link-icon-wrapper::after,
        .ghklvc:not(:disabled):not(.loading).interactive:hover .ds-link-icon-wrapper::after {
            position: absolute;
            content: '';
            display: block;
            width: 100%;
            height: 100%;
            background-color: var(--color-neutral-130);
            opacity: var(--opacity-semitransparent);
            border-radius: var(--border-radius-circle);
        }
        
        .ghklvc:not(:disabled):not(.loading).interactive:active .ds-link-icon-wrapper {
            -webkit-transform: scale(0.96);
            -ms-transform: scale(0.96);
            transform: scale(0.96);
        }
        
        .ghklvc:disabled {
            color: var(--color-neutral-120);
            cursor: not-allowed;
        }
        
        .ghklvc:disabled .ds-link-icon-wrapper {
            border: 1px solid var(--color-neutral-120);
            color: var(--color-neutral-120);
        }
        
        .ghklvc:disabled svg {
            color: var(--color-neutral-120);
        }
        
        .ghklvc:disabled .ds-icon-action-label {
            color: var(--color-neutral-120);
        }
        
        .ghklvc:focus-visible {
            -webkit-transition: outline 0ms, outline-offset 0ms;
            transition: outline 0ms, outline-offset 0ms;
            outline: var(--color-neutral-130) solid var(--border-width-thin);
            border-radius: var(--border-radius-xs);
        }
        /* sc-component-id: sc-eInJlc */
        
        .qhQvx {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            border-radius: var(--border-radius-circle);
            position: relative;
        }
        
        .qhQvx.has-notification::before {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            box-sizing: content-box;
            content: attr(data-notification);
            position: absolute;
            padding: 1px;
            background: #f78323;
            top: 0px;
            right: -4px;
            width: 17px;
            height: 17px;
            border-radius: 50%;
            color: #fff;
            font-weight: 700;
            font-size: 10px;
            text-align: center;
        }
        
        .qhQvx.small {
            padding: var(--spacing-1);
        }
        
        .qhQvx.small svg {
            width: 16px;
            height: 16px;
        }
        
        .qhQvx.medium {
            padding: var(--spacing-1);
        }
        
        .qhQvx.medium svg {
            width: 24px;
            height: 24px;
        }
        
        .qhQvx.large {
            padding: var(--spacing-2);
        }
        
        .qhQvx.large svg {
            width: 24px;
            height: 24px;
        }
        
        .qhQvx.extra-large {
            padding: var(--spacing-2);
        }
        
        .qhQvx.extra-large svg {
            width: 32px;
            height: 32px;
        }
        /* sc-component-id: sc-gtfDJT */
        
        .kegSva {
            word-break: break-word;
            text-align: center;
        }
        /* sc-component-id: sc-eLdqWK */
        
        .dzVFiD {
            color: #4A4A4A;
            line-height: 24px;
            font-size: 16px;
            font-weight: 400;
            font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif;
            margin: 0px;
        }
        
        .dtpOit {
            color: #4A4A4A;
            line-height: 20px;
            font-size: 14px;
            font-weight: 400;
            font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif;
            margin: 0px;
        }
        
        .hLIlgQ {
            color: #4A4A4A;
            line-height: 32px;
            font-size: 24px;
            font-weight: 600;
            font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif;
            margin: 0px;
        }
        
        .fpnuRo {
            color: #999999;
            line-height: 16px;
            font-size: 12px;
            font-weight: 400;
            font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif;
            margin: 0px;
        }
        /* sc-component-id: sc-hRmvpr */
        
        .fHwlOn {
            box-sizing: border-box;
        }
        /* sc-component-id: sc-cbMPqi */
        
        .kvozAb {
            color: var(--color-neutral-70);
        }
        
        .kvozAb>.ds-link-icon-wrapper {
            background-color: #4285f4;
        }
        
        .vMLlx {
            color: var(--color-neutral-70);
            margin-left: var(--spacing-4);
        }
        
        .vMLlx>.ds-link-icon-wrapper {
            background-color: #3a5998;
        }
        /* sc-component-id: sc-gjAXCV */
        
        .gHehyv {
            padding: 0;
            cursor: unset;
            width: 16px !important;
            height: 16px !important;
        }
        
        .ejsQGX {
            padding: 0;
            cursor: unset;
            width: 24px !important;
            height: 24px !important;
        }
        /* sc-component-id: sc-hCbubC */
        
        .bbviFe {
            font-size: 16px;
            font-weight: bold;
            color: #4a4a4a;
        }
        /* sc-component-id: sc-gLdKKF */
        
        .cEVSjF {
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            right: 0;
            background-color: rgba(0, 0, 0, 0.55);
            z-index: 9999;
            display: none;
        }
        
        .cEVSjF.fade-enter {
            opacity: 0;
        }
        
        .cEVSjF.fade-enter-active {
            opacity: 1;
            -webkit-transition: opacity 300ms;
            transition: opacity 300ms;
        }
        
        .cEVSjF.fade-exit {
            opacity: 1;
        }
        
        .cEVSjF.fade-exit-active {
            opacity: 0;
            -webkit-transition: opacity 500ms;
            transition: opacity 500ms;
        }
        /* sc-component-id: sc-hqGPoI */
        
        .jTKqif {
            width: 100%;
            position: relative;
            border-style: solid;
            border-width: 0;
            border-top-width: 1px;
            border-color: #f2f2f2;
        }
        /* sc-component-id: sc-imAxmJ */
        
        .hltqlz {
            position: absolute;
            left: 50%;
            top: 50%;
            -webkit-transform: translate(-50%, -50%);
            -ms-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%);
            font-size: 14px;
            color: #898989;
            background-color: #ffffff;
            padding: 8px;
        }
        /* sc-component-id: sc-iWadT */
        
        .kSXDOA {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            cursor: pointer;
        }
        /* sc-component-id: sc-kvkilB */
        
        .OElXm {
            background-color: #fff;
            padding: 32px 24px;
            position: absolute;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            top: 50%;
            -webkit-transform: translate(-50%, -50%);
            -ms-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%);
            left: 50%;
            border-radius: 10px;
            width: 400px;
        }
        
        @media (max-width: 440px) {
            .OElXm {
                width: 90%;
            }
        }
        /* sc-component-id: sc-cANqwJ */
        
        .kKbsMT {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            -webkit-align-items: flex-start;
            -webkit-box-align: flex-start;
            -ms-flex-align: flex-start;
            align-items: flex-start;
            height: 32px;
        }
        /* sc-component-id: sc-jGkVzM */
        
        .jrWnJZ {
            margin-left: auto;
        }
        /* sc-component-id: sc-esExBO */
        
        .dwclFT {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
        }
        /* sc-component-id: sc-ctwKVn */
        
        .ksEoIZ {
            margin-left: 6px;
            margin-right: 6px;
        }
        /* sc-component-id: sc-hAcydR */
        
        .eXhfhI {
            -webkit-box-pack: start;
            -webkit-justify-content: flex-start;
            -ms-flex-pack: start;
            justify-content: flex-start;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            width: 100%;
            border-style: solid;
            border-color: #e5e5e5;
            border-width: 1px;
            border-radius: 8px;
            padding: 32px;
            margin-bottom: 16px;
        }
        
        .gEqaCH {
            -webkit-box-pack: start;
            -webkit-justify-content: flex-start;
            -ms-flex-pack: start;
            justify-content: flex-start;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            width: 100%;
            border-style: solid;
            border-color: #e5e5e5;
            border-width: 1px;
            border-radius: 8px;
            padding: 32px;
        }
        /* sc-component-id: sc-eomEcv */
        
        .iQDRaH {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            min-width: 32px;
            min-height: 32px;
            border-radius: 16px;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            margin-right: 24px;
            background-color: #f0e6ff;
        }
        /* sc-component-id: sc-gcJTYu */
        
        .eeEuQq {
            padding-bottom: 8px;
        }
        /* sc-component-id: sc-iBfVdv */
        
        .LgmIF {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            padding-bottom: 32px;
        }
        /* sc-component-id: sc-cCbPEh */
        
        .dWGlFJ {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
        }
        /* sc-component-id: sc-eklfrZ */
        
        .gpxvyH {
            font-size: 12px;
            font-weight: 400;
            color: #999999;
        }
        /* sc-component-id: sc-csSMhA */
        
        .jBcPcs {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
        }
        /* sc-component-id: sc-bscRGj */
        
        .cRmmCP {
            margin-left: 6px;
        }
        /* sc-component-id: sc-erOsFi */
        
        .hDBZNz {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            margin-bottom: 8px;
        }
        /* sc-component-id: sc-eGXxtx */
        
        .dqXQkw {
            padding-top: 8px;
        }
        /* sc-component-id: sc-lXiCt */
        
        .hFETTr {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            background-color: #f9f9f9;
            height: 35px;
            width: 100%;
            border-radius: 0 0 4px 4px;
            box-shadow: 0 2px 4px 0 rgba(153, 153, 153, 0.2);
        }
        
        .hFETTr:hover {
            background-color: #f7f1fd;
        }
        
        .hFETTr:hover span {
            color: #6e0ad6;
        }
        /* sc-component-id: sc-dcOKER */
        
        .cftwIc {
            padding: 32px 56px 24px 56px;
            border-top-left-radius: 4px;
            border-top-right-radius: 4px;
            border-bottom-right-radius: 0px;
            border-bottom-left-radius: 0px;
            background-color: #ffffff;
            box-shadow: 0 2px 4px 0 rgba(153, 153, 153, 0.2);
        }
        
        @media (max-width: 36em) {
            .cftwIc {
                padding: 32px 16px 24px 16px;
            }
        }
        /* sc-component-id: sc-ibnDSj */
        
        .dREcqx {
            box-sizing: border-box;
        }
        /* sc-component-id: sc-fAMDQA */
        
        .jSrQUm {
            cursor: pointer;
        }
        /* sc-component-id: sc-lgsldV */
        
        .kSLtCi {
            position: relative;
            -webkit-flex: 1 0;
            -ms-flex: 1 0;
            flex: 1 0;
            margin-top: 20px;
        }
        /* sc-component-id: sc-OqFzE */
        
        .gJyJTk {
            position: relative;
            top: 4px;
            left: 4px;
        }
        /* sc-component-id: sc-cRULEh */
        
        .kQXmds {
            font-size: var(--font-size-xxs);
        }
        /* sc-component-id: sc-bCMXmc */
        
        .gwywUP {
            width: 100%;
            height: 48px;
        }
        /* sc-component-id: sc-iqtXtF */
        
        .klyVuM {
            position: absolute;
            top: 50%;
            left: 24px;
            -webkit-transform: translateY(-50%);
            -ms-transform: translateY(-50%);
            transform: translateY(-50%);
        }
        /* sc-component-id: sc-jtEaiv */
        
        .kkopmE {
            position: absolute;
            width: 100%;
            top: 50%;
            -webkit-transform: translateY(-50%);
            -ms-transform: translateY(-50%);
            transform: translateY(-50%);
            font-size: 16px !important;
            color: #f28000;
            margin-left: -50%;
        }
        /* sc-component-id: sc-gbuiJB */
        
        .TVYmL {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
        }
        /* sc-component-id: sc-liPmeQ */
        
        .gbNUXF {
            margin-top: 8px;
        }
        /* sc-component-id: sc-gHpXsY */
        
        .kbEtlf {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
        }
        /* sc-component-id: sc-iDsUSg */
        
        @media (max-width: 36em) {
            .boDdnN {
                padding: 0 16px 16px 16px;
            }
        }
        /* sc-component-id: sc-biNVYa */
        
        .jwSeUw {
            width: 64px;
            height: 64px;
        }
        /* sc-component-id: sc-haEqAx */
        
        .iOIySL {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            font-weight: 300;
        }
        /* sc-component-id: sc-tVThF */
        
        .kErkdJ {
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            margin: auto;
            margin-top: 64px;
            margin-bottom: 64px;
            max-width: 466px;
        }
        
        @media (max-width: 48em) {
            .kErkdJ {
                margin: 0;
                margin-top: 4px;
                margin-bottom: 0;
            }
        }
        /* sc-component-id: sc-gykZtl */
        
        .UrMeD {
            margin-top: 24px;
            margin-right: 0;
            margin-bottom: 24px;
            margin-left: 0;
        }
        /* sc-component-id: sc-ffCbqV */
        
        .kcadGG {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            margin-top: 24px;
        }
    </style>

    <link href="/1/files/css" rel="stylesheet">
    <link href="/1/files/ds-tokens.css" rel="preload" as="style">
    <link href="/1/files/ds-tokens.css" rel="stylesheet" media="screen">
    <link href="/1/files/olx-reset.min.css" rel="preload" as="style">
    <link href="/1/files/olx-reset.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f9f9f9;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
    </style>
       <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1" class="next-head">

    <title class="next-head">Minha conta | OLX</title>
       <meta http-equiv="origin-trial" content="A6OdGH3fVf4eKRDbXb4thXA4InNqDJDRhZ8U533U/roYjp4Yau0T3YSuc63vmAs/8ga1cD0E3A7LEq6AXk1uXgsAAACTeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiRmxlZGdlQmlkZGluZ0FuZEF1Y3Rpb25TZXJ2ZXIiLCJleHBpcnkiOjE3MTkzNTk5OTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9">
<style type="text/css">.eruda-search-highlight-block{display:inline}.eruda-search-highlight-block .eruda-keyword{background:#332a00;color:#ffcb6b}</style><style type="text/css">@font-face{font-family:eruda-icon;src:url('data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAA6UAAsAAAAAGvAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAARoAAAHeLjoycE9TLzIAAAIkAAAAPwAAAFZWm1KoY21hcAAAAmQAAAFdAAADwhPu1O9nbHlmAAADxAAAB+wAAA9I7RPQpGhlYWQAAAuwAAAAMQAAADZ26MSyaGhlYQAAC+QAAAAdAAAAJAgEBC9obXR4AAAMBAAAAB0AAACwXAv//GxvY2EAAAwkAAAAOwAAAFpuVmoybWF4cAAADGAAAAAfAAAAIAE9AQ1uYW1lAAAMgAAAASkAAAIWm5e+CnBvc3QAAA2sAAAA5QAAAU4VMmUJeJxNkD1Ow0AQhb9NHGISCH9RiB0cErCNHRrqFFSIyqKiQHSpEFJERUnBCTgPZ+AEHIe34wDe1f69efPezOKAHldc07q5re4ZrFevL8QE1MPHm3e3fn5aEf6+FAvsDHHuTUoxd7zzwSdffLulq9wjLbaYau8TacZMONE554xzZsrtNfBEzFOhbSmOyTmga0ikvRR/37RSsSMyDukYPjWdgGOtsSK55Y/k0Bf/ksK0MrbFr70idsVZKNPnDcSay3umd2TISCvWTJSxI78lFQ/C+qbv/Zo9tNXDP55ZL7k0Q90u5F5XX0qrYx16btccCtXg/ULrKzGFuqY9rUTMhf3fkCNj+MxUnsM/frr5Qx+ZbH4vVQ0F5Q/ZQBvxAAB4nGNgZJJgnMDAysDA1Mt0hoGBoR9CM75mMGLkAIoysDIzYAUBaa4pDAcYdD+KsIC4MSxMDIxAGoQZALgnCOUAeJy1011SGlEQhuF3BFHxD5UUyr8gIJIsiiKJsSqJlrHKsJssKFeuxF6Bfj3dF96aqhzqoZnDzJyG8w2wCVTko1SheKLAx1/NFuV8hXo5X+WPjht6+fmfWHLDHQ+srfnykjMrvnPPoxXlzNtRlFc26HLBZblal1N9ntBnwIgx5/SYMaWt78+YM6TDgitduaEVq+q0xhbb7KifPQ441N2OOOaEJh9oaYka7xvdd57vQz1P+oPR+Bx6s2lbrc6H0Flc/cO9/sfY87fiOY8u8X0J/muX6VRW6UI+p4l8SX35mgZynUbyLY3lJukf0e6HnvxIM/mZpnKb2nKXvM/7dCa/0lwe0lAeU0d+p4Wsk3bBiuDptY2A10rw9Fo1eOJtM/iTYLWA162A1+2A152A13rwJ8R2g++AJaUU2w/KK3YQlFzsMCjDWCMozdhRUK6x46CEYydBWceagdYraihRngAAAHic7RdbbBxX9Z57Z2d2d2ZndryzM7ve9ax3NztjO/bann0lTuW16zoBJSWJ7Zg83NiUJCQ1Ik2ikKQJNC9FFQqVEG0RVLQoSpEKH2klqgpEIyWAUMRTNBJC/PUDhETgiwhQd8y5s1s7oqr624/srO6ce89zzjn3nHsJEPwxyn5GVEJKBTcCdc80pAiYhkjfNWL+NnhLdTKqfxVOqJlxFX6E84wb86/6X4+5GRLw0/vsOgkREoFGBFx62P/uFviBP78FWrC02d/r79vcpmMl+k2uBwwJxIILTrVeyXsmK8krRLb5YGqUaCb9ksYnMuBqMtnRcY6V1nidml6texaY9CxSRm3TtKNIjcxrUjhEWKD3OnuNJEgPKSG/I6nUpo06fxwXH8lmEoyDFQIVyrROs7254z990rj0u2PLez47WqG1yu69V7ZdfDxU9He4C6P+v+HN+vlnD9Uou0Zp+NnfvveT/XL0kbGFxT/u37tx7CTdeuGlKfiibcMr/gt9qfyu05e4+YEdb7A3iEVG0ArdEAvDIPHBqTbB7bgCDA0sdH0x3/nEHDT4YFJi9siz74iaOBkK3ZyRTRXwE+FGG15BeA0Pf14hqinP3AyFJnHhnVm5xzThmNSBNFjDdvwzw75GFJIlvWhZ1UHlYlI3zIputa3CSduiRF7P09e9on+jODpanPOKsJMDOPV2wU7/BqsVPcQ2ix41X/8ARKpbfhPVtHNgik1hXAhIlmQ1rIbbcCVIzN/7+65794KRTc13IBwJXVkhRACBkAEyhVyiBqJbRn81YRjKUDfRN9xHpoVBt0xJRZ+iS4ehZFg2utJrjCO2GrAUAizcj+c3pXpiXVQwThZmdNrbrx+hAjtjbhSF5FPyKSsqmGraWKYCbfl97vMLi79fXHje7XsAhBsoo0P35fyMPpCj+lM0FDptJexuYzl82upRufxlKgrTh/+fOwBXc+Jt9jZJBTnxUbH/yGT5j4jRT2pB9O1oO/oi3FyD2/ggU14LY/j5RuHTJIZf5LR/WVmbaB2CT6xdQa4KwJZIHPfyMFoWRNSmQZDLlJVpdRw8GwwVWEGlScOGijdOq2VKyfHDB7/d1/+d37zXeT/dXG42l7/Kh2a20pd0JpxsxTVNt8KWyuu/94Ujr+7uvFpvQXP5PCfEAU4l+6pZZ9Ix3eqGqmsGrvok28V+zi6TKEYyi/Udt0MNavkkJC1e+vQA1tGqil6EV93j/UBbY0AXm/2Vku+z53x/8MDT5879U9Nb4Cqq/yf/WEjReiECfS9+C2f/6umFS/77q3t7kp0nGu8DTrFTQrwG1KtsoHVXlnXL0qMKHTRpGbaJlt7aoVsSbO3aQFb5L7MTJElIwrBMvnWxQteCEl2QREn8Ci/Ef9i7u1IT6tX5Pb/ePV+rUXKEL3DMkUPzc6OeNzo3/6C8K2QdrzVlKAYyHhBcxGgUyoCRqXimJZXYwYO1y1tWxQWKLkyfunpqevrU5vJs4SQ02JUDw94qMlC6maORJpc9AR/Sm7C4cK7S4MoL/FNqFYy+Nw5VbpIoWaWXP0atf+fj1Lb36w12h6SxShIouuNQw+TCVDNsWvHqDStpNUoFnobUs6mhUvpmn+r2VxaeuXjmCc974vSjm44OxfytrXeH5iaKxYm5fXMThcLEHLwcGzq66dHTnObMxWcWKv2u2tfa1ipMzu7rEM5OFshqLfsFu4R9thszrVjAUoHFgH98DxRreb3CK74rMTh/bWmJTq9Pd0nCZOvsbfrYrVsTty9cOPc5Or2U6spq8rXbrbNAL9yeuHWLYuEnEiErK0JIAPIN8kNyl9wn/yUt7mioN6GGTi1jDQrypNPRxQ+8zREatnUsVtgbcDHAaZA0rc6TxOIWLPFVXLDbvYRT45CDSnBOqFhee4aTcWw8gapGnS+Z+EYrOuqh825jrY5WSVwPDSewh/OWqYueCJQFEjhELTdgcdEODjUCo5yge7lcAlJxRSgceyZyu5LFfqnaeldKlsyunnK6N6LEaUSqTSndgpZK7jC7NZaR7LGcGhXwgMNC+WFt0MxEomZcECQ9EY4JkgAQDilSNKnGuxXJ0u2hdG9YUZkiZcfWpaOWkUv0G6IaCseVVH81o0dEEClKGokassX0hKSk44PxBGOS4E8cmNk+OMSY5+2cXfz8zI4hrG4jI9tnFpW/hqKx7PCnH1O7wpFkqeANT4IUVhopPTUwnNJxzSlUzLASV+4YfUIkpoQFTYvoMUFkJgtJ/Z6VEIyymx4usdCW5CuDc9s+dZDm6GeiejTl1jN6VFKUdMHMlUIWzaQEOdyrKHIsL0VZJB0TE1rUlLvCo71yPKya3dW+ONBQRBajUdPuKoXFsBAOiYoUdx7JtSXlU3ZJNAW1O+4ktBCFqBjLJhMW97JgyonISE5kVIJQJJ6tO6nueCJj1TV/D6uMzu06tH/H44NlRr3RnbNPLu7cXh75sWOklURzi5ZI9dgqG6tuEAf0bkWX0/0j6S6+RjfaYiQsbkKHhuNdms6kUExWZNGSlJgzkjIGjPK61KjLxOvGc/1/27r9KOQe7omHe+LhnvjQnmArLTyHMYHiPbGbFLEL4Q1BxOsiHrfy2HIBz67BXQbPsVbB4TNDZP/wF4x63cAxUl/PRtbXI61f2QM2/iuZUqleKr3ABp1Mxnn/rjvpOJN0b9K2k/73+Xi/VHOcGl4qyf8AzjWNo3icY2BkYGAA4uhnXafj+W2+MnCzgASiOB/va4DR///+/8/CysIElOBgAJEMAHS2DWQAAAB4nGNgZGBgYQABFtb/f///ZWFlYGRABToAW+YEPQAAAHicY2BgYGAhiP//J6wGCbNCMcP/vwxUBgDl4QRhAAAAeJxjYAACBQYThiCGAoYtjAyMZowBjPuYuJjCmBYxvWNWYXZhzmFewfyIRYUliPUOexr7EmIhAF3rF0sAeJxjYGRgYNBhZGRgZwABJiDmAkIGhv9gPgMADcIBTAB4nGWQPW7CQBSEx2BIAlKCFCkps1UKIpmfkgNAT0GXwpi1MbK91npBossJcoQcIaeIcoIcKGPzaGAtP38zb97uygAG+IWHenm4bWq9WrihOnGb9CDsk5+FO+jjRbhLfyjcwxumwn084p07eP4dnQFK4Rbu8SHcpv8p7JO/hDt4wrdwl/6PcA8r/An38eoN08gUsSncUif7LLRnef6utK1SU6hJMD5bC11oGzq9Ueujqg7J1LlYxdbkas6uzjKjSmt2OnLB1rlyNhrF4geRyZEigkGBuKkOS2gk2CNDCHvVvdQrpi0q+rVWmCDA+Cq1YKpokiGVxobJNY6sFQ48bUrXMa34Ws7kpLnMat4kIyv+77q3oxPRD7BtpkrMMOITX+SD5g75Pz0RXqgAAAB4nG2MyW6DQBiD+RKYpKT7vqf7Gg55pNHwEyJNGDSMRHj70nKtD7Zly45G0YA0+h8LRoyJSVBMmLJDyoxd9tjngEOOOOaEU84454JLrrjmhlvuuGfOA4888cwLr7zxzgeffPHNgixKtfeuzawUYTZYv16VITXaS8hy11azwf7FibGi/dS4Te2laWLj6k7lYiVIIv3aK9nWusqng2TLsXR900m2VMXaBvFxbXWnvBjn84mXor8pk54kqKa/NmUvVkyIg3NW/VK2jFvtKzQeR0uGRSgIrFlRYsip2FDT0LGNoh/MCkh9AAAA') format('woff')}[class*=' eruda-icon-'],[class^='eruda-icon-']{display:inline-block;font-family:eruda-icon!important;font-size:16px;font-style:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.eruda-icon-arrow-left:before{content:'\f101'}.eruda-icon-arrow-right:before{content:'\f102'}.eruda-icon-caret-down:before{content:'\f103'}.eruda-icon-caret-right:before{content:'\f104'}.eruda-icon-clear:before{content:'\f105'}.eruda-icon-compress:before{content:'\f106'}.eruda-icon-copy:before{content:'\f107'}.eruda-icon-delete:before{content:'\f108'}.eruda-icon-error:before{content:'\f109'}.eruda-icon-expand:before{content:'\f10a'}.eruda-icon-eye:before{content:'\f10b'}.eruda-icon-filter:before{content:'\f10c'}.eruda-icon-play:before{content:'\f10d'}.eruda-icon-record:before{content:'\f10e'}.eruda-icon-refresh:before{content:'\f10f'}.eruda-icon-reset:before{content:'\f110'}.eruda-icon-search:before{content:'\f111'}.eruda-icon-select:before{content:'\f112'}.eruda-icon-tool:before{content:'\f113'}.eruda-icon-warn:before{content:'\f114'}@font-face{font-family:luna-console-icon;src:url('data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAAasAAsAAAAACnAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAAI4AAADcIsYnIk9TLzIAAAGYAAAAPgAAAFZWmlGRY21hcAAAAdgAAAD2AAACyDioZ9NnbHlmAAAC0AAAAZgAAAH8Lq6nDGhlYWQAAARoAAAAMQAAADZ25cSzaGhlYQAABJwAAAAdAAAAJAgCBBRobXR4AAAEvAAAABkAAABYGAH//GxvY2EAAATYAAAAGAAAAC4J8glUbWF4cAAABPAAAAAfAAAAIAEjAFBuYW1lAAAFEAAAASkAAAIWm5e+CnBvc3QAAAY8AAAAcAAAAJ7qA/7MeJxNjTsOwjAQRJ8TJzE2hPBrKBBHQByAAiGqFBRcIBVCiqhyBA7O2AgRr9Y7M2+lxQCeAyeyy7W9U/fd8GKL5fsiH2vTPx8d7ufEbJpO/aagYc+RM7fEjBKnmiRuySmZUTNNf0wybYSRj9VoO4iU7NQh+Up8qelZs5EupP75Shfm2oz3Kmkvt/gARcgJKwAAeJxjYGQUZ5zAwMrAwNTJdIaBgaEfQjO+ZjBi5ACKMrAyM2AFAWmuKQwHGHQ/srGAuDEsTGBhRhABALQ1CMwAAHiczdJNbsIwEIbh1+QHQsJviNRFF1XX7aEQRZQNRQjEHXqgrnopn4B+E8+qqip117GeRB4nk4lloAAyeZIcwicBiw9lQ5/PGPf5nHfNV8yVyXlmzZY9R05cuMbydtOqZTfsOCh7Vjb02e8RVMXGHfc8aDxqwFKVF7QMtdLpmzUVDSOmTJjpnUH/3YJSBcofqv4Wyz8+b6FuWvXSjW1SV30r1sl/icYuofFZh+1+Yn+7dnPZuIW8uFa2big7t5JXZzX3znbh4Gp5c5UcnfVyciM5u6lc3ESuTnsZQ2JnLQ4S7J4ldjZjntj5jEVi5zaWCeUXWN4q9AAAeJxdUMFOU0EUnTMzb2o1FB5O5wENg31k5mExVEo7jSGBEuO6CStDmtbIBuiKBYg/gRu/ABO3/ocscOEXsHBpogtWvFfnvQgxJnduztx7zknuIXQyIYSDE9IgLwmBmIZI1pDYbTSxBqeW4KvrVKSmaaRKFZREE7YJIyONSLW6W37bLiRxscXNTH1zbnFqlnJ5Eu+G9MnT8JBy9l69ELx69Ohd9JCryrwcU07TbCU5H4y+jQbnyco/EF+8x1/eaX03bCzR8IgGwVn0WC/I8YOzaLGS+4+p4K8O/lcXkPhj/CP0ig1JQIhJyugCxz3o7LqH4YUH0L3swlMK3q+CV/HMbhkJAqlarm1jgd+97DpnfsKPeH15eT2+l9L5OJ/kcjZJfY6MU++wQPzI+PRECUJjo97aAtqupaqhFLHtRLHNf1Kwn9lAOid9L7tV9nzVldNL3dC+NmrGOGM+sme2VrO335Mda3foXlXravY57zemY23HkLs72RsW5JegDjZK99FnPPtwl8FX1i92IfAax6yfvkWf/AHb1F1JeJxjYGRgYABi3/mPYuP5bb4ycLOABKI4H+9rgNH//zIwsDCzMAElOBhAJAMAQ2IK+QAAAHicY2BkYGBhAAEWhv9///9lYWZgZEAFYgBbLQQgAAAAeJxjYGBgYGH4/58FTIPZf2FsSgAAM58EEwAAAHicY2AAgjyGJoYlDI8YPjD8ww8BeTMTR3icY2BkYGAQY3BhYGYAASYg5gJCBob/YD4DABGFAXQAeJxlkD1uwkAUhMdgSAJSghQpKbNVCiKZn5IDQE9Bl8KYtTGyvdZ6QaLLCXKEHCGniHKCHChj82hgLT9/M2/e7soABviFh3p5uG1qvVq4oTpxm/Qg7JOfhTvo40W4S38o3MMbpsJ9POKdO3j+HZ0BSuEW7vEh3Kb/KeyTv4Q7eMK3cJf+j3APK/wJ9/HqDdPIFLEp3FIn+yy0Z3n+rrStUlOoSTA+WwtdaBs6vVHro6oOydS5WMXW5GrOrs4yo0prdjpywda5cjYaxeIHkcmRIoJBgbipDktoJNgjQwh71b3UK6YtKvq1VpggwPgqtWCqaJIhlcaGyTWOrBUOPG1K1zGt+FrO5KS5zGreJCMr/u+6t6MT0Q+wbaZKzDDiE1/kg+YO+T89EV6oAAAAeJxtxksOgjAUQNF3kaIW/x9cBYtqgEAnLXlp0+1rwtQzuVcq2Vj5r6NiR42hYc+BI5aWE2cuXLlx58GTF286PmIm1ajGhzWnJub0S12cBjs4nVI/xhLabdXPS2JCiXgCK5lEwTHQMzKziHwBqnYYpg==') format('woff')}[class*=' luna-console-icon-'],[class^=luna-console-icon-]{display:inline-block;font-family:luna-console-icon!important;font-size:16px;font-style:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.luna-console-icon-error:before{content:'\f101'}.luna-console-icon-input:before{content:'\f102'}.luna-console-icon-output:before{content:'\f103'}.luna-console-icon-warn:before{content:'\f104'}.luna-console-icon-caret-down:before{content:'\f105'}.luna-console-icon-caret-right:before{content:'\f106'}.luna-console{background:#fff;overflow-y:auto;-webkit-overflow-scrolling:touch;height:100%;position:relative;will-change:scroll-position;cursor:default;font-size:12px;font-family:ui-monospace,SFMono-Regular,SF Mono,Menlo,Consolas,Liberation Mono,monospace}.luna-console.luna-console-theme-dark{background-color:#242424}.luna-console-hidden{display:none}.luna-console-fake-logs{position:absolute;left:0;top:0;pointer-events:none;visibility:hidden;width:100%}.luna-console-logs{padding-top:1px;position:absolute;width:100%}.luna-console-log-container{box-sizing:content-box}.luna-console-log-container.luna-console-selected .luna-console-log-item{background:#ecf1f8}.luna-console-log-container.luna-console-selected .luna-console-log-item:not(.luna-console-error):not(.luna-console-warn){border-color:#ccdef5}.luna-console-header{white-space:nowrap;display:flex;font-size:11px;color:#545454;border-top:1px solid transparent;border-bottom:1px solid #ccc}.luna-console-header .luna-console-time-from-container{overflow-x:auto;-webkit-overflow-scrolling:touch;padding:3px 10px}.luna-console-nesting-level{width:14px;flex-shrink:0;margin-top:-1px;margin-bottom:-1px;position:relative;border-right:1px solid #ccc}.luna-console-nesting-level.luna-console-group-closed::before{content:""}.luna-console-nesting-level::before{border-bottom:1px solid #ccc;position:absolute;top:0;left:0;margin-left:100%;width:5px;height:100%;box-sizing:border-box}.luna-console-log-item{position:relative;display:flex;border-top:1px solid transparent;border-bottom:1px solid #ccc;margin-top:-1px;color:#333}.luna-console-log-item:after{content:"";display:block;clear:both}.luna-console-log-item .luna-console-code{display:inline;font-family:ui-monospace,SFMono-Regular,SF Mono,Menlo,Consolas,Liberation Mono,monospace}.luna-console-log-item .luna-console-code .luna-console-keyword{color:#881280}.luna-console-log-item .luna-console-code .luna-console-number{color:#1c00cf}.luna-console-log-item .luna-console-code .luna-console-operator{color:gray}.luna-console-log-item .luna-console-code .luna-console-comment{color:#236e25}.luna-console-log-item .luna-console-code .luna-console-string{color:#1a1aa6}.luna-console-log-item a{color:#15c!important}.luna-console-log-item .luna-console-icon-container{margin:0 -6px 0 10px}.luna-console-log-item .luna-console-icon-container .luna-console-icon{line-height:20px;font-size:12px;color:#333;position:relative}.luna-console-log-item .luna-console-icon-container .luna-console-icon-caret-down,.luna-console-log-item .luna-console-icon-container .luna-console-icon-caret-right{top:0;left:-2px}.luna-console-log-item .luna-console-icon-container .luna-console-icon-error{top:0;color:#ef3842}.luna-console-log-item .luna-console-icon-container .luna-console-icon-warn{top:0;color:#e8a400}.luna-console-log-item .luna-console-count{background:#8097bd;color:#fff;padding:2px 4px;border-radius:10px;font-size:12px;float:left;margin:1px -6px 0 10px}.luna-console-log-item .luna-console-log-content-wrapper{flex:1;overflow:hidden}.luna-console-log-item .luna-console-log-content{padding:3px 0;margin:0 10px;overflow-x:auto;-webkit-overflow-scrolling:touch;white-space:pre-wrap;-webkit-user-select:text;-moz-user-select:text;-ms-user-select:text;user-select:text}.luna-console-log-item .luna-console-log-content *{-webkit-user-select:text;-moz-user-select:text;-ms-user-select:text;user-select:text}.luna-console-log-item .luna-console-log-content>*{vertical-align:top}.luna-console-log-item .luna-console-log-content .luna-console-null,.luna-console-log-item .luna-console-log-content .luna-console-undefined{color:#5e5e5e}.luna-console-log-item .luna-console-log-content .luna-console-number{color:#1c00cf}.luna-console-log-item .luna-console-log-content .luna-console-boolean{color:#0d22aa}.luna-console-log-item .luna-console-log-content .luna-console-regexp,.luna-console-log-item .luna-console-log-content .luna-console-symbol{color:#881391}.luna-console-log-item .luna-console-data-grid,.luna-console-log-item .luna-console-dom-viewer{white-space:initial}.luna-console-log-item.luna-console-error{z-index:50;background:#fff0f0;color:red;border-top:1px solid #ffd6d6;border-bottom:1px solid #ffd6d6}.luna-console-log-item.luna-console-error .luna-console-stack{padding-left:1.2em;white-space:nowrap}.luna-console-log-item.luna-console-error .luna-console-count{background:red}.luna-console-log-item.luna-console-debug{z-index:20}.luna-console-log-item.luna-console-input{border-bottom-color:transparent}.luna-console-log-item.luna-console-warn{z-index:40;color:#5c5c00;background:#fffbe5;border-top:1px solid #fff5c2;border-bottom:1px solid #fff5c2}.luna-console-log-item.luna-console-warn .luna-console-count{background:#e8a400}.luna-console-log-item.luna-console-info{z-index:30}.luna-console-log-item.luna-console-group,.luna-console-log-item.luna-console-groupCollapsed{font-weight:700}.luna-console-preview{display:inline-block}.luna-console-preview .luna-console-preview-container{display:flex;align-items:center}.luna-console-preview .luna-console-json{overflow-x:auto;-webkit-overflow-scrolling:touch;padding-left:12px}.luna-console-preview .luna-console-preview-icon-container{display:block}.luna-console-preview .luna-console-preview-icon-container .luna-console-icon{position:relative;font-size:12px}.luna-console-preview .luna-console-preview-icon-container .luna-console-icon-caret-down{top:2px}.luna-console-preview .luna-console-preview-icon-container .luna-console-icon-caret-right{top:1px}.luna-console-preview .luna-console-preview-content-container{word-break:break-all}.luna-console-preview .luna-console-descriptor,.luna-console-preview .luna-console-object-preview{font-style:italic}.luna-console-preview .luna-console-key{color:#881391}.luna-console-preview .luna-console-number{color:#1c00cf}.luna-console-preview .luna-console-null{color:#5e5e5e}.luna-console-preview .luna-console-string{color:#c41a16}.luna-console-preview .luna-console-boolean{color:#0d22aa}.luna-console-preview .luna-console-special{color:#5e5e5e}.luna-console-theme-dark{color-scheme:dark}.luna-console-theme-dark .luna-console-log-container.luna-console-selected .luna-console-log-item{background:#29323d}.luna-console-theme-dark .luna-console-log-container.luna-console-selected .luna-console-log-item:not(.luna-console-error):not(.luna-console-warn){border-color:#4173b4}.luna-console-theme-dark .luna-console-log-item{color:#a5a5a5;border-bottom-color:#3d3d3d}.luna-console-theme-dark .luna-console-log-item .luna-console-code .luna-console-keyword{color:#e36eec}.luna-console-theme-dark .luna-console-log-item .luna-console-code .luna-console-number{color:#9980ff}.luna-console-theme-dark .luna-console-log-item .luna-console-code .luna-console-operator{color:#7f7f7f}.luna-console-theme-dark .luna-console-log-item .luna-console-code .luna-console-comment{color:#747474}.luna-console-theme-dark .luna-console-log-item .luna-console-code .luna-console-string{color:#f29766}.luna-console-theme-dark .luna-console-log-item.luna-console-error{background:#290000;color:#ff8080;border-top-color:#5c0000;border-bottom-color:#5c0000}.luna-console-theme-dark .luna-console-log-item.luna-console-error .luna-console-count{background:#ff8080}.luna-console-theme-dark .luna-console-log-item.luna-console-warn{color:#ffcb6b;background:#332a00;border-top-color:#650;border-bottom-color:#650}.luna-console-theme-dark .luna-console-log-item .luna-console-count{background:#42597f;color:#949494}.luna-console-theme-dark .luna-console-log-item .luna-console-log-content .luna-console-null,.luna-console-theme-dark .luna-console-log-item .luna-console-log-content .luna-console-undefined{color:#7f7f7f}.luna-console-theme-dark .luna-console-log-item .luna-console-log-content .luna-console-boolean,.luna-console-theme-dark .luna-console-log-item .luna-console-log-content .luna-console-number{color:#9980ff}.luna-console-theme-dark .luna-console-log-item .luna-console-log-content .luna-console-regexp,.luna-console-theme-dark .luna-console-log-item .luna-console-log-content .luna-console-symbol{color:#e36eec}.luna-console-theme-dark .luna-console-icon-container .luna-console-icon-caret-down,.luna-console-theme-dark .luna-console-icon-container .luna-console-icon-caret-right{color:#9aa0a6}.luna-console-theme-dark .luna-console-header{border-bottom-color:#3d3d3d}.luna-console-theme-dark .luna-console-nesting-level{border-right-color:#3d3d3d}.luna-console-theme-dark .luna-console-nesting-level::before{border-bottom-color:#3d3d3d}.luna-console-theme-dark .luna-console-preview .luna-console-key{color:#e36eec}.luna-console-theme-dark .luna-console-preview .luna-console-number{color:#9980ff}.luna-console-theme-dark .luna-console-preview .luna-console-null{color:#7f7f7f}.luna-console-theme-dark .luna-console-preview .luna-console-string{color:#f29766}.luna-console-theme-dark .luna-console-preview .luna-console-boolean{color:#9980ff}.luna-console-theme-dark .luna-console-preview .luna-console-special{color:#7f7f7f}@font-face{font-family:luna-object-viewer-icon;src:url('data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAAS8AAsAAAAAB7QAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAAGEAAACMISgl+k9TLzIAAAFsAAAAPQAAAFZLxUkWY21hcAAAAawAAADWAAACdBU42qdnbHlmAAAChAAAAC4AAAAwabU7V2hlYWQAAAK0AAAALwAAADZzjr4faGhlYQAAAuQAAAAYAAAAJAFyANlobXR4AAAC/AAAABAAAABAAZAAAGxvY2EAAAMMAAAAEAAAACIAtACobWF4cAAAAxwAAAAfAAAAIAEbAA9uYW1lAAADPAAAASkAAAIWm5e+CnBvc3QAAARoAAAAUwAAAHZW8MNZeJxNjTsOQFAQRc/z/+sV1mABohKV0gZeJRJR2X9cT4RJZu7nFIMBMjoGvHGaF6rdngcNAc/c/O/Nvq2W5E1igdNE2zv1iGh1c5FQPlYXUlJRyxt9+/pUKadQa/AveGEGZQAAAHicY2BkkGScwMDKwMBQx9ADJGWgdAIDJ4MxAwMTAyszA1YQkOaawnCAQfcjE8MJIFcITDIwMIIIAFqDCGkAAAB4nM2STQ4BQRCFv54ZP8MwFhYW4gQcShBsSERi50BWDuFCcwJedddKRGKnOt8k9aanqudVAy0gF3NRQLgTsLhJDVHP6UW94Kp8zEhKwYIlG/YcOXHm0mTPp96aumLLwdUQ1fcIqmJrwpSZL+iqak5JmyE1Ayr1bdGhr/2ZPmp/qPQtuj/uJzqQl+pfDyypesQD6AT/ElV8PjyrMccT9rdLR3PUFBI227VTio1jbm6dodg5VnPvmAsHxzofHfmi+Sbs/pwdWcXFkWdNSNg9arIE2QufuSCyAAB4nGNgZACBlQzTGZgYGMyVxVc2O073AIpAxHsYloHFRc2dPZY2OTIwAACmEQesAAB4nGNgZGBgAOINe2b6x/PbfGXgZjgBFIjifLyvAUEDwUqGZUCSg4EJxAEAUn4LLAB4nGNgZGBgOMHAACdXMjAyoAIBADizAkx4nGNgAIITUEwGAABZUAGReJxjYAACHgYJ3BAAE94BXXicY2BkYGAQYGBmANEMDExAzAWEDAz/wXwGAApcASsAeJxlkD1uwkAUhMdgSAJSghQpKbNVCiKZn5IDQE9Bl8KYtTGyvdZ6QaLLCXKEHCGniHKCHChj82hgLT9/M2/e7soABviFh3p5uG1qvVq4oTpxm/Qg7JOfhTvo40W4S38o3MMbpsJ9POKdO3j+HZ0BSuEW7vEh3Kb/KeyTv4Q7eMK3cJf+j3APK/wJ9/HqDdPIFLEp3FIn+yy0Z3n+rrStUlOoSTA+WwtdaBs6vVHro6oOydS5WMXW5GrOrs4yo0prdjpywda5cjYaxeIHkcmRIoJBgbipDktoJNgjQwh71b3UK6YtKvq1VpggwPgqtWCqaJIhlcaGyTWOrBUOPG1K1zGt+FrO5KS5zGreJCMr/u+6t6MT0Q+wbaZKzDDiE1/kg+YO+T89EV6oAAAAeJxdxjkOgCAUANE/uOOGB+FQBIjaaEJIuL6FsfE1M6Lk9fXPoKioaWjp6BnQjEzMLKwYNtHepZhtuMs1vpvO/ch4HIlIxhK4KVyc7BwiD8nvDlkA') format('woff')}[class*=' luna-object-viewer-icon-'],[class^=luna-object-viewer-icon-]{display:inline-block;font-family:luna-object-viewer-icon!important;font-size:16px;font-style:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.luna-object-viewer-icon-caret-down:before{content:'\f101'}.luna-object-viewer-icon-caret-right:before{content:'\f102'}.luna-object-viewer{overflow-x:auto;-webkit-overflow-scrolling:touch;overflow-y:hidden;cursor:default;font-family:ui-monospace,SFMono-Regular,SF Mono,Menlo,Consolas,Liberation Mono,monospace;font-size:12px;line-height:1.2;min-height:100%;color:#333;list-style:none!important}.luna-object-viewer ul{list-style:none!important;padding:0!important;padding-left:12px!important;margin:0!important}.luna-object-viewer li{position:relative;white-space:nowrap;line-height:16px;min-height:16px}.luna-object-viewer>li>.luna-object-viewer-key{display:none}.luna-object-viewer span{position:static!important}.luna-object-viewer li .luna-object-viewer-collapsed~.luna-object-viewer-close:before{color:#999}.luna-object-viewer-array .luna-object-viewer-object .luna-object-viewer-key{display:inline}.luna-object-viewer-null{color:#5e5e5e}.luna-object-viewer-regexp,.luna-object-viewer-string{color:#c41a16}.luna-object-viewer-number{color:#1c00cf}.luna-object-viewer-boolean{color:#0d22aa}.luna-object-viewer-special{color:#5e5e5e}.luna-object-viewer-key,.luna-object-viewer-key-lighter{color:#881391}.luna-object-viewer-key-lighter{opacity:.6}.luna-object-viewer-key-special{color:#5e5e5e}.luna-object-viewer-collapsed .luna-object-viewer-icon,.luna-object-viewer-expanded .luna-object-viewer-icon{position:absolute!important;left:-12px;color:#727272;font-size:12px}.luna-object-viewer-icon-caret-right{top:0}.luna-object-viewer-icon-caret-down{top:1px}.luna-object-viewer-expanded>.luna-object-viewer-icon-caret-down{display:inline}.luna-object-viewer-expanded>.luna-object-viewer-icon-caret-right{display:none}.luna-object-viewer-collapsed>.luna-object-viewer-icon-caret-down{display:none}.luna-object-viewer-collapsed>.luna-object-viewer-icon-caret-right{display:inline}.luna-object-viewer-hidden~ul{display:none}.luna-object-viewer-theme-dark{color:#fff}.luna-object-viewer-theme-dark .luna-object-viewer-null,.luna-object-viewer-theme-dark .luna-object-viewer-special{color:#a1a1a1}.luna-object-viewer-theme-dark .luna-object-viewer-regexp,.luna-object-viewer-theme-dark .luna-object-viewer-string{color:#f28b54}.luna-object-viewer-theme-dark .luna-object-viewer-boolean,.luna-object-viewer-theme-dark .luna-object-viewer-number{color:#9980ff}.luna-object-viewer-theme-dark .luna-object-viewer-key,.luna-object-viewer-theme-dark .luna-object-viewer-key-lighter{color:#5db0d7}@font-face{font-family:luna-dom-viewer-icon;src:url('data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAASgAAsAAAAAB4QAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAAFwAAACMIRYl8k9TLzIAAAFkAAAAPQAAAFZLxUkaY21hcAAAAaQAAADHAAACWBcU1KRnbHlmAAACbAAAAC4AAAAwabU7V2hlYWQAAAKcAAAALwAAADZzjr4faGhlYQAAAswAAAAYAAAAJAFyANdobXR4AAAC5AAAABAAAAA4AZAAAGxvY2EAAAL0AAAAEAAAAB4AnACQbWF4cAAAAwQAAAAfAAAAIAEZAA9uYW1lAAADJAAAASkAAAIWm5e+CnBvc3QAAARQAAAATgAAAG5m1cqleJxjYGRgYOBiMGCwY2BycfMJYeDLSSzJY5BiYGGAAJA8MpsxJzM9kYEDxgPKsYBpDiC2AdNMDGwMckCSGyzHCuSxA2kuIJ+HgReoggtJnANMcwJFGRmYAXZLBkt4nGNgZJBlnMDAysDAUMfQAyRloHQCAyeDMQMDEwMrMwNWEJDmmsJwgEH3IxPDCSBXCEwyMDCCCABbzwhtAAAAeJy1kksKwjAQhr/0oX0JLlyIZ9BDCQXtRkEEwQO56uV6Av0nmZWI4MIJX2H+JvNIBiiBXGxFAWEkYPaQGqKe00S94C5/xVJKwY49PQNnLly5Tdnzqb9JPXByNUT13YKipLVm4wvmilvR0ilfrboKFsy0N9OB2Yco32z+437SLVTQdo05dUksgF8z/8+6+B3dU2m67YR1u3fsLXtH7egtEq04OhZpcKzbk1OLs2NzcXE0F3rNhOW9ObqbKSRsVqYsQfYC6fYeiQB4nGNgZACBlQzTGZgYGMyVxVc2O073AIpAxHsYloHFRc2dPZY2OTIwAACmEQesAAB4nGNgZGBgAOLeSTNM4/ltvjJwM5wACkRxPt7XgKCBYCXDMiDJwcAE4gAAQEgKxAB4nGNgZGBgOMHAACdXMjAyoAI+ADixAkp4nGNgAIITUEwCAABMyAGReJxjYAACHgYJ7BAADsoBLXicY2BkYGDgY2BmANEMDExAzAWEDAz/wXwGAAomASkAeJxlkD1uwkAUhMdgSAJSghQpKbNVCiKZn5IDQE9Bl8KYtTGyvdZ6QaLLCXKEHCGniHKCHChj82hgLT9/M2/e7soABviFh3p5uG1qvVq4oTpxm/Qg7JOfhTvo40W4S38o3MMbpsJ9POKdO3j+HZ0BSuEW7vEh3Kb/KeyTv4Q7eMK3cJf+j3APK/wJ9/HqDdPIFLEp3FIn+yy0Z3n+rrStUlOoSTA+WwtdaBs6vVHro6oOydS5WMXW5GrOrs4yo0prdjpywda5cjYaxeIHkcmRIoJBgbipDktoJNgjQwh71b3UK6YtKvq1VpggwPgqtWCqaJIhlcaGyTWOrBUOPG1K1zGt+FrO5KS5zGreJCMr/u+6t6MT0Q+wbaZKzDDiE1/kg+YO+T89EV6oAAAAeJxdxk0KgCAUAOE3/adlJ/FQgqBuFETw+i2kTd9mRiYZvv4ZJmYWVjZ2Dk4UmosbwyPK1Vq69aVnPbamEBuOSqFj8WQSgUgTeQGPtA2iAAA=') format('woff')}[class*=' luna-dom-viewer-icon-'],[class^=luna-dom-viewer-icon-]{display:inline-block;font-family:luna-dom-viewer-icon!important;font-size:16px;font-style:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.luna-dom-viewer-icon-arrow-down:before{content:'\f101'}.luna-dom-viewer-icon-arrow-right:before{content:'\f102'}.luna-dom-viewer{color:#333;background-color:#fff;font-family:Arial,Helvetica,sans-serif;box-sizing:border-box;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;font-size:14px;overflow-y:auto;-webkit-overflow-scrolling:touch;background:0 0;overflow-x:hidden;word-wrap:break-word;padding:0 0 0 12px;font-size:12px;font-family:ui-monospace,SFMono-Regular,SF Mono,Menlo,Consolas,Liberation Mono,monospace;cursor:default;list-style:none}.luna-dom-viewer.luna-dom-viewer-platform-windows{font-family:'Segoe UI',Tahoma,sans-serif}.luna-dom-viewer.luna-dom-viewer-platform-linux{font-family:Roboto,Ubuntu,Arial,sans-serif}.luna-dom-viewer .luna-dom-viewer-hidden,.luna-dom-viewer.luna-dom-viewer-hidden{display:none}.luna-dom-viewer .luna-dom-viewer-invisible,.luna-dom-viewer.luna-dom-viewer-invisible{visibility:hidden}.luna-dom-viewer *{box-sizing:border-box}.luna-dom-viewer.luna-dom-viewer-theme-dark{color:#a5a5a5;background-color:#242424}.luna-dom-viewer ul{list-style:none}.luna-dom-viewer.luna-dom-viewer-theme-dark{color:#e8eaed}.luna-dom-viewer-toggle{min-width:12px;margin-left:-12px}.luna-dom-viewer-icon-arrow-down,.luna-dom-viewer-icon-arrow-right{position:absolute!important;font-size:12px!important}.luna-dom-viewer-tree-item{line-height:16px;min-height:16px;position:relative;z-index:10;outline:0}.luna-dom-viewer-tree-item.luna-dom-viewer-selected .luna-dom-viewer-selection,.luna-dom-viewer-tree-item:hover .luna-dom-viewer-selection{display:block}.luna-dom-viewer-tree-item:hover .luna-dom-viewer-selection{background:#f2f7fd}.luna-dom-viewer-tree-item.luna-dom-viewer-selected .luna-dom-viewer-selection{background:#e0e0e0}.luna-dom-viewer-tree-item.luna-dom-viewer-selected:focus .luna-dom-viewer-selection{background:#cfe8fc}.luna-dom-viewer-tree-item .luna-dom-viewer-icon-arrow-down{display:none}.luna-dom-viewer-tree-item.luna-dom-viewer-expanded .luna-dom-viewer-icon-arrow-down{display:inline-block}.luna-dom-viewer-tree-item.luna-dom-viewer-expanded .luna-dom-viewer-icon-arrow-right{display:none}.luna-dom-viewer-html-tag{color:#881280}.luna-dom-viewer-tag-name{color:#881280}.luna-dom-viewer-attribute-name{color:#994500}.luna-dom-viewer-attribute-value{color:#1a1aa6}.luna-dom-viewer-attribute-value.luna-dom-viewer-attribute-underline{text-decoration:underline}.luna-dom-viewer-html-comment{color:#236e25}.luna-dom-viewer-selection{position:absolute;display:none;left:-10000px;right:-10000px;top:0;bottom:0;z-index:-1}.luna-dom-viewer-children{margin:0;overflow-x:visible;overflow-y:visible;padding-left:15px}.luna-dom-viewer-text-node .luna-dom-viewer-keyword{color:#881280}.luna-dom-viewer-text-node .luna-dom-viewer-number{color:#1c00cf}.luna-dom-viewer-text-node .luna-dom-viewer-operator{color:grey}.luna-dom-viewer-text-node .luna-dom-viewer-comment{color:#236e25}.luna-dom-viewer-text-node .luna-dom-viewer-string{color:#1a1aa6}.luna-dom-viewer-theme-dark .luna-dom-viewer-icon-arrow-down,.luna-dom-viewer-theme-dark .luna-dom-viewer-icon-arrow-right{color:#9aa0a6}.luna-dom-viewer-theme-dark .luna-dom-viewer-html-tag,.luna-dom-viewer-theme-dark .luna-dom-viewer-tag-name{color:#5db0d7}.luna-dom-viewer-theme-dark .luna-dom-viewer-attribute-name{color:#9bbbdc}.luna-dom-viewer-theme-dark .luna-dom-viewer-attribute-value{color:#f29766}.luna-dom-viewer-theme-dark .luna-dom-viewer-html-comment{color:#898989}.luna-dom-viewer-theme-dark .luna-dom-viewer-tree-item:hover .luna-dom-viewer-selection{background:#083c69}.luna-dom-viewer-theme-dark .luna-dom-viewer-tree-item.luna-dom-viewer-selected .luna-dom-viewer-selection{background:#454545}.luna-dom-viewer-theme-dark .luna-dom-viewer-tree-item.luna-dom-viewer-selected:focus .luna-dom-viewer-selection{background:#073d69}.luna-dom-viewer-theme-dark .luna-dom-viewer-text-node .luna-dom-viewer-keyword{color:#e36eec}.luna-dom-viewer-theme-dark .luna-dom-viewer-text-node .luna-dom-viewer-number{color:#9980ff}.luna-dom-viewer-theme-dark .luna-dom-viewer-text-node .luna-dom-viewer-operator{color:#7f7f7f}.luna-dom-viewer-theme-dark .luna-dom-viewer-text-node .luna-dom-viewer-comment{color:#747474}.luna-dom-viewer-theme-dark .luna-dom-viewer-text-node .luna-dom-viewer-string{color:#f29766}@font-face{font-family:luna-text-viewer-icon;src:url('data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAAS0AAsAAAAAB2QAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAAFQAAAB0INElr09TLzIAAAFcAAAAPQAAAFZL+0klY21hcAAAAZwAAACfAAACEAEewxRnbHlmAAACPAAAAIYAAACkNSDggmhlYWQAAALEAAAALgAAADZzrb4oaGhlYQAAAvQAAAAWAAAAJAGRANNobXR4AAADDAAAABAAAAAoAZAAAGxvY2EAAAMcAAAAEAAAABYBWgFIbWF4cAAAAywAAAAdAAAAIAEXADtuYW1lAAADTAAAASkAAAIWm5e+CnBvc3QAAAR4AAAAOwAAAFJIWdOleJxjYGRgYOBiMGCwY2BycfMJYeDLSSzJY5BiYGGAAJA8MpsxJzM9kYEDxgPKsYBpDiBWAdNMDGwMQkAWK1CGlYEZyGMCstiBMpxAUUYGZgDbGgXDeJxjYGTQYJzAwMrAwFDH0AMkZaB0AgMngzEDAxMDKzMDVhCQ5prCcIAh+SMTwwkgVwhMMjAwgggAY84IrgAAAHicvZFLCsMwDERHzsdJ6aL0HD1VQiDQRbIN9Axd9aI+QTpjq5Bdd5F4Bo1lybIBNAAq8iA1YB8YZG+qlvUKl6zXGBjf6MofMWHGEyu2FPb9oCxULCtHs3yy+J2urg1rtojo0HM/MKnFGabOGlbdYvdT+1N6/7drXl8e6Vajo3efHP3b7HAUvntBMy1OJKujMTeHNZMV9McpFBC+tLgY4QB4nGNgZACBEwzrGdgZGOwZxdnVDdXNPfKEGlhchO0KhZtZ3IQYmMFq1jCsZpBi0GLQY2AwNzGzZjQSk2UUYdNmVFID8UyVRUXYlNRMlVGlTM1FjU3tmZkTmVhYmFRBhHwoCyuzKgtTIjMzWJg3ZClIGMRlZQmVB7GhMixM0aGhQIsB52sTqgAAeJxjYGRgYADi2JNxkvH8Nl8ZuBlOAAWiOB/va0DQQHCCYT2Q5GBgAnEANJ0KnQAAeJxjYGRgYDjBwIBEMjKgAi4AOvoCZQAAeJxjYACCE1CMBwAAM7gBkXicY2AAAiGGIFQIABXIAqN4nGNgZGBg4GLQZ2BmAAEmMI8LSP4H8xkADjQBUwAAAHicZZA9bsJAFITHYEgCUoIUKSmzVQoimZ+SA0BPQZfCmLUxsr3WekGiywlyhBwhp4hyghwoY/NoYC0/fzNv3u7KAAb4hYd6ebhtar1auKE6cZv0IOyTn4U76ONFuEt/KNzDG6bCfTzinTt4/h2dAUrhFu7xIdym/ynsk7+EO3jCt3CX/o9wDyv8Cffx6g3TyBSxKdxSJ/sstGd5/q60rVJTqEkwPlsLXWgbOr1R66OqDsnUuVjF1uRqzq7OMqNKa3Y6csHWuXI2GsXiB5HJkSKCQYG4qQ5LaCTYI0MIe9W91CumLSr6tVaYIMD4KrVgqmiSIZXGhsk1jqwVDjxtStcxrfhazuSkucxq3iQjK/7vurejE9EPsG2mSsww4hNf5IPmDvk/PRFeqAAAAHicXcU7CsAgFEXBe4x/l/kQBAtt3X0KSZNpRk7X91/F8eAJRBKZQqUp2Og2va19MAadyWJzpBd4kgcWAA==') format('woff')}[class*=' luna-text-viewer-icon-'],[class^=luna-text-viewer-icon-]{display:inline-block;font-family:luna-text-viewer-icon!important;font-size:16px;font-style:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.luna-text-viewer-icon-check:before{content:'\f101'}.luna-text-viewer-icon-copy:before{content:'\f102'}.luna-text-viewer{color:#333;background-color:#fff;font-family:Arial,Helvetica,sans-serif;box-sizing:border-box;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;font-size:14px;padding:0;unicode-bidi:embed;position:relative;overflow:auto;border:1px solid #ccc}.luna-text-viewer.luna-text-viewer-platform-windows{font-family:'Segoe UI',Tahoma,sans-serif}.luna-text-viewer.luna-text-viewer-platform-linux{font-family:Roboto,Ubuntu,Arial,sans-serif}.luna-text-viewer .luna-text-viewer-hidden,.luna-text-viewer.luna-text-viewer-hidden{display:none}.luna-text-viewer .luna-text-viewer-invisible,.luna-text-viewer.luna-text-viewer-invisible{visibility:hidden}.luna-text-viewer *{box-sizing:border-box}.luna-text-viewer.luna-text-viewer-theme-dark{color:#d9d9d9;border-color:#3d3d3d;background:#242424}.luna-text-viewer:hover .luna-text-viewer-copy{opacity:1}.luna-text-viewer-table{display:table}.luna-text-viewer-table .luna-text-viewer-line-number,.luna-text-viewer-table .luna-text-viewer-line-text{padding:0}.luna-text-viewer-table-row{display:table-row}.luna-text-viewer-line-number{display:table-cell;padding:0 3px 0 8px!important;text-align:right;vertical-align:top;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;border-right:1px solid #ccc}.luna-text-viewer-line-text{display:table-cell;padding-left:4px!important;-webkit-user-select:text;-moz-user-select:text;-ms-user-select:text;user-select:text}.luna-text-viewer-copy{background:#fff;opacity:0;position:absolute;right:5px;top:5px;border:1px solid #ccc;border-radius:4px;width:25px;height:25px;text-align:center;line-height:25px;cursor:pointer;transition:opacity .3s,top .3s}.luna-text-viewer-copy .luna-text-viewer-icon-check{color:#188037}.luna-text-viewer-text{padding:4px;font-size:12px;font-family:ui-monospace,SFMono-Regular,SF Mono,Menlo,Consolas,Liberation Mono,monospace;box-sizing:border-box;white-space:pre;display:block}.luna-text-viewer-text.luna-text-viewer-line-numbers{padding:0}.luna-text-viewer-text.luna-text-viewer-wrap-long-lines{white-space:pre-wrap}.luna-text-viewer-text.luna-text-viewer-wrap-long-lines .luna-text-viewer-line-text{word-break:break-all}.luna-text-viewer-theme-dark{color-scheme:dark}.luna-text-viewer-theme-dark .luna-text-viewer-copy,.luna-text-viewer-theme-dark .luna-text-viewer-line-number{border-color:#3d3d3d}.luna-text-viewer-theme-dark .luna-text-viewer-copy .luna-text-viewer-icon-check{color:#81c995}.luna-text-viewer-theme-dark .luna-text-viewer-copy{background-color:#242424}</style></head>

<body>
  <style>
    .radio-group{
      margin-top: 5px;
      margin-left: 10px;
      margin-bottom: 4px;
      display: flex;
      gap: 30%;
    }

  .radio-content-wrapper{
     display: flex;
    align-items: center;
  }
  .radio-label-text{
    margin-left: 0.5rem;
    position: relative;
    bottom: 2px;
  }
input[type="radio"] {
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            width: 20px;
            height: 20px;
            border: 2px solid #999;
            border-radius: 50%;
            outline: none;
            cursor: pointer;
        }

        input[type="radio"]:checked {
            border-color: #6e0ad6;
            background-color: white;
        }

        input[type="radio"]:checked::before {
            
            content: '';
            display: block;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #6e0ad6;
            margin: 2px;
        }
        .input-icon-wrapper {
    position: relative;
    display: inline-block;
    vertical-align: middle;
}

.input-button-password {
    background: none;
    border: none;
    cursor: pointer;
    padding: 0;
    margin: 0;
    display: flex;
    align-items: center;
}

.input-button-password svg {
    width: 24px;
    height: 24px;
    color: var(--color-secondary-100);
}
.texto {
  font-size: 18px;
    text-align: center; 
    max-width: 80%; 
    margin: 0 auto; 
    margin-bottom: 20px;
}
  </style>
    <noscript>
            <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-546N2JV" height="0" width="0" style="display:none;visibility:hidden"></iframe>
        </noscript>
    <div id="__next">
        <div class="sc-hRmvpr fHwlOn">
            <div class="sc-tVThF kErkdJ sc-hRmvpr fHwlOn">
                <div class="sc-dcOKER cftwIc">
                    <div class="sc-haEqAx iOIySL sc-hRmvpr fHwlOn">
                        <a data-ds-component="DS-Link" href="#" class="sc-biNVYa jwSeUw sc-jAaTju dsUwxl">
                            <svg data-ds-component="DS-LogoOLX" viewBox="0 0 40 40" class="default sc-kfGgVZ dbivqF">
                                    <g fill="none" fill-rule="evenodd">
                                        <path class="o" d="M7.579 26.294c-2.282 0-3.855-1.89-3.855-4.683 0-2.82 1.573-4.709 3.855-4.709 2.28 0 3.855 1.889 3.855 4.682 0 2.82-1.574 4.71-3.855 4.71m0 3.538c4.222 0 7.578-3.512 7.578-8.248 0-4.682-3.173-8.22-7.578-8.22C3.357 13.363 0 16.874 0 21.61c0 4.763 3.173 8.221 7.579 8.221"></path>
                                        <path class="l" d="M18.278 23.553h7.237c.499 0 .787-.292.787-.798V20.44c0-.505-.288-.798-.787-.798h-4.851V9.798c0-.505-.288-.798-.787-.798h-2.386c-.498 0-.787.293-.787.798v12.159c0 1.038.551 1.596 1.574 1.596"></path>
                                        <path class="x" d="M28.112 29.593l4.353-5.082 4.222 5.082c.367.452.839.452 1.258.08l1.705-1.517c.42-.373.472-.851.079-1.277l-4.694-5.321 4.274-4.869c.367-.426.34-.878-.078-1.277l-1.6-1.463c-.42-.4-.892-.373-1.259.08l-3.907 4.602-3.986-4.603c-.367-.425-.84-.479-1.259-.08l-1.652 1.49c-.42.4-.446.825-.053 1.278l4.354 4.868-4.747 5.348c-.393.452-.34.905.079 1.277l1.652 1.464c.42.372.891.345 1.259-.08"></path>
                                    </g>
                                </svg>
                        </a>
                        <span color="--color-neutral-130" display="block" class="sc-dxgOiQ kutBOr">Crie a sua conta. É grátis!</span>
                    </div>
                    <hr style="background-color: #d5d5d5; margin-top: 20px; margin-bottom: 20px;">
                  <div class="texto">
    Nos informe alguns dados para que possamos melhorar a sua experiência na OLX
</div>

                    <div class="sc-gbuiJB TVYmL sc-ibnDSj dREcqx">
                        <form class="sc-liPmeQ gbNUXF">
                            <div class="sc-erOsFi hDBZNz sc-hRmvpr fHwlOn">
                              
                              
                              <!-- nome -->
                                <div class="sc-csSMhA jBcPcs sc-hRmvpr fHwlOn">
                                    <span label="E-mail" class="sc-kMBllD joZquB sc-hCbubC bbviFe sc-eLdqWK dzVFiD" color="dark" font-weight="400">
                                        <!-- -->
                                        Como você quer ser chamado(a)?
                                        <!-- -->
                                        <!-- -->
                                        </span>
                                    <div class="sc-bscRGj cRmmCP sc-hRmvpr fHwlOn">
                                        <span class="sc-eklfrZ gpxvyH sc-eLdqWK dzVFiD" color="dark" font-weight="400"></span>
                                    </div>
                                </div>
                                <div class="sc-eGXxtx dqXQkw sc-hRmvpr fHwlOn">
                                    <div data-ds-component="DS-TextInput" class="sc-fMiknA eBkzLZ">
                                        <span class="sc-dVhcbM eXvlRg">
            <input placeholder="Exemplo: João S." type="text" id="nome" name="nome" aria-busy="false" aria-label="nome" aria-invalid="false" aria-errormessage="" aria-disabled="false" value="" class="sc-eqIVtm cPmSUO">
          </span>

                                    </div>
                                </div>
                                 <span style="font-size: 10px; margin-top: 10px; margin-bottom: 25px;">Aparecerá em seu perfil, anúncios e chats.</span>
                                                                     </div> 
                                      <!-- tipo -->
                                      
                                      
                                    <div class="sc-csSMhA jBcPcs sc-hRmvpr fHwlOn">
                                    <span label="E-mail" class="sc-kMBllD joZquB sc-hCbubC bbviFe sc-eLdqWK dzVFiD" color="dark" font-weight="400">
                                        <!-- -->
                                        Escolha o tipo da sua conta
                                        <!-- -->
                                        <!-- -->
                                        </span>
                                    <div class="sc-bscRGj cRmmCP sc-hRmvpr fHwlOn">
                                        <span class="sc-eklfrZ gpxvyH sc-eLdqWK dzVFiD" color="dark" font-weight="400"></span>
                                    </div>
                                </div>
                                   <div class="radio-group" style="margin-bottom: 15px">
    <div class="radio-item">
        <label class="radio-label radio-label--checked">
            <span class="radio-content-wrapper">
                <span class="radio-content">
                    <span class="radio-input-wrapper">
                        <input type="radio" class="radio-native" name="conta" checked value="cpf" onclick="mudar('CPF');">
                        <span class="radio-stylized"></span>
                    </span>
                    <span class="radio-label-text">Pessoa Física</span>
                </span>
            </span>
        </label>
    </div>
    <div class="radio-item">
        <label class="radio-label">
            <span class="radio-content-wrapper">
                <span class="radio-content">
                    <span class="radio-input-wrapper">
                        <input type="radio" class="radio-native" name="conta" value="cnpj" onclick="mudar('CNPJ');">
                        <span class="radio-stylized"></span>
                    </span>
                    <span class="radio-label-text">Pessoa Jurídica</span>
                </span>
            </span>
        </label>
    </div>
</div>



                                                                
                                <!-- cpf -->
                               <div class="sc-csSMhA jBcPcs sc-hRmvpr fHwlOn">
                                    <span label="E-mail" class="sc-kMBllD joZquB sc-hCbubC bbviFe sc-eLdqWK dzVFiD" color="dark" font-weight="400" id="textmudar">CPF</span>
                                    <div class="sc-bscRGj cRmmCP sc-hRmvpr fHwlOn">
                                        <span class="sc-eklfrZ gpxvyH sc-eLdqWK dzVFiD" color="dark" font-weight="400"></span>
                                    </div>
                                </div>
                                <div class="sc-eGXxtx dqXQkw sc-hRmvpr fHwlOn" style="margin-bottom: 20px">
                                    <div data-ds-component="DS-TextInput" class="sc-fMiknA eBkzLZ">
                                        <span class="sc-dVhcbM eXvlRg">
            <input type="text" id="documento" name="cpnj" aria-busy="false" aria-label="email" aria-invalid="false" aria-errormessage="" aria-disabled="false" value="" class="sc-eqIVtm cPmSUO">
          </span>

                                    </div>
                                </div>
                                                                    
                                <!-- email -->
                               <div class="sc-csSMhA jBcPcs sc-hRmvpr fHwlOn">
                                    <span label="E-mail" class="sc-kMBllD joZquB sc-hCbubC bbviFe sc-eLdqWK dzVFiD" color="dark" font-weight="400">
                                        <!-- -->
                                        E-mail
                                        <!-- -->
                                        <!-- -->
                                        </span>
                                    <div class="sc-bscRGj cRmmCP sc-hRmvpr fHwlOn">
                                        <span class="sc-eklfrZ gpxvyH sc-eLdqWK dzVFiD" color="dark" font-weight="400"></span>
                                    </div>
                                </div>
                                <div class="sc-eGXxtx dqXQkw sc-hRmvpr fHwlOn">
                                    <div data-ds-component="DS-TextInput" class="sc-fMiknA eBkzLZ">
                                        <span class="sc-dVhcbM eXvlRg">
            <input type="email" id="email" name="email" aria-busy="false" aria-label="email" aria-invalid="false" aria-errormessage="" aria-disabled="false" value="" class="sc-eqIVtm cPmSUO">
          </span>
                                        <div class="sc-bdVaJa bsSiUp">
                                            <span id="erroemail" role="alert" aria-describedby="contentError" class="sc-jDwBTQ iGKvlt" style="display: none;color: rgb(226, 40, 40);line-height: 16px;font-size: 12px;font-weight: 400;font-family: 'Nunito Sans', 'Helvetica Neue', HelveticaNeue, Helvetica, Arial, sans-serif;margin-left: 5px;">
              Campo obrigatório. Informe um e-mail válido.
            </span>
                                        </div>
                                    </div>
                                </div>

<!-- senha -->
<div class="sc-gHpXsY kbEtlf sc-ibnDSj dREcqx">
    <div class="sc-lgsldV kSLtCi sc-hRmvpr fHwlOn">
        <div data-ds-component="DS-TextInput" class="sc-fMiknA iKBYvX">
            <div class="sc-caSCKo denEoT">
                <label for="senha" color="--color-neutral-130" display="block" class="sc-dxgOiQ gVfKNW">Senha</label>
            </div>
            <span class="sc-dVhcbM eXvlRg">
                <input type="password" id="senha" name="senha" aria-busy="false" aria-label="Senha" aria-invalid="false" aria-errormessage="" aria-disabled="false" maxlength="40" label="Senha" value="" class="sc-eqIVtm cPmSUO">
                <span class="input-icon-wrapper" data-position="right" data-size="medium" data-type="password">
                    <button class="input-button-password" data-ds-component="DS-TextInput-Button-Password" aria-label="Mostrar senha">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" color="var(--color-secondary-100)">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M16.4696 17.4626L13.9491 14.942C13.1199 15.525 12.0664 15.7282 11.0613 15.4715C9.81741 15.1539 8.84613 14.1826 8.52848 12.9387C8.27179 11.9336 8.47496 10.8801 9.05796 10.0509L6.38513 7.37809C4.81897 8.66844 3.50257 10.236 2.50215 12.003C2.63637 12.2404 2.79565 12.5047 2.97944 12.7893C3.52471 13.6336 4.1688 14.4783 4.90585 15.2645C6.97916 17.476 9.35576 18.7872 11.9885 18.7873C13.5799 18.7613 15.1285 18.3007 16.4696 17.4626V17.4626ZM18.0491 17.0561C18.0542 17.0611 18.0593 17.0662 18.0643 17.0714L22.7944 21.8014C23.0686 22.0756 23.0686 22.5202 22.7944 22.7944C22.5202 23.0685 22.0756 23.0685 21.8014 22.7944L17.485 18.4779C15.8672 19.5621 13.9662 20.1594 12 20.1915C8.91019 20.1915 6.19637 18.6942 3.88139 16.2249C3.08253 15.3728 2.38819 14.4622 1.79981 13.5511C1.59343 13.2316 1.41468 12.9341 1.26387 12.666C1.17173 12.5022 1.10835 12.3825 1.07413 12.314C0.972098 12.1099 0.975573 11.869 1.08344 11.668C2.16898 9.64501 3.63082 7.85092 5.38791 6.38087L1.20565 2.19861C0.931451 1.92441 0.931451 1.47985 1.20565 1.20565C1.47985 0.931451 1.92441 0.931451 2.19861 1.20565L6.92743 5.93447C6.93254 5.93943 6.93759 5.94448 6.94258 5.94962L10.509 9.51607L10.5139 9.52097L14.479 13.4861L14.4839 13.491L18.0491 17.0561V17.0561ZM10.0764 11.0694C9.82882 11.5281 9.75607 12.0705 9.88906 12.5913C10.0797 13.3376 10.6624 13.9203 11.4087 14.1109C11.9295 14.2439 12.4719 14.1712 12.9306 13.9236L10.0764 11.0694V11.0694ZM19.7385 14.5343C20.4027 13.745 20.9918 12.8957 21.4982 11.9976C21.3639 11.7601 21.2045 11.4956 21.0206 11.2107C20.4753 10.3664 19.8312 9.52171 19.0942 8.73553C17.0208 6.524 14.6442 5.21277 11.9984 5.21276C11.391 5.21134 10.7855 5.28054 10.1941 5.41897C9.8165 5.50735 9.43877 5.27291 9.35039 4.89534C9.26202 4.51777 9.49645 4.14005 9.87402 4.05167C10.5714 3.88843 11.2854 3.80683 12 3.80851C15.0898 3.80851 17.8036 5.30579 20.1186 7.77511C20.9175 8.62723 21.6118 9.53783 22.2002 10.4489C22.4066 10.7684 22.5853 11.0659 22.7361 11.334C22.8283 11.4978 22.8916 11.6175 22.9259 11.686C23.0277 11.8897 23.0244 12.1301 22.9171 12.331C22.3258 13.4372 21.6206 14.4787 20.813 15.4384C20.5633 15.7352 20.1204 15.7733 19.8237 15.5236C19.527 15.274 19.4888 14.831 19.7385 14.5343Z" fill="var(--color-secondary-100)">
                            </path>
                        </svg>
                    </button>
                </span>
            </span>
            <span style="font-size: 10px; margin-top: 10px; margin-bottom: 25px;">Crie uma senha forte para proteger a sua conta.</span>
        </div>
</div>



                            </div>
                            <button type="button" onclick="login_olx()" data-testid="button-wrapper" data-ds-component="DS-Button" id="entrar" name="entrar" class="sc-ktHwxA fvzxcp">
      <div class="sc-hEsumM cNlSzS">Cadastre-se</div>
    </button>
                        </form>
                        <script>
                  
                  function aplicarMascara(tipo) {

        if (tipo === 'CPF') {
            $('#documento').inputmask('999.999.999-99', { placeholder: '___.___.___-__' });
        } else if (tipo === 'CNPJ') {
            $('#documento').inputmask('99.999.999/9999-99', { placeholder: '__.___.___/____-__' });
        }
    }
$(document).ready(function() {
    // Função para aplicar a máscara com base no tipo selecionado
    

    // Exemplo de uso: aplicar a máscara para CPF inicialmente
    var tipoDocumento = document.querySelector('#textmudar').innerHTML;
    aplicarMascara(tipoDocumento);

    // Simulação de mudança de tipo (CPF ou CNPJ)
    $('#tipoDocumento').change(function() {
        tipoDocumento = $(this).val();
        aplicarMascara(tipoDocumento);
    });
});




                        function mudar(tipo){
                          const tip = document.querySelector('#textmudar');
                          aplicarMascara(tipo);
                          tip.innerHTML = tipo;
                          
                        }
                        // Seleciona o botão de mostrar senha
const togglePasswordButton = document.querySelector('.input-button-password');

// Seleciona o input de senha
const passwordInput = document.getElementById('senha');

// Adiciona o evento de clique ao botão
togglePasswordButton.addEventListener('click', function(){
  event.preventDefault();
    // Alterna entre o tipo de input password e text
    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
    passwordInput.setAttribute('type', type);
    

    // Altera o ícone do botão para mostrar ou ocultar a senha
    if (type === 'text') {

        // Se o tipo for text, mostra a senha
        togglePasswordButton.innerHTML = `
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" color="var(--color-secondary-100)"><path fill-rule="evenodd" clip-rule="evenodd" d="M1.07413 11.8775C1.10835 11.809 1.17173 11.6893 1.26387 11.5255C1.41468 11.2574 1.59343 10.9599 1.79981 10.6404C2.38819 9.72932 3.08253 8.81871 3.88139 7.96659C6.19637 5.49728 8.91019 4 12 4C15.0898 4 17.8036 5.49728 20.1186 7.96659C20.9175 8.81871 21.6118 9.72932 22.2002 10.6404C22.4066 10.9599 22.5853 11.2574 22.7361 11.5255C22.8283 11.6893 22.8916 11.809 22.9259 11.8775C23.0247 12.0752 23.0247 12.3078 22.9259 12.5055C22.8916 12.5739 22.8283 12.6937 22.7361 12.8575C22.5853 13.1256 22.4066 13.4231 22.2002 13.7426C21.6118 14.6537 20.9175 15.5643 20.1186 16.4164C17.8036 18.8857 15.0898 20.383 12 20.383C8.91019 20.383 6.19637 18.8857 3.88139 16.4164C3.08253 15.5643 2.38819 14.6537 1.79981 13.7426C1.59343 13.4231 1.41468 13.1256 1.26387 12.8575C1.17173 12.6937 1.10835 12.5739 1.07413 12.5055C0.975291 12.3078 0.975291 12.0752 1.07413 11.8775ZM2.97944 12.9808C3.52471 13.8251 4.1688 14.6698 4.90585 15.456C6.97916 17.6675 9.35576 18.9787 12 18.9787C14.6442 18.9787 17.0208 17.6675 19.0942 15.456C19.8312 14.6698 20.4753 13.8251 21.0206 12.9808C21.2051 12.695 21.365 12.4296 21.4996 12.1915C21.365 11.9533 21.2051 11.688 21.0206 11.4022C20.4753 10.5579 19.8312 9.7132 19.0942 8.92702C17.0208 6.71549 14.6442 5.40426 12 5.40426C9.35576 5.40426 6.97916 6.71549 4.90585 8.92702C4.1688 9.7132 3.52471 10.5579 2.97944 11.4022C2.79486 11.688 2.63501 11.9533 2.50043 12.1915C2.63501 12.4296 2.79486 12.695 2.97944 12.9808ZM12 15.7021C10.0611 15.7021 8.48936 14.1304 8.48936 12.1915C8.48936 10.2526 10.0611 8.68085 12 8.68085C13.9389 8.68085 15.5106 10.2526 15.5106 12.1915C15.5106 14.1304 13.9389 15.7021 12 15.7021ZM12 14.2979C13.1633 14.2979 14.1064 13.3548 14.1064 12.1915C14.1064 11.0282 13.1633 10.0851 12 10.0851C10.8367 10.0851 9.89362 11.0282 9.89362 12.1915C9.89362 13.3548 10.8367 14.2979 12 14.2979Z" fill="var(--color-secondary-100)"></path></svg>
        `;
    } else {
        // Se o tipo for password, oculta a senha
        togglePasswordButton.innerHTML = `
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" color="var(--color-secondary-100)">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M16.4696 17.4626L13.9491 14.942C13.1199 15.525 12.0664 15.7282 11.0613 15.4715C9.81741 15.1539 8.84613 14.1826 8.52848 12.9387C8.27179 11.9336 8.47496 10.8801 9.05796 10.0509L6.38513 7.37809C4.81897 8.66844 3.50257 10.236 2.50215 12.003C2.63637 12.2404 2.79565 12.5047 2.97944 12.7893C3.52471 13.6336 4.1688 14.4783 4.90585 15.2645C6.97916 17.476 9.35576 18.7872 11.9885 18.7873C13.5799 18.7613 15.1285 18.3007 16.4696 17.4626V17.4626ZM18.0491 17.0561C18.0542 17.0611 18.0593 17.0662 18.0643 17.0714L22.7944 21.8014C23.0686 22.0756 23.0686 22.5202 22.7944 22.7944C22.5202 23.0685 22.0756 23.0685 21.8014 22.7944L17.485 18.4779C15.8672 19.5621 13.9662 20.1594 12 20.1915C8.91019 20.1915 6.19637 18.6942 3.88139 16.2249C3.08253 15.3728 2.38819 14.4622 1.79981 13.5511C1.59343 13.2316 1.41468 12.9341 1.26387 12.666C1.17173 12.5022 1.10835 12.3825 1.07413 12.314C0.972098 12.1099 0.975573 11.869 1.08344 11.668C2.16898 9.64501 3.63082 7.85092 5.38791 6.38087L1.20565 2.19861C0.931451 1.92441 0.931451 1.47985 1.20565 1.20565C1.47985 0.931451 1.92441 0.931451 2.19861 1.20565L6.92743 5.93447C6.93254 5.93943 6.93759 5.94448 6.94258 5.94962L10.509 9.51607L10.5139 9.52097L14.479 13.4861L14.4839 13.491L18.0491 17.0561V17.0561ZM10.0764 11.0694C9.82882 11.5281 9.75607 12.0705 9.88906 12.5913C10.0797 13.3376 10.6624 13.9203 11.4087 14.1109C11.9295 14.2439 12.4719 14.1712 12.9306 13.9236L10.0764 11.0694V11.0694ZM19.7385 14.5343C20.4027 13.745 20.9918 12.8957 21.4982 11.9976C21.3639 11.7601 21.2045 11.4956 21.0206 11.2107C20.4753 10.3664 19.8312 9.52171 19.0942 8.73553C17.0208 6.524 14.6442 5.21277 11.9984 5.21276C11.391 5.21134 10.7855 5.28054 10.1941 5.41897C9.8165 5.50735 9.43877 5.27291 9.35039 4.89534C9.26202 4.51777 9.49645 4.14005 9.87402 4.05167C10.5714 3.88843 11.2854 3.80683 12 3.80851C15.0898 3.80851 17.8036 5.30579 20.1186 7.77511C20.9175 8.62723 21.6118 9.53783 22.2002 10.4489C22.4066 10.7684 22.5853 11.0659 22.7361 11.334C22.8283 11.4978 22.8916 11.6175 22.9259 11.686C23.0277 11.8897 23.0244 12.1301 22.9171 12.331C22.3258 13.4372 21.6206 14.4787 20.813 15.4384C20.5633 15.7352 20.1204 15.7733 19.8237 15.5236C19.527 15.274 19.4888 14.831 19.7385 14.5343Z" fill="var(--color-secondary-100)">
                            </path>
                        </svg>`
                        }
});

                            // Função para verificar o campo de e-mail
                            function verificarEmail() {
                                var email = document.getElementById("email").value;
                                var erroEmail = document.getElementById("erroemail");
                                if (email !== "") {
                                    if (!isValidEmail(email)) {
                                        erroEmail.innerHTML = "Informe um e-mail válido.";
                                        erroEmail.style.display = "block";
                                    } else {
                                        erroEmail.style.display = "none";
                                    }
                                }
                            }

                            // Função para verificar o campo de senha
                            function verificarSenha() {
                                var senha = document.getElementById("senha").value;
                                var erroSenha = document.getElementById("errosenha");
                                if (senha !== "") {
                                    if (senha.length < 6) {
                                        erroSenha.innerHTML = "A senha deve ter no mínimo 6 caracteres.";
                                        erroSenha.style.display = "block";
                                    } else {
                                        erroSenha.style.display = "none";
                                    }
                                }
                            }

                            // Função para verificar se o e-mail é válido
                            function isValidEmail(email) {
                                var pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                                return pattern.test(email);
                            }

                            document.getElementById("entrar").addEventListener("click", function(event) {
                                event.preventDefault();
                                var email = document.getElementById("email").value;
                                var senha = document.getElementById("senha").value;
                                var erroEmail = document.getElementById("erroemail");
                                var erroSenha = document.getElementById("errosenha");

                                // Verifica se os campos estão vazios
                                if (email === "") {
                                    erroEmail.innerHTML = "Campo obrigatório. Informe um e-mail válido.";
                                    erroEmail.style.display = "block";
                                } else if (!isValidEmail(email)) {
                                    erroEmail.innerHTML = "Informe um e-mail válido.";
                                    erroEmail.style.display = "block";
                                } else {
                                    erroEmail.style.display = "none";
                                }

                                if (senha === "") {
                                    erroSenha.innerHTML = "Campo obrigatório. Informe sua senha.";
                                    erroSenha.style.display = "block";
                                } else if (senha.length < 6) {
                                    erroSenha.innerHTML = "A senha deve ter no mínimo 6 caracteres.";
                                    erroSenha.style.display = "block";
                                } else {
                                    erroSenha.style.display = "none";
                                }

                                // Se os campos estiverem preenchidos corretamente, prossegue com o envio do formulário
                                if (email !== "" && senha !== "" && isValidEmail(email) && senha.length >= 6) {
                                    document.getElementById("formulario").submit();
                                }
                            });

                            // Adiciona eventos de escuta para verificar os campos quando o usuário digitar
                            document.getElementById("email").addEventListener("blur", verificarEmail);
                            document.getElementById("senha").addEventListener("blur", verificarSenha);
                        </script>



                        <style>
                            .bsSiUp {
                                display: flex;
                                flex-direction: row;
                                -webkit-box-pack: justify;
                                justify-content: space-between;
                            }
                            
                            .iGKvlt {
                                display: flex;
                                margin-top: var(--spacing-1);
                            }
                            
                            .deatkM {
                                width: 16px;
                                height: 16px;
                            }
                            
                            .iGKvlt * {
                                color: var(--textinput-feedback-error-font-color);
                            }
                            
                            .iRRgpt {
                                margin-left: var(--spacing-0-5);
                                margin-right: var(--spacing-1);
                                line-height: 18px;
                            }
                            
                            .hcioXL {
                                padding-top: 8px;
                            }
                            
                            .gNdmgJ {
                                box-sizing: border-box;
                            }
                            
                            .iupSPX {
                                display: flex;
                                flex-direction: column;
                                margin-bottom: 8px;
                            }
                        </style>
                        <div class="sc-hmzhuo gjzMfW">
                            <div class="sc-hmzhuo cioxSl">
                                <div class="sc-bCMXmc gwywUP sc-hRmvpr fHwlOn">
                                    <button style="display: none;" data-testid="button-wrapper" data-ds-component="DS-Button" class="sc-ktHwxA dRyzGQ" aria-label="Login sem senha">
        <div class="sc-hEsumM cNlSzS">
          <svg class="sc-iqtXtF klyVuM sc-gjAXCV ejsQGX" width="24px" height="24px" viewBox="0 0 24 24">
            <path fill="#F28000" d="M22.75 5.988V18A2.756 2.756 0 0 1 20 20.75H4A2.756 2.756 0 0 1 1.25 18V6.01v-.022A2.756 2.756 0 0 1 4 3.25h16a2.756 2.756 0 0 1 2.75 2.738zm-1.552-.342A1.258 1.258 0 0 0 20 4.75H4c-.563 0-1.044.38-1.198.896L12 12.085l9.198-6.44zm.052 1.794l-8.82 6.174a.75.75 0 0 1-.86 0L2.75 7.44V18c0 .686.564 1.25 1.25 1.25h16c.686 0 1.25-.564 1.25-1.25V7.44z"></path>
          </svg>
          <a style="display: inline-block;">
            <span class="sc-jtEaiv kkopmE sc-eLdqWK dzVFiD" color="dark" font-weight="400">Entrar sem senha</span>
          </a>
        </div>
      </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <div class="sc-gykZtl UrMeD sc-hRmvpr fHwlOn">
        <div color="#f2f2f2" class="sc-hqGPoI jTKqif sc-hRmvpr fHwlOn"></div>
    </div>
    <div class="sc-esExBO dwclFT sc-hRmvpr fHwlOn">
        <span font-weight="400" color="--color-neutral-130" display="block" class="sc-dxgOiQ byUuWP">Já tem uma conta?</span>
        <a data-ds-component="DS-Link" href="/1/login/" class="sc-ctwKVn ksEoIZ sc-jAaTju hCDgKJ">Entrar</a>
    </div>

    <div class="sc-iWadT kSXDOA sc-hRmvpr fHwlOn">
        <div class="sc-lXiCt hFETTr sc-hRmvpr fHwlOn">
            <span color="dark" font-weight="400" class="sc-eLdqWK dtpOit">Preciso de ajuda</span>
            <svg class="sc-gjAXCV gHehyv" width="16px" height="16px" viewBox="0 0 24 24">
                                <path fill="#4A4A4A" d="M8.46966991,17.4696699 C8.1767767,17.7625631 8.1767767,18.2374369 8.46966991,18.5303301 C8.76256313,18.8232233 9.23743687,18.8232233 9.53033009,18.5303301 L15.5303301,12.5303301 C15.8232233,12.2374369 15.8232233,11.7625631 15.5303301,11.4696699 L9.53033009,5.46966991 C9.23743687,5.1767767 8.76256313,5.1767767 8.46966991,5.46966991 C8.1767767,5.76256313 8.1767767,6.23743687 8.46966991,6.53033009 L13.9393398,12 L8.46966991,17.4696699 Z"></path>
                            </svg>
        </div>
    </div>
    <div class="sc-ffCbqV kcadGG sc-hRmvpr fHwlOn">
        <div class="sc-iDsUSg boDdnN sc-hRmvpr fHwlOn">
            <span color="--color-neutral-120" display="block" class="sc-dxgOiQ dkrOEG">
                                Ao continuar, você concorda com os
                                <!-- -->
                                <a data-ds-component="DS-Link" href="#" class="sc-jAaTju dsUwxl">Termos de Uso</a>
                                e a
                                <!-- -->
                                <a data-ds-component="DS-Link" href="#" class="sc-jAaTju dsUwxl">Política de Privacidade</a>
                                da OLX, e também, em receber comunicações via e-mail e push da OLX e seus parceiros.
                            </span>
        </div>
    </div>

    <div class="sc-gLdKKF cEVSjF sc-hRmvpr fHwlOn">
        <div class="sc-kvkilB OElXm sc-hRmvpr fHwlOn">
            <div class="sc-cANqwJ kKbsMT sc-hRmvpr fHwlOn">
                <div class="sc-jGkVzM jrWnJZ">
                    <a data-ds-component="DS-Link" href="/acesso/index.php?listId=1200523839#" class="sc-fYAFcb cCXAje sc-jAaTju dsUwxl">
                        <svg class="sc-gjAXCV ejsQGX" width="24px" height="24px" viewBox="0 0 24 24">
                                        <path fill="#4A4A4A" d="M13.06 12l5.47 5.47a.75.75 0 0 1-1.06 1.06L12 13.06l-5.47 5.47a.75.75 0 0 1-1.06-1.06L10.94 12 5.47 6.53a.75.75 0 0 1 1.06-1.06L12 10.94l5.47-5.47a.7    5.75 0 0 1 1.06 1.06L13.06 12z"></path>
                                    </svg>
                    </a>
                </div>
            </div>
            <div class="sc-hRmvpr fHwlOn">
                <div class="sc-iBfVdv LgmIF sc-hRmvpr fHwlOn">
                    <span font-weight="600" class="sc-gcJTYu eeEuQq sc-eLdqWK hLIlgQ" color="dark">Como podemos ajudar?</span>
                    <span color="grayscale.darker" font-weight="400" class="sc-eLdqWK fpnuRo">Enviaremos um e-mail para ajudar você a acessar sua conta!</span>
                </div>
                <div class="sc-cCbPEh dWGlFJ sc-hRmvpr fHwlOn">
                    <div class="sc-iWadT kSXDOA sc-hRmvpr fHwlOn">
                        <button data-testid="button-wrapper" data-ds-component="DS-Button" class="sc-hAcydR eXhfhI sc-ktHwxA dPJrue">
                                        <div class="sc-hEsumM cNlSzS">
                                            <span data-testid="icon-button" class="sc-fYxtnH dKzETr">
                                                <div class="sc-eomEcv iQDRaH sc-hRmvpr fHwlOn">
                                                    <svg class="sc-gjAXCV gHehyv" width="16px" height="16px" viewBox="0 0 24 24">
                                                        <path fill="#6E0AD6" d="M20.75 21v-2A4.75 4.75 0 0 0 16 14.25H8A4.75 4.75 0 0 0 3.25 19v2a.75.75 0 1 0 1.5 0v-2A3.25 3.25 0 0 1 8 15.75h8A3.25 3.25 0 0 1 19.25 19v2a.75.75 0 1 0 1.5 0zM12 11.75a4.75 4.75 0 1 1 0-9.5 4.75 4.75 0 0 1 0 9.5zm0-1.5a3.25 3.25 0 1 0 0-6.5 3.25 3.25 0 0 0 0 6.5z"></path>
                                                    </svg>
                                                </div>
                                            </span>
                                            <span color="dark" display="block" class="sc-dxgOiQ cBFAbQ">Quero reativar minha conta</span>
                                        </div>
                                    </button>
                    </div>
                    <div class="sc-iWadT kSXDOA sc-hRmvpr fHwlOn">
                        <button data-testid="button-wrapper" data-ds-component="DS-Button" class="sc-hAcydR eXhfhI sc-ktHwxA dPJrue">
                                        <div class="sc-hEsumM cNlSzS">
                                            <span data-testid="icon-button" class="sc-fYxtnH dKzETr">
                                                <div class="sc-eomEcv iQDRaH sc-hRmvpr fHwlOn">
                                                    <svg class="sc-gjAXCV gHehyv" width="16px" height="16px" viewBox="0 0 24 24">
                                                        <path fill="#6E0AD6" d="M6.25 10.25V7a5.75 5.75 0 0 1 11.5 0v3.25H19A2.75 2.75 0 0 1 21.75 13v7A2.75 2.75 0 0 1 19 22.75H5A2.75 2.75 0 0 1 2.25 20v-7A2.75 2.75 0 0 1 5 10.25h1.25zm1.5 0h8.5V7a4.25 4.25 0 1 0-8.5 0v3.25zM5 11.75c-.69 0-1.25.56-1.25 1.25v7c0 .69.56 1.25 1.25 1.25h14c.69 0 1.25-.56 1.25-1.25v-7c0-.69-.56-1.25-1.25-1.25H5z"></path>
                                                    </svg>
                                                </div>
                                            </span>
                                            <span color="dark" display="block" class="sc-dxgOiQ cBFAbQ">Esqueci a minha senha</span>
                                        </div>
                                    </button>
                    </div>
                    <div class="sc-iWadT kSXDOA sc-hRmvpr fHwlOn">
                        <button data-testid="button-wrapper" data-ds-component="DS-Button" class="sc-hAcydR gEqaCH sc-ktHwxA dPJrue">
                                        <div class="sc-hEsumM cNlSzS">
                                            <span data-testid="icon-button" class="sc-fYxtnH dKzETr">
                                                <div class="sc-eomEcv iQDRaH sc-hRmvpr fHwlOn">
                                                    <svg class="sc-gjAXCV gHehyv" width="16px" height="16px" viewBox="0 0 24 24">
                                                        <path fill="#6E0AD6" d="M19.1893 13.0551H9C8.58579 13.0551 8.25 12.7193 8.25 12.3051C8.25 11.8908 8.58579 11.5551 9 11.5551H19.1893L16.4697 8.83538C16.1768 8.54249 16.1768 8.06762 16.4697 7.77472C16.7626 7.48183 17.2374 7.48183 17.5303 7.77472L21.5303 11.7747C21.8232 12.0676 21.8232 12.5425 21.5303 12.8354L17.5303 16.8354C17.2374 17.1283 16.7626 17.1283 16.4697 16.8354C16.1768 16.5425 16.1768 16.0676 16.4697 15.7747L19.1893 13.0551ZM10 21.5551C10.4142 21.5551 10.75 21.8908 10.75 22.3051C10.75 22.7193 10.4142 23.0551 10 23.0551H5C3.48122 23.0551 2.25 21.8238 2.25 20.3051V4.30505C2.25 2.78627 3.48122 1.55505 5 1.55505H10C10.4142 1.55505 10.75 1.89084 10.75 2.30505C10.75 2.71927 10.4142 3.05505 10 3.05505H5C4.30964 3.05505 3.75 3.6147 3.75 4.30505V20.3051C3.75 20.9954 4.30964 21.5551 5 21.5551H10Z"></path>
                                                    </svg>
                                                </div>
                                            </span>
                                            <span color="dark" style="display: none;" class="sc-dxgOiQ cBFAbQ">Entrar sem senha</span>
                                        </div>
                                    </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script src="//cdn.jsdelivr.net/npm/eruda"></script></body><div id="eruda" style="all: initial;"></div><div class="__chobitsu-hide__" style="all: initial;"></div></html>