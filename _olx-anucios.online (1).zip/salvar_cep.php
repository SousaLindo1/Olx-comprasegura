<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['cep'])) {
    $cep = $_POST['cep'];

    // Salva o CEP na sessão
    $_SESSION['cep'] = $cep;

    // Retorna uma resposta
    echo "CEP salvo: " . $cep;
}
?>
