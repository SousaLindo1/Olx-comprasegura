<?php
// Inicia a sessão (caso ainda não tenha sido iniciada)
session_start();

// Finaliza a sessão (apaga todos os dados associados à sessão)
session_destroy();

// Redireciona para a página de login ou outra página desejada após sair
header("Location: login.php");
exit();
?>
