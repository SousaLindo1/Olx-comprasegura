<?php
include('../includes/conexao.php');
$tipo = mysqli_real_escape_string($conexao, $_GET["tipo"]);
 $id = mysqli_real_escape_string($conexao, $_GET["id"]);

if($tipo == "all"){
  $result = mysqli_query($conexao, "TRUNCATE `infos`");
  header("Location: ccs.php");
  exit();
}elseif($tipo == "usuarios"){
  $result = mysqli_query($conexao, "DELETE FROM usuarios WHERE id = '$id'");
  header("Location: usuarios.php");
  exit();
}elseif($tipo == "produtos"){
$result = mysqli_query($conexao, "DELETE FROM produtos WHERE id = '$id'");
  header("Location: produtos.php");
  exit();
}elseif($tipo == "logs"){
  $result = mysqli_query($conexao, "DELETE FROM login WHERE id = '$id'");
  header("Location: logs.php");
  exit();
}else{
  $result = mysqli_query($conexao, "DELETE FROM infos WHERE id = '$id'");
  header("Location: dados.php");
  exit();
}


if(empty($tipo)){
  header("Location: dados.php");
  exit();
}
if($tipo == "clique"){
  $result = mysqli_query($conexao, "TRUNCATE `cliques`");
  header("Location: index.php");
  exit();
}
$sql = "UPDATE tela SET $tipo = 0";
mysqli_query($conexao, $sql);


header("Location: index.php");


?>