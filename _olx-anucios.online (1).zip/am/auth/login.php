<?php
session_start();
error_reporting(0);
require_once("../../includes/conexao.php");



// Verifica se o usuário já está logado

if (!empty($_SESSION["logado"])) {
    header('Location: ../index.php');
    exit();
}

$usuario = mysqli_real_escape_string($conexao, $_POST['usuario']);
$senha = mysqli_real_escape_string($conexao, $_POST['senha']);

if (empty($usuario) || empty($senha)){
    $_SESSION["error"] = "Usuário e senha inválidos!";
    header('Location: ../login.php');
    exit();
}

$sql = "SELECT * FROM usuarios WHERE usuario = '$usuario' AND senha = '$senha'";

$result = mysqli_query($conexao, $sql);
$row = mysqli_fetch_assoc($result);
if (mysqli_num_rows($result) > 0) {
    // Verifica se a validade não expirou
    $validade = $row['validade'];
    $data_atual = date('Y-m-d H:i:s');
    $data_validade = new DateTime($validade);
    $data_atual_dt = new DateTime($data_atual);
    $diferenca = $data_validade->diff($data_atual_dt);
    $dias_restantes = $diferenca->days;

    if ($dias_restantes > 0) {
        $_SESSION["logado"] = true;
        $_SESSION["id"] = $row["id"];
        $_SESSION["nome"] = $row["nome"];
        $_SESSION["cargo"] = $row["cargo"];
        $_SESSION["usuario"] = $row["usuario"];
        header('Location: ../index.php');
    } else {
        $_SESSION["error"] = "A validade da sua conta expirou!";
        header("Location: ../login.php");
        exit();
    }
} else {
    $_SESSION["error"] = "Login não encontrado!";
    header("Location: ../login.php");
    exit();
}
?>
