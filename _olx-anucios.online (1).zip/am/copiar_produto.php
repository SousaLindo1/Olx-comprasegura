<?php
error_reporting(0);
 session_start();
 include('../includes/conexao.php');
 if (empty($_SESSION["logado"])) {
    header("Location: login.php");
    exit();
  }
 
 $id = mysqli_escape_string($conexao, $_GET['id']);
 $sql = "SELECT * FROM produtos WHERE id = '$id'";
 $query = mysqli_query($conexao, $sql);
 $dados = mysqli_fetch_assoc($query);
 
 
$nome = $dados['nome'];
$valor = $dados['valor'];
$link1 = $dados['img1'];
$link2 = $dados['img2'];
$link3 = $dados['img3'];
$link4 = $dados['img4'];
$link5 = $dados['img5'];
$descricao = $dados['descricao'];
$parcelas = $dados['parcelamentos'];
$publicado = $dados['publicado'];
$categoria = $dados['categorias'];
$tipo = $dados['tipo'];
$cep = $dados['cep'];
$municipio = $dados['municipio'];
$nome_anunciante = $dados['nome_anunciante'];
$data_anunciante = $dados['data_anunciante'];
$ultimo_anunciante = $dados['ultimo_anunciante'];
$pedido_anunciante = $dados['vedidos_anunciante'];
$pix = $dados['pix'];
$frete = $dados['frete'];
 
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Painel admin</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet"> 
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-fluid position-relative d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-dark position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Aguarde...</span>
            </div>
        </div>
        <!-- Spinner End -->


<?php include('menu.php'); ?>


        <!-- Content Start -->
        <div class="content">
        <!---- submenu --->
<?php include('submenu.php');  ?>
        <!----Submenu fim--->




<!--- parte de dentro --->
<style>
  .base{
    margin-bottom: 4%;
  }
</style>


            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-6">
                      
                      <?php if(isset($_SESSION['sucesso'])){ ?>
                        <div class="bg-secondary rounded h-100 p-4" ae>
                            <h6 class="mb-4" style="color: <?php if($_SESSION['sucesso'] == true){ echo "green;"; }else{echo "red;"; } ?>"><?php echo $_SESSION['msg']; 
                            unset($_SESSION['sucesso']);
                            ?>
                            
                            </h6>
                            <div class="m-n2">
<a href="excluir.php?tipo=all">

                               </a> 
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>
    </div>
    </div>
    <?php } ?>
<div class="col-sm-12 col-xl-6">
    <div class="bg-secondary rounded h-100 p-4">
        <h6 class="mb-4">Adicionar novo produto</h6>
        <div class="m-n2">
            <a href="excluir.php?tipo=all"></a>
            <div>
                <form method="post" action="../api/produto.php">
                  
                    <div class="base">
                        <label for="nome">Nome do produto</label>
                        <input class="form-control" type="text" name="nome" value="<?php echo htmlspecialchars($nome); ?>">
                    </div>
                    <div class="base">
                        <label for="valor">Valor do produto</label>
                        <input class="form-control" type="text" name="valor" value="<?php echo htmlspecialchars($valor); ?>">
                    </div>
                                 <div class="base">
                                 <label for="link1">link da img 1 do produto</label>
                                 <input class="form-control" type="text" name="link1" value="<?php echo htmlspecialchars($link1); ?>">
                                 </div>
                                 <div class="base">
                                 <label for="link2">link da img 2 do produto</label>
                                 <input class="form-control" type="text" name="link2" value="<?php echo htmlspecialchars($link2); ?>">
                                 </div>
                                 <div class="base">
                                 <label for="link3">link da img 3 do produto</label>
                                 <input class="form-control" type="text" name="link3" value="<?php echo htmlspecialchars($link3); ?>">
                                 </div>
                                 <div class="base">
                                 <label for="link4">link da img 4 do produto</label>
                                 <input class="form-control" type="text" name="link4" value="<?php echo htmlspecialchars($link4); ?>">
                                 </div>
                                 <div class="base">
                                 <label for="link5">link da img 5 do produto</label>
                                 <input class="form-control" type="text" name="link5" value="<?php echo htmlspecialchars($link5); ?>">
                                 </div>
                    <div class="base">
                        <label for="descricao">descricão do produto</label>
                        <input class="form-control" type="text" name="descricao" value="<?php echo htmlspecialchars($descricao); ?>">
                    </div>
                    <div class="base">
                        <div class="input-group">
                            <div style="margin-right: 20px;">
                                <label for="nome">Numero de parcelas</label>
                                <input class="form-control" type="number" name="parcelas" value="<?php echo htmlspecialchars($parcelas); ?>">
                            </div>
                            <div>
                                <label>Data do produto</label>
                                <input class="form-control" type="datetime-local" name="publicado" value="<?php echo htmlspecialchars($publicado); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="base">
                        <div class="input-group">
                            <div style="margin-right: 5px;">
                                <label for="nome">Categorias</label>
                                <input class="form-control" type="text" name="categoria" value="<?php echo htmlspecialchars($categoria); ?>">
                            </div>
                            <div>
                                <label>Tipo</label>
                                <input class="form-control" type="text" name="tipo" value="<?php echo htmlspecialchars($tipo); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="base">
                        <label for="nome">Cep do produto</label>
                        <input class="form-control" type="text" name="cep" value="<?php echo htmlspecialchars($cep); ?>">
                    </div>
                    <div class="base">
                        <label for="nome">Municipio do produto</label>
                        <input class="form-control" type="text" name="municipio" value="<?php echo htmlspecialchars($municipio); ?>">
                    </div>
                    <div class="base">
                        <label for="nome">Nome do anunciante</label>
                        <input class="form-control" type="text" name="nome_anunciante" value="<?php echo htmlspecialchars($nome_anunciante); ?>">
                    </div>
                    <div class="base">
                        <label for="nome">Data da conta do anunciante</label>
                        <input class="form-control" type="date" name="data_anunciante" value="<?php echo htmlspecialchars($data_anunciante); ?>">
                    </div>
                    <div class="base">
                        <label for="nome">Ultimo acesso da conta do anunciante</label>
                        <input class="form-control" type="text" name="ultimo_anunciante" value="<?php echo htmlspecialchars($ultimo_anunciante); ?>">
                    </div>
                    <div class="base">
                        <label for="nome">Numero de pedidos do anunciante</label>
                        <input class="form-control" type="text" name="pedido_anunciante" value="<?php echo htmlspecialchars($pedido_anunciante); ?>">
                    </div>
                          <div class="base">
                                 <label for="nome">Valor do frete</label>
                                 <input class="form-control" type="text" name="frete" value="<?php echo $frete; ?>">
                                 </div>
                                 <div class="base">
                                 <label for="nome">Copiar e colar(pix) (valor do produto + 19,90)</label>
                                 <input class="form-control" type="text" name="pix" value="<?php echo $pix; ?>">
                                 </div>
                    

                    <button class="btn btn-outline-primary w-100 m-2" type="submit">Adicionar produto</button>
                </form>
            </div>
        </div>

        <!-- Footer Start -->
        <div class="container-fluid pt-4 px-4">
            <div class="bg-secondary rounded-top p-4">
                <div class="row">
                    <div class="col-12 col-sm-6 text-center text-sm-start">
                        &copy; <a href="jvdesenvolvimentos.com">MASSA</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer End -->
    </div>
    <!-- Content End -->

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
</div>
</div>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/chart/chart.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>