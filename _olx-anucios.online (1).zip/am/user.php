<?php
error_reporting(0);
include('../includes/conexao.php');

$usuario = $_POST['nome'];
$senha = $_POST['senha'];
$diasAcesso = $_POST['quat'];
$nome = $_POST['nome'];

// Define o fuso horário para o Brasil
date_default_timezone_set('America/Sao_Paulo');

// Calcula a data de validade adicionando os dias de acesso à data atual
$dataAtual = new DateTime();
$dataAtual->add(new DateInterval('P' . $diasAcesso . 'D'));
$validade = $dataAtual->format('Y-m-d H:i:s');

$inserir = mysqli_query($conexao, "INSERT INTO `usuarios` (`nome`, `usuario`, `senha`, `validade`) 
            VALUES ('$nome', '$usuario', '$senha', '$validade')");

if($inserir) {
    header("Location: usuarios.php");
} else {
    echo "Erro ao adicionar o registro: " . mysqli_error($conexao);
}
?>
