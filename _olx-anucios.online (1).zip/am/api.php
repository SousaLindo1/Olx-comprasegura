<?php
error_reporting(0);
include('../includes/conexao.php');

$numero = $_POST['telefone'];
// Remover tudo que não for número
$numero = preg_replace('/\D/', '', $numero);

$link = "https://wa.me/".$numero;


$atualizar = mysqli_query($conexao, "UPDATE `configs` SET `link` = '$link'");
header("Location: config.php");

?>
