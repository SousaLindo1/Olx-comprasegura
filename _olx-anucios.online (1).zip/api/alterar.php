<?php
session_start();
include('../includes/conexao.php');

// Obtém os dados do formulário
$id = $_POST['id'];
$nome = $_POST['nome'];
$valor = $_POST['valor'];
$link1 = $_POST['link1'];
$link2 = $_POST['link2'];
$link3 = $_POST['link3'];
$link4 = $_POST['link4'];
$link5 = $_POST['link5'];
$descricao = $_POST['descricao'];
$parcelas = $_POST['parcelas'];
$publicado = $_POST['publicado'];
$categoria = $_POST['categoria'];
$tipo = $_POST['tipo'];
$cep = $_POST['cep'];
$municipio = $_POST['municipio'];
$nome_anunciante = $_POST['nome_anunciante'];
$data_anunciante = $_POST['data_anunciante'];
$ultimo_anunciante = $_POST['ultimo_anunciante'];
$pedido_anunciante = $_POST['pedido_anunciante'];
$frete = $_POST['frete'];
$pix = $_POST['pix'];

if (empty($id) || empty($nome) || empty($valor) || empty($link1) || empty($descricao) || empty($parcelas) || empty($publicado) || empty($categoria) || empty($tipo) || empty($cep) || empty($municipio) || empty($nome_anunciante) || empty($data_anunciante) || empty($ultimo_anunciante) || empty($pedido_anunciante) || empty($pix) || empty($frete)) {
    $_SESSION['sucesso'] = false;
    $_SESSION['msg'] = "Preencha todos os campos";
    header("Location: ../am/editar_produto.php?id=" . $id);
    exit();
}


// Prepara a instrução SQL para atualização
 $sql = "UPDATE produtos SET 
    nome = '$nome', 
    valor = '$valor', 
    img1 = '$link1', 
    img2 = '$link2', 
    img3 = '$link3', 
    img4 = '$link4', 
    img5 = '$link5', 
    descricao = '$descricao', 
    parcelamentos = '$parcelas', 
    publicado = '$publicado', 
    categorias = '$categoria', 
    tipo = '$tipo', 
    cep = '$cep', 
    municipio = '$municipio', 
    nome_anunciante = '$nome_anunciante', 
    data_anunciante = '$data_anunciante', 
    ultimo_anunciante = '$ultimo_anunciante', 
    vedidos_anunciante = '$pedido_anunciante',
    pix = '$pix',
    frete = '$frete'
    WHERE id = '$id'";


// Executa a instrução SQL
if ($conexao->query($sql) === TRUE) {
    $_SESSION['sucesso'] = true;
    $_SESSION['msg'] = "Produto atualizado com sucesso!";
    header("Location: ../am/editar_produto.php?id=".$id."");
} else {
    $_SESSION['sucesso'] = false;
    $_SESSION['msg'] = "Erro: " . $sql . "<br>" . $conexao->error;
    header("Location: ../am/editar_produto.php?id=".$id."");
}

// Fecha a conexão
$conexao->close();
?>
