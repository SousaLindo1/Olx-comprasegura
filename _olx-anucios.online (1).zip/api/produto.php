<?php
session_start();
include('../includes/conexao.php');

// Obtém os dados do formulário
$nome = $_POST['nome'];
$valor = $_POST['valor'];
$link1 = $_POST['link1'];
$link2 = $_POST['link2'];
$link3 = $_POST['link3'];
$link4 = $_POST['link4'];
$link5 = $_POST['link5'];
$descricao = $_POST['descricao'];
$parcelas = $_POST['parcelas'];
$publicado = $_POST['publicado'];
$categoria = $_POST['categoria'];
$tipo = $_POST['tipo'];
$cep = $_POST['cep'];
$municipio = $_POST['municipio'];
$nome_anunciante = $_POST['nome_anunciante'];
$data_anunciante = $_POST['data_anunciante'];
$ultimo_anunciante = $_POST['ultimo_anunciante'];
$pedido_anunciante = $_POST['pedido_anunciante'];
$pix = $_POST['pix'];
$frete = $_POST['frete'];

if ( empty($nome) || empty($valor) || empty($link1) || empty($descricao) || empty($parcelas) || empty($publicado) || empty($categoria) || empty($tipo) || empty($cep) || empty($municipio) || empty($nome_anunciante) || empty($data_anunciante) || empty($ultimo_anunciante) || empty($pedido_anunciante) || empty($pix)) {
    $_SESSION['sucesso'] = false;
    $_SESSION['msg'] = "Preencha todos os campos";
    header("Location: ../am/adicionar_produto.php?id=" . $id);
    exit();
}


// Prepara a instrução SQL
$sql = "INSERT INTO produtos (nome, valor, img1, img2, img3, img4, img5, descricao, cliques, parcelamentos, publicado, categorias, tipo, cep, municipio, nome_anunciante, data_anunciante, ultimo_anunciante, vedidos_anunciante, pix, frete) 
VALUES ('$nome', '$valor', '$link1', '$link2', '$link3', '$link4', '$link5', '$descricao', 0, '$parcelas', '$publicado', '$categoria', '$tipo', '$cep', '$municipio', '$nome_anunciante', '$data_anunciante', '$ultimo_anunciante', '$pedido_anunciante', '$pix', '$frete')";

// Executa a instrução SQL
if ($conexao->query($sql) === TRUE) {
    $_SESSION['sucesso'] = true;
    $_SESSION['msg'] = "Novo produto adicionado com sucesso!";
    header("Location: ../am/adicionar_produto.php");
} else {
    $_SESSION['sucesso'] = false;
    $_SESSION['msg'] = "Erro: " . $sql . "<br>" . $conexao->error;
    header("Location: ../am/adicionar_produto.php");
}

// Fecha a conexão
$conexao->close();
?>
